# Response for https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
          PT: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644 EN: https://www.ulusofona.pt/en/teachers/aleksandar-mikovic-1644
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
        fechar menu : https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/aleksandar-mikovic-1644
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Aleksandar Mikovic

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p1644
              ami***@ulusofona.pt
              7415-11D5-12E1: https://www.cienciavitae.pt/7415-11D5-12E1
              0000-0002-0009-1411: https://orcid.org/0000-0002-0009-1411
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/bf5d1984-0f0c-471a-892b-2d3b49429843
      : https://www.ulusofona.pt/

        Resume

        Licenciatura em Física em 1984 na Faculdade de Ciências Naturais e de Matemática, Universidade de Belgrado. Doutoramento em Física em 1990 na Universidade de Maryland, Estados Unidos. 1990 -1992 posdotouramento em teoria das cordas, Queen Mary College, Universidade de Londres. 1992-1994 posdoutoramento em gravitação quântica, Imperial College, Universidade de Londres. 1994-1999 investigador em física teorica das altas energias, Instituto de Física, Belgrado. 1999-2001 Bolsa de Cientista Convidado, Universidade do Algarve e Instituto Superior Técnico. Professor de matemática na Universidade Lusófona desde 2001. Membro do Grupo da Física Matemática da Universidae de Lisboa desde 2005.

        Graus

            * Doutoramento
              Física
            * Título de Agregado
              Matemática

        Publicações

        Artigo em revista

          * 2023-12-14, Finiteness of quantum gravity with matter on a PL spacetime, Classical and Quantum Gravity
          * 2022-04, Effective Actions for Regge Piecewise Flat Quantum Gravity, Universe
          * 2021-03-01, Standard Model and 4-groups, Europhysics Letters
          * 2019-01-10, Hamiltonian analysis of the BFCG formulation of general relativity, Classical and Quantum Gravity
          * 2018-10-01, Quantum gravity for piecewise flat spacetimes, SFIN
          * 2017-02-01, Effective actions for Regge state-sum models of quantum gravity, Advances in Theoretical and Mathematical Physics
          * 2016, Hamiltonian analysis of the BFCG theory for the Poincaré 2-group, Classical and Quantum Gravity
          * 2015, Solution to the cosmological-constant problem in a Regge quantum gravity model, EPL
          * 2015, Canonical formulation of Poincaré BFCG theory and its quantization, General Relativity and Gravitation
          * 2014, Categorical generalization of spinfoam models, Journal of Physics: Conference Series
          * 2013, Spin-Cube models of quantum gravity, Reviews in Mathematical Physics
          * 2013, Preface, Reviews in Mathematical Physics
          * 2013, A finiteness bound for the EPRL/FK spin foam model, Classical and Quantum Gravity
          * 2012, Poincaré 2-group and quantum gravity, Classical and Quantum Gravity
          * 2012, Effective action for EPRL/FK spin foam models, Journal of Physics: Conference Series
          * 2011, Lie crossed modules and gauge-invariant actions for 2-BF theories, Advances in Theoretical and Mathematical Physics
          * 2011, Large-spin asymptotics of Euclidean LQG flat-space wavefunctions, Advances in Theoretical and Mathematical Physics
          * 2011, Four-dimensional spin foam perturbation theory, Symmetry, Integrability and Geometry: Methods and Applications (SIGMA)
          * 2011, Effective action and semi-classical limit of spin-foam models, Classical and Quantum Gravity
          * 2009, Spin foam perturbation theory for three-dimensional quantum gravity, Communications in Mathematical Physics
          * 2008, Spin network wavefunction and nonperturbative graviton propagator, Fortschritte der Physik
          * 2008, Invariants of spin networks embedded in three-manifolds, Communications in Mathematical Physics
          * 2006, Quantum gravity as a deformed topological quantum field theory, Journal of Physics: Conference Series
          * 2006, Quantum gravity as a broken symmetry phase of a BF theory, Symmetry, Integrability and Geometry: Methods and Applications (SIGMA)
          * 2006, Erratum: Flat spacetime vacuum in loop quantum gravity (Classical and Quantum Gravity (2004) 21 (3909)), Classical and Quantum Gravity
          * 2006, Coherent states expectation values as semiclassical trajectories, Journal of Mathematical Physics
          * 2005, New spin foam models of quantum gravity, Modern Physics Letters A
          * 2005, Modern Physics Letters A: Preface, Modern Physics Letters A
          * 2004, Flat spacetime vacuum in loop quantum gravity, Classical and Quantum Gravity
          * 2003, Spin foam models of Yang-Mills theory coupled to gravity, Classical and Quantum Gravity
          * 2003, Quantum gravity vacuum and invariants of embedded spin networks, Classical and Quantum Gravity
          * 2003, Quantum Field Theory of Open Spin Networks and New Spin Foam Models, International Journal of Modern Physics A
          * 2002, Spin foam models of matter coupled to gravity, Classical and Quantum Gravity
          * 2001, Super Chern-Simons theory and flat super connections on a torus, Advances in Theoretical and Mathematical Physics
          * 2001, Quantum field theory of spin networks, Classical and Quantum Gravity
          * 2000, Painlevé III equation and Bianchi VII0 model, Advances in Theoretical and Mathematical Physics
          * 2000, Free-field realization of D-dimensional cylindrical gravitational waves, Classical and Quantum Gravity
          * 2000, Belinskii - Zakharov formulation for Bianchi models and Painlevé III equation, Journal of Mathematical Physics
          * 1999, One-loop corrections for a Schwarzschild black hole via 2D dilaton gravity, Physical Review D - Particles, Fields, Gravitation and Cosmology
          * 1998, Remarks on the reduced phase space of (2 + 1)-dimensional gravity on a torus in the Ashtekar formulation, Classical and Quantum Gravity
          * 1998, One-loop effective action for spherical scalar field collapse, Classical and Quantum Gravity
          * 1998, Free field realization of cylindrically symmetric Einstein gravity, Physics Letters, Section B: Nuclear, Elementary Particle and High-Energy Physics
          * 1997, W-strings on curved backgrounds, Modern Physics Letters A
          * 1997, One-loop effective action for a generic 2d dilaton gravity theory, Nuclear Physics B
          * 1997, On the Dirac-Born-Infeld action for D-branes, Physics Letters, Section B: Nuclear, Elementary Particle and High-Energy Physics
          * 1997, Loop corrections in the spectrum of two-dimensional Hawking radiation, Classical and Quantum Gravity
          * 1997, General solution for self-gravitating spherical null dust, Physical Review D - Particles, Fields, Gravitation and Cosmology
          * 1997, A quantum model of Schwarzschild black hole evaporation, Physics Letters, Section B: Nuclear, Elementary Particle and High-Energy Physics
          * 1996, Unitary theory of evaporating two-dimensional black holes, Classical and Quantum Gravity
          * 1996, Two-loop back-reaction in 2D dilaton gravity, Nuclear Physics B
          * 1995, Hawking radiation and back-reaction in a unitary theory of 2D quantum gravity, Physics Letters B
          * 1993, Symplectic structure of 2D dilaton gravity, Physics Letters B
          * 1993, Canonical analysis of the Bianchi models in an Ashtekar formulation, Classical and Quantum Gravity
          * 1993, 2D dilaton gravity in a unitary gauge, Physics Letters B
          * 1992, Hamiltonian construction of W-gravity actions, Physics Letters B
          * 1992, Gauge fixing and independent canonical variables in the Ashtekar formulation of general relativity, Nuclear Physics, Section B
          * 1992, Exactly solvable models of 2D dilaton quantum gravity, Physics Letters B
          * 1992, Ashtekar formulation of (2 + 1)-dimensional gravity on a torus, Nuclear Physics, Section B
          * 1991, Gauging the extended conformal algebras, Physics Letters B
          * 1991, Fermionic random walk and spinning strings, Physics Letters B
          * 1990, Vanishing of the cosmological constant in the green-schwarz superstring theory, Nuclear Physics, Section B
          * 1990, Random superstrings, Physics Letters B
          * 1990, Covariantly quantizable superparticles, Physics Letters B
          * 1989, Covariant vertex operators for the Siegel superstring, Nuclear Physics, Section B
          * 1989, BRST charge for the Brink-Casalbuoni-Schwarz superparticle, Physics Letters B
          * 1988, On-shell equivalence of superstrings, Physics Letters B
          * 1988, Free equations of motion for all D = 6 supermultiplets, Nuclear Physics, Section B
          * 1988, Equations of motion for N = 1 massless super-Poincaré representations in D = 3,4 space-time, Nuclear Physics, Section B

        Tese / Dissertação

          * 2018, Mestrado, Semiclassical limit of the EPRL spin foam model
          * 2017, Doutoramento, The BFCG theory and canonical quantization of gravity

        Livro

          * 2023, State-sum Models of Picewise Linear Quantum Gravity, Mikovic, Aleksandar; Marko Vojinovic, World Scientific
          * 2005, Spin foam models of quantum gravity, Mikovic, A.

        Relatório

          * 1997, On the Dirac-Born-Infeld action for D-branes, http://www.scopus.com/inward/record.url?eid=2-s2.0-0030675818&partnerID=MN8TOARS

        Artigo em conferência

          * Piece-wise flat metrics and quantum gravity , 10-th Mathematical Physics Meeting
          * 2006, Spin foam models from the tetrad integration
          * 2006, Graviton propagator from spin networks

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona