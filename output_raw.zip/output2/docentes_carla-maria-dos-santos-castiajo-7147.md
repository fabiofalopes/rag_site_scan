# Response for https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
          PT: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147 EN: https://www.ulusofona.pt/en/teachers/carla-maria-dos-santos-castiajo-7147
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
        fechar menu : https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carla-maria-dos-santos-castiajo-7147
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carla Maria Dos Santos Castiajo

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p7147
              p71***@ulp.pt
              B913-8847-48A7: https://www.cienciavitae.pt/B913-8847-48A7
              0000-0002-9429-5721: https://orcid.org/0000-0002-9429-5721
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/bf0839bf-36c6-4b6b-87e8-4c0d723fcd3a
      : https://www.ulusofona.pt/

        Resume

        Carla Castiajo cruza no seu trabalho diversas áreas artísticas. Tem utilizado muitas vezes o cabelo / pelo como material assim como outros tipos de materiais, pois estes possuem os seus próprios atributos e natureza simbólico-cultural, incorporam significados e podem criar e estabelecer diferentes diálogos. Carla finalizou o doutoramento, em 2016, na Estonian Academy of Arts, Tallinn, Estónia, com bolsa de estudo da Fundação para a Ciência e a Tecnologia, (FCT), 2011-2015. O tema da sua pesquisa artística foi “Purity or Promiscuity? Exploring Hair as a Raw Material in Jewellery and Art”. Concluiu o mestrado em Belas-Artes, em 2006, na Konstfack, em Estocolmo, Suécia, com bolsa de estudo da Fundação Calouste Gulbenkian, 2005-2006. Licenciou-se em Arte e Design, em 2003, na Escola Superior de Arte e Design (ESAD), em Matosinhos, Portugal. Lecionou em diversas Universidades em diferentes países, como a Academy of Fine Arts and Design, em Bratislava, Eslováquia, a Estonian Academy of Arts, em Tallinn, Estónia, a Escola Superior de Arte e Design, em Matosinhos, Portugal, a Oakham School, em Oakham, Inglaterra, e a Beaconhouse National University, em Lahore, Paquistão. Participou em algumas residências artísticas, destacando-se, Nida Art Colony, Nida, Lituânia, e o Programa Rede de Residências: Experimentação Arte, Ciência e Tecnologia, Departamento de Engenharia de Polímeros, 3B's (Biomateriais, Biodegradáveis e Biomiméticos), Universidade do Minho, Portugal. Tem apresentado regularmente o seu trabalho nas exposições individuais: “Colecção Compulsiva”, Galeria da Casa A. Molder, Lisboa, Portugal, 2022; "Adormeceu", Associação R.C. Nogueira, Nogueira, XXII Bienal Internacional de Arte de Cerveira, Vila Nova de Cerveira, Portugal, 2022; “GL 574”, Mupi Gallery, Saco Azul Associação Cultural, Maus Hábitos - Espaço de Intervenção Cultural, Porto, Portugal, 2019; Playlist #16, Café / Livraria Candelabro, Porto, Portugal, 2017; “Remain / Cease”, Cemitério, Convento Pirita, Tallinn, Estónia, 2015; “Filthy / Chastity”, Casa de Banho, Lembitu 3, Tallinn, Estónia, 2015; “Purus et Promiscuus”, Capela, Mosteiro Dominicano, Tallinn, Estónia, 2014. Tem também participado em diversas exposições coletivas em diferentes países.

        Graus

            * Doktor (PhD)
              Art and Design
            * Master
              Art and Design
            * Licenciatura
              Arte e Design
            * Outros
              Curso de Tricotagem da Camisola Tradicional Poveira
            * Outros
              Curso: Artes Têxteis – Iniciação
            * Outros
              Curso: Confeção de Peças de Vestuário.
            * Outros
              Formação Modular Certificada – B-Learning: Tingimentos Sustentáveis.
            * Curso de Especialização Tecnológica
              Curso: Iniciação à Fotografia.
            * Outros
              Formação Pedagógica Inicial de Formadores.
            * Curso de Especialização Tecnológica
              Curso de Ourives de Pratas / Cinzelador
            * Outros
              Curso Prático de Técnica de Joalharia.
            * Licenciatura
              ERASMUS, Escola Massana, Barcelona, Espanha

        Publicações

        Tese / Dissertação

          * 2016-12, Doutoramento, "Purity or Promiscuity? Exploring Hair as a Raw Material in Jewellery and Art"

        Artigo em jornal

          * 2019-02-28, "Purity or Promiscuity? Exploring Hair as a Material", Journal of Jewellery Research
          * 2017, "Purity or Promiscuity?", The Fashion Studies Journal.

        Recurso online

          * 2017, "Loss and Memory: Doris Salcedo and Mourning Jewelry", https://artjewelryforum.org/articles/loss-and-memory/

        Catálogo de exposição

          * 2016, Castiajo, Carla; Ondru¿ová, Slavomíra. Joon, Bratislava: Typografia Plus

        Exposição artística

          * 2022-11-26, Exposição coletiva: "PERFUME", Galeria Reverso, Lisboa
          * 2022-11-03, Exposição individual: "Colecção Compulsiva", Curadoria de Adriana Molder, Galeria da Casa A. Molder, Lisboa, Portugal
          * 2022-09-17, Exposição individual: "Adormeceu", Programa de Residências Artísticas da Fundação Bienal de Arte de Cerveira, Curadoria de Mafalda Santos. Associação R.C. Nogueira, Nogueira / Vila Nova de Cerveira, XXII Bienal Internacional de Arte de Cerveira, Vila Nova de Cerveira, Portugal
          * 2022-05-13, Exposição coletiva: 30th International Jewellery Competition "Touch", Gallery of Art, Legnica, Polónia; Romanian Jewelry Week / Museu Cotroceni, Bucareste, Roménia, Gallery of Art, Legnica, Polónia
          * 2021-10-29, Exposição coletiva: KORU7, International Contemporary Jewellery Triennal, South Karelia Museum, Lappeenranta, Finlândia
          * 2021-09-18, Exposição coletiva: "VADE RETRO", Galeria Tereza Seabra, Lisboa, Portugal
          * 2021-09-16, Exposição coletiva: "SUOR FRIO", 1.ª Bienal de Joalharia Contemporânea de Lisboa, Galeria de Exposições Temporárias do Museu de São Roque, Igreja, Museu de São Roque e Museu da Farmácia, Lisboa, Portugal
          * 2021-05-28, Exposição coletiva: 29th International Jewellery Competition "STILL HUMAN?", Gallery of Art, Legnica, Polónia; Galeria N, Jablonec nad Nisou, República Checa, Gallery of Art, Legnica, Polónia
          * 2021-05-13, Exposição coletiva: "BãOM!!!!", Curadoria de João Baeta, Poste Matosinhos, Mercearia São Miguel, Matosinhos, Portugal
          * 2021-04-22, Exposição coletiva: "TRIÂNGULO", Galeria da Brotéria, Lisboa, Portugal
          * 2021-04-16, Exposição coletiva: "Pilosities", Galeria Tereza Seabra, Lisboa, Portugal
          * 2020-12-02, Exposição coletiva: "HOPE: Uma Régua de Azul", Galeria Reverso, Lisboa, Portugal
          * 2020-06-25, Exposição coletiva: "Poético ou Político?", Curadoria de João Baeta, Mupi Gallery, Mupis na cidade do Porto, Porto, Portugal
          * 2020-03-07, Exposição - Instalação: TRABALHO CAPITAL # GREVE GERAL, Curadoria de Paulo Mendes, Centro de Arte Oliva, São João da Madeira, Portugal
          * 2020-03-05, Exposição coletiva: ANUÁRIO 19, Palácio das Artes, Porto, Portugal
          * 2019-10-12, Exposição coletiva: "A Espessura do Mundo", Curadoria de José Maia e João Terras, Espaço Mira, Porto, Portugal
          * 2019-07-19, Exposição coletiva: Convidados de verão. Joalharia Contemporânea em Portugal, Curadoria de Cristina Filipe, Museu Calouste Gulbenkian, Lisboa, Portugal
          * 2019-06-27, Exposição individual: "GL 574", Mupi Gallery, Saco Azul Associação Cultural, Maus Hábitos - Espaço de Intervenção Cultural, Porto, Portugal
          * 2019-05-18, Exposição coletiva: "Fazer do Fantasma uma Pessoa Viva", Curadoria de Raquel Guerra, Casa-Museu Marta Ortigão Sampaio, Porto, Portugal
          * 2019-03-16, Exposição coletiva: "SCHMUCKISMUS", Curadoria de Karen Pontoppidan, Pinakothek der Moderne, Die Neue Sammlung - The Design Museum, Munique, Alemanha
          * 2018-12-19, Exposição coletiva: "Ayer y Hoy. Joyería Portuguesa", Casa de la Cultural de la Municipalidad de San Isidro, Lima, Peru
          * 2018-11-07, Exposição coletiva: "21 GRAMS", Curadoria de Ruudt Peters, Craft Museum AAA Hangzhou, China; Silver Festival Legnica, Polónia; Galerie Handwerk, Munique, Alemanha; BeCraft Galerie, Mons, Bélgica; CODA Museum, Apeldoorn, Países Baixos
          * 2018-08-20, Exposição coletiva: KORU6, International Contemporary Jewellery Triennal, Imatra Art Museum, Imatra, Finlândia; Tiivistämö, Helsínquia, Finlândia
          * 2018-06-09, Exposição coletiva, Galeria INTHEPENDANT, Porto, Portugal
          * 2018-03-10, Exposição coletiva: "Tanto Mar. Fluxos Transatlânticos do Design", Curadoria de Bárbara Coutinho e Adélia Borges, Palácio dos Condes da Calheta, Jardim-Museu Agrícola Tropical (Belém), Lisboa, Portugal
          * 2017-12-01, Exposição coletiva: "MIX MÉDIA", Atelier ARTICULA e Livraria Sá da Costa, Espaço Camões, Lisboa, Portugal
          * 2017-11-02, Exposição individual: Playlist #16, Café / Livraria Candelabro, Porto, Portugal
          * 2017-05-19, Exposição coletiva: 26th Legnica International Jewellery Competition "IDENTITY", Galeria Sztuki, Legnica, Polónia; Feira Jubinale, Cracóvia, Polónia; Galeria Yes, Poznan, Polónia; Feira Zloto Srebro Czas, Varsóvia, Polónia; Galeria Otwarta, Sandomierz, Polónia; Feira Inhorgenta, Munique, Alemanha; Feira Amberif, Gdank, Polónia; Galeria N, Jablonec, República Checa
          * 2016-02-04, Exposição de Carla Castiajo e Slavomíra Ondrušová: "Joon", Hop Gallery, Tallinn, Estónia
          * 2015-11-29, Exposição de Carla Castiajo e Slavomíra Ondru¿ová: "The Sea of Possibilities", A4, Bratislava. Eslováquia
          * 2015-11-07, Exposição coletiva: "Body Alchemy", Hangzhou Contemporary International, Jewelry and Metal Art Triennial, Museum of Contemporary Art of CAA (MCACAA), China
          * 2015-09-07, Exposição individual: "Remain / Cease", Cemitério, Convento Pirita, Tallinn, Estónia
          * 2015-07-11, Exposição coletiva: "Hotel", Estonian Contemporary Jewellery, Curadoria de Maria Valdma, Reigi parsonage, Hiiumaa, Estónia
          * 2015-06-04, Exposição individual: "Filthy / Chastity", Casa de Banho, Lembitu 3, Tallinn, Estónia
          * 2015-02-18, Exposição coletiva: "Pussy Envy", Curadoria de Stacey Koosel e Anna-Stina Treumund, Ladyfest Tallinn 2015, Hobusepea Galleria, Tallinn, Estónia
          * 2014-10-31, Exposição coletiva: "From the School of Arts and Crafts to the Academy of Arts. A Hundred Years of Art Education in Tallinn", KUMU, Tallinn, Estónia
          * 2014-09-09, Exposição coletiva: "Pin 10 Anos", Comissariada por Marie-José van den Hout, Galeria de Arte Moderna Fernando Azevedo, na Sociedade Nacional de Belas Artes, Lisboa, Portugal
          * 2014-09-05, Exposição individual: "Purus et Promiscuus", Capela, Mosteiro Dominicano, Tallinn, Estónia
          * 2014-08-21, Exposição coletiva: "Ferromenaalne", Estonian Academy of Arts, Department of Jewellery and Blacksmithing, City Gallery, Tallinn, Estónia
          * 2014-08-13, Exposição coletiva: "The Homunculus Collection", Curadoria de Stacey Koosel, Hobusepea Gallery, Tallinn, Estónia
          * 2012-12-05, Exposição coletiva: "KAMA, Sesso e Design", Curadoria de Silvana Annicchiarico, Triennale Design Museum, Milão, Itália
          * 2012-05-10, Exposição coletiva: "Estonian Contemporary Jewellery: Ritual", Shenkar College of Engineering, Design and Art Ramat Gan, Israel
          * 2011-10-29, Exposição coletiva: European Triennial for Contemporary Jewellery, Mons, Bélgica
          * 2009-12-05, Exposição coletiva: PLATINA CELEBRATES 10th ANNIVERSARY, Galeria Platina, Estocolmo, Suécia
          * 2009-09-07, Exposição coletiva: "LINGAM", Curadoria Ruudt Peters, Gallery Vita Havet, Konstfack, Estocolmo, Suécia; WCC-BF, Mons, Bélgica; Museum Catharijneconvent, Utrecht, Países Baixos
          * 2009-06, Exposição coletiva da ESAD: Espaço multi-funções ESAD, Brito Capelo, Matosinhos, Portugal
          * 2009-05-04, Exposição coletiva: "SILVER SCHOOLS EXHIBITION", The Gallery of Art in Legnica, Polónia
          * 2009-04, Exposição coletiva: "Walking the Gray Area", Curaroria de Valeria Siemelink e Andrea Wagner, Galeria La Refaccionaria, Mexico City, México
          * 2008-03-13, "Jóias Reais - Joalharia Contemporânea Luso-Brasileira", Museu Histórico Nacional, Rio de Janeiro, Brasil; Palácio Nacional da Ajuda, Lisboa, Portugal; Centro Comercial Alexa, Berlin, Alemanha
          * 2008, Exposição coletiva: "Filum e granum", Museu de Artes Aplicadas de Belgrado, Sérvia.
          * 2008, Exposição coletiva: "HORROR VACUI - IN FEAR OF THE VOID“, Forum fur schmuck, touring exhibition 2008-2009
          * 2007-06-16, Exposição coletiva: "Impressions on Portuguese Contemporary Jewellery", LS LandskronSchneidzik Galerie und Kunstagentur, Nuremberga, Alemanha
          * 2007-03-08, Special Jewellery Show 59th International Trade Fair Munich, "Schmuck 2007", Munique, Alemanha
          * 2006-10, Exposição coletiva: "QUATRO PONTOS DE CONTACTO ENTRE LISBOA E ROMA", Alternatives Gallery, Roma, Itália.
          * 2006-08-06, Marzee Graduation Show 2006, Marzee, Nijmegen, Holanda; Villa Bengel, Idar-Oberstein, Alemanha; Midora fair Leipzig, Alemanha
          * 2006, Workshop internacional, Exposição intenerante: "2ndSKIN-Cork Jewellery", 2006-2007
          * 2006, Exposição coletiva: Pedras & Pêssegos, Porto, Portugal
          * 2006, Exposição coletiva: "Celebrating the Necklace", Mobilia Gallery, Cambridge, Estados Unidos.
          * 2006, Exposição coletiva intenerante: "Chromos", Le Arti Orafi, Florença, Itália; Birmingham Institute of Art and Design, School of Jewellery, Birmingham, Inglaterra; Fachhochschule Trier Hochschule für Wirtschaft, Technik und Gestaltung, Trier, Alemanha; Estonian Academy of Arts, Tallinn, Estónia; Akademija Sztuc, Lodz, Polónia; ESAD, Matosinhos, Portugal
          * 2005-11-21, Exposição coletiva: "Des+gn Mais", Contemporary Portuguese Design, ICEP / Flow Gallery, Londres, Reino Unido
          * 2005-10, Exposição internacional: Grassimesse, Leipzig, Alemanha
          * 2005-09-19, Exposição na 12th Biennale of Young Artists from Europe and the Mediterranean, tema: "Passion", Castel Sant' Elmo, Nápoles, Itália
          * 2005-08-20, Exposição da Escola Superior de Artes e Design (ESAD) na XIII Bienal de Cerveira, "Contamination", Tominõ, Espanha
          * 2005-07-07, “Em Toda a Parte. Em Lugar Nenhum / Everywhere, Nowhere", X Simpósio Internacional de Joalharia Contemporânea, ARS ORNATA EUROPEANA. Exposição coletiva: “Mais Perto. Intervenções a partir das coleções do Museu Nacional de Arte Antiga / Closer”, comissariada por Cristina Filipe, Marília Maria Mira e Paula Paour, Museu Nacional de Arte Antiga, Lisboa, Portugal
          * 2005-07, Exposição coletiva: "Everyhere, Nowhere", Galeria Tereza Seabra, Lisboa, Portugal
          * 2005, Exposição coletiva: "Inspired av Natur?" Gallery Platina / Edvard Andersons Conservatory Bergianska, Bergianska Botanical Garden, Estocolmo, Suécia
          * 2004, Mostra Nacional de Jovens Criadores 03 (Clube Português de Arte e Ideias), Sede do BNU, Silves, Portugal
          * 2004, Exposição coletiva: "Contact", Massachusetts, Estados Unidos
          * 2004, Exposição coletiva intenerante: "Leveza: Reanimar a Filigrana", 2004-2008
          * 2003-09-17, Exposição coletiva: Experimenta Design (EXD'03), Bienal de Lisboa, "Para além do consumo", Lisboa, Portugal
          * 2003-08, Marzee International Graduate Show, Galerie Marzee – Contemporary Art Jewellery, Nijmegen, Países Baixos
          * 2003-06-26, Exposição coletiva: "JOA.ESAD", Galeria Shibuichi, Leça da Palmeira, Portugal
          * 2003, Exposição coletiva: Midora Fair (Schmuckmesse), Leipzig, Alemanha
          * 2003, Exposição coletiva: "Cow Now – Jewellery for Cows", Gallery Rantapaja, Lappeeranta, Finlândia
          * 2003, Exposição coletiva: Porto Arte, Matosinhos, Portugal
          * 2002, Exposição coletiva: "JOA.ESAD", Galeria Shibuichi, Leça da Palmeira, Portugal
          * 2002, Exposição coletiva: "Nature and Time", Hanau, Alemanha, Portugal
          * 1999, Mostra Nacional Jovens Criadores '99, Braga, Portugal

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona