# Response for https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
          PT: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269 EN: https://www.ulusofona.pt/en/teachers/dragos-ionut-moldovan-5269
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
        fechar menu : https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/dragos-ionut-moldovan-5269
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ionut Dragos Moldovan

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5269
              dra***@ulusofona.pt
              391E-71CF-9991: https://www.cienciavitae.pt/391E-71CF-9991
              0000-0003-3085-0770: https://orcid.org/0000-0003-3085-0770
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/7ce45eb4-a8e1-42d5-809c-e05a6492d2bf
      : https://www.ulusofona.pt/

        Resume

        Dragos Ionut Moldovan. Completed the Doutoramento in Engenharia Civil in 2008/09/25 by Universidade de Lisboa Instituto Superior Técnico and Mestrado in Civil Engineering in 2002 by Universitatea Tehnica din Cluj-Napoca. Is Associate Professor in Universidade Lusófona de Humanidades e Tecnologias and Researcher in Universidade de Lisboa Instituto de Investigação e Inovação em Engenharia Civil para a Sustentabilidade. Published 35 articles in journals. Has 3 section(s) of books and 1 book(s). Has 1 patent(s) registered. Organized 4 event(s). Supervised 2 PhD thesis(es) e co-supervised 3. Supervised 11 MSc dissertation(s) e co-supervised 4. Participates and/or participated as PhD Student Fellow in 1 project(s), Post-doc Fellow in 1 project(s), Principal investigator in 2 project(s) and Researcher in 2 project(s). Works in the area(s) of Exact Sciences with emphasis on Mathematics with emphasis on Applied Mathematics, Exact Sciences with emphasis on Mathematics with emphasis on Applied Mathematics, Engineering and Technology with emphasis on Environmental Engineering with emphasis on Geotechnics and Engineering and Technology with emphasis on Civil Engineering with emphasis on Municipal and Structural Engineering. In his curriculum Ciência Vitae the most frequent terms in the context of scientific, technological and artistic-cultural output are: hybrid finite elements; hybrid-Trefftz finite elements; model updating; stochastic finite element method; boundary element method; fundamental solutions method; porous media; wave propagation in geomaterials; dynamic testing; bender element; numerical-experimental methods; structural health monitoring; machine learning; hybrid approach; damage detection; bridge management system; bender element test; open-source; heat conduction; acoustic waves; structural dynamics; structural statics; .

        Graus

            * Mestrado
              Civil Engineering
            * Doutoramento
              Engenharia Civil

        Publicações

        Journal article

          * 2024-04-14, Unsupervised transfer learning for structural health monitoring of urban pedestrian bridges, Journal of Civil Structural Health Monitoring
          * 2024-03-22, A Computational Platform for Automatic Signal Processing for Bender Element Sensors, Algorithms
          * 2024-02, Bayesian calibration for Lamb wave propagation on a composite plate using a machine learning surrogate model, Mechanical Systems and Signal Processing
          * 2024, Impact of climate change on long-term damage detection for structural health monitoring of bridges, Structural Health Monitoring
          * 2023-09-13, Transfer Learning for Structural Health Monitoring in Bridges That Underwent Retrofitting, Buildings
          * 2023-06-01, A Roadmap for an Integrated Assessment Approach to the Adaptation of Concrete Bridges to Climate Change, Journal of Bridge Engineering
          * 2023-01, Transfer Learning to Enhance the Damage Detection Performance in Bridges When Using Numerical Models, Journal of Bridge Engineering
          * 2022-11-04, Smartphone Application for Structural Health Monitoring of Bridges, Sensors
          * 2022-11, Damage Detection Approach for Bridges under Temperature Effects using Gaussian Process Regression Trained with Hybrid Data, Journal of Bridge Engineering
          * 2022-09-02, Hybrid-Trefftz displacement elements for three-dimensional elastodynamics, Computational Mechanics
          * 2022-04, A local frequency-dependent absorbing boundary condition for unsaturated porous media based on the theory of mixtures with interfaces, Soil Dynamics and Earthquake Engineering
          * 2022-03-18, Three-dimensional hybrid-Trefftz displacement elements for poroelastodynamic problems in saturated media, International Journal for Numerical Methods in Engineering
          * 2022-01-04, Reliability of probabilistic numerical data for training machine learning algorithms to detect damage in bridges, Structural Control and Health Monitoring
          * 2021-04-01, Direct boundary method toolbox for some elliptic problems in FreeHyTE framework, Engineering Analysis with Boundary Elements
          * 2021-04, Optimisation of receiver's location in bender element experiments using computational wave filtration, Soil Dynamics and Earthquake Engineering
          * 2021-03-01, A hybrid-Trefftz finite element platform for solid and porous elastodynamics, Engineering Analysis with Boundary Elements
          * 2019-09, On rank-deficiency in direct Trefftz method for 2D Laplace problems, Engineering Analysis with Boundary Elements
          * 2019-09, Hybrid-Trefftz finite elements for non-homogeneous parabolic problems using a novel dual reciprocity variant, Engineering Analysis with Boundary Elements
          * 2019-07, Finite Element–Based Machine-Learning Approach to Detect Damage in Bridges under Operational and Environmental Variations, Journal of Bridge Engineering
          * 2018-07, FreeHyTE: a hybrid-Trefftz finite element platform, Advances in Engineering Software
          * 2017, Fixed point automatic interpretation of bender-based G0 measurements, Computers and Geotechnics
          * 2017, Applied element method simulation of experimental failure modes in RC shear walls, Computers and Concrete
          * 2016, Trefftz-based dual reciprocity method for hyperbolic boundary value problems, International Journal for Numerical Methods in Engineering
          * 2016, Bender-based G0 measurements: A coupled numerical-experimental approach, Computers and Geotechnics
          * 2016, A new approach to non-homogeneous hyperbolic boundary value problems using hybrid-Trefftz stress finite elements, Engineering Analysis with Boundary Elements
          * 2015, On a mixed time integration procedure for non-linear structural dynamics, Engineering Computations (Swansea, Wales)
          * 2015, A new particular solution strategy for hyperbolic boundary value problems using hybrid-Trefftz displacement elements, International Journal for Numerical Methods in Engineering
          * 2014, Hybrid-trefftz displacement finite elements for elastic unsaturated soils, International Journal of Computational Methods
          * 2014, Elastic wave propagation in unsaturated porous media using hybrid-Trefftz stress elements, International Journal for Numerical Methods in Engineering
          * 2013, Hybrid-Trefftz finite elements for biphasic elastostatics, Finite Elements in Analysis and Design
          * 2012, Hybrid-Trefftz displacement and stress elements for bounded poroelasticity problems, Computers and Geotechnics
          * 2011, Hybrid-Trefftz stress element for bounded and unbounded poroelastic media, International Journal for Numerical Methods in Engineering
          * 2011, Hybrid-Trefftz displacement element for poroelastic media, Computational Mechanics
          * 2010, Mixed and hybrid stress elements for biphasic media, Computers and Structures
          * 2008-01-01, Hybrid-Trefftz stress and displacement elements for dynamic analysis of bounded and unbounded saturated porous media, Computer Assisted Mechanics and Engineering Sciences

        Book

          * 2022, Elasticidade: Conceitos e Aplicações, 1, Cortez Teixeira, Paulo; Moldovan, Ionut Dragos; Barata Marques, Manuel, IST Press

        Book chapter

          * 2023, Does Climate Change Impact Long-Term Damage Detection in Bridges?, Experimental Vibration Analysis for Civil Engineering Structures, Springer Nature Switzerland
          * 2023, Does Climate Change Impact Long-Term Damage Detection in Bridges?, Experimental Vibration Analysis for Civil Engineering Structures, Springer Nature Switzerland
          * 2021, Hybrid-Trefftz finite elements for non-homogeneous parabolic problems, Trefftz and Fundamental Solution-Based Finite Element Methods, Bentham Books
          * 2021, FreeHyTE: A Hybrid-Trefftz Finite Element Platform for Poroelastodynamic Problems, Advances in Transportation Geotechnics IV, Springer International Publishing
          * 2020, Unified Hybrid-Trefftz Finite Element Formulation for Dynamic Problems, Advances in Trefftz Methods and Their Applications, Springer International Publishing

        Edited book

          * 2013, Católica Editora

        Report

          * 2020-10-28, FreeHyTE Solid Transient - User's Manual, https://drive.google.com/file/d/1Yh5tDZwnzH7vRYlKzUozUWxMoFagdKrO/view?usp=sharing

        Conference paper

          * Tuned Liquid Dampers for Mitigating the Response of Structures Subjected to Dynamic Excitations – a state-of-the-art, Constructions 50 Conference
          * Trefftz spectral analysis of biphasic media, 6th World Congress on Computational Mechanics
          * Smartphone application for structural health monitoring, 10th European Workshop on Structural Health Monitoring
          * On the Reliability of Finite Element Models for the Training of Machine Learning Algorithms for Damage Detection in Bridges
          * Mixed and Hybrid Stress Elements for Biphasic Media, ACME07
          * Hybrid-Trefftz stress element for biphasic elastostatics, Congresso de Métodos Numéricos em Engenharia
          * Hybrid-Trefftz finite elements for transient parabolic problems, The Joint International Conference on Trefftz Method IX and Method of Fundamental Solutions V
          * Hybrid-Trefftz displacement and stress elements for biphasic elastostatics, Computer Methods in Mechanics
          * Hybrid-Trefftz Finite element models for bounded and unbounded elastodynamic problems, Third European Conference on Computational Mechanics
          * Hybrid-Trefftz Finite Elements for Multiphase Soils, 6th International Conference on Computational Methods for Coupled Problems in Science and Engineering
          * Hybrid training of supervised machine learning algorithms for damage identification in bridges, 10th European Workshop on Structural Health Monitoring
          * FreeHyTE: a hybrid-Trefftz finite element platform, The Joint International Conference on Trefftz Method VIII and Method of Fundamental Solutions IV
          * FreeHyTE - a hybrid-Trefftz finite element platform for solid and porous elastodynamics, 10th International Conference on Wave Mechanics and Vibrations
          * Ensaios dinâmicos e modelação da ponte sobre o Rio Itacaiúnas, Betão Estrutural - BE2018
          * Dynamic analysis of unsaturated porous media using hybrid-Trefftz finite elements, 11th International Conference on Vibration Problems
          * Coupling experimental and numerical techniques for improving the reliability of bender element experiments, 17th European Conference on Soil Mechanics and Geotechnical Engineering
          * Automatic interpretation of G0 measurements using bender elements, 3rd International Conference on Information Technology in Geo-Engineering
          * Acoplamento de técnicas numéricas e experimentais na caraterização das propriedades dinâmicas de geomateriais, 17º Congresso Nacional de Geotecnia
          * A unified hybrid-Trefftz formulation and its applications, The Joint International Conference on Trefftz Method IX and Method of Fundamental Solutions V
          * A p-adaptive algorithm for hybrid-Treffz stress element for elastodynamic analysis, 11th International Conference on Vibration Problems
          * A coupled numerical–experimental approach for bender-based G0 measurements in geomaterials, 19th International Conference on Soil Mechanics and Geotechnical Engineering
          * A Generalized Approach to Integrate Machine Learning, Finite Element Modeling and Monitoring Data for Bridges, 11th International Workshop on Structural Health Monitoring
          * 2023-06-27, Coupled experimental and numerical approaches in bender element testing of geomaterials, 10th European Conference on Numerical Methods in Geotechnical Engineering (NUMGE2023)
          * 2022-09-06, A toolbox for the automatic interpretation of bender element tests in geomechanics, ISIC International Conference “Trends on Construction in the Post-Digital Era”
          * 2022-06-21, A modified Rowe cell for echo dynamic testing of soils and interfaces, 3rd Conference on Testing and Experimentation in Civil Engineering
          * 2008, Hybrid-Trefftz stress and displacement elements for dynamic analysis of bounded and unbounded saturated porous media

        Conference abstract

          * 2024-06-07, Hybrid-Trefftz finite elements for non-homogeneous wave propagation problems, 9th European Congress on Computational Methods in Applied Sciences and Engineering
          * 2021-11, GeoHyTE: a toolbox for the automatic interpretation of bender element experiments, Transportation Research Congress 2021
          * 2021, Optimisation of receiver's location in bender element tests using advanced computational techniques, Workshop on Transportation Geotechnics GDRI-CSU
          * 2016, Trefftz-based Dual Reciprocity Method for non-homogeneous hyperbolic boundary value problems, VII European Congress on Computational Methods in Applied Sciences and Engineering
          * 2014, A new particular solution strategy for hyperbolic problems using hybrid-Trefftz finite elements, 11th World Congress on Computational Mechanics
          * 2010, Sensitivity Assessment of Hybrid-Trefftz Stress and Displacement Elements for Poroelasticity, European Conference on Computational Mechanics

        Patent

          * Processo de caracterização dinâmica de geomateriais utilizando modelos de Trefftz, 109549, Dragos Ionut Moldovan; António Gomes Correia

        Trademark

          * FreeHyTE

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona