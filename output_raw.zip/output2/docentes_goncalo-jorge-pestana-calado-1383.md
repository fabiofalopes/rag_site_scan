# Response for https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
          PT: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383 EN: https://www.ulusofona.pt/en/teachers/goncalo-jorge-pestana-calado-1383
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
        fechar menu : https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/goncalo-jorge-pestana-calado-1383
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Gonçalo Jorge Pestana Calado

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p1383
              gon***@ulusofona.pt
              8E1C-28CD-1BD9: https://www.cienciavitae.pt/8E1C-28CD-1BD9
              0000-0001-9727-6051: https://orcid.org/0000-0001-9727-6051
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/82c8e2c2-30b9-499a-87fa-db1c21fee3df
      : https://www.ulusofona.pt/

        Resume

        I 'm a Professor of Ecology and Marine Biology at Lusofona University, in Lisbon and a researcher at MARE - Marine and Environmental Sciences Centre. I am mostly a marine biologist and academic officer with 30+ years professional experience. From 2018-2022, I was the Vice-Rector for research and internationalisation. I have obtained in 2001 my PhD in biology from the University of Santiago de Compostela, Spain. Since then I have coordinated or been involved in a number of international research projects in the field of marine biology. I’ve also authored or co-authored more than 70 peer reviewed papers, mostly on marine biology issues. I also have 15+ years of assessment experience of both national and international R&D&I projects (FP4, Horizon 2020, Portuguese Innovation Agency, EEA Grants, Fundo Azul, PRR). In 2011, I finished my duties as advisor to the former Portuguese Secretary of State for the Environment, Humberto Delgado Rosa. I was member of his cabinet since 2009, where I was responsible for marine, fisheries, agriculture and conservation issues. In 2012, I also became a SCUBA diving instructor. From 2013 to 2017, I was a programme manager at Gulbenkian Oceans Initiative (GOI), a five-year program of the Calouste Gulbenkian Foundation with a vision of protection, conservation and good management of the oceans and of marine ecosystems towards an ecosystem services' approach.

        Graus

            * Doctor
              Biology
            * Mestrado
              Ecology, Management and Modelling of Marine Resources
            * Licenciatura
              Biology
            * Título de Agregado
              Animal Science

        Publicações

        Artigo em revista

          * 2022, Functional Histology and Ultrastructure of the Digestive Tract in Two Species of Chitons (Mollusca, Polyplacophora)
          * 2021, Photosynthesis from stolen chloroplasts can support sea slug reproductive fitness
          * 2019-11, Oxidation of cinnamyl alcohol and ethanol by oxidases and dehydrogenases in the digestive gland of gastropods, Journal of Molluscan Studies
          * 2018-06-15, Kleptoplast photoacclimation state modulates the photobehaviour of the solar-powered sea slugElysia viridis, The Journal of Experimental Biology
          * 2018, Profiling of Heterobranchia Sea Slugs from Portuguese Coastal Waters as Producers of Anti-Cancer and Anti-Inflammatory Agents, Molecules
          * 2018, Mannitol oxidase and polyol dehydrogenases in the digestive gland of gastropods: Correlations with phylogeny and diet, PLoS ONE
          * 2018, Effects of recreational diving on early colonization stages of an artificial reef in North-East Atlantic, Journal of Coastal Conservation
          * 2017, High unexpected genetic diversity of a narrow endemic terrestrial mollusc, PeerJ
          * 2016, With a little help from DNA barcoding: Investigating the diversity of Gastropoda from the Portuguese coast, Scientific Reports
          * 2016, Primary production enhancement in a shallow seamount (Gorringe — Northeast Atlantic), Journal of Marine Systems
          * 2016, Patterns in megabenthic assemblages on a seamount summit (Ormonde Peak, Gorringe Bank, Northeast Atlantic), Marine Ecology
          * 2016, Histochemical detection of mannitol oxidase in the digestive gland of gastropods, Microscopy and Microanalysis
          * 2016, First record of Algarvia alba García-Gómez and Cervera, 1989 (Gastropoda: Heterobranchia) outside the type locality, Marine Biodiversity
          * 2016, Comparative study of salivary glands in carnivorous and herbivorous cephalaspideans (Gastropoda: Euopisthobranchia), Journal of Molluscan Studies
          * 2015, Ultrastructural Detection of Calcium with the Pyroantimonate Method in Cells of Marine Gastropods, Microscopy and Microanalysis
          * 2015, Conservation status of a recently described endemic land snail, Candidula coudensis, from the iberian peninsula, PLoS ONE
          * 2015, A new nudibranch, Flabellina albomaculata sp. nov. (Flabellinidae), from the Cape Verde Archipelago with comparisons among all eastern Atlantic violet Flabellina spp, Marine Biology Research
          * 2013, Seaslugs (Mollusca: Opisthobranchia) from Campeche bank, Yucatan Peninsula, Mexico,Opistobranquios del banco de Campeche, Península de Yucatán, México, Thalassas
          * 2013, Photosynthetic efficiency and kleptoplast pigment diversity in the sea slug Thuridilla hopei (Vérany, 1853), Journal of Experimental Marine Biology and Ecology
          * 2012, Turning the game around: Toxicity in a nudibranch-sponge predator-prey association, Chemoecology
          * 2012, On the occurrence of the Caribbean sea slug Thuridilla mazda in the eastern Atlantic Ocean, Marine Biodiversity Records
          * 2012, Freshwater snail Pomacea bridgesii (Gastropoda: Ampullariidae), life history traits and aquaculture potential, AACL Bioflux
          * 2012, Defense in shallow-water invertebrates at oceanic islands vs. the mainland coast, Aquatic Biology
          * 2011, Polypropionates from Bulla occidentalis: Chemical markers and trophic relationships in cephalaspidean molluscs, Tetrahedron Letters
          * 2011, Microscopical study of the crop and oesophagus of the carnivorous opisthobranch Philinopsis depicta (Cephalaspidea: Aglajidae), Journal of Molluscan Studies
          * 2011, Histological and ultrastructural characterisation of the stomach and intestine of the opisthobranch bulla striata (heterobranchia: Cephalaspidea), Thalassas
          * 2010, Light and electron microscopic study of the anterior oesophagus of Bulla striata (Mollusca, Opisthobranchia), Acta Zoologica
          * 2010, Histochemical and ultrastructural characterization of the posterior esophagus of Bulla striata (Mollusca, Opisthobranchia), Microscopy and Microanalysis
          * 2010, Coloration and defense in the nudibranch gastropod Hypselodoris fontandraui, Biological Bulletin
          * 2010, Behaviour and a functional xanthophyll cycle enhance photo-regulation mechanisms in the solar-powered sea slug Elysia timida (Risso, 1818), Journal of Experimental Marine Biology and Ecology
          * 2010, A new cytotoxic tambjamine alkaloid from the Azorean nudibranch Tambja ceutae, Bioorganic and Medicinal Chemistry Letters
          * 2009, Light and electron microscopy study of the salivary glands of the carnivorous opisthobranch Philinopsis depicta (Mollusca, Gastropoda), Tissue and Cell
          * 2009, Does a shell matter for defence? Chemical deterrence in two cephalaspidean gastropodes with calcified shells
          * 2008, Histology and ultrastructure of the salivary glands in Bulla striata (Mollusca, Opisthobranchia), Invertebrate Biology
          * 2008, Biosynthetic evidence supporting the generation of terpene chemodiversity in marine mollusks of the genus Doriopsilla, Journal of Natural Products
          * 2007, Redescription of the tropical West African pleurobranchid Pleurobranchus reticulatus Rang, 1832 (Gastropoda: Opisthobranchia), Journal of Conchology
          * 2006, Calliopaea bellula feeding upon egg-masses of Haminoea orbignyana: Oophagy among opisthobranch molluscs, Journal of the Marine Biological Association of the United Kingdom
          * 2005, Pelseneeriol-1 and -2: New furanosesquiterpene alcohols from porostome nudibranch Doriopsilla pelseneeri, Tetrahedron
          * 2005, A new species of the genus Flabellina Voigt, 1834 (Mollusca: Nudibranchia) from the Cape Verde Islands, Journal of Conchology
          * 2004, Rediscovery of the syntypes of Doriopsilla pelseneeri D'Oliveira, 1895, Nautilus
          * 2004, New records of Portuguese opisthobranch molluscs, Journal of Conchology
          * 2004, An annotated and updated checklist of the opisthobranchs (Mollusca: Gastropoda) from Spain and Portugal (including islands and archipelagos), Boletin - Instituto Espanol de Oceanografia
          * 2003, New data on opisthobranchs (Mollusca: Gastropoda) from the southwestern coast of Portugal, Boletin - Instituto Espanol de Oceanografia
          * 2002, A revision of the status of Lepadogaster lepadogaster (Teleostei: Gobiesocidae): sympatric subspecies or a long misunderstood blend of species?
          * 2002, A new species of Calma Alder & Hancock, 1855 (Gastropoda: Nudibranchia) with a review of the genus, Journal of Molluscan Studies
          * 2001, Chemical studies of porostome nudibranchs: Comparative and ecological aspects, Chemoecology
          * 2001, Can molluscs biosynthesize typical sponge metabolites? The case of the nudibranch Doriopsilla areolata, Tetrahedron
          * 2000, Modelling growth of Ruppia cirrhosa, Aquatic Botany

        Livro

          * 2014, Calcium detection and other cellular studies in the esophagus and crop of the Marine slug aglaja tricolorata (Euopisthobranchia, Cephalaspidea), Lobo-Da-Cunha, A.; Pereira-Sousa, J.; Oliveira, E.; Alves, Â.; Guimarães, F.; Calado, G.

        Relatório

          * 2022-12, Terrestrial and Maritime Archaeological Survey of the Sir Bu Na'air Island, Sharjah Emirate (UAE). Sharjah Archaeology Authority - Govt. of Sharjah, https://saa.shj.ae/en/

        Artigo em conferência

          * Vacuolar cells seem to be a special trait of the esophagus and crop of carnivorous cephalaspideans (Euopisthobranchia)

        Resumo em conferência

          * 2018-07, Portugal's unique waves captured creatively: the immersive video "The Lagoon Goes to the Sea" and web documentary "Riding the Nazaré Wave", TOCRIA 2018, FCSH-UNL
          * 2018-07, A Lagoa Vai ao Mar"/ "The Lagoon Goes to the Sea": a multi-disciplinary approach to the production of a 360º video¿, Stereo Media and Immersive Media 2018, ULHT
          * 2015, Assessing the conservation status of a recently described short range endemic and land snail from Portugal, Congresso português l de Malacologia

        Poster em conferência

          * 2018, Fatty acid profiling of Armina maculata and assessment of its potential as a producer of anti-inflammatory agents., IJUP-Encontro de Investigação Jovem da Universidade do Porto, 11ª Edição

        Outra produção

          * 2016, With a little help from DNA barcoding, The Gastropoda is one of the best studied classes of marine invertebrates. Yet, most species have been delimited based on morphology only. The application of DNA barcodes has shown to be greatly useful to help delimiting species. Therefore, sequences of the cytochrome c oxidase I gene from 108 specimens of 34 morpho-species were used to investigate the molecular diversity within the gastropods fro
          * 2013, Beauties and beasts: a portrait of sea slugs aquaculture, Research on sea slugs production has steadily increased in the last decades as a result of their use as model organisms for biomedical studies, bioprospecting for new marine drugs and their growing demand for academic research and the marine aquarium trade. However, standardized methods for culturing sea slugs are still limited to a reduced number of species. The main bottlenecks impairing sea slu
          * 2002, New records for the Azorean opisthobranch fauna (Mollusca:Gastropoda)., Seven new species of opisthobranchs are recorded for the first time from the Azores. These are: Aegires sublaevis Odhnerm, 1931; Doto koenneckeri Lemche, 1976; Doto furva Garcia-Gomez and Ortea Rato, 1983; Favorinus branchialis (Rathke, 1806); Facelina annulicornis (Charmisso and Eisenhardt, 1821); Cuthona caerulea (Montagu, 1804) and Cuthona foliata. (Forbes and Goodsit, 1838). The total number o
          * 2002, Analysis of coastal lagoon metabolism as a basis for management, This work was carried out in a shallow eutrophic coastal lagoon (St. André lagoon, SW Portugal) which is artificially opened to the sea each year in early spring. Macrophytes, mainly Ruppia cirrhosa, are keystone species in this ecosystem covering up to 60% of its total area with peak biomasses over 500 g DWm-2. The main objectives were to study ecosystem metabolism, to evaluate the metabolic cont

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona