# Response for https://www.ulusofona.pt/docentes/carina-rossoni-6264

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carina-rossoni-6264
          PT: https://www.ulusofona.pt/docentes/carina-rossoni-6264 EN: https://www.ulusofona.pt/en/teachers/carina-rossoni-6264
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carina-rossoni-6264
        fechar menu : https://www.ulusofona.pt/docentes/carina-rossoni-6264

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carina-rossoni-6264
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carina Rossoni

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6264
              p62***@ulusofona.pt
              3213-C529-AE7F: https://www.cienciavitae.pt/3213-C529-AE7F
              0000-0002-6494-4639: https://orcid.org/0000-0002-6494-4639
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/90f5631d-0aeb-4c39-849a-a0148951fc73
      : https://www.ulusofona.pt/

        Resume

        Graduada em Nutrição na Universidade Regional do Noroeste do Estado do Rio Grande do Sul (UNIJUI), Doutora e Mestre em Medicina e Ciências da Saúde na Escola de Medicina da Pontifícia Universidade Católica do Rio Grande do Sul (PUCRS), com reconhecimento Português dos respectivos Graus Académicos na Faculdade de Medicina da Universidade de Lisboa (ULisboa). Título de Especialista em Nutrição Parenteral e Enteral (BRASPEN), MBA em Gestão Estratégica do Conhecimento Organizacional e em Administração Hospitalar (UDESC) e Docência Superior para Área da Saúde (UNOCHAPECÓ). Possui experiência na área de Nutrição com ênfase em Nutrição Clínica, Hospitalar e Docência no Ensino Superior nos cursos de Graduação, Aperfeiçoamento/Especialização e Mestrado: Enfermagem, Fisioterapia, Nutrição e Medicina. Atualmente Membro da Federação Internacional da Cirurgia da Obesidade e Doenças Metabólicas - IFSO, Coordenadora Científica e Nutricionista da Lasercenter LDA - Lisboa, em atividade no Centro Multidisciplinar de Tratamento da Obesidada do Hospital Lusíadas Amadora, Portugal. Investigadora Integrada no Instituto de Saúde Ambiental da Faculdade de Medicina da ULisboa, desenvolvendo estudos sobre: cirurgia, cirurgia bariátrica e metabólica, nutrição nas condições crónicas e obesidade.

        Graus

            * Bachelor
              Nutrição
            * Postgraduate Certificate
              Mestrado - Medicina e Ciências da Saúde
            * Postgraduate Certificate
              Doutoramento - Medicina e Ciências da Saúde
            * Postgraduate Certificate
              Especialização - MBA em Gestão Estratégica do Conhecimento Organizacional
            * Postgraduate Certificate
              Especialização - Docência Superior para a Área da Saúde
            * Postgraduate Certificate
              Especialização - Administração Hospitalar

        Publicações

        Artigo em revista

          * 2023-12-23, One Anastomosis Transit Bipartition (OATB): Rational and Mid-term Outcomes, Obesity Surgery
          * 2023-11-10, OAGB Bowel Function in Patients With up to 5 Years Follow-Up: Updated Outcomes, Obesity Surgery
          * 2023-11-07, Diet as an epigenetic factor in inflammatory bowel disease, World Journal of Gastroenterology
          * 2023-11-01, Relationship between weight status with sleep health, physical activity and perception of food consumption under stress among firefighters: a pilot study, Biomedical and Biopharmaceutical Research
          * 2023-06-16, Food Labeling - Knowledge among university students in the Lisbon region: an exploratory study, Biomedical and Biopharmaceutical Research
          * 2023-06-09, Position statement on nutrition therapy for overweight and obesity: nutrition department of the Brazilian association for the study of obesity and metabolic syndrome (ABESO—2022), Diabetology & Metabolic Syndrome
          * 2023-06-07, Relationship between weight status with sleep health, physical activity and perception of food consumption under stress among firefighters: a pilot study, Biomedical and Biopharmaceutical Research
          * 2023-04-11, Brazilian guide to nutrition in bariatric and metabolic surgery, Langenbeck's Archives of Surgery
          * 2023-03-21, Nutritional and Lifestyle Behaviors Reported Following One Anastomosis Gastric Bypass Based on a Multicenter Study, Nutrients
          * 2023-01, Interaction Between Food Pyramid and Gut Microbiota. A New Nutritional Approach, Arquivos de Gastroenterologia
          * 2023, Gastrointestinal reported outcomes following one anastomosis gastric bypass based on a multicenter study
          * 2023, Food and Nutrition Knowledge of Elementary School Teachers in a Region of Lisbon, Portugal, Biomedical and Biopharmaceutical Research
          * 2022-12-31, Obesidade como fator de risco para mortalidade pós cirurgia cardíaca, Revista Brasileira de Obesidade, Nutrição e Emagrecimento
          * 2022-12-31, Associação entre adesão à medicação para o HIV e aspetos sociodemográficos, económicos, comportamentais e clínicos
          * 2021-08-29, Health Literacy and Relation to Adherence to Pharmacologic Treatment of Patients in Hemodialysis, International Journal of Advanced Engineering Research and Science
          * 2021-07-26, Phase angle through electrical bioimpedance as predictor of cellularity in inflammatory bowel disease, Artificial Intelligence in Gastroenterology
          * 2021-07-16, Obesity in people with diabetes in COVID-19 times: Important considerations and precautions to be taken, World Journal of Clinical Cases
          * 2021-04-30, Bariatric curgery induces positive changes in body composition in older adults, Revista Brasileira de Obesidade, Nutrição e Emagrecimento
          * 2021-01-13, Identification of obesity in children and teenagers, Minerva Pediatrica
          * 2020-12-02, Consumo alimentar e saúde bucal em escolares de um município da Região Meio Oeste de Santa Catarina, Saúde e meio ambiente: revista interdisciplinar
          * 2020-10-10, Metabolic surgery: revisiting the concept, BMI Journal Seco - Seedo
          * 2020-07-22, Enhanced Recovery After Surgery (ERAS) protocol in bariatric and metabolic surgery (BMS) analysis of practices in nutritional aspects from five continents, Obesity Surgery
          * 2020-06-12, The real impact of colonic transit time and anorectal mamometry in the diagnosis of adult patients with chronic constipation
          * 2020-04-29, Mortality and lifestyle after ,myocardial infarction: a cohort study
          * 2020-04-23, Relação do linfedema e da fisioterapia na qualidade de vida de pacientes com câncer de mama, Revista FisiSenectus
          * 2020-03-30, Perception of body image and food tolerance of patients undergoing bariatric and metabolic surgery at a hospital of the South of Minas Gerais
          * 2019-12-19, Nutritional and metabolic profile of patients with systemic lupus erythematosus of a reference center, BRASPEN Journal
          * 2019-08-31, Perception of bearers of severe obesity regarding the body image and quality of life after bariatric and metabolic surgery . a pilot study
          * 2019-06-25, Dermatoglyphical impressions are different between children and adolescents with normal weight, overweight and obesity: a cross-sectional study, F1000Research
          * 2019-01-08, Systematization of Nutritional Care In Endoscopic Treatment for Obesity, Obesity Surgery
          * 2018-12-31, Adherence to treatment for diabetes and relation with kidney function and lifestyle, INTERNATIONAL JOURNAL OF DEVELOPMENT RESEARCH
          * 2018-12-01, INTOXICAÇÃO SUBAGUDA AO MANGANÊS EM RATOS WISTAR ADULTOS: AVALIAÇÃO DE PARÂMETROS OXIDATIVOS NO SNC E DEPOSIÇÃO DO METAL EM DIFERENTES TECIDOS, Revista Interdisciplinar de Estudos em Saúde
          * 2018-11-22, Interinstitutional action and social participation in the work of the Intersectoral Commission on Occupational Health: case report
          * 2018-10-26, Body composition and remission of comorbidities in patients submitted to Roux-en-Y Gastric Bypass, Jacobs Journal of Obesity
          * 2018-10-05, Weight loss as a prognostic factor for recurrence and survival in oropharyngeal squamous cell carcinoma patients, Molecular and Clinical Oncology
          * 2018, Physical-Chemical Properties of Strawberry Pseudofruits Submitted to Applications of Zinc Oxide Nanoparticles, International Journal of Advanced Engineering Research and Science
          * 2017-10-20, Nutritional assessment of cancer patients in outpatient care, Cogitare Enfermagem
          * 2017-06-12, Nutritional profile of cancer patients hospitalized at a university hospital in the midwest region of Santa Catarina, BRASPEN Journal
          * 2016-10-21, Otoneurological findings in olivoponto cerebellar atrophies
          * 2016-08-11, Nutritional assessment of patients attended in a Psychosocial Care Center (CAPS), BRASPEN Journal
          * 2016-07-25, Implementation of operational management tools in a food and nutrition unit of a Psychosocial Care Center (PCC), Revista Nutrição em Pauta
          * 2015-10-04, Predictors of Excess Weight Loss in Obese Patients After Gastric Bypass: a 60-Month Follow-up, Obesity Surgery
          * 2014, Implementing laparoscopy in Brazil´s National Public Health System: the bariatric surgeons´ point of view, ABCD. Arquivos Brasileiros de Cirurgia Digestiva (São Paulo)
          * 2013-08-08, Nutritional profile of patients referred to total knee arthroplasty, BRASPEN Journal
          * 2011-08, Antimaláricos e perfil lipídico em pacientes com lúpus eritematoso sistêmico, Revista Brasileira de Reumatologia

        Tese / Dissertação

          * 2015-03-02, Doutoramento, Análise da composição corporal e remissão de comorbidezes em pacientes submetidos à gastroplastia redutora com derivação gastrojejunal em Y de Roux
          * 2009-03-15, Mestrado, Perfil nutricional e metabólico de pacientes com Lúpus Eritematoso Sistêmico de um centro de referência

        Livro

          * 2022, Guia Brasileiro de Nutrição na Cirurgia Bariátrica e Metabólica, 1, Silvia Pereira; Rossoni, Carina; Oliveira Magro, Daniéla, Dialético

        Capítulo de livro

          * 2023, Recorrência de peso: a importância da equipe multiprofissional – a visão do cirurgião, do nutricionista e do psicólogo. , Recorrência de Peso Pós Cirurgia Bariátrica , 1, 1, Editora dos Editores
          * 2023, Nutrição, Tratado da Doença Inflamatória Intestinal - Epidemiologia, Etiopatogenia, Diagnóstico e Tratamento, 1, 1, Atheuneu
          * 2023, Falhas nutricionais e a recorrência de peso, Recorrência de Peso Pós Cirurgia Bariátrica , 1, 1, Editora dos Editores
          * 2023, Abordagem dietoterápica após a recorrência ponderal., Recorrência de Peso Pós Cirurgia Bariátrica , 1, 1, Editora dos Editores
          * 2022, Procedimento bariátricos, Posicionamento sobre o tratamento nutricional do sobrepeso e da obesidade : departamento de nutrição da Associação Brasileira para o estudo da obesidade e da síndrome metabólica (ABESO), 1, 1, ABESO
          * 2022, Aspectos nutricionais do protocolo de recuperação em cirurgia bariátrica e metabólica – ERASBS, MANUAL DA RESIDÊNCIA DE NUTROLOGIA, OBESIDADE E CIRURGIA DA OBESIDADE, 1, 2, Manole
          * 2021, TRATAMENTO NUTRICIONAL NAS DOENÇAS INFLAMATÓRIAS INTESTINAIS, PRONUTRI PROGRAMA DE ATUALIZAÇÃO EM NUTRIÇÃO CLÍNICA Ciclo 10 Volume3, 3, 10.5935
          * 2021, Sarcopenia e Cirurgia Bariátrica, PRONUTRI - Programa de Atualização em Nutrição Clínica. , 4, 9, Artmed Panamericana
          * 2020, Nutrição Aplicada à Enfermagem - o desenvolvimento de práticas pedagógicas, Práticas de Ensino em Enfermagem, 1, 1, APPRIS Editora
          * 2020, Natural Product Based Nanomedicine: polym eric nanoparticles as delivery cargoes of food bioactives and nutraceuticals for anticancer purposes., Advances and Avenues in the Development of Novel Carriers for Bioactives and Biological Agents., 1, 1, United Kingdom: Elsevier
          * 2020, Grupos Terapêuticos na Ótica de Equipes Multiprofissionais na Área da Saúde Mental, Psicologia: Compreensão Teórica e Prática Clínica, 2, 1, Atena Editora

        Manual

          * 2022, Nutrição, Unoesc
          * 2020, Nutrição na Doenças Inflamatória Intestinal
          * 2001, Manual do Estagiário no Consultório de Nutrição , Editora Unijuí

        Artigo em conferência

          * Bypass gástrico de anastomose única (OAGB): análise sos sintomas gastrintestinais até 5 anos pós-operatório

        Resumo em conferência

          * 2023-10-02, ONE-ANASTOMOSIS TRANSIT BIPARTITION (OATB): MID-TERM RESULTS, XXVI IFSO World Congress Napoli 2023
          * 2017-03-21, Relação entre as dimensões de Burnout e o estado nutricional de enfermeiros, Anais de Medicina

        Prefácio / Posfácio

          * 2021, Não ao Reganho de Peso

        Outra produção

          * 2015-12-20, Planeamento de produção da confeitaria, SENAI Brasília
          * 2015-12-20, Planeamento de Produção na Panificação, SENAI Brasília
          * 2007-12-01, Atendimento Nutricional em Consultório de Nutrição. In: Guia Prático do Estagiário em Consultório de Nutrição

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona