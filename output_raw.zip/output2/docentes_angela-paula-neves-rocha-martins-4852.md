# Response for https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
          PT: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852 EN: https://www.ulusofona.pt/en/teachers/angela-paula-neves-rocha-martins-4852
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
        fechar menu : https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/angela-paula-neves-rocha-martins-4852
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          ângela Paula Neves Rocha Martins

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4852
              vet***@gmail.com
              FE1F-1DBF-6715: https://www.cienciavitae.pt/FE1F-1DBF-6715
              0000-0002-2521-2582: https://orcid.org/0000-0002-2521-2582
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/5a5d9063-4ab5-4e6e-9d01-4487aa23ee60
      : https://www.ulusofona.pt/

        Resume

        Ângela Paula Neves Rocha Martins. Concluiu MEDICINA VETERINÁRIA pela Universidade Técnica de Lisboa em 1991. É Diretora Clínica e Proprietária - HOSPITAL VETERINÁRIO DA ARRÁBIDA. Publicou 7 artigos em revistas especializadas e 5 trabalhos em actas de eventos. Possui 3 itens de produção técnica. Participou em 40 eventos no estrangeiro e 47 em Portugal. Orientou 7 dissertações de mestrado e co-orientou 8, alem de ter orientado 11 trabalhos de conclusão de curso de bach./licenciatura nas áreas de Outras Ciências Médicas e Ciências Veterinárias. Actua na área de Ciências Médicas com ênfase em Outras Ciências Médicas. Nas suas actividades profissionais interagiu com 20 colaboradores em co-autorias de trabalhos científicos.

        Graus

            * Licenciatura
              MEDICINA VETERINÁRIA
            * Curso médio
              Traumatología y Rehabiltación Ortopédica en Pequeños Animales
            * Curso médio
              Rehabilitation and Physiotherapy of Small Animals I
            * Pós-Graduação
              Dermatologia em Animais de Companhia
            * Pós-Graduação
              Endocrinologia em Animais de Companhia
            * Pós-Graduação
              Dermatologia em Animais de Companhia
            * Pós-Graduação
              Curso de Medicina Felina em Animais de Companhia
            * Pós-Graduação
              Neurologia em Animais de Companhia
            * Pós-Graduação
              Oftalmologia em Animais de Companhia
            * Pós-Graduação
              Oncologia em Animais de Companhia
            * Pós-Graduação
              Renal em Animais de Companhia
            * Pós-Graduação
              Respiratório em Animais de Companhia
            * Pós-Graduação
              Cirurgia de Animais de Companhia
            * Curso médio
              VIII Curso Prático de Anestesia de Raquis
            * Curso médio
              VII Curso Práctico de Anestesiologia para Veterinários
            * Curso médio
              Prácticas de Anestesia en Pequeños Animales
            * Curso médio
              Curso de Fisioterapia
            * Curso médio
              Medicina y Urgencias Felinas
            * Curso médio
              Curso Teórico – Prático avançado de Cirurgia dos Tecidos Moles
            * Curso médio
              Practical course in Orthopedics and Fracture Repair
            * Curso médio
              Practical course in Orthopedics and Fracture Repair
            * Curso médio
              Curso Teórico-Prático de Ecografia e Ecocardiografia
            * Curso médio
              Certified Canine Rehabilitation Practitioner Level 1 & 2
            * Curso médio
              VETERINARY ACUPUNCTURE
            * Pós-Graduação
              Cirurgia de Tecido Moles e Cirurgia Ortopédica e Neurológica
            * Curso médio
              Reabilitação Canina
            * Curso médio
              Curso de Neurología en Pequeños Animales
            * Curso médio
              Intensiv workshop Neurologie
            * Título de especialista
              Ciências de Animais de Laboratório
            * Postgraduate Certificate
              Hyperbaric Medicine Team Training for Animal Applications
            * Outros
              Aprendizagem de técnicas de preparação de terapias celulares para aplicação em alterações neurológicas e músculo-esqueléticas
            * Postgraduate Certificate
              Diretor de segurança hiperbárica
            * Postgraduate Certificate
              Sepsis as You Never Known It
            * Outros
              Formação “Pensamento Crítico, Modernização, Ensino e Avaliação”
            * Outros
              Formação “Zoom para Docentes”
            * Outros
              Formação “FUC + RUC + Assinatura Digital”

        Publicações

        Artigo em revista

          * 2024-03-13, Early Intensive Neurorehabilitation in Traumatic Peripheral Nerve Injury—State of the Art, Animals
          * 2024-01-20, The Role of Early Rehabilitation and Functional Electrical Stimulation in Rehabilitation for Cats with Partial Traumatic Brachial Plexus Injury: A Pilot Study on Domestic Cats in Portugal, Animals
          * 2023-09-14, Spinal shock in severe SCI dogs and early implementation of intensive neurorehabilitation programs, Research in Veterinary Science
          * 2023-07-13, Intensive neurorehabilitation and allogeneic stem cells transplantation in canine degenerative myelopathy, Frontiers in Veterinary Science
          * 2023-03-25, Clinical Occurrences in the Neurorehabilitation of Dogs with Severe Spinal Cord Injury, Animals
          * 2022-12-18, Approach to Small Animal Neurorehabilitation by Locomotor Training: An Update, Animals
          * 2022-09-11, Early Locomotor Training in Tetraplegic Post-Surgical Dogs with Cervical Intervertebral Disc Disease, Animals
          * 2022-06-16, Influence of Spinal Shock on the Neurorehabilitation of ANNPE Dogs, Animals
          * 2022-01-18, Hyperbaric Oxygen Therapy in Systemic Inflammatory Response Syndrome, Veterinary Sciences
          * 2021-10-25, Functional neurorehabilitation in a dog with acute non-compressive nucleus pulposus extrusion, Veterinary Record Case Reports
          * 2021-10-22, A Controlled Clinical Study of Intensive Neurorehabilitation in Post-Surgical Dogs with Severe Acute Intervertebral Disc Extrusion, Animals
          * 2021-08-19, Functional Neurorehabilitation in Dogs with an Incomplete Recovery 3 Months following Intervertebral Disc Surgery: A Case Series, Animals
          * 2021-07-03, Spinal Locomotion in Cats Following Spinal Cord Injury: A Prospective Study, Animals
          * 2021-07-01, A Comparison Between Body Weight-Supported Treadmill Training and Conventional Over-Ground Training in Dogs With Incomplete Spinal Cord Injury, Frontiers in Veterinary Science
          * 2021-05-30, Nervous system modulation through electrical stimulation in companion animals, Acta Veterinaria Scandinavica
          * 2020-08-14, Treatment of canine osteoarthritis with allogeneic platelet-rich plasma: review of five cases, Open Veterinary Journal
          * 2020, Reabilitação Funcional em Animais de Companhia, Ciências Agrárias e Veterinárias - Revista Didática UTAD (Universidade de Trás-Os-Montes E Alto Douro)
          * 2017, Review article- the importance of magnotherapy in functional rehabilitation, in a sub-analysis for pain , International Journal of Scientific Research
          * 2017, Muscular Spasticity Classification – Implementation of the Modified Ashworth Scale in Veterinary Functional Rehabilitation, International Journal of Scientific Research
          * 2017, Magnotherapy as Adjuvant Modality in Pain Management in Functional Rehabilitation, International Journal of Scientific Research
          * 2016, The role of spasticity in functional neurorehabilitation part II – non-pharmacological and pharmacological management – a multidisciplinary approach, Archives of Medicine
          * 2016, The role of spasticity in functional neurorehabilitation part I - the pathophysiology of spasticity, the relationship with neuroplasticity, spinalshock and clinical signs, Archives of Medicine
          * 2016, Preliminary report on the prevalence of Angiostrongylus vasorum infection in dogs from Portugal adopting a commercially available test kit for serological analysis, Veterinary Parasitology: Regional Studies and Reports
          * 2016, Functional Neurorehabilitation in Dogs with Cervical Neurologic Lesion, Journal of Veterinary Sciense & Technology
          * 2015, Functional neuro-reabilitation (NRF) in small animal practice, Journal of Veterinary Sciense & Technology
          * 2015, Bacterial and protozoal agents of canine vector-borne diseases in the blood of domestic and stray dogs from southern Portugal , Bacterial and protozoal agents of canine vector-borne diseases in the blood of domestic and stray dogs from southern
          * 2014, Índice de Choque como Indicador de Prognóstico em Animais de Companhia, Índice de Choque como Indicador de Prognóstico em Animais de Companhia
          * 2014, Reabilitação de um canídeo com paraplegia, Veterinária Atual
          * 2014, Bacterial and protozoal agents of feline vector-borne diseases in domestic and stray cats from southern Portugal, parasitesandvectors
          * 2010, Feline Leishmania infection in a canine leishmaniasis endemic region - Veterinary Parasitology 174 (2010) 336–340, Veterinary Parasitology

        Capítulo de livro

          * 2023, In vivo animal models, Multiscale Cell-Biomaterials Interplay in Musculoskeletal Tissue Engineering and Regenerative Medicine, ELSEVIERJ
          * 2023, In vivo animal models, Multiscale Cell-Biomaterials Interplay in Musculoskeletal Tissue Engineering and Regenerative Medicine, ELSEVIERJ
          * 2018, Escreveu o capítulo 50 “Controle neuromuscular do cão atleta” Martins, A e Ferreira, A. (p. 479-484) no livro “Fisiatria em pequenos animais” Lopes, R S. e Diniz, R.; Ed. São Paulo: Editora inteligente; ISBN: 978-85-85315-00-9; 2018 , Fisiatria em pequenos animais, 1, 1, Editora inteligente
          * 2018, Escreveu o capítulo 26 “Neuroreabilitação funcional em lesões medulares” Martins, A e Ferreira, A. (p. 287-298) no livro “Fisiatria em pequenos animais” Lopes, R S. e Diniz, R.; Ed. São Paulo: Editora inteligente; ISBN: 978-85-85315-00-9; 2018 , Fisiatria em pequenos animais, 1, São Paulo, Ed. São Paulo
          * 2018, Controle neuromuscular do cão atleta, Fisiatria em pequenos animais, 1, 1, São Paulo
          * 2018, Controle neuromuscular do cão atleta, Fisiatria em pequenos animais, 1, 1, Editora inteligente

        Revisão de livro

          * Very-Low-Frequency Spike–Wave Complex Partial Motor Seizure Mimicking Canine Idiopathic Head Tremor Syndrome in a Dog
          * The Dual PDE7-GSK3β Inhibitor, VP3.15, as Neuroprotective Disease-Modifying Treatment in a Model of Primary Progressive Multiple Sclerosis
          * Static Body Weight Distribution and Girth Measurements Over Time in Dogs After Acute Thoracolumbar Intervertebral Disc Extrusion
          * Prevalence, MRI findings, and clinical features of lumbosacral intervertebral disc protrusion in French Bulldogs diagnosed with acute thoracic or lumbar intervertebral disc extrusion
          * Partial vaginectomy, complete vaginectomy, partial vestibule-vaginectomy, vulvo-vestibule-vaginectomy and vulvo-vestibulectomy: different surgical procedure in order to better approach vaginal diseases
          * Ozone Therapy versus Hyaluronic Acid Injections for Pain Relief in Patients with Knee Osteoarthritis: Preliminary Findings on Molecular and Clinical Outcomes from a Randomized Controlled Trial
          * New Insight on Insulinoma Treatment in a Pet Rat—A Case Report
          * Multiple Undifferentiated Pleomorphic Sarcoma (Malignant Fibrous Histiocytoma) with Extradural Involvement in a 7-Year-Old Labrador Retriever
          * Molecular Hydrogen Positively Affects Physical and Respiratory Function in Acute Post-COVID-19 Patients: A New Perspective in Rehabilitation
          * Microendoscopic Mini-Hemilaminectomy and Discectomy in Acute Thoracolumbar Disc Extrusion Dogs: A Pilot Study
          * Microendoscopic Dorsal Laminectomy for Multi-level Cervical Intervertebral Disc Herniations in Dogs: A Pilot Study
          * Magnetic Resonance Imaging and Magnetic Resonance Imaging Cholangiopancreatography of the Pancreas in Small Animals
          * Long-Term Outcome after Cholecystectomy without Common Bile Duct Catheterization and Flushing in Dogs
          * Lateral Approach and Plate Rod Sliding Humeral Osteotomy in Dogs—A Short Case Series
          * Femoral Neck Thickness Index as an Indicator of Proximal Femur Bone Modeling
          * Evaluation of the diagnostic value of transcranial electrical stimulation (TES) to assess neuronal functional integrity in horses
          * Evaluation of Augmented Reality Surgical Navigation in Percutaneous Endoscopic Lumbar Discectomy: Clinical Study
          * Endoscopic Retrieval of Esophageal and Gastric Foreign Bodies in Cats and Dogs: A Retrospective Study of 92 Cases
          * Efficient Topical Treatment of Canine Nodular Sebaceous Hyperplasia with a Nitric Acid and Zinc Complex Solution
          * Efficacy of Medical Ozone as an Adjuvant Treatment in Dog with Intervertebral Disc Protusions-A Retrospective Study
          * Effects of SKCPT on Osteoarthritis in Beagle Meniscectomy and Cranial Cruciate Ligament Transection Models
          * Effects of Neuromuscular Electrical Stimulation and Therapeutic Ultrasound on Quadriceps Contracture of Immobilized Rats
          * Effect of a Corset on the Gait of Healthy Beagle Dogs
          * Effect of Rehabilitation in a Dog with Delayed Recovery following TPLO: A Case Report
          * Effect of Physiotherapy and Treadmill Exercise in a Dog with Delayed Rehabilitation Following TPLO: A Case Report
          * Effect of Nail Grips on Weight Bearing and Limb Function in 30 Dogs 2 Weeks Post Tibial Plateau Leveling Osteotomy
          * Effect of Femoral Head and Neck Osteotomy on Canines¿ Functional Pelvic Position and Locomotion¿
          * Effect of Comprehensive and Integrative Medical Services on Patients with Degenerative Lumbar Spinal Stenosis: A Pilot Study
          * Comparison between Areas of Bone Visualization Using Radiolucent Hybrid Fixator Frames and Graphically Simulated Metallic Frames: An Ex Vivo Study
          * Combined laser-activated SVF and PRP remodeled spinal sclerosis via activation of Olig-2, MBP, and neurotrophic factors and inhibition of BAX and GFAP
          * Clinical Case of Feline Leishmaniosis: Therapeutic Approach and Long-Term Follow-Up
          * Canine Mesenchymal Stromal Cell Exosomes: State-of-the-Art Characterization, Functional Analysis and Applications in Various Diseases
          * Assessment of Dorsiflexion Ability across Tasks in Persons with Subacute SCI after Combined Locomotor Training and Transcutaneous Spinal Stimulation
          * A Prospective, Blinded, Open-Label Clinical Trial to Assess the Ability of Fluorescent Light Energy to Enhance Wound Healing after Mastectomy in Female Dogs
          * A Prospective, Blinded, Open-Label Clinical Trial to Assess the Ability of Fluorescent Light Energy to Enhance Wound Healing after Mastectomy in Female Dogs
          * A Controlled Trial of Polyglytone 6211 versus Poliglecaprone 25 for Use in Intradermal Suturing in Dogs

        Artigo em jornal

          * 2021-10-10, Effects of hyperbaric oxygen therapy on wound healing in veterinary medicine: A pilot study

        Artigo em conferência

          * Wet Lab - Vestibular techniques, 9Th International Symposium on Veterinary Rehabilitation and Physical Therapy
          * Uma Área de Reabilitação Animal – A Neuroreabilitação Funcional, IV Congresso Internacional de Enfermagem Veterinária
          * The Prognostic Value of Abnormal Coagulation Times in Dogs that are at Risk of Developing Sepsis, 24th International Veterinay Emergency & Critical Care Symposium (IVECCS-18)
          * Poster - Functional Neurorehabilitation in dogs with peripheral vestibular syndrome, 9Th International Symposium on Veterinary Rehabilitation and Physical Therapy
          * Physical Medicine and Rehabilitation of Dogs with Periferic Vestibular Syndrome, 5th Animal Health and Veterinary Medicine Congress
          * Neuroreabilitação Funcional – Quando, Porquê e Como!!!! Será uma solução?, XIV Congresso Veterinário
          * Neuroreabilitação Funcional como ferramenta fundamental na recuperação do doente neurológico pós-cirúrgico. Sim ou não?, XIV Congresso Veterinário
          * Medicina Física e Reabilitação Animal, IV Congresso Internacional de Enfermagem Veterinária
          * Leishmania infection in cats from three canine leishmaniasis endemic foci from Portugal, XIII Congresso Hospital Veterinário de Montenegro
          * Implementação do método de diagnóstico molecular da mielopatia degenerativa canina, XIV Congresso Veterinário do Hospital Veterinário do Montenegro
          * Hyperglycemia and Concurrent Hyperlactatemia as Prognostic Indicators in Dogs with Systemic Inflammatory Response Syndrome/Sepsis , International Veterinary Emergency & Critical Care Symposium (IVECCS) 2017
          * Functional neuro-reabilitation (NRF) in small animal practice, 2nd Indo-Global Summit & Expo on Veterinary
          * Functional Neurorehabilitation in Dogs with Cervical Neurologic Lesion, 5th Animal Health and Veterinary Medicine Congress
          * Functional Neurorehabilitation Scale for Dogs with Thoracolombar Spinal Cord Injury without Deep Pain Sensation, 31º Annual Symposium of the ESVN-ECVN (The European Society of Veterinary Neurology - The European College of Veterinary Neurology), Copenhaga
          * Evaluación de la Eficacia de la Neurorrehabilitación Funcional en Enfermedades no compresivas de la Medula Espinal, XVII Congreso de Especialidades Veterinarias
          * Development of a Basic Functional Neurorehabilitation Scale (BFNRS) for evaluation and monitoring of dogs with thoracolumbar injury, 10th International Symposium on Veterinary Rehabilitation and Physical Therapy 2018
          * Controlo da Dor e Analgesia, Controlo da Dor e Analgesia
          * 2019-06-24, Application of spinal cord transcutaneous electrical stimulation in T3-L3 in paraplegic dogs without deep pain perception , RehabWeek 2019
          * Evaluation of Functional NeuroRehabilitation Effect: Dog Thoracolumbar Intervertebral Disc Disease Study, BSAVA World Congress 2017

        Resumo em conferência

          * 2015, Functional Rehabilitation of Musculoskeletal Disorders Shockwave Therapy and Locomotor Training Association, 4th VEPRA (Veterinary European Physical Therapy and Rehabilitation Association) Conference
          * 2015, Functional Rehabilitation in Grade 0 Paraplegic Patients , 4th VEPRA (Veterinary European Physical Therapy and Rehabilitation Association) Conference

        Poster em conferência

          * 2024-04-13, The role of electrical stimulation in agility or work dogs after ANNPE, ACVSMR SYMPOSIUM 2024
          * 2024-03-23, POCUS in triage and monitoring of a peritoneopericardial diaphragmatic hernia in a dog, BSAVA CONGRESS 2024
          * 2023-10-13, Rehabilitation and physical therapy in a cat with post-traumatic hip fracture with peripheral nerve injury, XIX Congresso de Medicina Veterinária, Hospital Veterinário do Montenegro, Santa Maria da Feira, Portugal. 13 a 14 de Outubro de 2023;
          * 2023-10-13, Kinematic analysis in dogs with spinal reflex locomotion, . XIX Congresso de Medicina Veterinária, Hospital Veterinário do Montenegro, Santa Maria da Feira, Portugal. 13 a 14 de Outubro de 2023
          * 2023-10-13, Early funcional neurorehabilitation in a post-surgery of a cat diagnosed with melanoma, . XIX Congresso de Medicina Veterinária, Hospital Veterinário do Montenegro, Santa Maria da Feira, Portugal. 13 a 14 de Outubro de 2023
          * 2023-10-08, Influence of spinal shock on the neurorehabilitation of contusive spinal cord injury dogs, 62nd International Spinal Cord Society Annual Scientific Meeting (ISCoS 2023). Edimburgo, Escócia. 08 a 11 de Outubro de 2023
          * 2023-09-24, Multidisciplinary therapeutic protocolo for pressure sores in severe spinal cord injury dogs, Rehabweek 2023, Singapura, 24 a 28 de Setembro de 2023
          * 2022-11-05, 4-Aminopyridine safety in acute post-surgical dogs with intervertebral disc herniation by extrusion without deep pain perception, XVIII Congresso de Medicina Veterinária, XII Congresso de Enfermagem Veterinária. Hospital Veterinário do Montenegro, Santa Maria da Feira, Portugal. 4 a 5 de Novembro de 2022
          * 2022-10-31, Hyperbaric oxygen therapy in sirs positive dogs, 47thWorld Small Animal Veterinary Association Congress& XVIII FIAVAC Congress (WSAVA 2022). Lima, Perú, 29 a 31 de Outubro de 2022
          * 2022-09-18, Intensive functional neurorehabilitation in chronic spinal cord injury dogs, 61st International Spinal Cord Society Annual Scientific Meeting (ISCoS 2022). Vancouver, Canadá. 15 a 18 de Setembro de 2022
          * 2022-08-20, Long-term follow-up in osteoarthritis dogs after a multimodal functional rehabilitation protocol with intra-articular allogenic stem cells, 11 th Symposium for the International Association of Veterinary Rehabilitation and Physical Therapy. Cambridge, Reino Unido,18 e 20 de Agosto de 2022
          * 2022-07-29, Intensive Neurorehabilitation in Dogs with Severe Acute Intervertebral Disc Extrusion, Rehabweek 2022, Roterdão, Países Baixos, 25 a 29 de Julho 2022
          * 2021-10-02, Intensive functional neurorehabilitation of 84 Paraplegic dogs affected by spinal cord injury, 60th ISCoS Annual Scientific Meeting – ISCoS (International Spinal Cord Society Annual Scientific)
          * 2019-06-08, Abnormalities on Respiratory Examination Thoracic Radiographs and Veterinary Point of Care Ultrasound in Shelter Dogs, 18th Annual European Veterinary Emergency and Critical Care Congre. Talin Creative Hub,Estónia, 6 a 8 Junho 2019
          * 2019-06-06, Abnormalities on Respiratory Examination Thoracic Radiographs and Veterinary Point of Care Ultrasound in Shelter Dogs, 18th Annual European Veterinary Emergency and Critical Care Congress em Talin Creative Hub, 6 a 8 Junho 2019, Talin, Estonia
          * 2019-02-22, Neuroreabilitação Funcional em Casos de Doença Degenerativa do Disco Intervertebral, XV Congresso Hospital Veterinário Montenegro, Santa Maria da Feira, Portugal, 22 a 24 de Fevereiro de 2019;
          * 2019-02-22, Estudo Preliminar de Neuroreabilitação Espondilomielopatia Cervical em Cães, XV Congresso Hospital Veterinário Montenegro, Santa Maria da Feira, Portugal. 22 a 24 de Fevereiro de 2019
          * 2018-09-22, Functional Neurorehabilitation Scale for Dogs with Thoracolombar Spinal Cord Injury without Deep Pain Sensation, 31º Annual Symposium of the ESVN-ECVN (The European Society of Veterinary Neurology–The European College of Veterinary Neurology), Copenhaga, Dinamarca. 20 a 22 de Setembro de 2018;
          * 2018-09-18, The Prognostic Value of Abnormal Coagulation Times in Dogs that are at Risk of Developing Sepsis, 24th International Veterinay Emergency & Critical Care Symposium (IVECCS-18), College of Veterinay Emergency & Critical Care e Academy of Veterinary Emergency & Critical Care Technicians, Nova Orleans, Louisiana, Estados Unidos da América. 14 a 18 Setembr
          * 2018-04-21, Evaluación de la Eficacia de la Neurorrehabilitación Funcional en Enfermedades no compresivas de la Medula Espinal, XVII Congreso de Especialidades Veterinarias 2018 AVEPA (Asociación de Veterinarios Españoles Especialistas en Pequeños Animales). Hotel Melia, Madrid, Espanha. 20 e 21 de Abril de 2018.
          * 2017-09-17, Hyperglycemia and Concurrent Hyperlactatemia as Prognostic Indicators in Dogs with Systemic Inflammatory Response Syndrome/Sepsis, IVECCS (International Veterinary Emergency & Critical Care Symposium) 2017. Gaylord Opryland Nashville, Tennessee, Estados Unidos da América, 13 a 17 de Setembro de 2017
          * 2017-08-12, Functional Neurorehabilitation in Dogs with Peripheral Vestibular Syndrome, 9Th International Symposium on Veterinary Rehabilitation and Physical Therapy - IARVT (International Association for Veterinary Rehabilitation and Physical Therapy), Uppsala, Suécia, 8 a 12 de Agosto de 2016
          * 2017-04-29, Nuevo Enfoque en la Neurorehabilitatión Veterinária, XVI Congreso de Especialidades Veterinarias, Bilbao. 28 e 29 de Abril 2017
          * 2017-04-29, Monitorización del Entrenamiento Locomotor em Rehabilitación Funcional, XVI Congreso de Especialidades Veterinarias, Bilbao. 28 e 29 de Abril 2017
          * 2017-04-29, Escala de Puntos Gatillo em Rehabilitación Funcional, XVI Congreso de Especialidades Veterinarias, Bilbao. 28 e 29 de Abril 2017
          * 2017-04-09, Evaluation of Functional Neurorehabilitation Effect: Dog Thoracolumbar Intervertebral Disc Disease Study, BSAVA (British Small Animal Veterinary Association) World Congress. Birmingham, Reino Unido. 06 e 9 Abril 2017
          * 2015-09-20, Functional Rehabilitation of Musculoskeletal Disorders Shockwave Therapy and Locomotor Training Association, 4th VEPRA (Veterinary European Physical Therapy and Rehabilitation Association) Conference, Gdansk, Polónia.19 a 20 Setembro de 2015
          * 2015-09-20, Functional Rehabilitation in Grade 0 Paraplegic Patients, 4th VEPRA (Veterinary European Physical Therapy and Rehabilitation Association) Conference, Gdansk, Polónia. 19 a 20 Setembro 2015
          * 2013-02-24, Maneio Pós Cirúrgico de Enfermagem de um Caso de Estenose Pilórica Congénita, IX Congresso Veterinário, Hospital Veterinário do Montenegro, Santa Maria da Feir. Portugal 23 e 24 de Fevereiro de 2013
          * 2013-02-24, Emergências respiratórias felinas - abordagem nas primeiras 24 horas em 13 casos clínicos, IX Congresso Veterinário. Hospital Veterinário do Montenegro, Santa Maria da Feira, Portugal. 23 e 24 de Fevereiro de 2013
          * 2011-10-16, Hidroterapia em Fisioterapia Veterinária, 2º Congresso Internacional de Enfermagem Veterinária Auditório Prof. Abílio Lima de Carvalho, Instituto Politécnico de Viana do Castelo, 14 e 16 de Outubro de 2011
          * 2011-02-13, Reabilitação com hidroterapia no pós-operatório de hérnia discal Hansen tipo I apresentação de 6 casos clínicos, VII Congresso Veterinário, Hospital Veterinário do Montenegro, Santa Maria da Feira. Portugal 12 e 13 de Fevereiro de 2011

        Invenção

          * 2019-05-25, Oradora no curso CCRP (Certified Canine Rehabilitation Practitioner), organizado pelo CRAA (Centro de Reabilitação Animal da Arrábida) e HVA (Hospital Veterinário da Arrábida), com a certificação e colaboração da The University of Tennessee & Schloss-Seminar dos Estados Unidos da América. Vila Nogueira de Azeitão, Portugal, 25 a 29 de Maio de 2018
          * 2019-05-06, Oradora na palestra do curso “Intensive workshop “Neurologie mit Physiotherapie” com os temas “Functional neurorehabilitation in paraplegic patients”; “From lower motor neuron disease to upper motor neuron disease neurorehabilitation”; e “Practice of neurorehabilitation techniques”. Medizinische Kleintierklinik – Munique Alemanha,6 a 10 Maio de 2019
          * 2018-10-05, Palestrante no 1º Simpósio Internacional de Reabilitação Animal, realizado pelo IBRA (Instituto Brasileiro de Reabilitação Animal), com 20 horas de carga horária. Auditório Plug, São Paulo, Brasil, 5 a 7 de Outubro de 2018.

        Outra produção

          * 2022-07-05, Cervical Spondylomyelopathy also known as Wobbler Syndrome - part II/II, Realizou um webinar com o título "Cervical Spondylomyelopathy also known as Wobbler Syndrome - part II/II" no VAHL - Veterinary Academy of Higher Learning em 5 de Julho de 2022
          * 2022-06-14, Cervical Spondylomyelopathy also known as Wobbler Syndrome - part I/II, Realizou um webinar com o título "Cervical Spondylomyelopathy also known as Wobbler Syndrome - part I" no VAHL - Veterinary Academy of Higher Learning em 14 de Junho de 2022
          * 2021-11-05, Overview of neurozoonosis diseases and neurorehabilitation, Realizou um webinar com o título “Overview of neurozoonosis diseases and neurorehabilitation” através da VAHL • Veterinary Academy of Higher Learning dia 5 de Novembro de 2021
          * 2020-09-21, Neuroreabilitação na Mielopatia Degenerativa, Realizou um webinar com o título “Neuroreabilitação na Mielopatia Degenerativa” através do IBRA Brasil, 21 de Setembro de 2020
          * 2020-07-21, Lower motor neuron injuries – are they better than upper motor neuron? What can we improve? , Realizou um webinar com o titulo “Lower motor neuron injuries – are they better than upper motor neuron? What can we improve? através da Veterinary Academy of Higher Learning, 21 de Julho de 2020
          * 2020-07-07, A cat is not a dog, but they also should have access to neurorehabilitation, Realizou um webinar de pequenos animais com o título “A cat is not a dog, but they also should have access to neurorehabilitation” através da Veterinary Academy of Higher Learning, 7 de Julho de 2020
          * 2020-06-04, Reabilitação Funcional, Realizou um webinar de pequenos animais com o título “Reabilitação Funcional” através da Kimipharma, 4 de Junho de 2020
          * 2020-05-26, Vestibuar Syndrome - Diagnosis and What to Do, Realizou um webinar de pequenos animais com o título “Vestibuar Syndrome - Diagnosis and What to Do” através da Veterinary Academy of Higher Learning, 26 de Maio de 2020
          * 2020-05-19, O mundo da reabilitação funcional e a sua aplicação, Realizou um webinar com o título “O mundo da reabilitação funcional e a sua aplicação” através Webinar VetCesman-Hills-APMVEAC Reabilitação funcional, 19 de Maio de 2020
          * 2020-04-28, Functional Neurorehab, Realizou um webinar de pequenos animais com o título “Functional Neurorehab” através da Veterinary Academy of Higher Learning, 28 de Abril de 2020
          * 2020-01-15, Osteoartrite: Processo Degenerativo: Qual o Caminho? e Qual o Futuro?, Palestrante no Centro de Reabilitação Animal da Arrábida (CRAA) com o título “Osteoartrite: Processo Degenerativo: Qual o Caminho? e Qual o Futuro?”, V. N. Azeitão, Portugal, 15 de Janeiro de 2020
          * 2019-10-04, III ENEMV (Encontro Nacional de Estudantes de Medicina Veterinária), Palestrante e formadora no III ENEMV (Encontro Nacional de Estudantes de Medicina Veterinária), Universidade de Coimbra, Coimbra, Portugal, 4 a 6 de Outubro de 2019
          * 2019-09-29, XXII Jornadas Internacionais de Medicina Veterinária na Universidade de Trás-os-Montes e Alto Douro, XXII Jornadas Internacionais de Medicina Veterinária na Universidade de Trás-os-Montes e Alto Douro, Vila Real, Portugal, 29 e 30 de Setembro de 2019
          * 2019-07-04, Reabilitação funcional: Neurologia, Ortopedia e cães desportivos, Lecionou a formação de Reabilitação funcional: Neurologia, Ortopedia e cães desportivos, Novotel Wroclaw City, Wroclaw, Polonia, 4 a 7 de Julho 2019
          * 2019-06-08, Incidence of Z, I and B Lines Detected with Point of Care Ultrasound in Healthy shelter Dogs, Efectuou uma comunicação oral “Incidence of Z, I and B Lines Detected with Point of Care Ultrasound in Healthy shelter Dogs” no 18th Annual European Veterinary Emergency and Critical Care Congress em Talin Creative Hub, 6 a 8 Junho 2019, Talin, Estonia
          * 2019-05-30, Neuroreabilitação Funcional Avançada, Administrou o Curso Intensivo de Neuroreabilitação Funcional Avançada, realizado pelo IBRA – Instituto Brasileiro de Recursos Avançados, com carga horária de 24 horas, São Paulo, Brasil, 30 de Maio a 01 de Junho de 2019.
          * 2018, “Therapy for Functional Neurological Rehabilitation”
          * 2018, “Rehabilitation for Vestibular Problems”
          * 2018, Workshop em Neuroreabilitação Funcional
          * 2018, Palestrante em Neuroreabilitação Funcional
          * 2017, Oradora no tema “Functional neurorehabilitation in paraplegic patients” em Medizinische Kleintierklinik
          * 2017, Oradora no tema “From lower motor neuron disease to upper motor neuron disease neurorehabilitation” em Medizinische Kleintierklinik - Munique
          * 2017, Oradora no tema "Practice of neurorehabilitation techniques” - Medizinische Kleintierklinik – Munique
          * 2017, Oradora - “Neurorreabilitação funcional das doenças de NMI às doenças NMS”
          * 2017, Oradora - "Sports dog – From a neurology perspective" no 5ª Conferência do VEPRA (Veterinary European Physical Therapy and Rehabilitation Association)
          * 2017, Oradora - "Neurorreabilitação funcional em paraplégias: da locomoção voluntária à locomoção fictícia"
          * 2017, Lecionou o Workshop “Rehabilitation in neurologic patients: laser and therapeutic exercices
          * 2017, Lecionou o Workshop “Cinesioterapia”
          * 2017, Lecionou Workshop “Modalidades de reabilitação veterinária”
          * 2017, CCRP (Certified Canine Rehabilitation Practitioner)
          * 2017, Apresentou“Sciatic nerve peripheral lesion in politraumatized dogs” na 5ª Conferência do VEPRA (Veterinary European Physical Therapy and Rehabilitation Association)
          * 2017, Apresentou “Functional neurorehabilitation in polyradiculoneuritis: Spasticity vs Flaccidity” na 5ª Conferência do VEPRA (Veterinary European Physical Therapy and Rehabilitation Association)
          * 2017, Apresentou “Diathermy application in fibrotic join contractures in animal functional rehabilitation" na 5ª Conferência do VEPRA (Veterinary European Physical Therapy and Rehabilitation Association)
          * 2017, Apresentou "Extracorporeal shock waves therapy integrated in a fuctional rehabilitation protocol for viable non-union treatment" - 5ª Conferência do VEPRA (Veterinary European Physical Therapy and Rehabilitation Association)
          * 2016, “Novas abordagens novas modalidades de reabilitação e aplicação à prática clínica” - I Jornadas de Reabilitação Veterinária e Medicina Regenerativa, Universidade de Trás os Montes e Alto Douro, Vila Real, Portugal
          * 2016, Formadora - I Jornadas de Reabilitação Veterinária e Medicina Regenerativa - Universidade de Trás-os-Montes e Alto Douro
          * 2016, “Exame de reabilitação ortopédico funcional e as doenças mais comuns” - I Jornadas de Reabilitação Veterinária e Medicina Regenerativa, Universidade de Trás os Montes e Alto Douro
          * 2015, Palestrante no IV Congresso Internacional de Enfermagem Veterinária, “Uma Área de Reabilitação Animal – A Neuroreabilitação Funcional” – Instituto Politécnico de Castelo Branco, Castelo Branco
          * 2015, Oradora no OMICS International Conference - Hyderabad, India
          * 2015, Oradora nas I Jornadas de Enfermagem Veterinária do Monte Selvagem com o tema “Reabilitação Funcional em Novos Animais de Companhia”
          * 2015, Oradora na 6ª Edição – Vetbizz (Encontro Anual de Gestão Veterinária) – Num Caso Prático
          * 2015, Formadora no Curso - Medicina Física e Reabilitação Animal, no IV Congresso Internacional de Enfermagem Veterinária - Instituto Politécnico de Castelo Branco
          * 2015, Formadora no Curso - Fisioterapia em Técnicas Avançadas: Massagens, Hidroterapia e LASER - Escola Superior Agrária de Elvas e Hospital Veterinário da Arrábida
          * 2014, Oradora da palestra “Neurologia e Reabilitação Funcional” – X Congresso da OMV - V Encontro de Formação OMV �� 29 e 30 de Novembro a em Lisboa (Centro de Congressos de Lisboa)
          * 2014, Neurologia e Reabilitação Funcional - Centro de Congressos de Lisboa
          * 2014, I Curso Prático de Enfermagem Veterinária em Emergência na UCI - Escola Superior Agrária de Elvas
          * 2014, Formadora no Curso “Fisioterapia em Técnicas Avançadas: Massagens, Hidroterapia e LASER” – 22 e 23 de Novembro (Módulo I) na Escola Superior Agrária de Elvas e 6 e 7 de Dezembro de 2014 (Módulo II) no Hospital Veterinário da Arrábida
          * 2014, A reabilitação veterinária em desordens do movimento em Pequenos Animais - Universidade do Porto no ICBAS (Instituto de Ciências Biomédicas Abel Salazar)
          * 2013, Técnicas de Transfusão Sanguínea em Canídeos na Enfermagem Veterinária
          * 2013, Reabilitação em Medicina Veterinária de uma Poliradiculoneurite num Canídeo
          * 2013, Maneio Pós Cirúrgico de Enfermagem de um Caso de Estenose Pilórica Congénita
          * 2013, Laser de Classe IV em Enfermagem Veterinária
          * 2013, Fisioterapia em Técnicas Avançadas: Massagens, Hidroterapia e LASER - Escola Superior Agrária de Elvas e Hospital Veterinário da Arrábida
          * 2013, Emergências Respiratórias Felinas
          * 2012, REABILITAÇÃO COM HIDROTERAPIA NO PÓS-OPERATORIO DE HÉRNIA DISCAL HANSEN TIPO I
          * 2012, Atualização diagnóstica do hipotiroidismo canino

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona