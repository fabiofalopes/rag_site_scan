# Response for https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
          PT: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025 EN: https://www.ulusofona.pt/en/teachers/ana-rita-conde-dias-5025
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
        fechar menu : https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-rita-conde-dias-5025
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ana Rita Conde Dias

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5025
              rit***@ulusofona.pt
              EB12-5474-70F3: https://www.cienciavitae.pt/EB12-5474-70F3
              0000-0003-4493-5388: https://orcid.org/0000-0003-4493-5388
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/1c3cfd00-f4cf-4186-bc25-f33abc1dbb89
      : https://www.ulusofona.pt/

        Resume

        Ana Rita Conde Dias. Concluiu o(a) Doutoramento em Doutoramento em Psicologia da Justiça em 2012 pelo(a) Universidade do Minho, Mestrado em Psicologia em 2007 pelo(a) Universidade do Minho e Licenciatura em Psicologia em 2000 pelo(a) Universidade do Minho. É Professora auxiliar na licenciatura em Psicologia e nos mestrados em Psicologia Clínica e da Saúde e em Psicologia da Justiça Sub-diretora do mestrado em Psicologia da Justiça no(a) Universidade Lusófona do Porto. Publicou 20 artigos em revistas especializadas. Possui 1 livro(s). Recebeu 5 prémio(s) e/ou homenagens. Atua na(s) área(s) de Ciências Sociais com ênfase em Psicologia. No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural são: MESTRADO EM PSICOLOGIA DA JUSTIÇA; PSICOLOGIA; PSICOLOGIA FORENSE; VITIMAÇÃO; RECLUSOS; INFÂNCIA; PSYCHOLOGY; FORENSIC PSYCHOLOGY; VICTIMISATION; INMATES; CHILDHOOD; Construcionismo social; Cultura; Género; Violência conjugal; Agressividade feminina; Amor; Discursos socio-culturais; Violência na intimidade; Vitimação feminina; Female victimization; Female aggressiveness; Intimate violence; Love; Sociocultural; Discourses; amor; violência; construcionismo social; cultura; MESTRADO EM PSICOLOGIA CLÍNICA E DA SAÚDE; PSICOLOGIA CLÍNICA; DIVÓRCIO; PARENTALIDADE; HISTÓRIAS DE VIDA; CLINICAL PSYCHOLOGY; DIVORCE; PARENTHOOD; LIFE STORIES; VIOLÊNCIA; VIOLENCE; Construcionismo social; Cultura; Género; Violência conjugal; PSICOLOGIA CRIMINAL; JOVENS INSTITUCIONALIZADOS; DELINQUÊNCIA JUVENIL; PORTUGAL; CRIMINAL PSYCHOLOGY; INSTITUTIONALIZED YOUNG PEOPLE; JUVENILE DELINQUENCY; DECISÕES JUDICIAIS; HOMICÍDIO; ACÓRDÃOS; ENTREVISTAS; JUDICIAL DECISIONS; HOMICIDE; JUDGEMENTS; INTERVIEWS; Vitimação; Criminalidade; Ofensores; vitimação prisional ; métodos qualitativos; .

        Graus

            * Licenciatura
              Psicologia
            * Mestrado
              Psicologia
            * Doutoramento
              Doutoramento em Psicologia da Justiça

        Publicações

        Pré-impressão

          * 

        Artigo em revista

          * 2023-12-07, Exploring the Relationship between Capacity to Love and Well-being: A Comparative Study of Emerging Adults and Middle-aged Adults, Sexuality & Culture
          * 2023-06-16, Inclusive tourism and children with a diagnosis of autism spectrum disorders: Systematic review of the literature, European Journal of Tourism Research
          * 2023-05-05, Análise narrativa e investigação qualitativa em Psicologia: porquê e como fazer, Revista Psicologia, Diversidade e Saúde
          * 2023, The impact of imprisonment on individuals’ mental health and society reintegration: study protocol
          * 2023, The impact of imprisonment on individuals’ mental health and society reintegration: study protocol
          * 2023, Relaxing in virtual reality: one synthetic agent relaxes all, Virtual Reality
          * 2021-03-01, How to assess emotional recognition in individuals with a diagnosis of schizophrenia and other psychotic disorders: a pilot study, Current Psychology
          * 2021, Virtual reality-based cognitive stimulation on people with mild to moderate dementia due to alzheimer’s disease: A pilot randomized controlled trial, International Journal of Environmental Research and Public Health
          * 2021, Psychological intervention with victims of prison violence: a systematic literature review, Annales of Psychology
          * 2021, Psychological intervention with victims of prison violence: A systematic literature review,Intervención con víctimas de violencia penitenciaria: Revisión sistemática de la literature, Anales de Psicologia
          * 2021, Ethical decision-making training goes virtual
          * 2019-09-18, Alexithymia among long-term drug users: a pilot study in Oporto., Journal of Psychology & Clinical Psychiatry
          * 2019-08-08, Victimization and psychopathology prevalece’s in a sample of inmates in Cape Verde.
          * 2019, Mental health and victimization: an exploratory study in prisons of Cape Verde, Journal of Psychology & Clinical Psychiatry
          * 2018, Narratives of Those Who “Love” Violently: Identity Issues and Construction of Meaning of the Batterers, Journal of Humanistic Psychology
          * 2018, Delinquência juvenil em Portugal: estudo qualitativo das histórias de vida de jovens reclusos, Revista Psicologia, Diversidade e Saúde
          * 2017-11-06, La perpetuación del comportamiento antisocial de los jóvenes caboverdianos: un estudio predictivo, Actualidades en Psicología
          * 2015, Multiple victimization and social exclusion: a grounded analysis of the life stories of women, Journal of Humanistic Psychology
          * 2014-07-02, Discursos socioculturais sobre o amor em Portugal: Um percurso geracional?, PSICOLOGIA
          * 2014-02-01, Relações de intimidade juvenis e adultas, uma análise comparativa: Das narrativas de amor às conjugalidades violentas, PSICOLOGIA
          * 2014-01-02, Violência conjugal: Representações e significados no discurso mediático, PSICOLOGIA
          * 2014, International self-report delinquency (ISRD3): tradução e adaptação ao contexto cabo-verdiano
          * 2013, Lifetime multiple victimization among women: A systematic review of the literature | Vitimação múltipla feminina ao longo da vida: Uma revisão sistemática da literatura, Psicologia e Sociedade
          * 2012, Repertórios interpretativos sobre o amor e as relações de intimidade de mulheres vítimas de violência : Amar e ser amado violentamente?
          * 2012, Prevalência, significações e prevenção na violência nas relações juvenis de intimidade: um projecto integrado de investigação., Global Journal of Community Psychology Practice.
          * 2012, Interpretative repertoires about love and intimate relationships of women victims of violence: To love and be loved violently? | Repertórios interpretativos sobre o amor e as relações de intimidade de mulheres vítimas de violência: Amar e ser amado violentamente?, Analise Psicologica
          * 2012, From "Chastity As a Gift" to "Doing It As a Sign of Love": A Longitudinal Analysis of the Discourses on Female Sexuality in Popular Magazines in Portugal, SAGE Open
          * 2011, To love violently: From essentialist approaches to love as a performance | Amor e violência na intimidade: Da essência à construção social, Psicologia e Sociedade
          * 2011, Amor e violência na intimidade: da essência à construção social
          * 2010, Marital violence: Representations and meanings in the media discourse
          * 2008, Representações da mulher no discurso mediático, de 1965 à actualidade., Psicologia: Teoria, Investigação e Prática.
          * 2008, Género e violência conjugal: Uma relação cultural, Análise Psicológica
          * 2007, Child and partner abuse: Self-reported prevalence and attitudes in the north of Portugal, Child Abuse & Neglect

        Tese / Dissertação

          * 2019, Mestrado, A decisão judicial nos casos de violência conjugal: um estudo qualitativo com acórdãos de quatro comarcas
          * 2018, Mestrado, Vitimação na infância, vitimação prisional e desajustamento psicológico na população reclusa em Portugal: o papel da vitimação direta na infância
          * 2018, Mestrado, Vitimação indireta na infância, violência prisional e psicopatologia: um estudo com a população reclusa em Portugal
          * 2018, Mestrado, O processo de divórcio e a coparentalidade: um estudo qualitativo com pais divorciados
          * 2017, Mestrado, Jovens “delinquentes” institucionalizados em Portugal : um estudo qualitativo das suas histórias de vida
          * 2017, Mestrado, As teorias explicativas sobre o crime de homicídio na decisão judicial - uma análise comparativa entre o discurso dos magistrados e os acórdãos
          * 2017, Mestrado, Análise comparativa entre as histórias de vida de jovens delinquentes e de jovens “normativos”: serão assim tão diferentes?

        Livro

          * 2018, The Use of Grounded Analysis in Life Stories of Victims of Violence: Uncovering Discourses, Rita Conde; Marlene Matos, {SAGE

        Capítulo de livro

          * 2022, Turismo Náutico Inclusivo Dirigido a Crianças com Diagnóstico de Perturbação do Espectro Autista (PEA): Potencialidades, Turismo Náutico: A gestão sustentável dos recursos hídrico-fluviais, culturais e naturais , Instituto Politécnico de Tomar
          * 2021, VR-based assessment and intervention of cognitive functioning after stroke
          * 2018, Quando também nos matam: Intervenção com familiares de vítimas de homicídio intrafamiliar, Violência, agressão e vitimação: práticas para a intervenção, Almedina
          * 2016, Desigualdad y asímetria de género en el amor y la intimidade: Cuando las mujeres víctimas recurren a la violência., Mujeres en riesgo de exclusión social. Una perspectiva transnacional., Dykinson
          * 2014, Vitimação cumulativa em contexto prisional: Modelos explicativos e respostas de intervenção., Vitimas de crime e violência: Práticas de intervenção.
          * 2014, Mulheres portuguesas nativas vs. imigrantes: Trajetórias de vitimação múltipla., Mujeres en riesgo de exclusión social y violencia de género., Imprenta Kadmos
          * 2014, Mulheres multiplamente vitimadas: desafios e especificidades, Psiquilibrios
          * 2013, Vítimas de violência conjugal: Intervenção multicultural com mulheres marginalizadas., Almedina
          * 2013, Gender and domestic violence in Portugal: Intervention practices and their effects., Teaching against Violence. Reassessing the toolbox: Teaching with gender. European women¿s studies in international and interdisciplinary classrooms, AtGender Publications
          * 2013, Females victims of violence: From knowledge to practice., Teaching against Violence reassessing the toolbox: Teaching with Gender, European Women’s Studies in International and Interdisciplinary Classrooms., European Association for Gender Research & Central European University Press
          * 2011, Violência sexual na intimidade: dos discursos dos media aos discursos e práticas dos jovens., Jovens e Rumos. , Imprensa de Ciências Sociais
          * 2011, Avaliação psicológica de agressores conjugais., Manual de Psicologia Forense: Contextos, práticas e desafios., Psiquilibrios
          * 2011, Avaliação de agressores sexuais. , Manual de Psicologia Forense: Contextos, práticas e desafios.
          * 2011, Abordagens Culturais à vitimação: O caso da violência conjugal., GUIMARÃES ROSA: novas perspectivas, Psiquilibrios
          * 2010, Culture and wife abuse: An overview of theory, research and practice., International Handbook of Victimology., Taylor and Francis
          * 2007, Abordajes inter-culturales de la violencia familiar: Teoría e Investigación.

        Artigo em conferência

          * 2021-09-09, Synthetic agents: relaxing agents?, 13th International Conference on Disability, Virtual Reality & Associated Technologies
          * 2021-09-09, Interviewing a Virtual Patient: Exploring patterns in clinical interviewing of psychologists, 13th International Conference on Disability, Virtual Reality & Associated Technologies

        Resumo em conferência

          * 2021, Inclusive tourism and children with autism spectrum disorders (ASD): a systematic review of the literature, International online Conference Smart, Sustainable, Social and Accessible Tourism (SSAT 2021)
          * 2017, Quando os juízes são vítimas de crime: Uma análise crítica do discurso., 6º Congresso Ibero-Americano em Investigação Qualitativa e do 2nd International Symposium on Qualitative Research.
          * 2017, Histórias de vida de jovens delinquentes: O contributo da investigação qualitativa para a compreensão da Delinquência Juvenil., 6º Congresso Ibero-Americano em Investigação Qualitativa e do 2nd International Symposium on Qualitative Research.

        Outra produção

          * 2020-07-01, VREthics, VR simulator for training psychology students used by Ordem dos Psicólogos Portugueses - OPP
          * 2014, Multiple victimisation in socially excluded women: from prevalence to meanings, Studies about violence against women usually fail to account the multiple nature of victimisation. This study aims to characterize the phenomenon of multiple victimisation in a sample of 41 socially excluded women. In the quantitative study, results showed a high number of experiences of victimisation suffered throughout life, with a higher prevalence in adulthood perpetrated by partners. In the q
          * 2010, Culture and Wife Abuse, International Handbook of Victimology

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona