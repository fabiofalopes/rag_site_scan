# Response for https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
          PT: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156 EN: https://www.ulusofona.pt/en/teachers/antonio-neves-duarte-teodoro-156
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
        fechar menu : https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/antonio-neves-duarte-teodoro-156
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          António Neves Duarte Teodoro

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p156
              a.t***@ulusofona.pt
              1413-99DE-E077: https://www.cienciavitae.pt/1413-99DE-E077
              0000-0001-7819-0498: https://orcid.org/0000-0001-7819-0498
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/da7e7107-bc54-472f-946c-9add81bb188c
      : https://www.ulusofona.pt/

        Resume

        António Teodoro is Full Professor of Sociology of Education and Comparative Education at Lusofona University, Lisbon, Director of Institute of Education, and scientific coordinator of the Interdisciplinary Research Centre for Education and Development (CeiED). He has a Bachelor on Physical Education (INEF 1972), a Master and a PhD in Education Sciences (NOVA University 1989 and 1999). He also has Provas de Agregação at Comparative Education (Lusofona 2009). In 1974, he was one of the young navy officer who put an end to the dictatorships that shamed Europe, thus allowing the democratization of Portugal and the independence of its African colonies. He also actively participated in the democratization of education, namely as Chief-Inspector of Primary Education in the revolutionary period (1974 - 1975). He was a founding member of the teachers' union movement (1971-1974), President of the Board of the Lisbon Region Teachers' Union SPGL (SPGL 1979-1989), and Secretary General of the National Teachers' Federation, (FENPROF 1983-1994), the largest Portuguese teachers' union. At international level, he was a member of the European Committee of the World Confederation of Organizations of the Teaching Profession, CMOPE/WCOTP (1988-1992) and of the European Committee of Education International (1993-1994). Teodoro was founder-member of the Portuguese National Education Council (1988 ¿ 1994), and later consultant to the Council of Ministers for Education, Training, Culture and Science (1995-1999) of the Cabinet of the then Prime Minister António Guterres, the current UN General Secretary. After returning to university and academic life exclusively, he did his PhD with a thesis on the Political Construction of Education in the 19th and 20th centuries, and developed an intense academic and scientific activity, at the University and at national and international level. At Lusofona University, he founded the Institute of Education and was the conceptualizer and first director of the Bachelor's Degree in Educational Sciences (1997), the Master's Degree in Educational Sciences (1998) and the Doctorate in Education (2007). In 1997, he also founded the Observatory of Education Policies and Education Contexts, the first R&D Unit, predecessor of the Interdisciplinary Research Centre for Education and Development (CeiED). Teodoro contributed to a high level of internationalization of the social sciences of education. He is a co-founder of Portuguese Paulo Freire Institute and one of the founders of the Portuguese Society of Comparative Education. Now, he is member of the Executive Committee of the World Council of Comparative Education Societies (WCCES). Before this, for more than 10 years, he was a member of the Board and Vice-President for Europe of the Research Committee of Sociology of Education of the International Sociological Association (ISA). Regarding his R&D activities, after 2007 Teodoro coordinated the Ibero-American Network for Education Policy Research (RIAIPE), first, with the support of CYTED (OEI 2007-2010), and secondly with the founding of the European Commission (Alfa 2010-2013. As researcher, he has wide experience in leading and participating in FCT-funded projects. The last one: 2018-2022, A success story? Portugal and the PISA. Teodoro is a member of the Scientific Council of the Education Doctoral Programme of Masaryk University, Czech Republic, and evaluator of the National Science Centre, from Poland, CONICYT, from Chile, and Agencia I+D+i, from Argentina. He is the founding director of Revista Lusófona de Educação (the most international education journal published in Portugal) and member of the Editorial Board of dozens of journals in Portugal, Brazil, US (including the American Journal of Educational Research), Czech Republic and France. His scientific production in English, French, Spanish and Portuguese has a high impact (h index 29, i10 Index 64, 4045 citations, in 26/01/2024).

        Graus

            * Licenciatura
              Teacher of Physical Education / Professores de Educação Física
            * Mestrado
              Education Sciences, Specialisation in Education and Development / Ciências da Educação, Especialização em Educação e Desenvolvimento
            * Outros
              Programme de Chercheurs Invités
            * Outros
              História / History
            * Título de Agregado
              Education Sciences. Comparative Education
            * Doutoramento
              PhD Education Sciences / Doutoramento em Ciências da Educação

        Publicações

        Magazine article

          * 2010-12-17, Diagnóstico a exigir mais audácio, Jornal de Letras/Educação
          * 2010-08-19, Desporto escolar. Para uma planificação das actividades desportivas no ensino secundário, Cadernos de Educação Física
          * 2008-12-19, Horizonte com... António Teodoro, Horizonte. Revista de Educação Física e Desporto
          * 2008-10-01, Pedagogia do Oprimido. Dedo na Ferida, Revista Educação
          * 1993-12-01, Educação, factor estratégico para o desenvolvimento nacional, Jornal da FENPROF
          * 1985-12-01, Depoimento sobre o Desporto de Alta Competição, Horizonte. Revista de Educação Física e Desportos

        Journal issue

          * Editorial, Revista Lusófona de Educação, 54
          * Editorial da Revista Lusófona de Educação

        Journal article

          * 2024-01-12, Why Did Portugal Enter PISA? Divergent Political Views, the National Agenda and the OECD Push, European Education
          * 2024, Why did Portugal enter PISA? Divergent political views, the national agenda and the OECD push, European Education
          * 2021-06-30, The OECD again: legitimization of a new vocationalism in the educational policies in Portugal (1979–1993), Paedagogica Historica
          * 2021, Editorial, Revista Lusofona de Educacao
          * 2021, Editorial, Revista Lusofona de Educacao
          * 2021, Editorial, Revista Lusofona de Educacao
          * 2020-06-29, PISA, TIMSS e PIRLS em Portugal: Uma análise comparativa , Revista Portugesa de Educação
          * 2020, PISA, TIMSS e PIRLS em Portugal: Uma análise comparativa: PISA, TIMSS and PIRLS in Portugal: A comparative analysis
          * 2020, Editorial, Revista Lusofona de Educacao
          * 2020, Editorial, Revista Lusofona de Educacao
          * 2020, Editorial, Revista Lusofona de Educacao
          * 2020, Editorial, Revista Lusofona de Educacao
          * 2020, A dialogue about Education and University: an interview with Antonio Teodoro, Revista Eletronica Pesquiseduca
          * 2019-09-30, A Sociologia da Educação em Portugal. Do conhecimento das realidades a discursos paralelos, Revista de Sociología de la Educación-RASE
          * 2019-04-29, The end of isolationism: examining the OECD influence in Portuguese education policies, 1955–1974, Paedagogica Historica
          * 2019-02-22, Critical Discourse Analysis: Between Educational Sciences and Journalism, Fronteiras: Journal of Social, Technological and Environmental Science
          * 2019, Editorial, Revista Lusofona de Educacao
          * 2019, Editorial, Revista Lusofona de Educacao
          * 2019, Editorial, Revista Lusofona de Educacao
          * 2019, Editorial
          * 2019, Editorial
          * 2019, Editorial
          * 2019, Apresentação
          * 2018-09-01, University rankings: between market regulation and the diffusion of organizational models. The Brazilian case, Revista LUsófona de Educação
          * 2018, Educação e Poder: como se escolhe um Ministro? Apontamentos para a História da Educação em Portugal (1955-1976), Investigar em Educação
          * 2018, Editorial, Revista Lusofona de Educacao
          * 2018, Editorial, Revista Lusofona de Educacao
          * 2018, Editorial, Revista Lusofona de Educacao
          * 2017-08-24, A EDUCAÇÃO SUPERIOR EM TEMPOS DE MUDANÇA NA AMÉRICA LATINA E NA EUROPA: ANOTAÇÕES PARA UMA AGENDA ALTERNATIVA, Laplage em Revista
          * 2017, Vers l'analyse des résistances aux normes éducatives issues de la globalisation, Education et sociétés
          * 2017, Vers l'analyse des résistances aux normes éducatives issues de la globalisation, Education et Societes
          * 2017, Présentation du dossier, Education et Societes
          * 2017, Medir la educación:perspectivas desde la crítica sociológica, RASE:Revista de la Asociación de Sociología de laEducación
          * 2017, La medida de la calidad educativa: acerca de los rankings universitarios, RASE:Revista de la Asociación de Sociología de laEducación
          * 2017, Editorial, Revista Lusofona de Educacao
          * 2017, Editorial, Revista Lusofona de Educacao
          * 2017, Editorial, Revista Lusofona de Educacao
          * 2017, Editorial, Revista Lusofona de Educacao
          * 2017, A educação superior em tempos de mudança na América Latina e na Europa: anotações para uma agenda alternativa
          * 2017, A educação superior em tempos de mudança na América Latina e na Europa: anotações para uma agenda alternativa
          * 2017, A EDUCAÇÃO SUPERIOR EM TEMPOS DE MUDANÇA NA AMÉRICA LATINA E NA EUROPA: ANOTAÇÕES PARA UMA AGENDA ALTERNATIVA, Laplage Em Revista
          * 2016, Governando por números: os grandes inquéritos estatísticos internacionais e a construção de uma agenda global nas políticas de educação. Em Aberto, 29(96), 41-52. Disponível em, Em Aberto
          * 2016, Governando por números: os grandes inquéritos estatísticos internacionais e a construção de uma agenda global nas políticas de educação
          * 2016, European and Latin American Higher Education Between Mirrors : Designing possible futures
          * 2016, Editorial, Revista Lusofona de Educacao
          * 2016, A reconfiguração da gestão da coisa pública face à emergência de processos participativos centrados no cidadão: o caso do orçamento participativo de Palmela
          * 2016, A reconfiguração da gestão da coisa pública face à emergência de processos participativos centrados no cidadão: O caso do orçamento participativo de Palmela, Educação, Sociedade & Culturas
          * 2016, A construção da educação mundial ou o lugar da Educação Comparada no estudo das políticas (e práticas) de educação, Revista Brasileira de Pós-Graduação
          * 2016, A construção da educação mundial ou o lugar da Educação Comparada no estudo das políticas (e práticas) de educação
          * 2016, 1ª Conferência SPCE-SEC A Educação Comparada para além dos números: contextos locais, realidades nacionais, processos transnacionais (Reseña), Revista Latinoamericana de Educación Comparada, 9, pp. 104-107.
          * 2015, European and Latin American higher education between mirrors. Designing possible futures | Enseignement supérieur Européen et latin-américain entre miroirs. La conception de futurs possible | Ensino superior Europeu e latino-americano entre espelhos. Projetar futuros possíveis | Educación superior en Europa y en América latina entre espejos. Diseño de futuros posibles, Revista Lusofona de Educacao
          * 2015, European and Latin American higher education between mirrors. Designing possible futures , Revista Lusofona de Educacao
          * 2015, A universidade no século XXI. Desenhando futuros possíveis, Universidades
          * 2014, The evolution of the Technical Drawing and the division of the industrial labor, in the global core and periphery | L’évolution du Dessin Technique et de la division du travail industriel: Entre le centre et la périphérie dans le monde | Evolução do Desenho Técnico e a divisão do trabalho industrial: Entre o centro e a periferia mundial, Revista Lusofona de Educacao
          * 2014, Evolução do Desenho Técnico e a divisão do trabalho industrial: entre o centro e a periferia mundial, Revista Lusófona de Educação
          * 2014, Evolução do Desenho Técnico e a divisão do trabalho industrial: entre o centro e a periferia mundial
          * 2014, Critique et utopie, ou une pédagogie de la possibilité dans la construction de politiques d¿éducation démocratiques
          * 2014, Critique et utopie, ou une pédagogie de la possibilité dans la construction de politiques d?éducation démocratiques, Revista Lusófona de Educação
          * 2014, Critique and utopia, or a pedagogy of possibility in the building of democratic educational policies | Critique et utopie, ou une pédagogie de la possibilité dans la construction de politiques d'éducation démocratiques, Revista Lusofona de Educacao
          * 2014, A Educação Superior na Europa e América Latina. Propostas para uma Universidade cidadã no século XXI, Revista Argentina de Educación Superior (RAES)
          * 2013, Educação Superior e Inclusão. Tendências e desafios no século XXI, Revista Temas em Educação
          * 2012, Redes institucionais na América Latina: construindo as Ciências Sociais e a Educação, Revista Lusófona de Educação
          * 2012, Políticas de formação docente na Bahia: Uma análise a partir de pressupostos da teoria social de Habermas. , Revista Brasileira de Pesquisa sobre Formação de Professores, 3(3), 65-85.
          * 2012, Editorial
          * 2011, ‘A fortuna é de que a agarrar’. A Rede Iberamericana de Investigação em Políticas de Educação, Revista de la Associacion de Sociologia de la Educación
          * 2011, Untitled - Editorial, Gynecologic and Obstetric Investigation
          * 2011, RIAIPE3 - Programa Marco Interuniversitário para uma Política de Equidade e Coesão Social na Educação Superior, Revista Lusófona de Educação
          * 2011, Programa Marco Interuniversitário para uma Política de Equidade e Coesão Social na Educação Superior, RIAIPE 3, RAES, Revista Argentina de Educação Superior
          * 2011, Contemporary Themes in the Sociology of Education. International Journal of Contemporary Sociology, International Journal of Contemporary Sociology
          * 2011, A "nova classe média" e o mandato atribuído à escola: Um olhar sobre artigos de opinião publicados na imprensa portuguesa, Educação, Sociedade & Culturas
          * 2010, In Memoriam - Rogerio Fernandes' death: the loss of a resercher, a teacher and a friend Rogerio Fernandes University professor has works published, Revista Lusofona de Educacao
          * 2010, Educando para a Liberdade. A natureza da educação carcerária e a (re)socialização de presidiários, Educação, Sociedade & Culturas
          * 2010, Do fim dos eleitos ao processo de bolonha: as políticas de educação superior em portugal (1970-2008)/ From the end of the elected to the bologna process: the higher education policy in portugal (1970-2008).
          * 2010, Do fim dos eleitos ao processo de Bolonha: as políticas de educação superior em Portugal (1970-2008), Ensino em Re-Vista-.
          * 2010, Curriculum policy in Portugal (1995-2007): global agendas and regional and national reconfigurations, Journal of Curriculum Studies
          * 2010, Compreender, agir, mudar, incluir : da investigação-acção à educação inclusiva, Revista Lusófona de Educação
          * 2010, A morte de Rogério Fernandes: a perda de um Investigador, de um Professor e de um Amigo, Revista Lusófona de Educação
          * 2009, O diálogo na construção das identidades docentes: Significados e caminhos para a construção de uma escola instituinte, Revista Brasileira de Formação de Professores
          * 2009, De menina a mestra: memórias do curso de formação feminina
          * 2009, A “lenda” ou história da borboleta: os movimentos sociais e a educação – o caso do movimento dos trabalhadores rurais sem terra e a educação do campo
          * 2009, A "lenda" ou história da borboleta: os movimentos sociais e a educação - o caso do Movimento dos Trabalhadores Rurais Sem-Terra e a educação do campo, EccoS Revista Científica
          * 2009, A "Lenda" ou História da Borboleta: Os Movimentos Sociais e a Educação - o caso do Movimento dos Trabalhadores Rurais Sem Terra e a Educação do Campo, EccoS. REvista Científica
          * 2008, Education in Times of Globalisation: Modernization and Hybridism in the Educational Policies in Portugal, International Journal of Contemporary Sociology
          * 2008, Editorial
          * 2008, EDUCATION IN TIMES OF GLOBALIZATION. MODERNIZATION AND HYBRIDISM IN EDUCATIONAL POLICIES IN PORTUGAL, Revista Iberoamericana de Educacion
          * 2008, As Políticas Curriculares em Portugal (1995-2007). Agendas Globais e Reconfigurações Regionais e Nacionais, Revista Espaço do Currículo
          * 2008, A política educativa da União Europeia. O processo de unionização no contexto de globalização. Revista Iberoamericana de Educación, 48, 93-110., Revista Iberoamericana de Educación
          * 2007, Revolution and Utopia. A program of action in education for a society on the road to socialism - Portugal 1975, Revista Lusofona de Educacao
          * 2007, Procurando indicadores de educação inclusiva: as práticas dos professores de apoio educativo
          * 2007, Nouvelles modalités de régulation transnationale des politiques éducatives., Carrefours de lÃ©ducation
          * 2007, Nouvelles modalités de régulation transnationale des politiques éducatives. Évidences et possibilités, Carrefours de l'Éducation
          * 2007, Educational Policies and New Forms of Transnational Regulation. Evidences and possibilities | Nouvelles modalités de régulation transnationale des politiques éducatives. Évidences et possibilités, Carrefours de l'Education
          * 2007, Education in times of Globalisation. The modernization and hybridism in the educational policies in Portugal, Revista Lusofona de Educacao
          * 2007, Editorial, Revista Lusófona de Educação
          * 2007, Editorial, Revista Lusófona de Educação
          * 2007, A Educação em tempos de Globalização. Modernização e hibridismo nas políticas educativas em Portugal
          * 2006, Editorial, Revista Lusófona de Educação
          * 2006, Editorial, Revista Lusófona de Educação
          * 2006, Da integração à inclusão escolar: cruzando perspectivas e conceitos
          * 2006, A reforma universitária: dos riscos às possibilidades, Janus - Anuário de Relações Exteriores
          * 2006, A reforma universitária: dos riscos às possibilidades
          * 2005-01-01, Mandato e legitimação nas políticas para a educas, REVISTA PERSPECTIVA
          * 2005, Editorial, Revista Lusófona de Educação
          * 2005, Editorial, Revista Lusófona de Educação
          * 2004, Um olhar sobre o Brasil: Desafios na Educação, Fênix. Revista Pernambucana de Educação Popular e de Educação de Adultos
          * 2004, Mobilização educativa em tempos de crise revolucionária. Periferia e centro no processo de democratização das escolas (1974-1976), Revista Portuguesa de Educação
          * 2004, Mobilização educativa em tempos de crise revolucionária. Periferia e centro no processo de democratização das escolas (1974-1976), Revista Portuguesa de Educação
          * 2004, Editorial, Revista Lusófona de Educação
          * 2003, É possível uma política de educação à esquerda? Uma reflexão sobre possibilidade e esperança na acção política, Revista Lusófona de Educação
          * 2003, É possível uma política de educação à esquerda? Uma reflexão sobre a possibilidade e esperança na acção política
          * 2003, É possive uma política de edução à esquerda? Una reflexão sobre sobre possibilidade e esperança no acção política, Revista Lusófona de Educação
          * 2003, Paulo Freire, or Pedagogy as the Space and Time of Possibility:Reading Freire and Habermas: Critical Pedagogy and Transformative Social Change;Reinventing Paulo Freire: A Pedagogy of Love;The Freirean Legacy: Educating for Social Justice, Comparative Education Review
          * 2003, Paulo Freire, or Pedagogy as the Space and Time of Possibility, Comparative Education Review
          * 2003, Educação e políticas educativas no Portugal contemporâneo: da construção do modelo escolar ao tesouro a descobrir, Revista Lusófona de Educação
          * 2003, Educação e políticas educativas no Portugal contemporâneo: Da construção do modelo escolar ao tesouro a descobrir, Revista Lusófona de Educação
          * 2003, Editorial, Revista Lusófona de Educação
          * 2003, Editorial, Revista Lusófona de Educação
          * 2003, Auto-representações das funções das professoras, Revista Lusófona de Educação
          * 2003, Auto-representações das Funções das Professoras na Escola
          * 2003, Auto-representaçaõ de profesores: a realidade brasileira em análise, Revista Lusófona de Educação
          * 2002, As novas formas de regulação transnacional no campo das políticas educativas, ou uma globalização de baixa intensidade, EccoS. Revista científica Centro Universitário Nove de Julho
          * 2002, As novas formas de regulação transnacional no campo das políticas educativas, ou uma globalização de baixa intensidade
          * 2002, As novas formas de regulação transnacional no campo das políticas educativas, ou uma globalização de baixa intensidade, EccoS Revista Científica
          * 2000, O fim do isolacionismo. Da participação de Portugal no Plano Marshall ao Projecto Regional do Mediterrâneo, Revista de Humanidades e Tecnologias
          * 1999, Políticas educativas: considerações breves sobre a transdisciplinaridade de um campo de estudo, Revista de Humanidades e Tecnologias
          * 1999, Os Programas dos Governos Provisórios no campo da Educação. De uma intenção de continuidade com a reforma Veiga Simão à elaboração de um programa para uma sociedade a caminho do socialismo, Educação, Sociedade & Culturas
          * 1998, Unificação ou diversificação? Notas sobre a evolução do ensino secundário em Portugal, 1970-1990, Educació i Història, Societat d’Història dels Paisos de Llengua Catalana
          * 1998, O tempo dos professores?, Arquipélago. Perspectivas e debates
          * 1996, Sete reflexões sobre as raízes do atraso educativo português, Revista Educação e Ensino
          * 1995, Reforma educativa ou a legitimação do discurso sobre a prioridade educativa, Educação, Sociedade & Culturas
          * 1994, Da Profissionalização da Actividade Docente à Crise de Identidade dos Professores. Considerações Preliminares para um estudo da Situação Portuguesa, Boletim da Sociedade Portuguesa de Educação Física
          * 1993, Escola e Comunidade. A complementaridade necessária, Revista Educação e Ensino
          * 1992, Uma acção sindical renovada num mundo em transformação, para mudar a escola e valorizar a profissão docente, Universidade e Sociedade
          * 1991, Os Professores Face à Reforma Educativa. Considerações (datadas) sobre a Situação Portuguesa, Boletim da Sociedade Portuguesa de Educação Física
          * 1991, A formação contínua e o desenvolvimento profissional dos professores, Revista Educação
          * 1990, Um Estatuto que não serve a Educação, Revista Educação
          * 1990, Sobre o mal-estar na profissão docente e a construção de uma identidade profissional nos professores, O Professor
          * 1990, O professor e a criação de meios estimulantes de aprendizagem. Um breve apontamento a propósito do filme de Peter Weiss O Clube dos Poetas Mortos, O Professor
          * 1990, Autonomia, vazio social e sindicalismo docente - a propósito de um texto de Yves Barel 'Aspiration à l'autonomie et vide social, Vértice
          * 1989, Política de confronto com a Lei de Bases, Cadernos de Economia
          * 1985, Educação e desenvolvimento. O papel dos professores e das suas organizações na luta pelo desenvolvimento e o progresso social, O Professor
          * 1979, Sobre las calificaciones escolares y profesionales de los trabajadores portugueses, Revista de la UIE sobre la Democratización y Reforma de la Enseñanza
          * 1979, Em torno da problemática da moderna ciência histórica, O Professor
          * 1975, O Ensino no Século XIX Português, Seara Nova

        Thesis / Dissertation

          * 2021, Master, Educação profissional integrada ao ensino médio : obstáculos e desafios da implantação nas escolas da rede estadual do Espírito Santo
          * 2018, PhD, A face jurídico-legal da transnacionalização da educação superior no Brasil – o caso Laureate/FMU
          * 2018, Master, O ensino superior militar em Portugal e Angola. Um estudo sobre as academias da força aérea portuguesa e angolana
          * 2016, PhD, Políticas públicas de mobilidade acadêmica internacional: um estudo exploratório do dia a dia do aluno brasileiro na cidade de Lyon-França
          * 2015, PhD, Os grupos de estudo do pessoal docente do ensino secundário, 1969-1974: as raízes do sindicalismo docente
          * 2015, PhD, Entre o sonho e a esperança : uma análise do programa escola ativa no Brasil
          * 2015, PhD, Aprender a decidir em tempos de escola: a formação superior e a aprendizagem da tomada de decisão no processo de cuidados
          * 2015, PhD, Alquimia do conhecimento: a construção do conhecimento curricular em Portugal (1970-2009)
          * 2014, PhD, A escola e a exclusão social: consequências do fracasso escolar nos percursos de vida de jovens e adultos pouco escolarizados dos meios populares da zona da mata de Pernambuco- Brasil
          * 2014, PhD, A educação conta? : ensino profissional e estratégias de mobilidade social em jovens das cidades de Barcelona e Lisboa um estudo comparado
          * 2013, PhD, Olhar a Escola pelos artigos de opinião : da parentocracia à meritocracia ou um mandato da nova classe média
          * 2013, PhD, Entre Sísifo e Prometeu: lideranças, orçamento participativo e cidadania. As representações de uma líder autárquica no desvelar de uma cidade educadora
          * 2012, PhD, O círculo de eranos: a experiência da educação do campo ou como os contextos podem gerar
          * 2011, PhD, Desenho Técnico e Formação de Trabalhadores da Indústria Automóvel : um estudo comparado entre Portugal e Brasil
          * 2011, Master, A educação básica em Inhambupe - BA: um estudo avaliativo sobre as políticas públicas no município (2001 – 2005)
          * 2010, PhD, As autarquias e a educação. Centro e periferia na construção das políticas educativas (1998-2008)
          * 2010, Master, Educação sem instrução promove a cuia mão : um estudo sobre as relações entre o ensino médio e o mercado de trabalho em Inhambupe - BA
          * 2009, Master, Tecnologias de informação e comunicação (TIC) nas escolas : da idealização à realidade : estudos de casos múltiplos avaliativos realizado em escolas públicas do ensino médio do interior paraibano brasileiro
          * 2009, Master, Metamorfoses em espelho de água : identidade, perfil, contextos e mudança nas (auto)representações dos professores
          * 2009, Master, Formação técnica no ensino médio e demanda estudantil: um estudo no curso profissionalizante em edificações
          * 2009, Master, Da educação de adultos à educação e formação de adultos : o sistema de reconhecimento, validação e certificação de competências em Portugal
          * 2008, Master, Formação inicial em serviço: análise do programa da URCA na percepção dos professores – alunos
          * 1999, PhD, A construção social das políticas educativas: estado, educação e mudança social no Portugal contemporâneo
          * 1992, Master, Educação, desenvolvimento e participação política dos professores: contributo para uma análise crítica da política educativa portuguesa dos anos oitenta

        Book

          * 2023, Repressão Estudantil e Ação Psicológica no Final do Estado Novo. A história esquecida do CDI (1966-1974), 1, Teodoro, A., Edições Universitárias Lusófonas
          * 2022, Critical Perspectives on PISA as a Means of Global Governance, Teodoro, António, Routledge
          * 2020, Contesting the global development of sustainable and inclusive education: Education reform and the challenges of neoliberal globalization, Teodoro, A.
          * 2020, Contesting the Global Development of Sustainable and Inclusive Education: Education Reform and the Challenges of Neoliberal Globalization , Teodoro, António, Routledge
          * 2018, O outro lado do espelho: percursos de investigação (CeiED 2013-2017), Benavente, Ana; Teodoro, António; Serrão, Jacinto; Brás, José Gregório Viegas; Gonçalves, Maria Neves; Martins, Jorge; Figueira, Eduardo Álvaro do Carmo; et al, Edições Universitárias Lusófonas
          * 2018, Beyond Mirrors: research pathways (CeiED 2013-2017), Costa, Carlos Smaniotto; Bovelet, Jan; Dolata, Kai; Menezes, Marluci; Moutinho, Mário Caneva; Primo, Judite Santos; Rechena, Aida; et al, Edições Universitárias Lusófonas
          * 2014, Introduction, Teodoro, A.; Guilherme, M.
          * 2014, European and Latin American higher education between mirrors, Teodoro, A.; Guilherme, M.
          * 2014, Conclusion, Teodoro, A.; Guilherme, M.
          * 2011, A educação em tempos de globalização neoliberal. Os novos modos de regulação das políticas educacionais, 1, Teodoro, António, Liber Livro
          * 2010, Educação, Globalização e Neoliberalismo. Os novos modos de regulação transnacional das políticas de educação., 1, Teodoro, António, Edições Universitárias Lusófonas
          * 2006, Professores, para quê? Mudanças e desafios na profissão docente, 1, Teodoro, António, Profedições
          * 2004, Globalització i Educació. Polítiques educatives i noves formes de govern, 1, Teodoro, António, Ediciones del Crec
          * 2003, Globalização e Educação. Políticas educacionais e novos modos de governação, 1, Teodoro, António, Cortez Editora
          * 2003, Globalização e Educação. Políticas Educacionais e Novos Modos de Governação, 1, Teodoro, António, Edições Afrontamento
          * 2002, As Políticas de Educação em discurso directo (1955-1995), 1, Teodoro, António, Instituto de Inovação Educacional
          * 2001, A Construção Política da Educação. Estado, Mudança Social e Políticas Educativas no Portugal Contemporâneo, 1, Teodoro, António, Edições Afrontamento
          * 1997, Poder e Participação em Educação, 1, Teodoro, António, Edições Universitárias Lusófonas
          * 1994, Política Educativa em Portugal. Educação, Desenvolvimento e Participação Política dos Professores, 1, Teodoro, António, Bertrand Editora
          * 1994, A Carreira Docente. Formação, Avaliação, Progressão, 1, Teodoro, António, Texto Editora
          * 1990, Os Professores. Situação Profissional e Carreira Docente, 1, Teodoro, António, Texto Editora
          * 1984, Guia Prático do Sistema Educativo, 1, Teodoro, António; Fernandes, Graça; Teodoro, Vítor Duarte, Plátano Editora
          * 1982, O Sistema Educativo Português. Situação e perspectivas, 1, Teodoro, António, Livros Horizonte
          * 1978, A Revolução Portuguesa e a Educação, 1, Teodoro, António, Editorial Caminho
          * 1977, Sobre as Qualificações escolares e profissionais dos trabalhadores portugueses, 1, Teodoro, António, Seara Nova
          * 1976, Perspectiva do Ensino em Portugal, 1, Teodoro, António, Cadernos O Professor
          * 1974, Professores: que vencimentos?, 1, Teodoro, António, Autor/ Revista O Professor

        Book chapter

          * 2023, Trajectories and challenges of the section of comparative education of the portuguese society of education sciences, Brill Sense Book Series
          * 2022, Teaching National Languages as an Instrument of inclusion and Unification in Angola , Brill
          * 2022, Introduction: A success story? Critical perspectives on PISA as a means of global governance, Critical Perspectives on PISA as a Means of Global Governance, Routledge
          * 2022, Introduction. A success story? Critical perspectives on PISA as a means of global governance, Critical Perspectives on PISA as a Means of Global Governance, Routledge
          * 2022, Conclusion. Limitations and risks of an OECD global governance project, Critical Perspectives on PISA as a Means of Global Governance, Routledge
          * 2022, European and Latin American researchers between mirrors. The internationalization of higher education for social cohesion and equity, A Framework for Critical Transnational Research Advancing Plurilingual, Intercultural, and Inter-epistemic. Collaboration in the Academy, 1, 1, Routledge
          * 2021, Paulo Freire Hoje. Itinerários do Pensamento de Paulo Freire na Educação do Século XXI. , Paulo Freire. Vozes do Brasil e de Portugal., 1, Editora Fibra / Edições Brasil / Editora Brasília
          * 2020, Prefácio, Identidades, Paco Editorial
          * 2020, Las “dos culturas” en la Educación Comparada: ¿Un diálogo (im)posible? , Educación comparada. Tendencias teóricas y empíricas internacionales y nacionales , Plaza y Valdés Editores, S. A. de C. V.
          * 2020, A OCDE e o sonho de uma governação mundial da educação. Pressupostos e análise crítica , Transferencia, transnacionalización y transformación de las políticas educativas (1945-2018), FahrenHouse
          * 2019, Teaching Comparative Education in Portugal, Encyclopedia of Teacher Education, Springer Singapore
          * 2018, Universidade Lusofona de Humanidades Tecnologias, Educación Superior y Formación del Profesorado: Gobernanza y Política Social, Pertinencia Curricular e Innovacíon Docente, Institut de Creativitat i Innovacions Educatives de la Universitat de València
          * 2018, Introdução. Percursos de investigação, entre a austeridade e a incerteza , Edições Universitárias Lusófonas
          * 2018, Introduction. Research paths between austerity and uncertainty, Beyond Mirrors: research pathways (CeiED 2013-2017), Edições Universitárias Lusófonas
          * 2016, Rankings universitários: entre a regulação do mercado e a difusão de modelos organizacionais – o caso brasileiro. In A. Del Vecchio & E. Santos (Orgs.). Educação Superior no Brasil: modelos e missões institucionais (pp. 33-56). S. Paulo: BT Acadêmica. ISBN: 978-85-9485-013-3, Educação Superior no Brasil: modelos e missões , BT Académica
          * 2016, La construcción política de la educación en el Escenario Europeo, Educación Comparada. La dialéctica de lo global y lo local, 1, 1, Tirant Humanidades
          * 2016, La construcción política de la educación en el Escenario Europeo , Educación Comparada. La dialéctica de lo global y lo local , Tirant Humanidades
          * 2015, A Educação como Frente de Luta. Recortes sobre um Programa de Democratização da Escola Básica em Portugal (1974-1976)., Educação, História e Políticas. Tributo a Rogério Fernandes, Edições Piaget
          * 2014, Social and Cognitive Justice: The Social Relevance of the Higher Education in Latin America, International Handbook of Educational Leadership and Social (In)Justice, 29, Springer Netherlands
          * 2014, Introduction, European and Latin American Higher Education Between Mirrors. Conceptual Frameworks and Policies of Equity and Social Cohesion, 1, Sense Publishers
          * 2014, Institutional networks in Latin America: Building new paths in academic cooperation
          * 2014, Institutional Networks in Latin America. Building New Paths in Academic Cooperation, European and Latin American Higher Education Between Mirrors: Conceptual Frameworks and Policies of Equity and Social Cohesion, Sense Publishers
          * 2014, Conclusion, European and Latin American Higher Education Between Mirrors: Conceptual Frameworks and Policies of Equity and Social Cohesion, Sense Publishers
          * 2014, Apresentação, Sumando voces. Ensayos sobre Educación Superior en términos de igualdad e inclusión social, Mino y Dávila
          * 2013, The role of the academicians' networks in the exercise of leadership for fight the social injustice: An institutional challenge. In I. Bogotch & C. Shields (Eds.). International Handbook of Social [In]Justice and Educational Leadership. (Chapter 42). New York, London & Frankfurt: Springer., International Handbook of Educational Leadership and Social (In)Justice, 2, 1, Springer International Handbooks of Education 29
          * 2013, The Political Construction of European Education Space, Comparative Education. The Dialectic of the Global and the Local, 4, Rowman & Littlefield
          * 2013, Políticas Educativas o la Transdisciplinaridad de un Campo de Estudio. , Epistemologías de Política Educativa. Posicionamientos, perspectivas y enfoques, Mercado de Letras
          * 2013, Espaços, identidades e culturas na América Latina: alternativas epistémicas para um outro mundo possível. , Interculturalid y Educación Superior. Desafios de la diversidad para un cambio educativo, 1, Editorial Biblos
          * 2013, Associativismo, sindicalismo e identidade(s) docente(s): algumas particularidades do percurso português., Associativismo e sindicalismo em educação: teoria, história e movimentos , Paralelo 15
          * 2012, Os novos modos de regulação transnacional das políticas de educação: a regulação pelos resultados e o papel das comparações internacionais. , Organizações internacionais e modos de regulação das políticas de educação. Indicadores e comparações internacionais, 1, 1, Liber Livro
          * 2012, From Prescribed to Narrative Curriculum - An Attempt to Understand Educational Change in Portugal, Globalization - Education and Management Agendas, InTech
          * 2011, Reforma do ensino superior e implantação do processo de Bolonha em Portugal. Mudanças e encruzilhadas. In B. L. Ramalho, J. Beltran Llavador, M. E. P. Carvalho & A. V. S. Diniz (Eds.) Reformas Educativas, Educación Superior y Globalización en Brasil, Portugal y España (pp. 97 - 131. Valencia: Germania., Reformas Educativas, Educación Superior y Globalización en Brasil, Portugal y España, Germania
          * 2011, Reforma do Ensino Superior e a Implementação do Processo de Bolonha em Portugal. Mudanças e Encruzilhadas, Reformas Educativas, Educación Superior y Globalización en Brasil, Portugal y España, Germania
          * 2011, Between equity and excellence: challenges for secondary education policies, Portugal in the Era of the Knowledge Society, Edições Universitárias Lusófonas
          * 2011, Alma e corpo - ética deontológica da profissão docente, um constructo identitário, Formação e Profissão Docente, Junqueira & Marin Editores
          * 2011, A modernização das Universidades portuguesas nos anos 1970 e a influência inglesa. Anotações para um programa de pesquisa. In J. M. Hernandez Díaz (Ed.) Influencia Inglesa en la Educación Española e Iberoamericana (1810-2010) (pp. 85 - 87). Salamanca: Centro de Educación, Universidad de Salamanca., Influencia Inglesa en la Educación Española e Iberoamericana (1810-2010) , Centro de Educación, Universidad de Salamanca.
          * 2011, A modernização das Universidades portuguesas nos anos 1970 e a influência inglesa. Anotações para um programa de pesquisa, Influencia Inglesa en la Educación Española e Iberoamericana (1810-2010), Centro de Educación, Universidad de Salamanca
          * 2011, A educação e o Movimento Sem-Terra, ou como o povo (re)aprende e (re)constrói a escola, Movimentos Sociais e Educação de Adultos na Ibero-América. Lutas e desafios, 1, Liber Livro
          * 2011, "A fortuna é de quem a agarrar". A rede iberoamericana de investigação em políticas de educação (RIAIPE) e as perspectivas de trabalho futuro, Miradas en Movimiento. Textos y Contextos de Políticas de Educación, Germania
          * 2010, Neoliberalismo, globalização hegemônica e internacionalização da educação superior, Teorias e Politicas em Educação, Xamã
          * 2010, Do fim dos eleitos ao processo de Bolonha. As políticas de educação superior em Portugal (1970-2008), A Educação Superior no Espaço Iberamericano. Do Elitismo à Transnacionalização , 1, Edições Universitárias Lusófonas
          * 2010, Between Equity and Academic Excellence. Challenges for Policies on Secondary Education in Portugal. , Portugal in the Era of the Knowledge Society, Edições Universitárias Lusófonas
          * 2009, La reconfiguratión de las Políticas Curriculares. El caso portugués, Espejo y Reflejo. Políticas Curriculares y Evaluaciones Internacionales, 1, Germania
          * 2009, Evaluaciones internacionales y políticas curriculares, Espejo y Reflejo: Políticas curriculares y Evaluaciones Internacionales, 1, Germania
          * 2009, Crítica e Utopística: contributos para uma agenda política educacional cosmopolita, Globalização, Educação e Movimentos Sociais. 40 anos de Pedagogia do Oprimido, Editora Paulo Freire e Editora Esfera
          * 2008, New Ways of Transnational Regulation of Educational Policies: Evidences and Possibilities, Social Justice Education for Teachers. Paulo Freire and the Possible Dream, Sense Publishers
          * 2008, Globalização e reconstrução das identidades docentes: a luta pela fabricação da alma dos professores, Políticas Públicas e Conhecimento Profissional. A Educação e a Enfermagem em reestruturação, Livpsic / Legis Editora
          * 2007, És possible una política de l'educació a l'esquerra? Una reflexió sobre la possibilitt i l'esperança, Paulo Freire en el temps present, Denes Editorial/Ediciones del CreC
          * 2007, Es posible una política de la educación a la izquierda? Una refléxion sobre la posibilidad y la esperanza en la acción política, Paulo Freire en el tiempo presente, Denes Editorial/Ediciones del CreC
          * 2007, Educação e Pensamento Contemporâneo: da construção do modelo escolar ao tesouro a descobrir, Introdução ao Pensamento Contemporâneo. Tópicos, Ensaios, Documentos, Edições Universitárias Lusófonas
          * 2007, Educational Policies and the Sense of Possibility. A Contribution to Democratic Education in a Progressive Age, Critique and Utopia. New Developments in the Sociology of Education in the Twenty-First Century, Rowman & Littlefield
          * 2006, É possível uma política de educação à esquerda? Uma reflexão sobre possibilidade e esperança na acção política, Paulo Freire na História do Tempo Presente, Edições Afrontamento
          * 2006, Nota Introdutória. A expansão escolar no Portugal do pós-guerra: uma contextualização, Temas de Educação. Subsídios para a análise crítica da expansão escolar (no Portugal dos anos 60 e 70 do século XX), Edições Universitárias Lusófonas
          * 2005, Bolonha e a reforma universitária. Dos riscos potenciais às possibilidades de mudança, O Processo de Bolonha e a Formação dos Educadores e Professores Portugueses, Profedições
          * 2004, Um novo cenário: o acesso dos alunos ao conhecimento e o bem-estar dos professores, Professores. Identidades (re)construídas, Edições Universitárias Lusófonas
          * 2004, Um estudo europeu sobre os professores. Atractividade, perfil e conteúdo ocupacional da profissão docente, Professores. Identidades (re)construídas , Edições Universitárias Lusófonas
          * 2004, Apresentação. Um contributo para a renovação de fontes e de metodologias em História da Educação, Histórias (re)construídas. Leituras e interpretações de processos educacionais, Cortez Editora
          * 2003, O Estado Novo e a Educação. As mudanças invisíveis na sociedade portuguesa do pós-guerra e a expansão educativa, A Modernização Pedagógica e a Escola para todos na Europa do Sul no Século XX , Grupo SPICAE
          * 2003, Ensino superior: tendencias e desafios no caso português, Ensinar e Aprender no Ensino Superior. Por uma epistemologia da curiosidade na formação universitária, Cortez Editora / Editora Mackenzie
          * 2003, Educational Policies and New Ways of Governance in a Transnationazation Period, The International Handbook on the Sociology of Education. An International Assessment of New Research and Theory, Rowman & Littlefield Publishers.
          * 2001, Organizações internacionais e políticas educativas nacionais: a emergência de novas formas de regulação transnacional ou uma globalização de baixa intensidade, Da Crise da Educação à “Educação” da Crise: Educação e a Transnacionalização dos Mecanismos de Regulação Social, Edições Afrontamento
          * 1999, Ensino Secundário: constatações breves e três tópicos para um debate urgente, O Ensino Secundário em Portugal (Estudos), Conselho Nacional de Educação
          * 1999, Crise de identidade nos papéis e na formação de professores. Quatro tópicos a partir de uma leitura sociológica, Os Professores na História, Sociedade Portuguesa de Ciências da Educação
          * 1998, Rui Grácio, Educação: memórias e testemunhos , Conselho Nacional de Educação
          * 1998, O tempo dos professores? Conhecimento e poder: de uma intervenção acrescida na vida política a uma nova centralidade no processo educativo, Professor/a: uma profissão em mutação?, Fórum Educação
          * 1998, O conceito de construção retórica da educação. As despesas públicas com a educação, Fazer e ensinar História da Educação, Instituto de Educação e Pedagogia/Universidade do Minho
          * 1998, Educação, democracia e cidadania. Cinco tópicos para um debate sobre inovação e mudança na escola, A Educação Física em finais de século. As mudanças necessárias, Areal Editores
          * 1997, Políticas educativas: um campo de estudo no cruzamento de vários campos científicos e metodológicos, Métodos e Técnicas de Investigação Científica em Educação, AFIRSE & FPCE-UL
          * 1997, Políticas educativas e mudanças no campo educativo. Considerações a propósito de um debate interdisciplinar, Contributos da Investigação Científica para a Qualidade do Ensino. Actas do III Congresso da Sociedade Portuguesa de Ciências da Educação, Sociedade Portuguesa de Ciências da Educação
          * 1996, Políticas educativas e mudanças no campo educativo, 1970-1990: uma análise comparativa das políticas respeitantes à formação de professores na Reforma Veiga Simão e na Lei de Bases do Sistema Educativo, Formação, Saberes Profissionais e Situações de Trabalho, AFIRSE & FPCE-UL
          * 1979, Por uma formação de elevado nível científico e pedagógico, Seminário sobre Formação de Professores, Escola/Separata - Sindicato dos Professores da Grande Lisboa
          * 1979, O debate irá continuar!, Seminário sobre Formação de Professores, Escola/Separata - Sindicato dos Professores da Grande Lisboa

        Edited book

          * 2018, EDITORA CRV
          * 2018, 2018, Edições Universitárias Lusófonas
          * 2017, 1, 1, Edições Universitárias Lusófonas
          * 2014, 1, Mino y Dávila
          * 2014, 1, 1, Sense Publishers
          * 2013, 1, Mino y Dávila
          * 2013, 1, 1, Editorial Biblos
          * 2013, 1, 1, Editorial Biblos
          * 2012, 1, 1, Liber Livro
          * 2011, 1, Liber Livro
          * 2010, 1, Edições Universitárias Lusófonas
          * 2009, 1, Germania
          * 2009, 1, 1, Edições Universitárias Lusófonas
          * 2008, 1, 1, Liber Livro
          * 2007, 1, Rowman & Littlefield
          * 2005, 1, Edições Afrontamento
          * 2004, 1, Cortez Editora
          * 2003, 3, Cortez Editora / Editora Mackenzie
          * 2001, 1, 1, Edições Universitárias Lusófonas
          * 1998, 1, Fórum Educação
          * 1996, 1, Texto Editora

        Book review

          * Um Cidadão do Mundo

        Translation

          * 2002, Educação e Democracia - A praxis de Paulo Freire em São Paulo, Westview Press

        Newspaper article

          * 2018-11-01, A decisão política em Educação e os contributos da Ciência, Sol
          * 2012-10-22, Uma escola democrática, inclusiva e exigente, Público
          * 2011-06-17, Mudar de rumo (2): cinco propostas para o ensino superior, Público
          * 2011-05-13, Mudar de rumo: seis propostas para a Educação, Público
          * 2007-12-01, Nos sindicatos não há carreira, Jornal de Notícias
          * 2006-11-01, Todos os problemas sociais passaram a ser problemas escolares, A Página da Educação
          * 2005-12-01, Os intelectuais e a participação política, A Página da Educação
          * 2004-12-01, Um olhar sobre o Brasil, A Página da Educação
          * 2003-12-01, Globalização. As novas formas de regulação transnacional nas políticas de educação, ou uma globalização de baixa intensidade, A Pagina da Educação
          * 2002-03-11, Ensino superior: interrogações e desafios às políticas públicas, Público
          * 2001-06-13, A Sociedade na Escola, Jornal de Letras/Educação
          * 1998-01-09, Os professores e as reformas educativas, Expresso
          * 1996-04-27, Prioridade à educação e à formação, Expresso
          * 1996-03-23, Nota mínima e acesso ao ensino superior, Diário de Notícias
          * 1996-02-13, Educação e construção europeia, Diário de Notícias
          * 1996-01-30, Diálogo social e decisão política, Diário de Notícias
          * 1995-12-21, Ensino superior e desafios do final do século, Diário de Notícias / Suplemento Universidades
          * 1995-12-01, Escola, Autonomia e Gestão Democrática. Considerações críticas sobre o modelo instituído pelo Decreto-Lei 172/91, A Página da Educação
          * 1995-05-13, Sindicalismo docente: a renovação necessária, Público
          * 1995-04-14, Autonomia e gestão escolar. O trilhar de novos rumos na educação escolar exige audácia e uma ruptura com a tradição retórica sobre a prioridade educativa, Expresso
          * 1995-03-17, Entrevista: Escola com regras de há cem anos, Templário
          * 1994-12-01, Reforma educativa: a legitimação de um discurso (seguido de 'paradoxos'), A Página da Educação
          * 1994-12-01, Ano lectivo 1994/95: O fim da Reforma Educativa?, A Página da Educação
          * 1993-03-03, O futuro do sindicalismo, Público
          * 1993-02-12, O perigo de um efeito boomerang, Público
          * 1992-12-01, António Teodoro denuncia uma situação pantanosa, A Página da Educação
          * 1992-07-05, Impasse na reforma educativa, Público
          * 1979-11-09, Formação de Professores: seminário internacional inicia-se hoje no LNEC, O Diário
          * 1973-02-02, A situação do professorado em Portugal, Diário de Lisboa

        Report

          * 2010, A morte de Rogério Fernandes: a perda de um Investigador, de um Professor e de um Amigo, http://scielo.pt/scielo.php?script=sci_arttext&pid=S1645-72502010000100002

        Conference paper

          * Reforma educativa ou a procura de uma outra estratégia de mudança, II Conferência Internacional de Sociologia da Educação
          * Por um desenvolvimento autónomo da Universidade Portuguesa, A Universidade Portuguesa em debate. Seminário sobre Problemas do Ensino Superior
          * No fio da navalha: as tecnologias políticas de reforma e a luta pela fabricação da alma dos professores, V Simpósio sobre Organização e Gestão Escolar
          * Impasses e novos desafios na formação de professores, Fórum Impasses e Novos Desafios Na Formação de Professores
          * Globalização e Educação: evidências e possibilidades, 9ª Edição dos Encontros de Basto
          * Formação contínua dos professores: dos conceitos à prática, ou a necessidade de repensar os modelos dominantes de formação, 1º Encontro de Educação e Cultura do Concelho de Oeiras.
          * Educação, democracia e cidadania. Cinco tópicos para um debate sobre inovação e mudança na escola, IV Congresso Nacional de Educação Física
          * Educação e Desenvolvimento: prioridades para uma política de desenvolvimento e democratização da educação em Portugal, Seminário Evolução Recente e Perspectivas de Transformação da Economia Portuguesa
          * Educação e Desenvolvimento: a implementação da Lei de Bases do Sistema Educativo, questão central de uma política de modernização e desenvolvimento da sociedade portuguesa, Seminário Emprego, Modernização, Desenvolvimento: que soluções?
          * Cidadania e Políticas Educativas, Conferência Ibérica Educação para a Cidadania
          * A Emergência da Prioridade Educativa no Discurso Político dos Anos 80, 2º Congresso da Sociedade Portuguesa de Ciências da Educação
          * A Educação Comparada para além dos números : contextos locais, realidades nacionais, processos transnacionais

        Conference abstract

          * 2023-03-03, A AGENDA 2030 E A PRÁTICA EDUCATIVA PARA UMA CIDADANIA FUNDAMENTADA NO DESENVOLVIMENTO SUSTENTÁVEL, ENCONTRO NACIONAL DE JOVENS INVESTIGADORES EM EDUCAÇÃO
          * 2022-09-16, A educação para a cidadania global nas revistas científicas portuguesas (2012-2021) [Education for global citizenship in Portuguese scientific journals (2012-2021)], XVI Congresso da SPCE - Sociedade Portuguesa de Ciências da Educação Educação e Cidades: Tempos, Espaços, Atores e Culturas
          * 2022-05-02, The evidence-based education policy movement and Its effects on the curriculum policy in Portugal (2011-2019), ECER Plus - European Conference on Educational Research
          * 2021-09-02, A success story? The PISA impacts on media discourse and public policies in Portugal (2000-2018) , ESERA Conference 2021 Fostering scientific citizenship in an uncertain world
          * 2019-09-03, PISA and literacy concept: Analyse of the centrality of literacy as the main operative concept in student assessment. , ECER 2019, Education in an Era of Risk
          * 2019-06-13, O movimento da evidence-based education policy e as políticas curriculares em Portugal [The evidence-based education policy movement and the curricular policies in Portugal], II Seminário Internacional CAFTe - Currículo, Avaliação, Formação e Tecnologias Educativas, FPCEUP - Faculdade de Psicologia e de Ciências da Educação da Universidade do Porto
          * 2010, Governing By Indicators. The News Forms of Transnational Regulation of Education Politics, XVII ISA World Congress of Sociology
          * 2008, The new architecture in the construction of the educational and curricular policies: Regional and national reconfigurations, First ISA Forum of Sociology
          * 2008, The New Architecture of Educational and Curricular Policies in Portugal: Curricular Knowledge Reconfiguration., 1º Fórum de Sociologia International Sociological Association
          * 1993, Reforma Educativa ou a procura de uma estratégia de mudança, II Conferência Internacional de Sociologia da Educação
          * 1992, Da profissionalização da actividade docente à crise de identidade dos professores. Considerações preliminares para um estudo da situação portuguesa, IV Congresso da Sociedade Portuguesa de Educação Física

        Preface / Postscript

          * 2014
          * 2012
          * 2010
          * 2009
          * 2009
          * 2007
          * 2006
          * 2005
          * 1988
          * 1979

        Other output

          * 2014, Editorial
          * 2014, Editorial
          * 2013, Editorial
          * 2013, Editorial
          * 2013, Editorial
          * 2013, Apresentação, Introdução, Editorial
          * 2012, Editorial
          * 2012, Editorial
          * 2012, Editorial
          * 2011, Editorial
          * 2010, Editorial
          * 2010, Editorial
          * 2010, Apresentação, Introdução, Editorial
          * 2009, Editorial
          * 2008, Políticas de Educación en Tiempos de Globalización, Introdução, Editorial
          * 2008, Editorial
          * 2008, Apresentação, Introdução, Editorial
          * 2007, Steve Stoer: o Scholar Exemplar e o Cidadão do Mundo
          * 2007, Revolução e Utopia. Um programa de acção no campo educativo para uma sociedade a caminho do socialismo - Portugal 1975, Tempos e Andamentos nas Políticas de Educação. Estudos Iberoamericanos
          * 2007, Introduction: Critique and Utopia in the Sociology of Education, Introdução, Editorial
          * 2007, Editorial
          * 2007, Editorial
          * 2007, Editorial
          * 2007, Editorial
          * 2006, In Memoriam - Stephen R. Stoer (1943-2005). Um cidadão do mundo
          * 2006, Editorial
          * 2006, Editorial
          * 2005, Mandato e legitimação nas políticas para a educação [Entrevista]
          * 2005, Editorial
          * 2005, Editorial
          * 2005, Editorial
          * 2005, Editorial
          * 2005, Crítica e Utopia. Novos desenvolvimentos na Sociologia da Educação emergentes neste início de Século XXI, Introdução, Editorial
          * 2004, Editorial, Introdução, Editorial
          * 2004, Editorial
          * 2004, Editorial
          * 2003, Editorial, Introdução, Editorial
          * 2003, Editorial, Introdução, Editorial
          * 2003, Editorial
          * 2003, Editorial
          * 2003, Apresentação, Introdução, Editorial
          * 2001, O Portugal Pós-Colonial: políticas e estratégias educativas
          * 2001, Nota de Apresentação, Introdução, Editorial
          * 1997, Conquistas e Insucessos da Reforma Educativa
          * 1996, Nota de Abertura, Introdução, Editorial
          * 1988, Parecer da FENPROF sobre a Proposta de Reorganização dos Planos Curriculares dos Ensinos Básico e Secundário
          * 1980, Parecer do Sindicato dos Professores da Grande Lisboa [sobre a Proposta de Lei de Bases do Sistema Educativo apresentada pelo VI Governo Constitucional]
          * 1975, A função da escola na construção da democracia da democracia portuguesa

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona