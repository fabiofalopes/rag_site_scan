# Response for https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
          PT: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265 EN: https://www.ulusofona.pt/en/teachers/dulce-maria-morais-do-amaral-franco-265
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
        fechar menu : https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/dulce-maria-morais-do-amaral-franco-265
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Dulce Maria Franco

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p265
              dul***@ulusofona.pt
              4313-FC40-CD8E: https://www.cienciavitae.pt/4313-FC40-CD8E
              0000-0002-0288-1804: https://orcid.org/0000-0002-0288-1804
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/769f38bc-e261-4e08-ab90-b2d2f9e4349b
      : https://www.ulusofona.pt/

        Resume

        PhD in Educational Sciences from the University of Évora. Director of the master's in teaching in the 1st Cycle of Basic Education and Maths and Natural Sciences in the 2nd Cycle of Basic Education. Elected member of the Pedagogical Council and member of the Technical-Scientific Council (Escola Superior de Educação da Lusofonia). Researcher at the Research Centre for Education and Development (CeiED), as part of the Research and Learning Community (ReLeCo) and Public Policies and Governance in Education(ReLeCo PPGE). He has been a lecturer in higher education since 1992. She was a member of the Ibero-American Educational Policy Research Network (RIAIPE). She has carried out teaching activities at distinct levels and applied pedagogical innovation experiments. Author and co-author of textbooks (Natural Sciences) for basic education adopted in public and public schools. Author and co-author of funded national and international projects in the field of science and ICT. She was the coordinator and author of a project funded by the F.C. Gulbenkian in the context of school failure and dropout (school radio). She specializes in training teachers and trainers in the technological field. Research - Teacher training, socio-educational inclusion and ICT. Member of the Scientific Committee of various events. She has also supervised doctorates, master's degrees, and professional internships. As a researcher, she takes part in various projects in the field of School Handbooks, E-Handbooks and student learning processes and teacher training. As a researcher, she has been part of the TASK21 - EdTEch and AI for Essential Skills of the 21st Century 2019-1- FR01-KA203-063063 (2022) project, among others that have been funded. *In July 2022, the article Impactos do ensino à distância no ensino superior privado em Portugal, of which she was co-author, published in Revista Lusófona de Educação nº 54 was, according to Crossref data in the TOP10 DOIs(10.24140/ISSN.1645-7250. _____________________________________________________________________________________________________________________________ Doutor em Ciências da Educação pela Universidade de Évora. Diretora do Mestrado em Ensino do 1º Ciclo do Ensino Básico e de Matemática e Ciências Naturais no 2º Ciclo do Ensino Básico. Membro eleito do Conselho Pedagógico e do Técnico-Científico (Escola Superior de Educação da Lusofonia). Investigador integrado do C. de Investigação para a Educação e Desenvolvimento (CeiED), integrando a Comunidade de Pesquisa e Aprendizagem (ReLeCo) e do Ceied Docente desde 1992 no ensino superior. Foi membro da Rede Ibero-Americana de Investigação de Políticas Educativas (RIAIPE). Desenvolveu atividades de ensino em diferentes graus e aplicadas experiências de inovação pedagógica. Autor e coautora de manuais didáticos (Ciências Naturais) para o ensino básico adotados em escolas públicas e privadas. Autora e coautora de projetos nacionais e internacionais no âmbito das Ciências e das TIC que foram financiados. Foi coordenadora e autora de um projeto financiado pela F.C. Gulbenkian no contexto de insucesso escolar e abandono escolar (rádio escolar). Especialista na área de Formação de Professores e Formadores na Área Tecnológica. Investigação - Formação de Professores, Inclusão Socioeducativa e TIC. Integra a Comissão Científica de vários eventos. Orientadora de doutoramentos, mestrados e estágios profissionais. Como investigadora participa em vários projetos na área dos Manuais Escolares, E-manuais e nos processos de aprendizagem dos estudantes e formação de professores. Integrou como investigadora o projeto TASK21 - EdTEch and AI for Essential Skills of the 21st Century 2019-1- FR01-KA203-063063 (2022) entre outros financiados *Em Julho de 2022, o artigo Impactos do ensino à distância no ensino superior privado em Portugal do qual foi coautora, publicado na Revista Lusófona de Educação nº 54 foi, segundo dados da Crossref no TOP10 DOIs(10.24140/ISSN.1645-7250.

        Graus

            * Mestrado
              Mestrado em Ciências da Educação
            * Curso médio
              Curso de e-formador. Curso de especialização
            * Pós-Graduação
              Formação Pessoal e Social
            * Curso médio
              Curso de Capacitação Pedagógica para o Ensino Superior. Curso de especialização.
            * Doutoramento
              Doutoramento em Ciências da Educação
            * Diploma de especialização
              Formação de Professores e Formadores de Área Tecnológica.
            * Ensino básico 2º ciclo
              Avaliação do Ensino Básico e Secundário
            * Mestrado
              Dificuldades de Aprendizagem e boas práticas de diferenciação pedagógica

        Publicações

        Artigo em revista (magazine)

          * 2004-11-20, Como avaliar um Site de Escola. , Revista Bimensal Proformar Online

        Artigo em revista

          * 2022-03-23, 2022- Impactos do ensino remoto no ensino superior privado em Portugal: competências socioemocionais e digitais, Revista Lusófona de Educação
          * 2021-07-03, O Educador Social no Século XXI, Revista Lusófona de Educação
          * 2021-06, 2021 - O ensino profissionalizante e o multiculturalismo: vozes docentes no Instituto Federal de Sergipe, Latin American Journal of Development
          * 2021, 2021-O Educador Social no século XXI: perceções dos recém-licenciados de uma instituição de ensino superior privada em Portugal, Revista Lusófona de Educação
          * 2016, 2016 -The challenge of learning in the digital age. An analysis of the DER School textbook, Portuguese Language, 12th, Revista TICs & EaD em Foco
          * 2010, Teoria da deriva dos continentes de Alfred Wegener nos manuais escolares de Ciências Naturais Portugueses
          * 2010, A teoria da deriva dos continentes de Alfred Wegener nos manuais escolares de Ciências Naturais portugueses
          * 2010, 2010 -A teoria da deriva dos continentes de Alfred Wegener nos manuais escolares de Ciências Naturais portugueses. Entretextos nº 12 , Entretextos
          * 2003, Um local de Encontro. O site de Escola, Challenges 2003
          * 2003, Site de escola, uma janela aberta para o mundo
          * 2003, O Site de Escola: Uma Janela Aberta para o Mundo, Revista Lusófona de Educação, nº 2

        Tese / Dissertação

          * 2018, Programa ensino médio presencial com mediação tecnológica : tempos e espaços escolares em transformação
          * 2017, Mestrado, Orientador:Avaliação de objetos virtuais de aprendizagem para o ensino superior à distância: um estudo numa universidade particular de São Luís-ma
          * 2016, Mestrado, Orientador: Percepção discente em relação ao uso das tecnologias de informação e comunicação na sua formação em fisioterapia
          * 2016, Mestrado, Orientador: Aprendendo.com: o papel dos tablets na aprendizagem um olhar sobre o espaço escolar
          * 2015, Mestrado, Orientador:Uso das tecnologias da informação e comunicação como facilitadoras da aprendizagem significativa no ensino de ciência
          * 2015, Mestrado, Orientador:A tecnologia da informação e comunicação como mediadora do ensino e aprendizagem da língua portuguesa
          * 2015, Mestrado, Orientador: O uso do software Educandus como recurso didático no ensino de Biologia com ênfase nos conteúdos de Ecologia para os alunos do ensino médio das escolas de referência de Garanhuns-PE
          * 2015, Mestrado, Orientador: Avaliação da aprendizagem no ensino superior a distância: análise das concepções docentes acerca da prática avaliativa em instituições públicas de Recife-PE
          * 2014, Mestrado, Orientador: A inclusão digital na terceira idade: a integração das TIC numa Escola Superior Sénior
          * 2012-01, Doutoramento, 2012 - "Aprendizagem e trabalho colaborativo numa plataforma online numa escola básica do 2.º e 3.º ciclos. Um estudo de caso.".
          * 2012, Doutoramento, Aprendizagem e trabalho colaborativo numa plataforma online numa escola básica do 2.º e 3.º ciclos. Um estudo de caso.

        Livro

          * 2014, O meu livro de Ciências - Nova Edição, 1, Franco, Dulce Maria, ASA
          * 2005, Formar Professores Para que Escola?Teorias e Práticas, 5, José B. Duarte; Franco, Dulce 4313-FC40-CD8E, Edições Universitárias Lusófonas

        Capítulo de livro

          * 2024, Profissão docente em Portugal e Angola: Que perceções?, Livro de Atas do III Congresso Internacional de Angolanística. CEDESA., 2023
          * 2023, A cidadania digital e a Covid-19: perceções de estudantes do ensino superior em Portugal, Humanismo e desafios de cidadania, 1, 1ª, Edições Universitárias Lusófonas
          * 2023, A cidadania digital e a Covid-19: perceções de estudantes do ensino superior em Portugal, Humanismo e desafios de cidadania, 1, 1ª, Edições Universitárias Lusófonas
          * 2023, A cidadania digital e a Covid-19: perceções de estudantes do ensino superior em Portugal, Humanismo e Desafios da Cidadania , 1, 2023, Edições Universitárias Lusófonas
          * 2017, 2017 - NOVOS/ VELHOS DESAFIOS DA APRENDIZAGEM COM O MANUAL ESCOLAR: UMA AVALIAÇÃO DE RECURSOS EDUCATIVOS DIGITAIS EM MANUAL MULTIMÉDIA

        Revisão de livro

          * Recensão crítica Atas do II Congresso Internacional de Angolanística. Santos, F. & Verde, R. (eds.). (2022).

        Manual

          * 2014, O meu livro de ciências: ciências naturais: 5ºano, 2º ciclo do ensino básico , Asa II
          * 2014, 2014 - O meu livro de ciências: caderno de atividades: ciências naturais: 5º ano, 2º ciclo do ensino básico, Asa II
          * 2010, O meu livro de Ciências, ASA
          * 2010, O meu livro de Ciências, ASA
          * 2000, Naturalmente 5. , Editorial O livro
          * 1996, Páginas da Natureza: Ciências da Natureza: 6.º Ano , O Livro
          * 1995, Páginas da Natureza , Editorial O Livro

        Artigo em conferência

          * Um olhar sobre o site. , AFIRSE
          * O ensino b-learning no ensino superior: relato de uma experiência na Universidade Lusófona de Humanidades e Tecnologias - LHT
          * O Site de Escola. Ideias e Práticas, Evolutic 2003 – 1o. Encontro Ibérico de Tecnologias de Informação.
          * Manuais, e-manuais e actividades dos alunos."Pode o manual contribuir para a escola ser outra coisa?"., Conference Educating the Global Citizen. Globalization, Education and New
          * 2024-01-12, Iniciação à Prática Profissional: desafios e potencialidades.
          * 2023-11, O ProInfo (2007-2021) no Rio Grande do Norte - Brasil: Um estudo com base no conceito de “ciclo de políticas, XXVI Congresso Internacional de Informática Educativa (TISE)
          * 2023-09-28, Ser (e tornar-se) educador em Portugal: das necessidades aos anseios.
          * 2021-11, REMOTE LEARNING AND DIGITAL LITERACIES AND COMPETENCES: A STUDY IN PORTUGAL
          * 2021-11, EDUCATIONAL TECHNOLOGIES IN THE DIGITAL AGE: A STUDY IN PORTUGAL
          * 2021-09-30, 2021- O processo de ensino-aprendizagem para alunos do ensino superior: reconfigurações de práticas docentes., Symposium XVIII Foro Internacional sobre la evaluación de la calidad de la investigación y de la educación superior (FECIES)
          * 2021-07, 2021-REMOTE LEARNING: STRENGTHS AND WEAKNESSES?
          * 2021-07, 2021- COVID-19 AND REMOTE TEACHING: CHALLENGES FOR POST-PANDEMIC TEACHING?
          * 2021-06-03, The impact of Covid-19 on education: perceptions of Brazilian higher education students., IX Oxbridge Conference on Brazilian Studies
          * 2020-11, 2020- WHEN TECHNOLOGY MEETS PEDAGOGY. AN ERASMUS+ PROJECT PROPOSAL TO CREATE AN INTERDISCIPLINARY HIGHER EDUCATION MODEL
          * 2020- HOW CAN NEW TECHNOLOGIES AND ARTIFICIAL INTELLIGENCE COLLABORATE WITH EDUCATION? KNOWLEDGE AND RECOMMENDATIONS FROM EU STUDENTS AND TEACHERS, CERI2020
          * 2018-07-02, 2018 - O Centro de Mídias de Educação (Cemeam). Um caminho de inovação para as comunidades online do Estado do Amazonas, 8ºEncontro de Investigadores
          * 2018-07-02, 2018 -Política pública e tecnologia educacional , 8º Encontro de Investigadores Investigação em Educação: percursos e processos contemporâneos ESTUDOS
          * 2015-06, 2015 -O desafio de um recurso educativo digital. Uso para além da sala de aula., 5ºEncontro CeiED
          * 2010 - Galileu, O Fascínio do Saber: um projeto de combate ao insucesso escolar numa escola da periferia de Lisboa, XII Colóquio Ibérico de Geografia

        Resumo em conferência

          * 2024-01-12, Iniciação à Prática Profissional: desafios e potencialidades, Encontro “A Boa Educação na escola: perspetivas, práticas e desafio,
          * 2023-10-22, O sonho de ser educador/professor: motivações e anseios de mestrandos em ensino , III Congresso Internacional Humanismo , Direitos Humanos e cidadania
          * 2023-06-21, Profissão docente em Portugal e Angola: Que perceções?, III Congresso Internacional de Angolanística
          * 2023-02-27, Ser Educador de Infância e ser Professor é, hoje, uma profissão atrativa?, 30ºColóquio AFFIRSE 2023
          * 2022-07, 2022- CREATING PEDAGOGICAL MATERIAL FOR THE 21ST CENTURY: ANALYSIS OF AN INTERDISCIPLINARY COURSE WITHIN THE SCOPE OF THE ERASMUS+ PROGRAMME, EDULEARN22 (14th annual International Conference on Education and New Learning Technologies)
          * 2021-12-17, 2021-Impactos da Covid-19: perceções de estudantes do ensino superior em Angola e em Portugal., Segundo Congresso Internacional de Angolanística
          * 2021-10-19, 2021-The impact of Covid-19 on education: perceptions of Brazilian higher education students., IX Oxbridge Conference on Brazilian Studies - IX Conferência Oxbridge em Estudos Brasileiros
          * 2021-09, 2021-As perceções da Covid-19 na educação: um estudo com estudantes do ensino superior brasileiros, IX Oxbridge Conference on Brazilian Studies - IX Conferência Oxbridge em Estudos Brasileiros
          * 2021-07-17, Covid-19 e ensino remoto - perceções de estudantes do ensino superior em Portugal, I Congresso Internacional sobre Metodologia: Desafios Metodológicos Atuais (Qualis2021).
          * 2021-07-07, 2021 - Covid-19 e ensino remoto: perceções de estudantes do ensino superior em Portugal, I Congresso Internacional sobre Metodologia: Desafios Metodológicos Atuais (Qualis2021).
          * 2021-07-02, Remote learning: strengths and weaknesses?
          * 2021, 2021- THE TEACHING-LEARNING PROCESS FOR HIGHER EDUCATION: RECONFIGURATIONS OF TEACHING PRACTICES MARIA NEVES GONÇALVES AND DU, XVIII FORO INTERNACIONAL sobre la EVALUACIÓN de la CALIDAD de la INVESTIGACIÓN y de la EDUCACIÓN SUPERIOR (FECIES)
          * 2017-11-14, 2017 - Portugal School textbooks: a barometer of the media, 14th IARTEM Conference September 2017, Lisbon
          * 2016, 2016 -Português: desafios com fios de ciência na construção da comunicação, Congresso Língua e Cultura Portuguesas: Memória, Inovação e Diversidade.
          * 2014, 2014 - Uma avaliação zoom de red em manual multimédia... ...para uma pedagogia multimédia , TIC@Portugal2014 - Encontro de Professores sobre Utilização Educativa das TIC
          * 2014, 2014 - A educação ambiental e as tic: conceção e criação de um clube numa rede social - o Facebook
          * 2013, Os Recursos Educativos Digitais (R.E.D.) e o Manual de Português (12º Ano). Contributo dos RED em contexto de aula¿, 5º Colóquio Internacional Manuais Escolares - Manuais Escolares, E-Manuais e Investigação em Didática
          * 2013, Aprendizagem e trabalho colaborativo numa plataforma online., Encontro TIC@Portugal
          * 2013, 2013 - O ensino b-learning no ensino superior. Relato de uma experiência na Universiadde Lusófona de Humanidades e Tecnologias, III Colóquio Luso Brasileiro de Educação a Distância e Elearning
          * 2012, 2012 - Moodle: um caminho de inovação para comunidades e ambientes escolares online.
          * 2009, Manuais escolares e dinâmica da aprendizagem, I Fórum de Investigação em Ciências da Educação Uma iniciativa das Unidades de I&D em Ciências da Educação.
          * 2008, MOODLE: UM CAMINHO DE INOVAÇÃO PARA AMBIENTES E COMUNIDADES ESCOLARES ONLINE., Conference Educating the Global Citizen. Globalization, Education and New

        Poster em conferência

          * 2024-01, Derrubar Tijolos para ser feliz Knocking down bricks
          * 2024-01, Derrubar Tijolos para Ser Feliz., 8º Congresso Internacional da Criança e do Adolescente – 2024,
          * 2022-06-14, 2022- DILEMMAS OF REMOTE EDUCATION: PERCEPTIONS OF HIGHER EDUCATION STUDENTS IN PORTUGAL AND BRAZIL¿, EDULEARN22 (14th annual International Conference on Education and New Learning Technologies)
          * 2022, 2022- COVID 19 AND EMERGENCY REMOTE TEACHING: A COMPARATIVE EXPLORATORY STUDY IN PORTUGUESE AND BRAZILIAN HIGHER EDUCATION¿, ICERI2022 (15th annual International Conference of Education, Research and Innovation)
          * 2020-07-23, 2020 -O papel das tecnologias de informação e comunicação na formação de professores do Ensino Básico e Médio em Angola: quais os desafios?, 10º Encontro de Investigadores do CeiED
          * 2020-07-23, 2020 -Jogos digitais no ensino de cibersegurança para crianças do 1.º ciclo de escolaridade, 10º Encontro de Investigadores do CeiED
          * 2020-07-23, 2020 - O design instrucional como parte da metodologia de ensino em ambientes virtuais de aprendizagem, 10º Encontro de Investigadores do CeiED

        Outra produção

          * 2009, e-CDP- Comunidades de Prática no Espaço digital
          * 2009, Recursos Educativos Digitais. em Ciências da Natureza.
          * 2004, Newsletter da UID- OPECE , Produto
          * 2003, Portal da UID OPECE, Software
          * 2001, Site da UID OPECE

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona