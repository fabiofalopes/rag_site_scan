# Response for https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
          PT: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399 EN: https://www.ulusofona.pt/en/teachers/ana-luisa-gomes-julio-5399
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
        fechar menu : https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-luisa-gomes-julio-5399
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ana Luísa Gomes Júlio

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5399
              ana***@ulusofona.pt
              C418-6811-6ED7: https://www.cienciavitae.pt/C418-6811-6ED7
              0000-0002-3129-6495: https://orcid.org/0000-0002-3129-6495
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/c7d732c0-81dd-408d-bf02-71971940d7e3
      : https://www.ulusofona.pt/

        Resume

        Ana Júlio (AJ) is currently a Teacher at the School of Health Sciences and Technologies of Lusófona University and she is a collaborator of CBIOS - Research Center for Biosciences & Health Technologies. AJ received her PhD Degree in Health Sciences (Biomedical Sciences) from Facultad de Medicina y Ciencias de la Salud, Universidad de Alcalá, in partnership with Lusófona University, in December 2023. She graduated in Pharmaceutical Sciences (Integrated Master's) from Lusófona University in 2017. AJ has already published several articles in national and international peer-reviewed journals and she is also the author/co-author of various oral/poster communications in (inter)national conferences. She has also won some awards with her work and/or in collaborations. She has been involved in the co-supervision of MSc and BSc students. She has also participated in several scientific outreach activities for general society and high school students. Her research interests focus on producing hybrid systems that combine drug delivery systems and ionic liquids, however, she has collaborated in several works within the scope of nano- and pharmaceutical technology.

        Graus

            * Mestrado
              Integrated Master's in Pharmaceutical Sciences
            * Outros
              Advanced Training in Manipulation and Analysis of Gene Expression
            * Outros
              Advanced Training in Fundamentals of Cell Culture
            * Doutoramento
              PhD in Health Sciences
            * Outros
              Advanced Training in "Principles and Applications of NMR Spectroscopy"
            * Outros
              Advanced Training "Clinical Trial Monitoring - 15th Edition"
            * Outros
              Advanced Training "II Cell Migration"
            * Outros
              Postgraduate in Advanced Cosmetology

        Publicações

        Preprint

          * 

        Journal issue

          * Abstract Book - InnovDelivery '22 - I Lusophone Meeting on Innovative Delivery Systems, 2

        Journal article

          * 2022-06, Ionic liquids as tools to improve gel formulations containing sparingly soluble phenolic acids, Journal Biomedical and Biopharmaceutical Research
          * 2021-12, TransfersomILs: From Ionic Liquids to a New Class of Nanovesicular Systems, Nanomaterials
          * 2021-07, Biobased Ionic Liquids as Multitalented Materials in Lipidic Drug Implants, Pharmaceutics
          * 2021-04, Upgrading the Topical Delivery of Poorly Soluble Drugs Using Ionic Liquids as a Versatile Tool, International Journal of Molecular Sciences
          * 2021, Roots and rhizomes of wild Asparagus: Nutritional composition, bioactivity and nanoencapsulation of the most potent extract
          * 2020-12, Proceedings Book - IV CBIOS Seminar, 2020, Biomedical and Biopharmaceutical Research Journal
          * 2020-04, III Lusófona’s Nutrition Meeting, Biomedical and Biopharmaceutical Research Journal
          * 2020-03, In vitro cytotoxicity assessment of ferulic, caffeic and p-coumaric acids on human renal cancer cells, Biomedical and Biopharmaceutical Research Journal
          * 2020-02, Anticancer Activity of Rutin and Its Combination with Ionic Liquids on Renal Cells, Biomolecules
          * 2019-12, Proceedings - 1st International Conference of the Portuguese Physiology Society - Physioma 2019, Journal Biomedical and Biopharmaceutical Research
          * 2019-08-10, Ionic Liquid-Polymer Nanoparticle Hybrid Systems as New Tools to Deliver Poorly Soluble Drugs, Nanomaterials
          * 2019-06, Preparation and characterization of microparticles loaded with seed oil of Caatinga passion fruit obtained by spray drying, Journal Biomedical and Biopharmaceutical Research
          * 2019-06, I Bioactive Natural Products Research Meeting 2019, Journal Biomedical and Biopharmaceutical Research
          * 2019-01, Development of ionic liquid-polymer nanoparticle hybrid systems for delivery of poorly soluble drugs, Journal of Drug Delivery Science and Technology
          * 2019, Influence of preparation procedures on the phenolic content, antioxidant and antidiabetic activities of green and black teas, Brazilian Journal of Pharmaceutical Sciences
          * 2018-12-19, Choline-Amino Acid Ionic Liquids as Green Functional Excipients to Enhance Drug Solubility, Pharmaceutics
          * 2018-06, Proceedings - CBiOS Scientific Sessions - 2018, Journal Biomedical and Biopharmaceutical Research
          * 2018-06, Influence of two choline-based ionic liquids on the solubility of caffeine, Journal Biomedical and Biopharmaceutical Research
          * 2018-06, COSMETINNOV – V Congress of the Portuguese Society of Cosmetological Sciences and the 1st Portuguese Fair of Ingredients and Packaging - Proceedings, Journal Biomedical and Biopharmaceutical Research
          * 2018-01-04, Applicability of Ionic Liquids in Topical Drug Delivery: A Mini Review, Journal of Pharmacology & Clinical Research
          * 2018, Proceedings - III CBIOS Seminar, Journal Biomedical and Biopharmaceutical Research
          * 2018, Proceedings - II Lusófonas Scientific Conference Days of Nutrition, Journal Biomedical and Biopharmaceutical Research
          * 2017-12-21, Applicability of Ionic Liquids in Topical Drug Delivery Systems: A Mini Review, Journal of pharmacology & clinical research
          * 2017, Permeation of Ionic Liquids through the skin, Journal Biomedical and Biopharmaceutical Research
          * 2017, Choline- versus imidazole-based ionic liquids as functional ingredients in topical delivery systems: cytotoxicity, solubility, and skin permeation studies, Drug Development and Industrial Pharmacy
          * 2017, An emerging integration between ionic liquids and nanotechnology: General uses and future prospects in drug delivery, Therapeutic Delivery
          * 2015-10, Ionic liquids as solubility/permeation enhancers for topical formulations: Skin permeation and cytotoxicity characterization, Toxicology Letters

        Thesis / Dissertation

          * 2023-12-13, PhD, Application of Ionic Liquids in the Development of Sustained Delivery Systems
          * 2017-09-27, Master, Ionic liquids as functional ingredients in drug delivery systems: solubility, permeation and cytotoxicity stydies

        Book chapter

          * 2020, An Overview on Ionic Liquids: A New Frontier for Nanopharmaceuticals, Nanopharmaceuticals: Principles and Applications Vol. 1, 1, Springer International Publishing

        Conference abstract

          * 2018-10-26, Application of ionic liquids-nanoparticles hybrid systems in food technology, II Jornadas Lusófonas da Nutrição
          * 2018-10-08, Choline-based ionic liquids to deliver poorly soluble drugs in topical delivery systems, 27th EuCheMS Conference on Molten Salts and Ionic Liquids
          * 2018-10-04, Choline-amino acid ionic liquids as functional excipients for topical delivery of poorly soluble drugs, III CBIOS Seminar
          * 2018-10-04, Application of ionic liquids in drug delivery: a nanotechnological approach, III CBIOS Seminar
          * 2018-10-04, Choline-amino acid ionic liquids as green functional excipients for topical delivery of poorly soluble drugs, III Scientific Conferences CBIOS
          * 2018-05-02, Applicability of ionic liquids in delivery systems, Sessões CBIOS
          * 2018-02-08, Ionic liquids and polymeric nanoparticles hybrid systems as new tools for delivery of poorly soluble drugs, SPF Meeting 2018
          * 2017-07, Ionic liquids as functional ingredients in drug delivery systems, Encontro Ciência 2017
          * 2017-07, Ionic liquids as functional ingredientes in drug delivery systems, Encontro Ciência 2017
          * 2016-10, Functional ingredients in delivery systems, II Jornadas CBIOS

        Conference poster

          * 2024-02-14, May TransfersomILs redefine the hydroxycinnamic acids delivery to the skin?, XV Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2024-02-14, Lipid extract from larvae biomass: an added-value biomaterial to produce lipid nanoparticles to tackle atopic dermatitis, XV Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2024-02-14, Cerosomes at the forefront: a multifunctional strategy for addressing Xeroderma Pigmentosum, XV Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2023-11-10, TransfersomILs loading caffeic or p-coumaric acids: na innovative approach for cutaneous delivery, V Jornadas CBIOS
          * 2023-11-10, TransfersomILs for the skin delivery of ferulic acid: impact on permeation assays?, V Jornadas CBIOS
          * 2023-07-05, Using insect larvae biomass to produce innovative lipid nanoparticles: a bioinspired and sustainable approach to tackle atopic dermatitis, Ciência 2023
          * 2023-06-19, TransfersomILs: an innovative nanosystem for the cutaneous delivery of hydroxycinnamic acids, NanoMed Europe 2023
          * 2023-06-19, From insect larvae biomass to lipid-based nanocarriers: an advanced approach for the management of atopic dermatitis., NanoMed Europe 2023
          * 2023-06-19, Combining lipids extracted from larvae biomass and biobased ionic liquids to boost skin nanodelivery, NanoMed Europe 2023
          * 2023-02-06, Exploring the innovative TransfersomILs for the cutaneous delivery of hydroxycinnamic acids, 4th SPLC-CRS Young Scientists Meeting
          * 2022-11-11, Probing the impact of TransferomILs containing rutin in skin physiology ¿ cytotoxicity studies, 2nd International Meeting of the Portuguese Society of Physiology
          * 2022-10-21, Improving the performance of SLNs - combining lipids extracted from larvae biomass and choline-based ILs, 5º Encontro de Biotecnologia Medicinal/2nd Iberian Congress on Medicinal Biotechnology
          * 2022-06-30, O/W emulsions containing glycinate-based ILs and phenolic compounds, InnovDelivery’22
          * 2022-06-30, Impact of the loaded phytochemical on TransfersomILs performance, InnovDelivery’22
          * 2021-11-18, The role of bioderived ionic liquids in topical formulations containing hydroxycinnamic acids, II Bio.Natural 2021 – Bioactive Natural Products Research
          * 2021-08-18, Líquidos iónicos como tática para optimizar o desempenho de formulações tópicas, 33º Congresso Brasileiro de Cosmetologia
          * 2021-06-28, Ionic liquids to upgrade the performance of O/W emulsions containing sparling soluble phenolic compounds, Encontro Ciência 2021
          * 2021-05-18, Glycine-based IL to improve the performance of O/W emulsions containing rutin, Fascination of Plants Day Event
          * 2020-11-23, The effect of phenolic compounds on human renal cancer cells and the potential combination with ionic liquids, IV CBIOS Seminar
          * 2020-11-23, Impact of amino acid ionic liquids on the stability of O/W emulsions containing rutin, IV CBIOS Seminar
          * 2020-11-03, Impact of phenolic compounds on renal cancer cells and the key applicability of ionic liquids, Encontro Ciência 2020
          * 2020-11-03, Development of rutin delivery systems assisted by a choline-amino acid ionic liquid, Encontro Ciência 2020
          * 2020-09-25, Anticancer activity of phenolic compounds on human renal cancer, Webinar – Cancer biology: from basic to translational research
          * 2020-01-22, Evaluation of the effect of ionic liquids on the stability of polymer nanoparticles, XIIIth Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2020-01, Ionic liquids as a strategy to improve drug delivery systems, 13º Encontro Nacional de Química Orgânica / 6º Encontro Nacional de Química Terapêutica
          * 2019-09-27, Ionic liquids as vehicles to deliver poorly soluble antioxidants for biomedical applications, I Bio.Natural
          * 2019-09-27, In vitro safety assessment of rutin, of a choline-based ionic liquid and of their combination in renal cells, I Bio.Natural
          * 2019-09-27, Development of lipid based nanoparticles for delivery of caffeine and curcumin, I Bio.Natural
          * 2019-07-08, Influence of a choline-based ionic liquid on the effect of rutin in renal cells, Encontro com a Ciência e Tecnologia em Portugal
          * 2019-02-25, Ionic liquids in drug delivery, COST CA17103 - Delivery of Antisense RNA Therapeutics
          * 2019-02-21, Ionic liquids-nanoparticle hybrid systems as tools to deliver poorly soluble drugs, 46th Controlled Release Society Annual Meeting & Exposition
          * 2018-11-08, Development of ionic liquid nanoparticle system for the delivery of rutin, 1a Conferência Conjunta sobre Investigação em Produtos Naturais / 4a Reunião de Coordenação da Rede Iberoavícola
          * 2018-11-08, Applicability of choline-based ionic liquids as functional excipients in topical formulations containing poorly soluble compounds, 1a Conferência Conjunta sobre Investigação em Produtos Naturais / 4a Reunião de Coordenação da Rede Iberoavícola
          * 2018-10-11, Evaluation of the cryoprotectant capacity of ionic liquids on the stabilization of polymer nanoparticles upon freeze-drying, 3rd International Symposium on BA/BE of Oral Drugs Products "Biopharmaceutics meets Galenics"
          * 2018-10-11, Design of an ionic liquids-nanoparticle hybrid system to deliver poorly soluble drugs, 3rd International Symposium on BA/BE of Oral Drugs Products "Biopharmaceutics meets Galenics"
          * 2018-10-07, Development of stable ionic liquids-polymer nanoparticle hybrid systems to deliver poorly soluble drugs, 27th EuCheMS Conference on Molten Salts and Ionic Liquids
          * 2018-10-07, Applicability of ionic liquids as functional ingredients in lipidic implants, 27th EuCheMS Conference on Molten Salts and Ionic Liquids
          * 2018-10-04, Ionic liquids-polymer nanoparticles hybrid systems as tools to deliver poorly soluble drugs, III CBIOS Seminar
          * 2018-10-04, Ionic liquids as tools to improve the leprosy treatment, III CBIOS Seminar
          * 2018-10-04, Exploitation of cryoprotectant properties of ionic liquids on the PLGA nanoparticles stabilization upon lyophilization, III CBIOS Seminar
          * 2018-07-02, Choline-based ionic liquid as green excipients for topical delivery of poorly soluble drugs, Encontro com a Ciência e Tecnologia em Portugal
          * 2018-07, Choline-based ionic liquid as green excipient for topical delivery of poorly soluble drugs , Encontro com a Ciência e Tecnologia em Portugal
          * 2018-03-19, Development of ionic liquids-polymer nanoparticles hybrid systems for delivery of poorly soluble drugs, 11th World Meeting on Pharmaceutics, Biopharmaceutics and Pharmaceutical Technology
          * 2018-03-02, Ionic liquids-polymer nanoparticle systems for the delivery of poorly soluble drugs, COSMETINNOV - V Congress of the Portuguese Society of Cosmetological Sciences and the 1st Portuguese Fair of Ingredients and Packaging
          * 2018-02-07, Polymer nanoparticles and ionic liquids hybrid systems for delivery of poorly soluble drugs, NanoPT 2018
          * 2018-02-07, A new approach for development of nanostructured lipid carriers for topical drug delivery, NanoPT 2018
          * 2018-01-14, Optimization of production of nanostrutured lipid carriers by solvent-evaporation double emulsion technique for topical drug delivery, XII Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2018-01-14, Ionic liquids and nanoparticle hybrid systems as new tools to deliver poorly soluble drugs, XII Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2018-01, Optimization of production of nanostructured lipid carriers by solvent-evaporation double emulsion technique for topical drug delivery, XII Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2018-01, Ionic liquids and nanoparticle hybrid systems as new tools to deliver poorly soluble drugs, XII Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2017-10-13, Influência do Industrial Colour-Coding na Adesão à Terapêutica, Congresso Nacional dos Farmacêuticos’17: Medicamentos para todos
          * 2017-07, Ionic liquids as functional ingredients in lipidic implants, XXV Encontro Nacional da Sociedade Portuguesa de Química
          * 2017-05, Influence of ionic liquids in drug release from lipidic implants, 6th FIP Pharmaceutical Sciences World Congress
          * 2016-10, Nanocarriers for skin delivery of cosmetic antioxidant, II Jornadas CBIOS
          * 2016-10, Amino acid based ionic liquids as functional ingredients in topical formulations containing caffeine, II Jornadas CBIOS
          * 2015-10, Study of the applicability of ionic liquids as excipients in topical formulations, V Congresso Nacional de Ciências Dermatocosméticas / IV Congresso da Sociedade Portuguesa de Ciências Cosmetológicas
          * 2015-10, Ionic liquids as functional solvents/vehicles for topical and dermocosmetic products, 28th Congress of the International Federation of Societies of Cosmetics Chemists
          * 2015-09, Ionic liquids as solubility/permeation enhancers for topical formulations: skin permeation and cytotoxicity characterization, 51st Congress of the European Societies of Toxicology
          * 2015-07, Ionic liquids as solubility/permeation enhancers for topical drug delivery systems, 19th European Symposium of Organic Chemistry
          * 2014-10, Ionic liquids as functional solvents in topical drug delivery systems, I Jornadas CBIOS
          * 2014-10, Ionic liquids as functional ingredients in topical drug delivery systems, I Jornadas CBIOS

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona