# Response for https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
          PT: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742 EN: https://www.ulusofona.pt/en/teachers/daniel-dos-santos-cardoso-3742
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
        fechar menu : https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/daniel-dos-santos-cardoso-3742
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Daniel Cardoso

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3742
              dan***@gmail.com
              3E12-8F4C-AEF8: https://www.cienciavitae.pt/3E12-8F4C-AEF8
              0000-0001-7864-7531: https://orcid.org/0000-0001-7864-7531
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/44a8b62c-d252-42e5-8b08-0a90724c812f
      : https://www.ulusofona.pt/

        Resume

        Daniel Cardoso, PhD in Communication Sciences at NOVA University of Lisbon. They are an Associate Professor at Lusófona University. They have published over 30 peer-review articles in scientific journals, as well as several book chapters. They have helped to organize over 10 national and international events, and have received several awards. They have been awarded a Marie-Slodowska Curie Fellowship from the European Commission. Their work focuses on Social Sciences, especially Sociology, Psychology, Communication Studies, Gender Studies and Queer Studies. Their last decade of work has often focused on social movements, political change and the conquest for rights around gender and sexuality, both in Portugal and internationally. They are, or have been, involved in several national and international research projects at the intersection of media, politics, and gender-sexual diversity, either as team member, task leader, or consultant. They have worked alongside several dozen academics and activists throughout their career. They have accumulated over a decade of teaching experience in the area of Media Studies, Gender and Sexualities, Psychology, Sociology, and Research Methods, in UG, MA and PhD courses.

        Graus

            * Mestrado
              Cultura Contemporânea e Novas Tecnologias
            * Doutoramento
              Ciências da Comunicação - Cultura Contemporânea e Novas Tecnologias
            * Licenciatura
              Ciências da Comunicação

        Publicações

        Artigo em revista (magazine)

          * 2023-11, Entre o silêncio das cordas [In the silence of ropes], Indizível
          * 2022-07, Pensar a(s) Família(s) para além da(s) Monogamia(s) [Thinking families beyond monogamies], Revista Insubmissa
          * 2020-03, On bonding, bondage and emotion, Eat More Bondage
          * 2015-06-30, A igualdade não casa com toda a gente, Mpessoal
          * 2012-07-01, Recensão: "Seduzir ou Informar?" de Carla Cardoso, Jornalismo & Jornalistas
          * 2012-07, Diálogo com dor, Qüir

        Edição de número de revista

          * Videogames and narratives, 2
          * Revista Lusófona de Educação [Lusophone Journal of Education]
          * Non-Monogamies and Contemporary Intimacies, 1

        Artigo em revista

          * 2023-10-25, Sexual Fluidity, BDSM and Gender: An Exploratory Study on Portuguese BDSM Practitioners, Sexuality & Culture
          * 2023-09-26, A Qualitative Study on University Students' Perceptions Regarding Sexual Violence Perpetrated by Women Against Men, Sexuality Research and Social Policy
          * 2023-02-08, Constructing Sexual Victimization: A Thematic Analysis of Reader Responses to A Literary Female-on-Male Rape Story on Goodreads, The Journal of Sex Research
          * 2022-08, Lay People´s Myths Regarding Pedophilia and Child Sexual Abuse: A Systematic Review, Sexual Medicine Reviews
          * 2022-07-14, Introduction: Parenting, polyamory and consensual non-monogamy. Critical and queer perspectives, Sexualities
          * 2022-04, Choking Autoerotic Asphyxiation: For a Reconfiguration of Discourses Around Breath Play, The Journal of Sexual Medicine
          * 2021-12-28, Diversidade relacional e olhares mediáticos: Uma década de representações jornalísticas de não-monogamias consensuais em Portugal [Relationship diversity and media gazes: A decade of journalistic representations of consensual non-monogamies in Portugal], Communitas
          * 2021-12-20, The bodies of the (digitized) body: Experiences of sexual(ised) work on OnlyFans, MedieKultur
          * 2021-07-30, Correction to: Defining Polyamory: A Thematic Analysis of Lay People's Definitions, Archives of Sexual Behavior
          * 2021-07-22, Obscenity, Pornography, Morality: Moral Power as Carnal Resonance, Journal of Science and Technology of the Arts
          * 2021-05-11, (De)Politicizing polyamory: Social media comments on media representations of consensual non-monogamies, Archives of Sexual Behavior
          * 2021-05, Defining polyamory: A thematic analysis of lay people's definitions, Archives of Sexual Behavior
          * 2020-09-09, Interview with Meg-John Barker, Sexualities
          * 2020-06-11, The value of print, the value of porn, Porn Studies
          * 2019-12, The Political Is Personal: The Importance of Affective Narratives in the Rise of Poly-activism, Sociological Research Online
          * 2019-07-29, A Construção da Identidade dos Novos Partidos em Páginas Oficiais do Facebook [The identity constrcution of new parties in official Facebook pages], Journal of Digital Media & Interaction
          * 2018-12-27, Facing polyamorous lives: translation and validation of the attitudes towards polyamory scale in a Portuguese sample, Sexual and Relationship Therapy
          * 2018-10, Watchdogs in the Social Network: A Polarized Perception?, Observatorio (OBS*)
          * 2018-06, Notas sobre a Criança transviada: considerações queerfeministas sobre infâncias [Notes on the wayward Child: Queerfeminist considerations on childhoods], Revista Periódicus
          * 2018-05, Bodies and BDSM: Redefining Sex Through Kinky Erotics, The Journal of Sexual Medicine
          * 2018-03, Review of the book Power, Knowledge and Feminist Scholarship: An Ethnography of Academia, Feminist Encounters: A Journal of Critical Studies in Culture and Politics
          * 2017-10-02, Gazing upon the (disgusted) gaze: the abnormal regulation of ‘normal’ sexuality, Porn Studies
          * 2017, Género, sexualidade e ativismo online: Um olhar intersecional para o papel da participação cívica na internet por jovens portugueses [Gender, sexuality and online activism: An intersectional look into the role of online civic engagement by portuguese youngsters], ex aequo - Revista da Associação Portuguesa de Estudos sobre as Mulheres
          * 2017, Amores Plurais Situados - Para uma meta-narrativa sociohistórica do poliamor [Situated plural loves – towards a sociohistorical metanarrative of polyamory], Revista Tempo da Ciência
          * 2015, Sexual Satisfaction and Distress in Sexual Functioning in a Sample of the BDSM Community: A Comparison Study Between BDSM and Non-BDSM Contexts, The Journal of Sexual Medicine
          * 2014-06, My Spivak is bigger than yours: (Mis-)representations of polyamory in the Portuguese LGBT movement and mononormative rhetorics, LES Online
          * 2014, Review: Grebowicz, Margret. Why internet porn matters., Participations: Journal of Audience and Reception Studies
          * 2013, Debating Polyamory as Research: an Auto-Ethnographic Account of a Round-Table on Polyamory and Lesbianism, LES Online
          * 2013, Argumentação numa esfera pública reticular: as vozes femininas online [Discussion in a reticular public sphere: feminine voices online], Comunicação & Informação
          * 2012, Reflex(ã)o nas sombras [Reflecting on shadows], revista (in)visível
          * 2011, Polyamory: Gender and Non-Monogamy on the Internet, Culture, Health & Sexuality
          * 2011, Poliamor, ou Da Dificuldade de Parir um Meme Substantivo [Polyamory, or the difficulties of spawning a substantive meme], Interact
          * 2011, 'As Desigualdades do Amor', Revista de Comunicação & Cultura, 'Pós-Género', 9: 89 - 106.
          * 2010, As Desigualdades do Amor [The inequalities of Love], Revista de Comunicação & Cultura
          * 2009, A Europa e mais além - Encontro da ESA em Lisboa [Europe and beyond – ESA meeting in Lisbon], Media & Jornalismo
          * 2008, Notícias desalinhadas de crianças em linha. Como a imprensa configura riscos e oportunidades da Internet [Misaligned news of online children. How the press configures risks and opportunities on the internet], Revista Comunicação e Sociedade

        Livro

          * 2023, História dos Ativismos Feministas em Portugal [The history of feminist activisms in Portugal], Pereira, Ana Sofia; Camila Lamartine; Cerqueira, Carla; Taborda, Célia; Cardoso, Daniel; Drummond, Daniela; Babo, Isabel; et al, Edições Universitárias Lusófonas
          * 2005, Pena Que Sangra, Cardoso, Daniel, Corpos Editora

        Capítulo de livro

          * 2023, Navigating Dissonant Desires: Kink (In)Compatibility in Romantic Relationships, The Power of BDSM: Play, Communities, and Consent in the 21st Century, Oxford University Press
          * 2022, O poder das palavras [The power of words], Media, masculinidades e equidade de género: O papel da comunicação na transformação social, Centro de Estudos Sociais da Universidade de Coimbra
          * 2022, Living outside the box - Consensual Non-Monogamies, Intimacies and Communities. Notes on Research and Terminology, The Handbook of Consensual Non-Monogamy: Affirming Mental Health Practices, Rowman & Littlefield
          * 2022, Digital Sex Work?
          * 2021, Breaking the silence: Young people, sex information and the internet in Italy and Portugal, Gender and Sexuality in the European Media: Exploring Different Contexts Through Conceptualisations of Age, Routledge
          * 2020, Situações problemáticas na internet e modos de lidar com elas [Problematic situations on the internet and ways of dealing with it], Nós na Rede: Ambientes digitais de crianças e jovens, Edições Almedina
          * 2020, Género e experiências digitais. Tensões entre estereótipos e autonomias [Gender and digital experiences: Tensions between stereotypes and autonomies], Nós na Rede: Ambientes digitais de crianças e jovens, Edições Almedina
          * 2018, Celos, género y comunidad [Jealousy, gender and community], (h)amor3: celos y culpas, Continta Me Tienes
          * 2017, ‘I sort of knew what I was, so I wanted to see what awaited me’: Portuguese LGB youngsters and their situated experiences with new media, LGBTQs, Media and Culture in Europe, Routledge
          * 2015, Del amor a la amistad [From love to friendship], (h)amor2, Continta Me Tienes
          * 2013, Em casa e no quarto: modelos de uso da internet por crianças e jovens (9-16 anos) [At home and in the bedroom: models of internet usage by children and youngsters (9-16 year olds)], Nascidos Digitais: Novas Linguagens, Lazer e Dependências, Coisas de Ler
          * 2012, Introdução, Crianças e internet em Portugal, MinervaCoimbra
          * 2012, Ficção científica (social) - As ténues fronteiras entre real e ficção [(Social) Science Fiction - The thin borders between reality and fiction], Cibercultura e Ficção, Documenta
          * 2012, A cultura de quarto e o uso excessivo da internet. Resultados nacionais do inquérito EU Kids Online [Bedroom culture and excessive internet use. National Results from the EU Kids Online], Crianças e Internet em Portugal, 1, MinervaCoimbra
          * 2012, 'Loving Many': Polyamorous Love, Gender and Identity, Gender and Love: Interdisciplinary Perspectives, Inter-Disciplinary Press

        Edição de livro

          * 2012, 1, MinervaCoimbra
          * 2009

        Tradução

          * 2008, “Os baldas tomam as ruas”: Jovens, política e cidadania no Reino Unido, Minerva
          * 2008, Media e Direitos das Crianças, Minerva
          * 2007, Será possível uma voz global? Crianças migrantes, novos media e limites do empowering, MinervaCoimbra
          * 2007, Recensão, Minerva

        Artigo em jornal

          * 2022-05-19, A Criança Cidadã e a Criança-Objecto ou, Da Parentalidade como Omnipotência, Setenta e Quatro
          * 2017-12-12, O machismo também se automatiza, P3
          * 2017-06-07, A “arma fumegante” invisível do machismo, P3
          * 2017-02-28, A democracia passa bem sem jornalismo, P3
          * 2016-12-22, Abstinência sexual e morte, Geringonça
          * 2016-12-20, Homofobia e silêncios em João Miguel Tavares, P3
          * 2016, Violação sexual e Verdade, P3
          * 2016, Orlando e o fantasma do Islão, P3
          * 2016, Orlando e a heterossexualidade tóxica, P3
          * 2016, Mude-se o nome para "dia d@s espancad@s", P3
          * 2015-11-13, A direita é "Deus, Pátria, Família", P3
          * 2015, Olho por olho, vídeo por vídeo, P3
          * 2014-07-25, "Poliamor" - Porque surgem novas palavras: Direito de Resposta publicado por decisão da ERC, Diário de Notícias
          * 2014, Tantos Charlies, tão pouca liberdade, P3
          * 2014, Socorro, o meu telemóvel não me impede de violar mulheres!, P3
          * 2014, O colonialismo deixou saudades e sede de violência, P3
          * 2014, Das masculinidades-chouriço e do feminismo como ingrediente principal, A Comuna
          * 2014, Co-adopção: "ser moderado" bem que podia ser crime, P3
          * 2013, Um amor anémico, P3
          * 2013, Passada uma semana..., P3
          * 2013, Parentalidades e direitos para além dos dualismos, P3
          * 2013, O Papa diz para não se paparem, P3
          * 2013, Engolir piropos não devia provocar o reflexo de vómito, P3
          * 2013, Adoptar para além do romantismo, P3
          * 2013, (Des)Amarrar a diferença, P3
          * 2012, O Rio da Ignorância, P3
          * 2012, As galdérias (também) marcham, P3

        Artigo em boletim informativo

          * 2014, Feminismo e o combate ao privilégio, ou A arte de fazer perguntas incómodas, Comemorações do Dia da Mulher: Colectânea de Textos sobre Feminismo e Igualdade de Género

        Entrada de enciclopédia

          * Women's Lifestyle Magazines, The International Encyclopedia of Gender, Media, and Communication
          * Pornography as Education, The International Encyclopedia of Gender, Media, and Communication

        Relatório

          * 2021-11-30, Consensual non-monogamies: Policy and Political activist perspectives from Portugal and the UK, https://www.danielscardoso.net/images/docs/short%20report%20political%20cnm-moves_final.pdf
          * 2021-11-20, Consensual Non-monogamies in the UK press: The Years 2010-2014, https://www.danielscardoso.net/images/docs/short%20report%20uk1_vfinal.pdf
          * 2020-07, Ten years of consensual non-monogamies in the media in Portugal - An analysis of news coverage, https://www.mmu.ac.uk/media/mmuacuk/content/documents/rcass/cnm-moves/Short-Report-PT-en_v7_FINAL.pdf
          * 2020-07, Dez anos de não-monogamias consensuais nos media em Portugal - Uma análise da cobertura jornalística, https://www.mmu.ac.uk/media/mmuacuk/content/documents/rcass/cnm-moves/Short-Report-PT_v4.pdf
          * 2016, Relatório Científico do Projeto #ON_Sex, http://dx.doi.org/10.5935/ref.20160087
          * 2011, Stakeholders’ consultation 2: general report
          * 2010, Stakeholders' Forum General Report, http://www2.lse.ac.uk/media@lse/research/EUKidsOnline/EUKidsII%20(2009-11)/EU%20Kids%20Online%20II%20Reports.aspx
          * 2009, A Primeira das Primeiras. Colégio Conciliar de Maria Imaculada e a Escola do Futuro PT

        Manual

          * 2009, Guia do/a Formador/a de “Sessão de Sensibilização em Segurança Online de Crianças”

        Recurso online

          * 2020-06-25, Intimidades digitais, pandemia e capitalismo [Digital intimacies, pandemics and capitalism], https://antropia.hypotheses.org/?p=1028

        Artigo em conferência

          * ‘Loving Many’: Polyamorous Love, Gender and Identity, 1st Gender and Love Conference
          * Training young trainers, empowering children, Faro Euromeduc Seminar
          * Explorando perfis de vulnerabilidade para uma sensibilização do risco. Contributos do Projecto EU Kids Online. , XVII Encontro da Adolescência
          * Experiências de poliamor no espaço público: auto e hetero escrita etnográfica, VIII Congresso da Geografia Portuguesa
          * Entre nativos digitais e fossos geracionais. Questionando acessos, usos e apropriações dos novos media por crianças e jovens, XVI Encontro da Adolescência
          * Between access and use: a case-study on technology mediation in a school environment., V International Conference on Multimedia and ICT in Education (m-ICTE2009)
          * Atenção à Diferença Digital Entre Gerações, ESA Research Network 18 Metting
          * Acessos e Usos: estudo de caso sobre a mediação das tecnologias em contexto escolar., VI Congresso SOPCOM
          * 2021-07-13, How the Portuguese media represented the first racialized female MP head of a political party, IAMCR Online 2021 - 11-15 July
          * 2018, Making games, making literacy: A case-study in formal educational contexts, 12th European Conference on Games Based Learning
          * Polyamory as a possibility of feminine empowerment, 9th Conference of European Sociological Association

        Resumo em conferência

          * 2023-06-05, The (Re-)Start of a Portuguese #MeToo: Tensions and re-mobilizations on Twitter, IAMCR2023
          * 2022, Maximizing the Audiences: Portuguese Parties' Facebook Presence in 2019, General Online Research Conference 2022 (GOR 2022)
          * 2016, Polyamory as a gendered experience: Portuguese women talk about non-monogamies and discrimination, 6º Congresso da Associação Portuguesa de Antropologia
          * 2016, Poliamor numa perspectiva genderizada - Discriminação e preconceitos na voz de mulheres em não-monogamias consensuais, 1st International Congress of the Interdisciplinary Center for Gender Studies
          * 2015, Entre informações, titilações e identificações: Os papéis da internet como recurso de informação sobre sexualidade para jovens, 9º Congresso SOPCOM
          * 2015, A imprensa como facilitadora de voyeurismo sexual: Representações de BDSM e de fetichismo no jornalismo em Portugal, 9º Congresso SOPCOM
          * 2015, "Activismo não é tanto a minha praia, gosto mais de fazer mesmo as coisas". Concepções e contestações de participação cívica na cidadania para a intimidade, Activismo em Tempos de Crise
          * 2014-01-01, The voyeuristic fascination of sexual alterity: BDSM and kink representations in Portuguese journalism, Gender in focus: (new) trends in media
          * 2014-01-01, Portuguese youngsters, new media and sexuality – information, activism and pleasure-seeking experiences, Gender in focus: (new) trends in media
          * 2013, Portuguese youngsters and sexualized usages of new media, Midterm ESA Sexualities Research Network Conference
          * 2013, Polyamory: attempting an identitary meta-narrative, Critical Social Psychology: Discourse Materiality and Politics Conference
          * 2013, My Spivak is bigger than yours: (Mis-)representations of polyamory in the Portuguese LGBT movement and mononormative rhetorics, 2nd European Geographies of Sexualities Conference
          * 2012, Tempos e espaços da utilização da internet: a adicção e a cultura de quarto, Conferência Final do EU Kids Online II
          * 2012, Reading books as spaces - Heterotopias against techno-scientific determinism, Mensageiros das Estrelas: Episódio II
          * 2012, Polyamory awareness-raising: An auto-ethnographic account of a round-table on polyamory and lesbianism, Sexual Cultures Conference
          * 2012, Poliamor - género e feminismo, ausências presentes, VII Congresso Português de Sociologia
          * 2012, Orgasmic puppeteering: sex and sexuality in Portuguese women's and men's magazines, 11th International Conference on Social Representations
          * 2012, Internet, riscos e segurança online de crianças e jovens: resultados portugueses do projecto EU Kids Online, VII Congresso Português de Sociologia
          * 2012, Ficção científica (social) - As ténues fronteiras entre real e ficção, Colóquio "Ficção e Cibercultura"
          * 2012, Communicate, communicate, communicate: Sexual and intimacy ethics in polyamory, IASR Conference
          * 2012, "Communicate, communicate, communicate" - building ethical subjectivities within polyamory, Sexual Cultures Conference
          * 2011, Sexualized Technology: Portuguese Youngsters and the New Media, 10th Conference of the European Sociological Association
          * 2011, Polyamory: relationship identities from sex to feelings, 10th Conference of the European Sociological Association
          * 2011, Polyamory: gender and non-monogamy on the Internet, Naming and Framing: The Making of Sexual (In)Equality
          * 2011, Poliamor: género e não-monogamia na Internet, VII Congresso da SOPCOM
          * 2011, Experiences of polyamory in Public Space: ethnographic self and alter-writing, EUROPEAN GEOGRAPHIES OF SEXUALITIES CONFERENCE
          * 2011, (Ir)racionalidades da diferença sexual – manifestações genderizadas da esfera pública online no fórum ex aequo, VII Congresso da SOPCOM
          * 2009, Inequalities of Love: Portraying Romantic Relationships in Women’s and Men’s Magazines, Media, Communication and the Spectacle - ECREA
          * 2008, Mind the (generational) gap. Children’s online experiences, adult concerns and challenges for rising awareness in European countries, European Sociological Association RN18 Meeting
          * 2008, Generational gaps in internet use in Portugal at home and at school: implications for media literacy, IAMCR XXVI International Conference

        Poster em conferência

          * 2023-08, Diversity in partner number sexuality via Sexual Configurations Theory, International Academy of Sex Research 2023 Conference
          * 2023-04, Diversity in partner number sexuality via Sexual Configurations Theory, Queen's Honours Thesis Psychology Research Day

        Arte visual

          * Herm::aphrodite
          * Classic needleplay photo

        Conjunto de dados

          * Referências ao conflito israelo-palestiniano em imprensa Portuguesa 7Out-7Nov 2023, Recolha feita através da plataforma MediaCloud, a 8 de Novembro de 2023, por Daniel Cardoso, que recolhe referências ao conflito israelo-palestiniano no jornalismo digital em Portugal entre 7 de Outubro e 7 de Novembro de 2023.
          * List of Opinion Pieces on Joacine Katar Moreira - 2nd half of 2019

        Outra produção

          * 2016, PROJECTO #ON_SEX DIREITOS SEXUAIS E JOVENS VULNERÁVEIS

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona