# Response for https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
          PT: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128 EN: https://www.ulusofona.pt/en/teachers/diogo-dos-santos-teixeira-5128
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
        fechar menu : https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/diogo-dos-santos-teixeira-5128
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Diogo S. Teixeira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5128
              dio***@ulusofona.pt
              8613-9D4F-7E6C: https://www.cienciavitae.pt/8613-9D4F-7E6C
              0000-0003-4587-5903: https://orcid.org/0000-0003-4587-5903
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/481fae37-775a-4ac4-9c3a-b810ba6ab03c
      : https://www.ulusofona.pt/

        Resume

        Diogo S. Teixeira. Publicou mais de 100 artigos em revistas especializadas. No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural são: psychological assessment; confirmatory factor analysis; self-determination theory; multi-group analysis; physical education; Self-Determination Theory; sport; exercise; emotional response.

        Graus

            * Doutoramento
              Educação Física e Desporto
            * Mestrado
              Exercício e Bem-Estar
            * Pós-Graduação
              Saúde, Nutrição e Exercício
            * Licenciatura
              Educação Física e Desporto

        Publicações

        Artigo em revista

          * 2024-01-03, The Nostrum to Exercise: How Self-Selected and Imposed Exercise Intensity Prescription Relates to Affective, Cognitive, and Behavioral Outcomes - A Systematic Review, Cuadernos de Psicología del Deporte
          * 2024, Validation of the Portuguese Version of the Perceived Physical Literacy Instrument, Journal of Physical Activity and Health
          * 2023-12-14, From data to action: a scoping review of wearable technologies and biomechanical assessments informing injury prevention strategies in sport, BMC Sports Science, Medicine and Rehabilitation
          * 2023-11, Affective responses to stretching exercises: Exploring the timing of assessments, Psychology of Sport and Exercise
          * 2023-09-16, O exercício físico e a vitalidade: análise multigrupos em função do sexo e experiência da prática, Cuadernos de Psicología del Deporte
          * 2023-07-26, The relationships between passions, intentions, habit and exercise frequency, Journal of Sports Sciences
          * 2023-07, Exploring the impact of individualized pleasure-oriented exercise sessions in a health club setting: Protocol for a randomized controlled trial, Psychology of Sport and Exercise
          * 2023-03-20, Adolescents’ enjoyment in face-to-face physical education during the COVID-19 pandemic, European Physical Education Review
          * 2023-03-01, Assessing Affective Valence and Activation in Stretching Activities with the Feeling Scale and the Felt Arousal Scale: A Systematic Review, Perceptual and Motor Skills
          * 2023-01-20, How Does the Level of Physical Activity Influence Eating Behavior? A Self-Determination Theory Approach, Life
          * 2023-01-02, Experiência profissional e formação académica dos profissionais de exercício físico: relação das pressões no trabalho com as necessidades psicológicas básicas no contexto laboral, Retos
          * 2023, Validity of a wearable device for measuring vertical displacement and jump count in young artistic roller skating athletes, Proceedings of the Institution of Mechanical Engineers, Part P: Journal of Sports Engineering and Technology
          * 2023, Using Psychometric Testing Procedures for Scale Validity, Reliability, and Invariance Analysis: The PRETIE-Q Portuguese Version, European Journal of Investigation in Health, Psychology and Education
          * 2023, Testing Assumptions of the Physical Activity Adoption and Maintenance Model: A Longitudinal Perspective of the Relationships Between Intentions and Habits on Exercise Adherence, Perceptual and Motor Skills
          * 2023, Measuring Need-Supportive and Need-Thwarting Behaviors Among Athletes from Different Sports: Scale Validity and Reliability, Measurement in Physical Education and Exercise Science
          * 2023, Autonomic responses and internal load analysis through acute assessment of heart rate variability after a high-intensity functional training session,Respuestas autonómicas y análisis de la carga interna mediante la evaluación aguda de la variabilidad de la frecuencia cardíaca tras una sesión de entrenamiento funcional de alta intensidad, Archivos de Medicina del Deporte
          * 2023, Assessing affective valence and activation in resistance training with the feeling scale and the felt arousal scale: A systematic review, PLoS ONE
          * 2023, Are Preference and Tolerance Measured With the PRETIE-Q (Preference for and Tolerance of the Intensity of Exercise Questionnaire) Relevant Constructs for Understanding Exercise Intensity in Physical Activity? A Scoping Review, Kinesiology Review
          * 2023, Analysis of the Effect of Different Physical Exercise Protocols on Depression in Adults: Systematic Review and Meta-analysis of Randomized Controlled Trials, Sports Health
          * 2022-11, The Behavioral Regulation in Exercise Questionnaire (BREQ-4): Psychometric evidence of introjected approach regulation in Portuguese health club exercisers, Psychology of Sport and Exercise
          * 2022-09-30, Clinical applications of exercise in Parkinson’s disease: what we need to know?, Expert Review of Neurotherapeutics
          * 2022-09, Affective responses to resistance exercise: Toward a consensus on the timing of assessments, Psychology of Sport and Exercise
          * 2022-08-20, Validação da Passion Scale para a população portuguesa praticante de exercício físico, Cuadernos de Psicología del Deporte
          * 2022-08-20, Translation and Construct Validity of the Feeling Scale and the Felt Arousal Scale in Portuguese Recreational Exercisers, Cuadernos de Psicología del Deporte
          * 2022-08-14, Understanding the Associations across Fibromyalgia-Related Fatigue, Depression, Anxiety, Self-Esteem Satisfaction with Life and Physical Activity in Portuguese and Brazilian Patients: A Structural Equation Modeling Analysis, Medicina
          * 2022-08-09, Set to fail: Affective dynamics in a resistance training program designed to reach muscle concentric failure, Scandinavian Journal of Medicine & Science in Sports
          * 2022-05-12, The preference for and tolerance of exercise intensity: An exploratory analysis of intensity discrepancy in health clubs settings, Current Psychology
          * 2022-04-17, Exploring the Relationship between Fibromyalgia-Related Fatigue, Physical Activity, and Quality of Life, International Journal of Environmental Research and Public Health
          * 2022-01-02, Can regular physical exercise be a treatment for panic disorder? A systematic review, Expert Review of Neurotherapeutics
          * 2022, The relationship between past exercise behavior and future exercise adherence: A sequential mediation analysis, Journal of Sports Sciences
          * 2022, The circumplex model of affect in physical activity contexts: a systematic review, International Journal of Sport and Exercise Psychology
          * 2022, Impact of victory and defeat on the perceived stress and autonomic regulation of professional eSports athletes, Frontiers in Psychology
          * 2022, Enjoyment as a Predictor of Exercise Habit, Intention to Continue Exercising, and Exercise Frequency: The Intensity Traits Discrepancy Moderation Role, Frontiers in Psychology
          * 2022, Corrigendum: Impact of victory and defeat on the perceived stress and autonomic regulation of professional eSports athletes(Front. Psychol., (2022), 13, (987149), 10.3389/fpsyg.2022.987149), Frontiers in Psychology
          * 2022, Assessment in Sport and Exercise Psychology: Considerations and Recommendations for Translation and Validation of Questionnaires, Frontiers in Psychology
          * 2021-10, O papel do divertimento e das determinantes motivacionais na persistência da prática de exercício físico, Ciência & Saúde Coletiva
          * 2021-08-17, Re-Applying the Basic Psychological Needs in Exercise Scale to Various Portuguese Exercise Groups: An Analysis of Bifactor Models and Contextual Invariance, Perceptual and Motor Skills
          * 2021-08-11, The dualistic model of passion in adapted sport: a double-serial mediation analysis on satisfaction with life, Current Psychology
          * 2021-04-24, Preference for and tolerance of the intensity of exercise questionnaire (PRETIE-Q): validity, reliability and gender invariance in Portuguese health club exercisers, Current Psychology
          * 2021-01-01, Análise comportamental da prática de exercício físico em adultos em contexto de ginásio ao longo de dois anos, Cuadernos de Psicología del Deporte
          * 2021-01, Adaptation and validation of the Portuguese version of the regulation of eating behavior scale (REBSp), Appetite
          * 2021, The Physical Activity Enjoyment Scale (Paces) as a Two-Dimensional Scale: Exploratory and Invariance Analysis, Montenegrin Journal of Sports Science and Medicine
          * 2021, The Co-Occurrence of Satisfaction and Frustration of Basic Psychological Needs and Its Relationship with Exercisers' Motivation, The Journal of Psychology
          * 2021, Preference for and tolerance of exercise intensity: the mediating role of Vitality in Exercise Habit, International Journal of Sport Psychology
          * 2021, Personal Training: Recommendations for Raising the Quality of the Service Provided
          * 2021, Perceptions of an Online Mental Cooldown: Acceptability of a Post-Exercise Psychological Skills Intervention, International Journal of Sport Psychology
          * 2021, Life satisfaction of Paralympians: The role of needs satisfaction and passion
          * 2021, Fitness trainers’ use of need-supportive and need-thwarting behaviors: the role of gender, fitness activity, and professional experience, Revista Andaluza de Medicina del Deporte
          * 2021, Differences between Portuguese and Brazilian Patients with Fibromyalgia Syndrome: Exploring the Associations across Age, Time of Diagnosis, and Fatigue-Related Symptoms, Medicina
          * 2021, Did You Enjoy It? The Role of Intensity-Trait Preference/Tolerance in Basic Psychological Needs and Exercise Enjoyment
          * 2021, Could tDCS Be a Potential Performance-Enhancing Tool for Acute Neurocognitive Modulation in eSports? A Perspective Review, International Journal of Environmental Research and Public Health
          * 2021, Cognitive-motivational model for the promotion of persistence in higher education: relationship between teaching organization, student competence and grit, Estudios Sobre Educacion
          * 2021, Cognitive-motivational model for the promotion of persistence in higher education: Relationship between teaching organization, student competence and grit,Modelo cognitivo-motivacional para la promoción de la persistencia en Educación Superior: Relación entre la organización docente, la competencia del alumnado y el grit, Estudios Sobre Educacion
          * 2021, Análise comportamental da prática de exercício físico em adultos em contexto de ginásio ao longo de dois anos, Cuadernos de Psicología del Deporte
          * 2021, Adaptation and Validation of a Portuguese Version of the Sports Motivation Scale-II (SMS-II-P) Showing Invariance for Gender and Sport Type, Perceptual and Motor Skills
          * 2021, A avaliação do hábito em praticantes de exercício físico: Testando a validade do Self-Report Behavioral Automaticity Index
          * 2020-09-27, Trainer-exerciser relationship: The congruency effect on exerciser psychological needs using response surface analysis, Scandinavian Journal of Medicine & Science in Sports
          * 2020-08-30, Exercise is medicine: a new perspective for health promotion in bipolar disorder, Expert Review of Neurotherapeutics
          * 2020-07-22, The Multidimensional Daily Diary of Fatigue-Fibromyalgia-17 Items (MDF-Fibro-17): Evidence from Validity, Reliability and Transcultural Invariance between Portugal and Brazil, Journal of Clinical Medicine
          * 2020-07-16, What Is the Recommended Dose of Physical Activity in the Treatment of Depression in Adults? A Protocol for a Systematic Review, Sustainability
          * 2020-06-05, Understanding Needs Satisfaction and Frustration in Young Athletes: Factor Structure and Invariance Analysis, International Journal of Environmental Research and Public Health
          * 2020-06, Assessing the Relationship between Autonomy Support and Student Group Cohesion across Ibero-American Countries, International Journal of Environmental Research and Public Health
          * 2020-05-27, Sex Differences in Relationships Between Perceived Coach-Induced Motivational Climates, Basic Psychological Needs, and Behavior Regulation Among Young Swimmers, Perceptual and Motor Skills
          * 2020-04-18, Motivation in sport and exercise: a comparison between the BRSQ and BREQ, Quality & Quantity
          * 2020-04-15, Exploração de um modelo de segunda ordem da Versão Portuguesa da Basic Psychological Needs in Exercise Scale (BPNESp): validade do constructo e invariância, Cuadernos de Psicología del Deporte
          * 2020-04-05, The bright and dark sides of motivation as predictors of enjoyment, intention, and exercise persistence, Scandinavian Journal of Medicine & Science in Sports
          * 2020-02-12, Understanding Exercise Adherence: The Predictability of Past Experience and Motivational Determinants, Brain Sciences
          * 2020, Understanding exercise adherence: the predictability of past experience and motivational determinants
          * 2020, The retinoid X receptor: a nuclear receptor that modulates the sleep-wake cycle in rats, Psychopharmacology
          * 2020, The relationship between teachers and peers’ motivational climates, needs satisfaction, and physical education grades: an AGT and SDT approach
          * 2020, Teaching the coach to be a football coach: A theoretical approach with practical implications, Revista Brasileira de Futsal E Futebol
          * 2020, O papel dos instrutores de fitness na adesão à prática de exercício físico em Portugal: a importância dos comportamentos de suporte e dos climas motivacionais
          * 2020, Motivation in sport and exercise: a comparison between the BRSQ and BREQ
          * 2020, Ginásios e Health Clubs em Portugal: Estaremos perante uma República das Bananas?
          * 2020, Fitness instructor’s role on exercise adherence in Portugal: the importance of need-supportive behaviors and motivational climates, Motricidade
          * 2020, Exergames for children and adolescents with autism spectrum disorder: An overview, Clinical Practice and Epidemiology in Mental Health
          * 2020, Examining achievement goals in exercisers: adaptation and validation of the goal orientations in exercise measure (GOEM)
          * 2020, COVID-19 and Quarantine: Expanding Understanding of How to Stay Physically Active at Home
          * 2020, Assessing the relationship between autonomy support and student group cohesion across Ibero-American countries
          * 2020, Assessing the Management of Excessive Daytime Sleepiness by Napping Benefits, Sleep and Vigilance
          * 2020, A perceção de divertimento em jovens, adultos e idosos: um estudo comparativo, Cuadernos de Psicología del Deporte
          * 2020, A Motivational Pathway Linking Physical Activity to Body-Related Eating Cues, Journal of Nutrition Education and Behavior
          * 2019-12-06, The role of dark-side of motivation and intention to continue in exercise: A self-determination theory approach, Scandinavian Journal of Psychology
          * 2019-11-28, Examining exercise motives between gender, age and activity: A first-order scale analysis and measurement invariance, Current Psychology
          * 2019-10-20, Motivational patterns in persistent swimmers: A serial mediation analysis, European Journal of Sport Science
          * 2019-09-25, Have you been exercising lately? Testing the role of past behavior on exercise adherence, Journal of Health Psychology
          * 2019-07-25, The Basic Psychological Need Satisfaction and Frustration Scale in Exercise (BPNSFS-E): Validity, Reliability, and Gender Invariance in Portuguese Exercisers, Perceptual and Motor Skills
          * 2019-07-15, Initial validation of the Portuguese version of the Interpersonal Behavior Questionnaire (IBQ & IBQ-Self) in the context of exercise: Measurement invariance and latent mean differences, Current Psychology
          * 2019-07-09, Estimulación transcraneal de corriente continua anódica como potencial recurso ergogénico para fuerza muscular y percepción de esfuerzo:, Cuadernos de Psicología del Deporte
          * 2019-06-25, Promoting Physical Exercise Participation: The Role of Interpersonal Behaviors for Practical Implications, Journal of Functional Morphology and Kinesiology
          * 2019-05-14, The Passion Scale—Portuguese Version: Reliability, Validity, and Invariance of Gender and Sport, Perceptual and Motor Skills
          * 2019-01-23, Behavioral Regulation Sport Questionnaire: Gender and Sport Invariance in Portuguese Athletes, Perceptual and Motor Skills
          * 2019-01-16, Assessing Need Satisfaction and Frustration in Portuguese Exercise Instructors: scale validity, reliabity and invariance between gender, Cuadernos de Psicología del Deporte
          * 2019, Physical exercise and sedentary lifestyle: health consequences.
          * 2019, Perceived Environmental Supportiveness Scale: Portuguese Translation, Validation and Adaptation to the Physical Education Domain, Motriz: Revista de Educação Física
          * 2019, Motivational determinants of physical education grades and the intention to practice sport in the future, PLOS ONE
          * 2019, Impact of aerobic exercise on anxiety and neurobiological mechanisms in panic disorder: a mini-review, Journal of Physical Education and Sport
          * 2018-11-06, Can Interpersonal Behavior Influence the Persistence and Adherence to Physical Exercise Practice in Adults? A Systematic Review, Frontiers in Psychology
          * 2018-06-29, How does frustration make you feel? A motivational analysis in exercise context, Motivation and Emotion
          * 2018, Translation and validation of the perceived locus of causality questionnaire (PLOCQ) in a sample of Portuguese physical education students, Motriz. Revista de Educacao Fisica
          * 2018, The Behavioral Regulation in Exercise Questionnaire (BREQ-3) Portuguese-version: Evidence of reliability, validity and invariance across gender, Frontiers in Psychology
          * 2018, Perceived effort in football athletes: The role of achievement goal theory and self-determination theory, Frontiers in Psychology
          * 2018, PERFIL HEMATOLÓGICO DOS JOGADORES DE UMA EQUIPE DE FUTEBOL DE ELITE DA 1ª LIGA PORTUGUESA, Revista Brasileira de Futsal e Futebol
          * 2018, Hematological profile of players from a elite team football of the Portigiese 1st league, Revista Brasileira de Futsal E Futebol
          * 2018, Associations between affect, basic psychological needs and motivation in physical activity contexts: Systematic review and meta-analysis, Revista Iberoamericana de Psicologia del Ejercicio y el Deporte
          * 2016, Needs satisfaction effect on exercise emotional response: A serial mediation analysis with motivational regulations and exercise intensity, Motriz. Revista de Educacao Fisica
          * 2016, Expectation and beliefs: Influence on health based on physical exercise,Expectativas e crenças: Influência na saúde tendo por base o exercício físico, Revista Iberoamericana de Psicologia del Ejercicio y el Deporte
          * 2016, EXPECTATION AND BELIEFS: INFLUENCE ON HEALTH BASED ON PHYSICAL EXERCISE, Revista Iberoamericana de Psicologia del Ejercicio Y el Deporte
          * 2015, Analysis of the indirect effects of the quality of motivation on the relation between need satisfaction and emotional response to exercise, International Journal of Sport Psychology
          * 2014, Non Formal Education in the Prevention of Alcohol-related Problems
          * 2014, A Educação Não Formal na Prevenção dos Problemas Ligados ao Álcool
          * 2013-03, Priming, mindfulness e efeito placebo. Associação com a saúde, exercício físico e actividade física não programada. Uma revisão sistemática da literatura, Revista Andaluza de Medicina del Deporte
          * 2013, Priming, mindfulness and placebo effect. Association with health, physical exercise and non-structured physical activity. A systematic review of the literature,Priming, mindfulness e efeito placebo. Associação com a saúde, exercício físico e actividade física não programada. Uma revisão sistemática da literatura, Revista Andaluza de Medicina del Deporte
          * 2013, Nutrição na atividade física e estilos de vida saudáveis: Novas perspetivas., REDAF

        Outra produção

          * 2016, Exercise Motivational and Emotional Processes: An Exploratory Study of the Moderation Role of Basic Psychological Needs Satisfaction
          * 2016, Estudo observacional do golo no futebol: Deteção de padrões temporais
          * 2016, Análise dos golos em equipas de elite de futebol

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona