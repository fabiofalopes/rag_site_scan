# Response for https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
          PT: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343 EN: https://www.ulusofona.pt/en/teachers/ana-sofia-pereira-caldeira-6343
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
        fechar menu : https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-sofia-pereira-caldeira-6343
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Sofia P. Caldeira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6343
              sof***@ulusofona.pt
              1B1C-18F4-9B4E: https://www.cienciavitae.pt/1B1C-18F4-9B4E
              0000-0001-7681-6952: https://orcid.org/0000-0001-7681-6952
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/85c0f8e4-8adc-42dd-a023-a9e80f288165
      : https://www.ulusofona.pt/

        Resume

        Sofia P. Caldeira is Marie Sklodowska-Curie postdoctoral fellow at CICANT, Lusófona University (doi: 10.54499/UIDB/05260/2020). Her current project, "Exploring Ephemeral Feminisms on Portuguese Instagram," focuses how online feminist practices take shape in increasingly popular yet under-researched practices of ephemeral social media by focusing on Instagram stories. She holds a Communication Sciences PhD from Ghent University, Belgium (2020), funded by the Fundação para a Ciência e Tecnologia (FCT). Her doctoral dissertation, entitled "Instagrammable Femininities: Exploring the gender politics of self-representations on Instagram and women's magazines", explored contemporary social media cultures and practices of self-representation and their intertextual relationship with women's magazines. Her research focuses primarily on social media, self-representation practices, politics of gender representation, everyday aesthetics, and feminist media studies. Sofia¿s research has been published in journals such as Social Media + Society, Feminist Media Studies, and Information Communication & Society. She currently serves as the Chair of ECREA¿s Digital Culture and Communication section. Sofia has also completed a master degree in Anthropology - Visual Cultures in 2014 by Universidade Nova de Lisboa, Faculdade de Ciências Sociais e Humanas and a bachelors in Art and Multimedia in 2011 by Universidade de Lisboa, Faculdade de Belas-Artes.

        Graus

            * Curso de Especialização Tecnológica
              Realização I
            * Licenciatura
              Arte e Multimédia
            * Mestrado
              Antropologia - Culturas Visuais
            * Doctorat
              PhD Student (Department of Communication Sciences)

        Publicações

        Magazine article

          * 2015-07, Copy As Creation: The Reversal of the Benjaminian Concept of Aura and the Aesthetics of the Accidental in Rachel Phillips // Madge Cameron's Fixed, Interartive Magazine, Special Issue - Original VS Copy

        Journal article

          * 2023-06-12, Situating #MeToo: a comparative analysis of the movement in Catalonia and Portugal, Media, Culture & Society
          * 2023-05, Instagrammable feminisms: Aesthetics and attention-seeking strategies on Portuguese feminist Instagram, Convergence
          * 2023, The red lipstick movement: exploring #vermelhoembelem and feminist hashtag movements in the context of the rise of far-right populism in Portugal, Feminist Media Studies
          * 2023, The Pluralization of Feminist Hashtag Landscapes: An Exploratory Mapping of Feminist Hashtags on Portuguese Instagram, Social Media + Society
          * 2022, Photographable Femininities: An intertextual comparative analysis of representations of femininity in women's magazines and on Instagram, European Journal of Cultural Studies
          * 2021, It's not just Instagram models: Exploring the gendered political potential of young women's Instagram use, Media and Communication
          * 2020-07, Between the Mundane and the Political: Women's Self-Representations on Instagram, Social Media + Society
          * 2020, Shop it. Wear it. Gram it.: A qualitative textual analysis of women's fashion glossy magazines and their intertextual relationship with Instagram, Feminist Media Studies
          * 2020, "Everybody needs to post a selfie every once in a while": exploring the politics of Instagram curation in young women's self-representational practices, Information, Communication & Society
          * 2018, Exploring the Politics of Gender Representation on Instagram: Self-representations of Femininity, DiGeSt: Journal of Diversity and Gender Studies
          * 2018, A Different Point of View: Women's Self-Representation in Instagram's Participatory Artistic Movements @girlgazeproject and @arthoecollective, Critical Arts: South-North Cultural and Media Studies
          * 2017-10-01, Representing diverse femininities on Instagram: A case study of the body-positive @effyourbeautystandards Instagram account, Catalan Journal of Communication & Cultural Studies
          * 2017, As Potencialidades do Estudo da Imagem Fotográfica na Antropologia Visual, Vista - Revista de Cultura Visual
          * 2016-11-02, Identities in Flux: An Analysis to Photographic Self-Representation on Instagram, Observatorio (OBS*)

        Thesis / Dissertation

          * 2020-10, PhD, Instagrammable Femininities: Exploring the gender politics of self-representations on Instagram and women's magazines
          * 2014, Master, Identidade em Fluxo: A Auto-Representação Fotográfica e o Caso Prático do Instagram

        Book

          * 2023, História dos Ativismos Feministas em Portugal, Pereira, Ana Sofia; Camila Lamartine; Cerqueira, Carla; Taborda, Célia; Cardoso, Daniel; Drummond, Daniela; Babo, Isabel; et al, Edições Universitárias Lusófonas

        Book chapter

          * 2022, “Hello My Lovelies!”: Conflicted Feminisms and the Neoliberalisation of Portuguese Activist Influencer Practices, Identities and Intimacies on Social Media: Transnational Perspectives
          * 2022, Bolsas de Pós-Doutoramento Marie Sklodowska-Curie: Breves Notas Sobre o Processo de Candidatura, Rotas para a Investigação em Comunicação: Um Guia de Pensamento e Prática para Início de Percurso, Edições Universitárias Lusófona

        Book review

          * Berry, D. M., & Fagerjord, A. (2017). Digital humanities: Knowledge and critique in a digital age. Cambridge: Polity Books, 248 pp.

        Report

          * 2021, #homesofInsta for a #lockdownlife, https://smart.inovamedialab.org/past-editions/2021-platformisation/project-reports/homesofinsta-for-a-lockdownlife/

        Online resource

          * 2022, Embracing Tensions: Studying Self-representations on Social Media using a Feminist Multi-methodological Approach (In: SAGE Research Methods: Doing Research Online), https://dx.doi.org/10.4135/9781529798890
          * 2017, When working on 'the digital' is something other than Digital Humanities

        Conference paper

          * Putting the ‘insta’ back on Instagram? Exploring the uses of ephemeral Stories for everyday feminist practices, 3º Congresso Internacional do CIEG
          * Feminismos efémeros: Explorando os usos feministas de Instagram Stories, SOPCOM XIII 2024

        Conference abstract

          * 2023-11, Click here for feminism! Exploring tensions on Instagram feminisms self-promotion practices, Gendered Cultures Platform Economies 2023
          * 2023-09, Online feminist activisms and affective ambiences of dis/connectivity, ECREA Temporary Working Group Affect, Emotion & Media: Interdisciplinary Approaches to Affect and Emotion Research in Media and Communication Studies
          * 2023-09, Negotiating On- and Offline Feminisms: Digital Activism and Small Acts of Disengagement, Contested Visibilities: Everyday politics and online imaginaries of the body
          * 2023-09, A Story within a Story: Re-sharing practices in feminist uses of Instagram Stories, Contested Visibilities: Everyday politics and online imaginaries of the body
          * 2023-07, Situating #MeToo: A comparative analysis of the movement in Portugal and Catalonia, IAMCR 2023
          * 2023-07, Exploring the imaginaries of feminist activism on Instagram, IAMCR 2023
          * 2022-10, Interrogating transnational feminist imaginaries: Feminist hashtags and Instagrammable aesthetics, ECREA 2022
          * 2022-09, #VermelhoEmBelem: Conflicted femininities in the context of a Portuguese feminist hashtag campaign, Emergent Femininities and Masculinities in 21st Century Media and Popular Culture
          * 2022-06, Thinking digital methods in practice: A critical reflection on the challenges and possibilities of digital methods for feminist social media research, 11th European Feminist Research Conference
          * 2022-06, Instagramming Feminisms in Portugal: An exploratory look into the portuguese landscape of feminist hashtags on Instagram, 11th European Feminist Research Conference
          * 2022-04, #FeminismoPortugal: Um mapeamento exploratório do panorama de hashtags feministas no Instagram, XII CONGRESSO DA SOPCOM
          * 2021-10, Feminismos Instagrammáveis: Uma análise exploratória do panorama de hashtags feministas no Instagram Português e das suas convenções imagéticas, Ativismo em Rede e Plataformas Colaborativas
          * 2021-09, Photographable Femininities: an intertextual comparative analysis of representations of femininity in women's magazines and on Instagram, ECREA 2021
          * 2021-07, "Hello my lovelies!": From liberation to the neoliberalisation of feminist discourses on social media, a case study of the Portuguese Instagrammer @taniiagraca, IAMCR Nairobi 2021
          * 2019-11, Instagrammable femininities: Exploring young women’s understandings of gendered self-representations on Instagram, Media, Gender and Sexuality in Contemporary Europe
          * 2019-10, Getting word out through Instagram: understanding young women's experiences of the gendered infrastructural politics of Instagram, Infrastructures and Inequalities: Media industries, digital cultures and politics
          * 2019-07, Everybody needs to post a selfie every once in a while: exploring young women's self-representation practices on Instagram, IAMCR Madrid 2019
          * 2019-05, Researching young women's self-representation on Instagram : a critical reflection on the challenges and possibilities of a multi-methodological feminist approach, DIGITAL - CULTURE 2019
          * 2018-11, #TheInstagramIssue : exploring the adoption of social media logic by women's glossy fashion magazines in light of their intertextual relationship with Instagram, ECREA 2018
          * 2018-06, Between the banal and the political : a qualitative textual analysis of women's photographic self-representation on Instagram, Instagram Conference 2018: Studying Instagram Beyond Selfies
          * 2018-05, Exploring the political potential of self-representation on Instagram : a case study of the body-positive @effyourbeautystandards Instagram account, Thinking Gender Justice - First Annual Conference of UCD Centre for Gender, Feminisms and Sexualities
          * 2018-02, Shop it. Wear it. 'Gram it.: A textual analysis of women's glossy fashion magazines and their representations of femininity in the context of its intertextual relationship with Instagram, Etmaal 2018
          * 2017, When working on 'the digital' is something other than Digital Humanities, Ghent University - Digital Humanities Doctoral School Symposium
          * 2015-11, As Potencialidades do Estudo da Imagem Fotográfica na Antropologia Visual, I Encontro Cultura Visual

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona