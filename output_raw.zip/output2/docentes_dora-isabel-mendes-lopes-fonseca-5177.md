# Response for https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
          PT: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177 EN: https://www.ulusofona.pt/en/teachers/dora-isabel-mendes-lopes-fonseca-5177
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
        fechar menu : https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/dora-isabel-mendes-lopes-fonseca-5177
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Dora Lopes Fonseca

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5177
              ado***@gmail.com
              DF11-3106-4686: https://www.cienciavitae.pt/DF11-3106-4686
      : https://www.ulusofona.pt/

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona