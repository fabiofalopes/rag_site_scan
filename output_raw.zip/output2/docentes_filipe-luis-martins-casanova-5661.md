# Response for https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
          PT: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661 EN: https://www.ulusofona.pt/en/teachers/filipe-luis-martins-casanova-5661
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
        fechar menu : https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/filipe-luis-martins-casanova-5661
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Filipe Casanova

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5661
              p56***@ulusofona.pt
              5B1D-9AB5-CD2F: https://www.cienciavitae.pt/5B1D-9AB5-CD2F
              0000-0002-9696-9355: https://orcid.org/0000-0002-9696-9355
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/296c105c-568d-4d2c-8c14-44499ed37b58
      : https://www.ulusofona.pt/

        Resume

        Filipe Luis Martins Casanova. É Professor Auxiliar Convidado no(a) Universidade do Porto Faculdade de Desporto e Professor Auxiliar no(a) Universidade Lusófona do Porto Faculdade de Psicologia Educação e Desporto. Atua na(s) área(s) de Ciências Médicas e da Saúde com ênfase em Ciências da Saúde com ênfase em Ciências do Desporto.

        Graus

            * Mestrado
              Treino Desportivo
            * Doutoramento
              Ciências do Desporto
            * Pós-doutoramento
              Ciências do Desporto
            * Licenciatura
              Educação Física e Desporto
            * Doutoramento
              Ciência do Desporto

        Publicações

        Artigo em revista (magazine)

          * 2019, O comportamento visual exploratório em futebolistas sub19: aplicação em contexto de treino (Parte II), Treino Científico
          * 2019, O comportamento visual exploratório em futebolistas sub19: aplicação em contexto de treino (Parte I), Treino Científico
          * 2019, Análise do processo de instrução do Treinador de Futebol- Parte II, Treino Científico
          * 2019, Análise do processo de instrução do Treinador de Futebol (Parte I), Treino Científico
          * 2018, O treino funcional no Futebol aplicado à qualidade de movimento: Parte I.
          * 2018, O comportamento visual exploratório como indicador-chave na tomada de decisão: Parte II, Treino Científico
          * 2018, O comportamento visual exploratório como indicador-chave na tomada de decisão: Parte I, Treino Científico
          * 2018, O comportamento decisional do guarda-redes de Futebol: Parte II, Treino Científico
          * 2018, O comportamento decisional do guarda-redes de Futebol: Parte I, Treino Científico
          * 2017, O treino funcional no Futebol aplicado à qualidade de movimento: Parte II, Treino Científico
          * 2016, O treino funcional no contexto do Futebol., Treino Científico
          * 2016, O custo benefício da antecipação no Guarda-redes de Futebol., Treino Científico
          * 2016, Caraterísticas do Guarda-Redes de Futebol e seu contexto de atuação., Treino Científico
          * 2016, A importância dos exercícios contextualizados no processo de treino dos Guarda-redes de Futebol, Treino Científico
          * 2016, A importância dos comportamentos do Guarda-redes de Futebol, nos momentos que antecedem a defesa, Treino Científico
          * 2015, Avaliações decisionais (percetivo-cognitivas) e sua aplicabilidade no treino., Treino Científico
          * 2014, Observação e análise das ações de bola parada ofensivas e defensivas na segunda Liga Profissional Portuguesa, Treino Científico
          * 2012, A propósito da importância da excelência decisional do futebolista., Treino Científico

        Artigo em revista

          * 2024-05, Impact of temperature on physical and cognitive performance in elite female football players during intermittent exercise, Scandinavian Journal of Medicine & Science in Sports
          * 2023-12-08, What is the visual behaviour and attentional effort of football players in different positions during a real 11v11 game? A pilot study [version 4; peer review: 2 approved]
          * 2023-12-01, What is the visual behaviour and attentional effort of football players in different positions during a real 11v11 game? A pilot study, F1000Research
          * 2023-09-18, The Effects of Massage Guns on Performance and Recovery: A Systematic Review, Journal of Functional Morphology and Kinesiology
          * 2023-08-21, What is the visual behaviour and attentional effort of football players in different positions during a real 11v11 game? A pilot study, F1000Research
          * 2023-06-15, What is the visual behaviour and attentional effort of football players in different positions during a real 11v11 game? A pilot study, F1000Research
          * 2023-05-18, Relationship between Bioelectrical Impedance Phase Angle and Upper and Lower Limb Muscle Strength in Athletes from Several Sports: A Systematic Review with Meta-Analysis, Sports
          * 2022-12-14, Development of an innovative method for evaluating a network of collective defensive interactions in football, Proceedings of the Institution of Mechanical Engineers, Part P: Journal of Sports Engineering and Technology
          * 2022-05-30, The Effects of Physiological Demands on Visual Search Behaviours During 2 vs. 1 + GK Game Situations in Football: An in-situ Approach, Frontiers in Psychology
          * 2022, Validação do FUT-SAT no desempenho tático dos jogadores de Futebol para formatos de reduzida complexidade nos Jogos Reduzidos e Condicionados., Brazilian Journal of Development
          * 2022, Análise da simetria da força em membros inferiores e sua influência na precisão do chute em atletas, Brazilian Journal of Development
          * 2022, A influência do constrangimento da tarefa no comportamento da procura visual em futebolistas, Brazilian Journal of Development
          * 2022, A importância dos municípios no desenvolvimento desportivo, JuSportivus
          * 2021-06, How Task Constraints Influence the Gaze and Motor Behaviours of Elite-Level Gymnasts, International Journal of Environmental Research and Public Health
          * 2021-05-24, Concurrent Validation of 3D Joint Angles during Gymnastics Techniques Using Inertial Measurement Units, Electronics
          * 2021-05, Effects of pitch dimension and skilllevel on the application of space and concentration principles in football small-sided and conditioned games, Journal of Physical Education and Sport
          * 2021, Mais diversidade na unidade. O comportamento da procura visual nos jogadores de basquetebol, Revista Portuguesa de Ciências do Desporto
          * 2021, Effects of pitch dimension and skilllevel on the application of space and concentration principles in football small-sided and conditioned games, Journal of Physical Education and Sport
          * 2021, Effects of pitch dimension and skill level on the application of space and concentration principles in football small-sided and conditioned games., Journal of Physical Education and Sport
          * 2020-09-29, Visual search strategy and anticipation in tactical behavior of young soccer players, Science and Medicine in Football
          * 2020, The Attention As a Key Element to Improve Tactical Behavior Efficiency of Young Soccer Players, Revista de Psicologia del Deporte
          * 2020, The Attention As a Key Element to Improve Tactical Behavior Efficiency of Young Soccer Players, Revista de Psicologia del Deporte
          * 2020, Representativeness of offensive scenarios to evaluate perceptual-cognitive skills of water polo players. , Central European Journal of Sport Sciences and Medicine
          * 2020, Representativeness of offensive scenarios to evaluate perceptual-cognitive skills of water polo players, Central European Journal of Sport Sciences and Medicine
          * 2020, Physiological Arousal and Visual search behaviour under intensity exercise demands in elite and nonelite soccer players, Serbian Journal of Sports Sciences
          * 2020, O contributo do comportamento visual exploratório e das habilidades táticas na Tomada de Decisão do futebolista (Parte I), Treino Científico
          * 2020, Gaze behaviour in elite teamgym gymnasts when performing mini-trampoline and mini-trampoline with vault - A pilot study, Science of Gymnastics Journal
          * 2020, Gaze behaviour in elite gymnasts when performing mini-trampoline and mini-trampoline with vaulting table – a pilot study, Science of Gymnastics Journal
          * 2020, GAZE BEHAVIOUR IN ELITE GYMNASTS WHEN PERFORMING MINI-TRAMPOLINE AND MINI TRAMPOLINE WITH VAULTING TABLE - A PILOT STUDY, Science of Gymnastics Journal
          * 2020, Avaliação qualitativa de percursos pedestres em espaços de montanha: o projeto trails4health
          * 2019-07-16, Comparison between teams of different ranks in small-sided and conditioned games tournaments, International Journal of Performance Analysis in Sport
          * 2019, Number of players manipulation effect on space and concentration principles of the game representativeness during football small-sided and conditioned games, Journal of Physical Education and Sport
          * 2019, Number of players manipulation effect on space and concentration principles of the game representativeness during football small-sided and conditioned games, Journal of Physical Education and Sport
          * 2019, Contributos científicos no domínio das habilidades percetivo-cognitivas e da expertise em futebol, Revista Portuguesa de Ciências do Desporto
          * 2019, Contributos científicos no domínio das habilidades percetivo-cognitivas e da expertise em Futebol. , Revista Portuguesa de Ciências do Desporto
          * 2019, Contributos científicos no domínio das habilidades percetivo-cognitivas e da expertise em Futebol, Revista Portuguesa de Ciências do Desporto
          * 2017, Visual search behavior and defensive tactical performance during small-sided conditioned soccer games, Revista Portuguesa de Ciências do Desporto
          * 2017, Perception and action in soccer: Performance comparison under different perceived effort intensities in Small-Sided and Conditioned Games, Revista Portuguesa de Ciências do Desporto
          * 2017, Multivariate Profiles of Selected Versus non-Selected Elite Youth Brazilian Soccer Players, Journal of Human Kinetics
          * 2017, Comportamento da procura visual no Basquetebol: Análise e comparação do lançamento livre e do lançamento em suspensão, Revista Portuguesa de Ciências do Desporto
          * 2014, The contribution of perceptual and cognitive skills in anticipation performance of elite and non-elite soccer players., International Journal of Sports Science
          * 2013-08, Effects of Prolonged Intermittent Exercise on Perceptual-Cognitive Processes, Medicine & Science in Sports & Exercise
          * 2012-10-19, Representativeness of Offensive Scenarios to Evaluate Perceptual- Cognitive Expertise of Soccer Players, The Open Sports Sciences Journal
          * 2009, Expertise and perceptual-cognitive performance in soccer: a review., Revista Portuguesa de Ciências do Desporto
          * 2009, Expertise and perceptual-cognitive performance in soccer: a review, Revista Portuguesa de Ciências do Desporto
          * 2009, Expertise and perceptual-cognitive performance in soccer: a review
          * 2009, Expertise and perceptual-cognitive performance in soccer : a review

        Tese / Dissertação

          * 2021, Mestrado, Relatório final de estágio realizado na equipa de Juvenis do Clube Recreativo Águias da Musgueira e complementaridade funcional na Equipa de Benjamins A/B do Sport Lisboa e Benfica, na época desportiva 2020/2021
          * 2021, Mestrado, Relatório final de estágio na Equipa de Sub.19 do Rio Ave Futebol Clube : modelação metodológica no treino dos guarda-redes
          * 2021, Mestrado, Relatório final de estágio Clube Desportivo de Tondela - Iniciados A época desportiva 2020/2021
          * 2012-08-02, Doutoramento, Perceptual-cognitive behavior in soccer players: Response to prolonged intermittent exercise.
          * 2012, Doutoramento, Perceptual-Cognitive Behavior in Soccer Players:Response to prolonged intermittent exercise.
          * 2012, Doutoramento, Perceptual-Cognitive Behavior in Soccer Players:Response to prolonged intermittent exercise.
          * 2003-01-14, Mestrado, Avaliação da performance anaeróbia - Estudo de validação criterial de um teste de terreno e comparação da performance anaeróbia em futebolistas de diferentes idades.
          * 1998, Licenciatura, Estudo da correlação entre dois testes de terreno de avaliação do metabolismo oxidativo e a capacidade aeróbia.

        Livro

          * 2021, O Futebol multidimensional: Compilações científico-desportivas., Casanova, Filipe, Novas Edições Acadêmicas
          * 2021, O Futebol multidimensional, Casanova, Filipe
          * 2020, O léxico do Futebol português , Casanova, Filipe; Pacheco, Rui Pedro, Edições Universitárias Lusofonas
          * 2020, O Léxico do Futebol Português, Casanova, Filipe; Pacheco, Rui Pedro, Edições Universitárias Lusófonas

        Capítulo de livro

          * 2018, The importance of perceptual-cognitive skills in water polo players., Sport Science: Current and Future Trends for Performance Optimization ., ESECS/Instituto Politécnico de Leiria
          * 2017, Considerações práticas. , A Tomada de Decisão nos Jogos Desportivos Coletivos., 1
          * 2017, Compreender a natureza decisional dos jogos desportivos coletivos. , A Tomada de Decisão nos Jogos Desportivos Coletivos, 1
          * 2017, Avaliações e Investigações acerca das habilidades perceptiva-cognitivas subjacentes à tomada de decisão nos jogos desportivos coletivos. , A Tomada de Decisão nos Jogos Desportivos Coletivos , 1
          * 2017, As habilidades percetivo-cognitivas subjacentes à tomada de decisão dos atletas dos jogos desportivos e suas conceções., A Tomada de Decisão nos Jogos Desportivos Coletivos , 1, Fadeup
          * 2017, Anticipation., Encyclopedia of Personality and Individual Differences, Springer International Publishing
          * 2015, Observação e análise das ações de bola parada ofensivas e defensivas na segunda Liga Profissional Portuguesa. , Mestrado em Futebol: Compilação dos melhores textos das grandes referências do Futebol nacional ., 1
          * 2015, A propósito da importância da excelência decisional do futebolista., Mestrado em Futebol: Compilação dos melhores textos das grandes referências do Futebol nacional , 1
          * 2013, A atividade decisional do jogador nos jogos desportivos., Jogos Desportivos Coletivos: Ensinar a Jogar , 1, Fadeup

        Edição de livro

          * 2017, 1, Editora Fadeup
          * 2015, 1

        Artigo em jornal

          * 2019, O impossível não existe, Semanário O Sol

        Resumo em conferência

          * 2019, Visual Behavior in Elements of Balance and Rotation in Rhythmic Gymnastics, 12th IJUP (Meeting of Young Researchers of University of Porto)
          * 2019, The visual search behaviour of U14 basketball players of different competitive levels, 12th IJUP (Meeting of Young Researchers of University of Porto)
          * 2017, Tactical Behaviour in Soccer: an assessment proposal based in micro structures, Meeting of Young Researchers of University of Porto
          * 2017, Software development to evaluate tactical behaviour of soccer players, Meeting of Young Researchers of University of Porto
          * 2017, Representatividade de cenários ofensivos na avaliação dos comportamentos percetivo-cognitivos de jogadores polo aquático., do XXXX Congresso da APTN
          * 2017, Relação entre o desempenho tático e a busca visual no futebol., 6th Soccer Experience
          * 2017, Perceived Effort, Defensive Tactical Performance and Visual search behavior in soccer players during small-sided and conditioned games., World Conference on Science and Soccer
          * 2017, Gaze Behavior of Soccer Players Under Specific-Exercise, World Conference on Science and Soccer
          * 2017, Field dimensions to evaluate basketball players expertise, Meeting of Young Researchers of University of Porto
          * 2017, Busca visual no futebol: Comparação de dois momentos em jogos reduzidos e condicionados, 6th Soccer Experience
          * 2017, Análise biomecânica da estirada aérea do guarda-redes de Futebol sénior: comparação entre a técnica de defesa com a mão inferior e a técnica de defesa com a mão superior., 7º Congresso Nacional de Biomecânica
          * 2017, A importância da excelência decisional do futebolista, 6º Congresso Internacional de Jogos Desportivos “Desafios da excelência nos JDC- da investigação à prática
          * 2016, Visual Search Behaviour in Soccer: which predictor could explain competitive level? , 21th Annual Congress of the European College of Sport Science
          * 2015, Visual search behavior and anticipation of elite and non-elite soccer players, 5º Congresso Internacional de Jogos Desportivos
          * 2015, A intervenção decisional do jogador na participação de elevados desempenhos desportivos: realidade e... futuro?, 5º Congresso Internacional de Jogos Desportivos
          * 2014, Sleeping patterns of African Elite Soccer Players during preseason training camp, 19th European College of Sport Science – Sport Science around the Canals
          * 2014, Padrões de sono de jogadores de futebol africanos de elite durante o estágio no período pré-competitivo, I Conferência Internacional em Ciências no Treino do Futebol
          * 2014, Effect of number players manipulation on football small-sided and conditioned games representativeness., V Encontro Internacional de Pesquisa em Educação Física e Nutrição
          * 2014, Efeitos da dimensão do campo e da perícia no comportamento tático de jovens futebolistas em jogos reduzidos e condicionados., I Conferência Internacional em Ciências no Treino do Futebol.
          * 2014, Efeito do número de jogadores e da posse de bola na largura e no comprimento das equipas durante a prática de jogos reduzidos., I Conferência Internacional em Ciências no Treino do Futebol.
          * 2013, Effects of prolonged intermitente exercise on perceptual-cognitive skills in soccer players, XIV Congreso Nacional y I Internacional de Psicología de la Actividad Física y del Deporte
          * 2013, Effects of prolonged intermitente exercise on perceptual-cognitive processes in soccer players, 4º Congresso Internacional de Jogos Desportivos
          * 2011, Validation of offensive scenarios to evaluate perceptual-cognitive skills in soccer, VIIth World Congress on Science & Football
          * 2010, Validation study of attacking scenarios to evaluate perceptual-cognitive expertise of soccer players., Second World Conference Book of Science and Soccer
          * 2009, Excelência e performance perceptivo-cognitiva no Futebol, II International Congress of Team Sports
          * 2003, Estudo de validação criterial do Running-based anaerobic sprint test para a avaliação da performance anaeróbia., II Simpósio Treino e Avaliação da Força e Potência Muscular
          * 2002, Validity of the Running-based Anaerobic Sprint Test to Assess Anaerobic Performance, 7th Annual Congress of the European College of Sport Science
          * 2002, Validação do Running-based anaerobic sprint test para a avaliação da performance anaeróbia, Congress of Sport, Physical Activity and Health - the contribution of science and the role of the school
          * 2002, Sprint ability in soccer players of different ages, 7th Annual Congress of the European College of Sport Science
          * 2002, Avaliação da performance anaeróbia em futebolistas de diferentes idades, Congress of Sport, Physical Activity and Health - the contribution of science and the role of the school

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona