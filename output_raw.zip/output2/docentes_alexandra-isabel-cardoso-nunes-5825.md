# Response for https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
          PT: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825 EN: https://www.ulusofona.pt/en/teachers/alexandra-isabel-cardoso-nunes-5825
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
        fechar menu : https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/alexandra-isabel-cardoso-nunes-5825
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Alexandra Isabel Cardoso Nunes

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5825
              ale***@ulusofona.pt
              CE12-369F-B36D: https://www.cienciavitae.pt/CE12-369F-B36D
              0000-0001-6449-8053: https://orcid.org/0000-0001-6449-8053
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/874f66ea-c4a2-4e06-914b-cb988ce72480
      : https://www.ulusofona.pt/

        Resume

        Alexandra Nunes, PhD (Biology - Molecular Genetics). Researcher at the Genomics and Bioinformatics Unit of the Department of Infectious Diseases of the Portuguese National Institute of Health (INSA). ANunes published 66 peer-reviewed papers (2737 citations; h-index 26) (34 since 2018), 20 as first (co-)author and 4 as corresponding author, including a The New England Journal of Medicine, Nature Medicine, Nature Microbiology and Matter, two revisions (one by invitation), 9 preprints, and more than 10 publications in national scientific journals (https://orcid.org/0000-0001-6449-8053). ANunes is recipient of 8 awards/honors, including the European ERA-NET PathoGenoMics Ph.D. Award 2011, which recognizes "up to three of the most remarkable and outstanding PhD theses in the field of genome research on human-pathogenic microorganisms". ANunes has participated (as PI or collaborator) in 24 collaborative research projects at national and international level, including 3 on behalf of the OneHealth approach (OneHealth EJP-JRP13-R2-AMR2.22-FED AMR; OneHealth EJP-JRP24-FBZSH9-BEONE; OneHealth EJP-JRP21-R2-ET2-TELE-Vir) funded by Horizon 2020, TITANGEL (as PI) funded by FCT/Portugal, and HERA (ECDC/HERA/2021/021 ECD.12236) funded by ECDC. Currently, ANunes participates in four projects, such as the EU4Health projects GENEO (EU4H-PJG ID-101113460, for enhancing national infrastructures and capacities for WGS-based surveillance and outbreak investigation activities) and DURABLE (EU4H-2021-PJ4 ID-101102733, for delivering a European unified response against Epidemics). In 2019, she was nominee as the Portuguese National Molecular Surveillance Focal Point for the European Reference Laboratory Network for Tuberculosis (ERLTB-Net) - ECDC. Being proficient in cell culture, microbiology, genomics, transcriptomics and bioinformatics, with total access to the NIH sequencing core-facility, ANunes scientific activity focuses on "microbial genomics" of pathogens with impact on public health, in particular for: i) epidemiological surveillance of diverse pathogens; ii) outbreaks investigation; iii) microbial evolution and within-patient adaptation studies; iv) establishment of genotype-phenotype relationships; v) identification of emergent pathogen threats; vi) analysis of relevant phenotypic traits; and vii) development of novel antimicrobial compounds or drug-delivery systems. She is also involved in the development and implementation of bioinformatic automated and flexible solutions for an integrative surveillance of multiple bacterial and viral pathogen agents. Since 2020, ANunes has been continuously involved in the genomic surveillance of SARS-CoV-2 in Portugal. Recently, as a member of Genomics and Bioinformatics Unit of INSA, she was awarded with the Gold Medal for Distinguished Services from the Ministry of Health, on behalf of scientific advice towards the pandemics control. She is also a member of the COST Action CA21145 "EURESTOP - European Network for diagnosis and treatment of antibiotic-resistant bacterial infections". So far, ANunes has (co-)supervised 27 students, including 1 Post-doc, 1 PhD, 9 MSc, 15 bachelor projetcs and 1 Eramus student. ANunes is an invited professor at the Faculty of Veterinary Medicine (FMV) (since 2018) and at School of Psychology and Life Sciences (EPCV) (since 2021) at the Lusófona University (ULusófona). As such, ANunes is the institutional liaison between the Infectious Diseases Department of INSA and the FMV-ULusófona on behalf of research studies under the One Health context. Since 2024, she is a member of the Animal and Veterinary Research Centre (CECAV) research unit.

        Graus

            * Licenciatura
              Química aplicada (ramo Biotecnologia)
            * Doutoramento
              Biologia
            * Pós-doutoramento
              Tracking molecular interactions during host-cell invasion by Chlamydia trachomatis

        Publicações

        Artigo em revista (magazine)

          * 2024-01-16, Salmonella spp. serovars isolated from healthy Leopard geckos (Eublepharis macularius) in Lisbon, Portugal, Revista Lusófona de Ciência e Medicina Veterinária: II Encontro de Investigação da FMV da Universidade Lusófona - Edição Especial
          * 2024-01-16, Frequência e caracterização fenotípica de estirpes de Campylobacter coli em suínos abatidos para consumo Humano em Portugal, Revista Lusófona de Ciência e Medicina Veterinária: II Encontro de Investigação da FMV da Universidade Lusófona - Edição Especial
          * 2024-01-16, Bactérias zoonóticas multirresistentes, numa perspetiva "One Health", Revista Lusófona de Ciência e Medicina Veterinária: II Encontro de Investigação da FMV da Universidade Lusófona - Edição Especial
          * 2022-12-29, Dinâmica de transmissão de Clostridioides difficile – exemplos de abordagens One Health, Revista Lusófona de Ciência e Medicina Veterinária: I Encontro de Investigação da FMV da Universidade Lusófona - Edição Especial
          * 2021, Genetic Characterization of Brucella spp., ToxOmics
          * 2020-12-01, INSA and the emergency response to the laboratory diagnosis of COVID-19 in Portugal, Boletim Epidemiológico Observações
          * 2018-12, Resistance of Clostridium difficile from ribotype 017 to imipenem: contribution of the whole genome sequencing, Boletim Epidemiológico Observações
          * 2018, Whole genome sequencing as a tool for molecular epidemiology: characterization of Neisseria meningitidis serogroup W strains isolated in Portugal, Boletim Epidemiológico Observações
          * 2018, Novel genomic approach to decode syphilis, Boletim Epidemiológico Observações
          * 2018, New era on the surveillance of multidrug resistant tuberculosis in Portugal: whole genome sequencing, Boletim Epidemiológico Observações
          * 2017-04-10, A Sequenciação Total do Genoma na monitorização de surtos: exemplo do grande surto da Doença dos Legionários em Vila Franca de Xira, Magazine SPM
          * 2015, Burkholderia pseudomallei: primeiro caso de melioidose em Portugal, Boletim Epidemiológico Observações
          * 2014-10-15, Vigilância laboratorial das infeções por Neisseria gonorrhoeae em Portugal, 2004-2013, Boletim Epidemiológico Observações
          * 2008, Laboratory Diagnose of Sexually Transmitted Infections, Trabalhos da Sociedade Portuguesa de Dermatologia e Venereologia

        Pré-impressão

          * 
          * 
          * 
          * 
          * 
          * 
          * 
          * 
          * 

        Software

          * 

        Edição de número de revista

          * Special issue: Antibiotic Resistance, Virulence Profile and Genomic Analysis among Multidrug-Resistant Bacteria Isolated from Humans and Animals

        Artigo em revista

          * 2024, Preclinical assessment of an antibiotic-free cationic surfactant-based cellulose hydrogel for sexually and perinatal transmitted infections, Matter
          * 2024, Phenotypic and Genotypic Characterization of E. coli and Salmonella spp. Isolates from Pigs at Slaughterhouse and from Commercial Pig Meat in Portugal , Antibiotics
          * 2024, Distribution of Chlamydia trachomatis ompA-genotypes over three decades in Portugal, Sexually Transmitted Infections
          * 2023-12-12, Erratum for Nunes et al., “Recurrent Campylobacter jejuni Infections with In Vivo Selection of Resistance to Macrolides and Carbapenems: Molecular Characterization of Resistance Determinants”, Microbiology Spectrum
          * 2023-12-07, Epidemiology and genetic diversity of invasive Neisseria meningitidis strains circulating in Portugal from 2003 to 2020, International Microbiology
          * 2023-09-11, Viral genetic clustering and transmission dynamics of the 2022 mpox outbreak in Portugal, Nature Medicine
          * 2023-08-17, Recurrent Campylobacter jejuni Infections with In Vivo Selection of Resistance to Macrolides and Carbapenems: Molecular Characterization of Resistance Determinants, Microbiology Spectrum
          * 2023-03-15, CRISPRi-mediated characterization of novel anti-tuberculosis targets: mycobacterial peptidoglycan modifications promote beta-lactam resistance and intracellular survival, Frontiers in Cellular and Infection Microbiology
          * 2023-01-06, Molecular epidemiology of Clostridioides difficile in companion animals: Genetic overlap with human strains and public health concerns, Frontiers in Public Health
          * 2023, Distribution and Clinical Significance of HPV16 Variants in Head and Neck Squamous Cell Carcinomas: Data from a Portuguese Cohort and Systematic Review, Pathobiology
          * 2023, Comparative Effectiveness of COVID-19 Vaccines in Preventing Infections and Disease Progression from SARS-CoV-2 Omicron BA.5 and BA.2, Portugal, Emerging Infectious Diseases
          * 2022-12, Airborne spores' dissemination of a swine associated Clostridioides difficile clone, Anaerobe
          * 2022-10-15, Characterization of the Human Papillomavirus 16 Oncogenes in K14HPV16 Mice: Sublineage A1 Drives Multi-Organ Carcinogenesis, International Journal of Molecular Sciences
          * 2022-09-21, Addendum: Phylogenomic characterization and signs of microevolution in the 2022 multi-country outbreak of monkeypox virus, Nature Medicine
          * 2022-09-06, Identification of drivers of mycobacterial resistance to peptidoglycan synthesis inhibitors, Frontiers in Microbiology
          * 2022-08, Uncovering Beta-Lactam Susceptibility Patterns in Clinical Isolates of Mycobacterium tuberculosis through Whole-Genome Sequencing, Microbiology Spectrum
          * 2022-07-31, Global gene expression analysis of Streptococcus agalactiae at the exponential growth phase, Cellular and Molecular Biology
          * 2022-06-24, Phylogenomic characterization and signs of microevolution in the 2022 multi-country outbreak of monkeypox virus, Nature Medicine
          * 2022-04-14, Assessment of the Transmission Dynamics of Clostridioides difficile in a Farm Environment Reveals the Presence of a New Toxigenic Strain Connected to Swine Production, Frontiers in Microbiology
          * 2022-02-26, Cryptic Prophages Contribution for Campylobacter jejuni and Campylobacter coli Introgression, Microorganisms
          * 2022-02, Genomic surveillance of Neisseria meningitidis serogroup W in Portugal from 2003 to 2019, European Journal of Clinical Microbiology & Infectious Diseases
          * 2022-01-28, SARS-CoV-2 introductions and early dynamics of the epidemic in Portugal, Communications Medicine
          * 2021-11-12, Genetic Characterization of Brucella spp.: Whole Genome Sequencing-Based Approach for the Determination of Multiple Locus Variable Number Tandem Repeat Profiles, Frontiers in Microbiology
          * 2021-10-26, Campylobacter jejuni in Different Canine Populations: Characteristics and Zoonotic Potential, Microorganisms
          * 2021-09, Genomic insights on DNase production in Streptococcus agalactiae ST17 and ST19 strains, Infection, Genetics and Evolution
          * 2021-08, Increased antibacterial properties of indoline-derived phenolic Mannich bases, European Journal of Medicinal Chemistry
          * 2021-01-01, Characterization of Multidrug-Resistant Isolates of Salmonella enterica Serovars Heidelberg and Minnesota from Fresh Poultry Meat Imported to Portugal, Microbial Drug Resistance
          * 2021, Genetic Characterization of Brucella spp.
          * 2020-07-14, Lung abscess due to Neisseria meningitidis serogroup X - unexpected virulence of a commensal resulting from putative serogroup B capsular switching, European Journal of Clinical Microbiology & Infectious Diseases
          * 2020-03-09, Genome-scale approach to study the genetic relatedness among Brucella melitensis strains, PLOS ONE
          * 2020-01-01, Massive dissemination of a SARS-CoV-2 Spike Y839 variant in Portugal, Emerging Microbes & Infections
          * 2019-08, Proficiency Testing of Virus Diagnostics Based on Bioinformatics Analysis of Simulated In Silico High-Throughput Sequencing Data Sets, Journal of Clinical Microbiology
          * 2019-03, Evaluation of a gene-by-gene approach for prospective whole-genome sequencing-based surveillance of multidrug resistant Mycobacterium tuberculosis, Tuberculosis
          * 2018-11-29, Aminobenzylated 4-Nitrophenols as Antibacterial Agents Obtained from 5-Nitrosalicylaldehyde through a Petasis Borono–Mannich Reaction, ACS Omega
          * 2018-09, Whole-Genome Sequence Analysis of Multidrug-Resistant Campylobacter Isolates: a Focus on Aminoglycoside Resistance Determinants, Journal of Clinical Microbiology
          * 2018-05, Dissecting whole-genome sequencing-based online tools for predicting resistance in Mycobacterium tuberculosis : can we use them for clinical decision guidance?, Tuberculosis
          * 2018-04, Imipenem Resistance in Clostridium difficile Ribotype 017, Portugal, Emerging Infectious Diseases
          * 2017-07-10, Human brucellosis in Portugal - Retrospective analysis of suspected clinical cases of infection from 2009 to 2016, PLOS ONE
          * 2017-04-24, The expression of Helicobacter pylori tfs plasticity zone cluster is regulated by pH and adherence, and its composition is associated with differential gastric IL-8 secretion, Helicobacter
          * 2017-02-16, Genomic structure and insertion sites of Helicobacter pylori prophages from various geographical origins, Scientific Reports
          * 2016-10-17, Genome-scale analysis of the non-cultivable Treponema pallidum reveals extensive within-patient genetic variation, Nature Microbiology
          * 2016-09, Molecular studies on HSV: Replication rate, infection capacity and progeny, Journal of Clinical Virology
          * 2016-09, A large outbreak of Legionnaires' Disease in an industrial town in Portugal, Revista Portuguesa de Saúde Pública
          * 2016-06-23, In Vitro Activity of Quaternary Ammonium Surfactants against Streptococcal, Chlamydial, and Gonococcal Infective Agents, Antimicrobial Agents and Chemotherapy
          * 2016-05, Legionella pneumophila strain associated with the first evidence of person-to-person transmission of Legionnaires' disease: a unique mosaic genetic backbone, Scientific Reports
          * 2016-04-28, A Multi-Component Prime-Boost Vaccination Regimen with a Consensus MOMP Antigen Enhances Chlamydia trachomatis Clearance, Frontiers in Immunology
          * 2016-03-07, Quaternary ammonium surfactant structure determines selective toxicity towards bacteria: mechanisms of action and clinical implications in antibacterial prophylaxis, Journal of Antimicrobial Chemotherapy
          * 2016-02-04, Probable Person-to-Person Transmission of Legionnaires' Disease, New England Journal of Medicine
          * 2016, Burkholderia pseudomallei: First case of melioidosis in Portugal, IDCases
          * 2015-07-24, Chlamydia trachomatis In Vivo to In Vitro Transition Reveals Mechanisms of Phase Variation and Down-Regulation of Virulence Factors, PLOS ONE
          * 2015-07-01, Bioinformatic Analysis of Chlamydia trachomatis Polymorphic Membrane Proteins PmpE, PmpF, PmpG and PmpH as Potential Vaccine Antigens, PLOS ONE
          * 2015, Genome Sequencing of 10 Helicobacter pylori Pediatric Strains from Patients with Nonulcer Dyspepsia and Peptic Ulcer Disease, Genome Announcements
          * 2014-11-05, In Silico Scrutiny of Genes Revealing Phylogenetic Congruence with Clinical Prevalence or Tropism Properties of Chlamydia trachomatis Strains, G3 Genes|Genomes|Genetics
          * 2014-04, Evolution, phylogeny, and molecular epidemiology of Chlamydia - Review, Infection, Genetics and Evolution
          * 2014-02-27, Complete Genome Sequence of Chlamydia trachomatis Ocular Serovar C Strain TW-3, Genome Announcements
          * 2014-02-20, Role of inter-species recombination of the ftsI gene in the dissemination of altered penicillin-binding-protein-3-mediated resistance in Haemophilus influenzae and Haemophilus haemolyticus, Journal of Antimicrobial Chemotherapy
          * 2013-07, Effect of long-term laboratory propagation on Chlamydia trachomatis genome dynamics, Infection, Genetics and Evolution
          * 2013-07, Assessment of the load and transcriptional dynamics of Chlamydia trachomatis plasmid according to strains’ tissue tropism, Microbiological Research
          * 2013-06, Genomic features beyond Chlamydia trachomatis phenotypes: What do we think we know? - Review, Infection, Genetics and Evolution
          * 2012, Impact of loci nature on estimating recombination and mutation rates in chlamydia trachomatis, G3 Genes|Genomes|Genetics
          * 2012, Directional Evolution of Chlamydia trachomatis towards Niche-Specific Adaptation, Journal of Bacteriology
          * 2010-10-05, Adaptive Evolution of the Chlamydia trachomatis Dominant Antigen Reveals Distinct Evolutionary Scenarios for B- and T-cell Epitopes: Worldwide Survey, PLoS ONE
          * 2010-09, Normalization strategies for real-time expression data in Chlamydia trachomatis, Journal of Microbiological Methods
          * 2009-12, Evolutionary Dynamics of ompA, the Gene Encoding the Chlamydia trachomatis Key Antigen, Journal of Bacteriology
          * 2009-02, Lymphogranuloma venereum in Portugal: unusual events and new variants during 2007, Sexually Transmitted Diseases
          * 2008, Chlamydia trachomatis diversity viewed as a tissue-specific coevolutionary arms race, Genome Biology
          * 2007-09-12, Comparative Expression Profiling of the Chlamydia trachomatis pmp Gene Family for Clinical and Reference Strains, PLoS ONE
          * 2006-11-07, Evolution ofChlamydia trachomatisdiversity occurs by widespread interstrain recombination involving hotspots, Genome Research
          * 2006-01, Polymorphisms in the Nine Polymorphic Membrane Proteins of Chlamydia trachomatis across All Serovars: Evidence for Serovar Da Recombination and Correlation with Tissue Tropism, Journal of Bacteriology

        Tese / Dissertação

          * 2022, Mestrado, Novel alkylaminophenols as antibacterial agents against Staphylococcus aureus infections
          * 2022, Mestrado, Evaluation of Quaternary Ammonium Surfactants as prophylactic options for Streptococcus agalactiae infections
          * 2016, Mestrado, Molecular studies on HSV: replication rate, infection capacity and progeny
          * 2010, Doutoramento, Genomic and transcriptomic features of Chlamydia trachomatis. Tracking the basis for the ecological success

        Artigo em conferência

          * WGS-based dual strategy for the identification of key targets to enhance beta-lactam activity in mycobacterium tuberculosis
          * Transcriptomic analysis of plasmid and plasmid-related chromosomal ORFs in C. trachomatis strains with different cell-appetence
          * Resistência ao imipenemo em clone endémico de Clostridium difficile do ribotipo 017
          * Positive selection in the evolution of Helicobacter pylori outer membrane proteins
          * Phylogenomic characterization of the causative strain of one of the largest worldwide outbreaks of Legionnaires’ disease occurred in Portugal in 2014
          * Molecular studies on HSV: replication rate, infection capacity and progeny
          * Molecular features underlying the higher ecological success of C. trachomatis E and F genotypes
          * A Bioinformática na Identificação dos Processos Moleculares de Interacção entre o Agente Patogénico e o Homem

        Resumo em conferência

          * 2023-12, NiPharmins: novel low resistance-inducing antimicrobials with antibiofilm activity against Staphylococcus aureus - work published on Conference Abstracts Book of Congress of Microbiology and Biotechnology 2023 (MICRO-BIOTEC'23), Covilhã, Portugal, 7th-9th December
          * 2023-11-17, Performance of metagenomics NGS probe-based pathogen detection in clinical samples - work published on Conference Abstracts Book of the 3rd Symposium of the National Research Infrastructure for Genome Sequencing and Analysis - GenomePT Symposium 2023, Lisbon, Portugal, 17th November
          * 2023, Zoonotic Salmonella spp. isolated from healthy Leopard Geckos (Eublepharis Macularius): in vivo study - work published on Conference Proceedings Book of Montenegro International Veterinary Congress (XIXª Edition), Santa Maria da Feira, Portugal, 13-14 October
          * 2023, Salmonella spp. serovars isolated from healthy Leopard geckos (Eublepharis macularius) in Lisbon, Portugal - work published on Conference Abstracts Book of FMVet Research Meetings 2023, Lisbon, Portugal, 19th May
          * 2023, Probe-based Metagenomics: an added value for clinical decision? - work published on Conference Abstracts Book of Congress of Microbiology and Biotechnology 2023 (MICRO-BIOTEC'23), Covilhã, Portugal, 7th-9th December
          * 2023, Prevalence and phenotypic characterization of strains of Campylobacter coli in pigs slaughtered for human consumption in Portugal - work published on Conference Abstracts Book of FMVet Research Meetings 2023, Lisbon, Portugal, 19th May
          * 2023, Potential impact of low ciprofloxacin concentrations in the promotion of resistance in Aliarcobacter butzleri - published by MDPI in Proceedings of the 3rd International Electronic Conference on Antibiotics (ECA 2023), 1–15 December
          * 2023, Performance of metagenomics NGS probe-based pathogen detection in clinical samples - work published on Conference Abstracts Book of the 25º European Society for Clinical Virology (ESCV 2023), Milano, Italy, 30 August - 2 September
          * 2023, Multidrug-resistant Escherichia coli and Salmonella spp. in pigs slaughtered for human consumption, a potential source for Humans? - published by MDPI in Proceedings of The 2nd International Electronic Conference on Microbiology (ECM 2023), 01-15 December
          * 2023, Multi-resistant zoonotic bacteria, from a "One Health" perspective - work published on Conference Abstracts Book of FMVet Research Meetings 2023, Lisbon, Portugal, 19th May
          * 2023, Evolution of Aliarcobacter butzleri under Low Ciprofloxacin Concentrations Associated with the Selection of Multidrug-Resistant Mutants - work published on Conference Abstracts Book of Congress of Microbiology and Biotechnology 2023 (MICRO-BIOTEC'23), Covilhã, Portugal, 7th-9th December
          * 2023, Evaluation of multidrug resistant Campylobacter spp. strains isolated from poultry slaughtered for human consumption in Portugal - work published on Conference Abstracts Book of FMVet Research Meetings 2023, Lisbon, Portugal, 19th May
          * 2023, Epidemiology of invasive meningococcal disease in Portugal from 2012 to 2022 - work published on Conference Abstracts Book of the 16th Congress of The European Meningococcal and Haemophilus Disease Society (EMGM), Dubrovnik, Croatia, 29th May to 1st June
          * 2023, Characterization of Campylobacter spp. isolates from poultry slaughtered for human consumption in Portugal - work published on Conference Abstracts Book of Congress of Microbiology and Biotechnology 2023 (MICRO-BIOTEC'23), Covilhã, Portugal, 7th-9th December
          * 2023, Are food-producing animals a source of multidrug-resistant E. coli and Salmonella spp.? - work published on Conference Abstracts Book of the 6th International Congress of CiiEM - Immediate and Future Challenges to Foster One Health, Almada, Portugal, 5th-7th July
          * 2022, Transmission dynamics of Clostridioides difficile ¿ examples of One Health approaches - work published on Conference Abstracts Book of FMVet Research Meetings 2022, Lisbon, Portugal, 25th July
          * 2019, Genomic epidemiology study of multidrug resistant Campylobacter coli isolated in the context of One Health - work published in Proceedings of the 1st Annual Scientific Meeting of the One Health European Joint Programme on Foodborne Zoonoses, Antimicrobial Resistance and Emerging Threats., Dublin, Irland, 22-24 May -

        Poster em conferência

          * 2024, ZOONOTIC GRAM-NEGATIVE BACTERIA FROM THE ORAL CAVITY AND CLOACA OF HEALTHY LEOPARD GECKOS (EUBLEPHARIS MACULARIUS) , 6th International Conference on Avian, Herpetological, Exotic Mammal, Zoo and Wildlife Medicine, Ghent, Belgium, 20-24 May
          * 2024, Multi-country outbreak of multi-drug resistant Campylobacter coli ST-10042 strain (2018-2023), The 34th European Congress of Clinical Microbiology and Infectious Diseases (ECCMID), Barcelona, Spain, 27-30 April
          * 2023-12-01, Multidrug-resistant Escherichia coli and Salmonella spp. in pigs slaughtered for human consumption, a potential source for humans?, The 2nd International Electronic Conference on Microbiology (online), 01-15 December
          * 2023-12, NiPharmins: novel low resistance-inducing antimicrobials with antibiofilm activity against Staphylococcus aureus, The 2nd International Electronic Conference on Microbiology (online), 01-15 December
          * 2023-12, NiPharmins: novel low resistance-inducing antimicrobials with antibiofilm activity against Staphylococcus aureus, Congress of Microbiology and Biotechnology 2023 (MICRO-BIOTEC'23), Covilhã, Portugal, 7-9 December
          * 2023-12, Evolution of Aliarcobacter butzleri under Low Ciprofloxacin Concentrations Associated with the Selection of Multidrug-Resistant Mutants, Congress of Microbiology and Biotechnology 2023 (MICRO-BIOTEC'23), Covilhã, Portugal, 7-9 December
          * 2023-12, Characterization of Campylobacter spp. isolates from poultry slaughtered for human consumption in Portugal, Congress of Microbiology and Biotechnology 2023 (MICRO-BIOTEC'23), Covilhã, Portugal, 7-9 December
          * 2023-06-26, CRISPRi-mediated depletion of distinctive PG modifications promotes beta-lactam hypersusceptibility phenotypes in M. tuberculosis
          * 2023-05-19, Salmonella spp. serovars isolated from healthy Leopard geckos (Eublepharis macularius) in Lisbon, Portugal, FMVet Research Meetings 2023, Lisbon, Portugal, 19th May
          * 2023-05-19, Prevalence and phenotypic characterization of strains of Campylobacter coli in pigs slaughtered for human consumption in Portugal, FMVet Research Meetings 2023, Lisbon, Portugal, 19th May
          * 2023-05-19, Evaluation of multidrug resistant Campylobacter spp. strains isolated from poultry slaughtered for human consumption in Portugal, FMVet Research Meetings 2023, Lisbon, Portugal, 19th May
          * 2023, Zoonotic Salmonella spp. isolated from healthy Leopard Geckos (Eublepharis Macularius): in vivo study, Montenegro International Veterinary Congress (XIXª Edition), Santa Maria da Feira, Portugal, 13-14 October
          * 2023, Performance of metagenomics NGS probe-based pathogen detection in clinical samples, 3rd Symposium of the National Research Infrastructure for Genome Sequencing and Analysis (GenomePT Symposium 2023), Portuguese National Institute of Health, Lisbon, Portugal, 17th November
          * 2023, Epidemiology of invasive meningococcal disease in Portugal from 2012 to 2022, 16th Congress of The European Meningococcal and Haemophilus Disease Society (EMGM), Dubrovnik, Croatia, 29th May to 1st June
          * 2023, Are Food-Producing Animals a Source of Multidrugresistant E. coli and Salmonella spp.? , 6th Egas Moniz International Scientific Congress (CiiEM) - Immediate and Future Challenges to Foster One Health, Almada, Portugal, 5-7 July
          * 2022-04, Decoding Beta-lactam Susceptibility Patterns in Mycobacterium tuberculosis Clinical Strains, 32nd European Congress of Clinical Microbiology and Infectious Diseases (ECCMID 2022), Lisbon, Portugal, 23-26 April
          * 2022-04, Anticipating Mycobacterial Beta-lactam Resistance: Do we know the whole story?, 32nd European Congress of Clinical Microbiology and Infectious Diseases (ECCMID 2022), Lisbon, Portugal, 23-26 April
          * 2022, WGS-based Dual Strategy for the Identification of Key Targets to Enhance Beta-lactam Activity in Mycobacterium tuberculosis, Conference on Drug Development to Meet the Challenge of AMR 2022, Dublin, Ireland, 4-7 October
          * 2022, WGS-based Dual Strategy Identifies Lipoproteins with PBP Activity as Potential Targets to Enhance Beta-lactam Activity in Mycobacterium tuberculosis, 3rd INSA's Young Researcher Day, Lisbon, Portugal, 8 November
          * 2022, Prophylactic potential of quaternary ammonium surfactants against Streptococcus agalactiae vertical transmission, 3rd INSA's Young Researcher Day, Lisbon, Portugal, 8 November
          * 2022, NiPharmins as efficacious prophylactic options to prevent Staphylococcal infections, 3rd INSA's Young Researcher Day, Lisbon, Portugal, 8 November
          * 2022, Genomic epidemiology of SARS-CoV-2 in Portugal: supporting evidence-informed public health decision-making, 3rd INSA's Young Researcher Day, Lisbon, Portugal, 8 November
          * 2022, Genomic epidemiology of SARS-CoV-2 in Portugal: supporting evidence-informed public health decision-making, 32nd European Congress of Clinical Microbiology and Infectious Diseases (ECCMID), Lisbon, Portugal, 23-26 April
          * 2022, Bioinformatic analysis of Claudin genes family as therapeutic targets for pancreatic adenocarcinoma, ISCB-Latin America SolBio BioNetMX Conference on Bioinformatics 2022, Juriquilla, Mexico, 3-7 November
          * 2022, BeONE: Building Integrative Tools for One Health Surveillance, OneHealth EJP Joint PMC POC Meeting, Stockholm, 21-22 November
          * 2022, Assessment of the Transmission Dynamics of Clostridioides difficile in a Farm Environment Reveals the Presence of a New Toxigenic Strain Connected to Swine Production , 3rd Day of INSA's Young Researcher, Lisbon, Portugal, 8 November
          * 2021-11, Finding Key Genomic Markers of Beta-lactam Susceptibility in Clinical Isolates of Mycobacterium tuberculosis, MICROBIOTEC'21 - Congress of Microbiology and Biotechnology 2021, 23-26 November
          * 2021-11, Ascertaining mycobacterial inducible resistance to peptidoglycan synthesis inhibitors, MICROBIOTEC'21 - Congress of Microbiology and Biotechnology 2021, 23-26 November
          * 2021-06-09, Diversity and dynamics of Clostridioides difficile in a farm environment, One Health EJP Annual Scientific Meeting 2021, Copenhagen, Denmark, 9-11 June
          * 2021, The combination of carbapnems and clavulanic acid efficiently inhibits Mycobacetrium tuberculosis clinical isolates, iMed.ULisboa Meeting 2021 (online), Lisbon, Portugal, June-July
          * 2021, Repurposing Beta-lactams in Tuberculosis: a Valuable Therapeutic Alternative Against Drug-Resistant Clinical Isolates of Mycobacterium tuberculosis, New Health Challenges at ULisboa, Lisbon, Portugal, 29-30 November
          * 2021, QAS-hydrogels as a promising microbicide against sexually and perinatal transmitted infections, MICROBIOTEC'21 - Congress of Microbiology and Biotechnology 2021, 23-26 November
          * 2021, Inhibition of Peptidoglican Biosynthesis as a strategy against drug-resistant Mycobacterium tuberculosis, Symposium of Research on Tuberculosis and Nontuberculous Mycobacteria in Portugal
          * 2021, Increased antibacterial properties of indoline-derived phenol Mannich bases, 31st European Congress of Clinical Microbology and Infectious Diseases (ECCMID), 9-12 July
          * 2021, Evaluation of the genetics underlying a putative acquisition of antimicrobial resistance to novel alkylaminophenols, MICROBIOTEC'21 - Congress of Microbiology and Biotechnology 2021, 23-26 November
          * 2021, Delta variant and mRNA Covid-19 vaccines effectiveness: higher odds of vaccine infection breakthroughs, European Scientific Conference on Applied Infectious Disease Epidemiology (ESCAIDE) (online), 16-19 November
          * 2021, Are quaternary ammonium surfactants good prophylatic options for Neisseria gonorrhoeae "superbug"?, 31st European Congress of Clinical Microbology and Infectious Diseases (ECCMID), 9-12 July
          * 2021, Are quaternary ammonium surfactants a good prophylatic option against Streptococcus agalactiae vertical transmission?, MICROBIOTEC'21 - Congress of Microbiology and Biotechnology 2021, 23-26 November
          * 2019-12, Inhibition of Peptidoglycan Biosynthesis as a Strategy Against Drug-resistant Mycobacterium tuberculosis, MICROBIOTEC 19 - Congress of Microbiology and Biotechnology' 19, Coimbra, Portugal, 5-7 December
          * 2019-09, Shifting the Paradigm: Repurposing Beta-lactam Antibiotics Against Drug-Resistant Clinical Isolates of Mycobacterium tuberculosis, The Great Wall Symposium 2019, Paris, France, 25-27 September
          * 2019, Strengthening Mycobacterium tuberculosis surveillance through culture-independent whole-genome sequencing, 12th International Meeting on Microbial Epidemiological Markers 2019 (IMMEM XII), Dubrovnik, Croatia, 18-21 September
          * 2019, Neisseria meningitidis serogroup W in Portugal: a 16-year story, 15th European Meningococcal and Haemophilus Disease Society, Lisbon, Portugal, 27-30 May
          * 2019, Genomic epidemiology study of multidrug resistant Campylobacter coli isolated in the context of One Health, 1st Annual Scientific Meeting of the One Health European Joint Programme on Foodborne Zoonoses, Antimicrobial Resistance and Emerging Threats., Dublin, Irland, 22-24 May
          * 2019, First case of a noninvasive infection caused by Neisseria meningitidis serogroup X in Portugal, 15th European Meningococcal and Haemophilus Disease Society, Lisbon, Portugal, 27-30 May
          * 2018, Recurrent Campylobacter jejuni infections with in vivo selection of resistance to macrolides and carbapenems: molecular characterization of resistance determinants , 28th European Congress of Clinical Microbiology and Infectious Diseases (ECCMID), Madrid, Spain, 21-24 April
          * 2018, Can we use bioinformatics platforms for predicting M. tuberculosis resistance?, 28th European Congress of Clinical Microbiology and Infectious Diseases (ECCMID 2018), Madrid, Spain, 21-24 April
          * 2016, Molecular studies on HSV: replication rate, infection capacity and progeny, 19th ESCV, Lisbon, Portugal, 14-17 September
          * 2015, Sequencing and bioinformatics analysis of 161 genomes from 18 public health-related microbial strains, Applied Bioinformatics and Public Health Microbiology, Wellcome Trust Genome Campus, Hinxton, UK, 6-8 May
          * 2014, Vigilância laboratorial das infeções por Neisseria gonorrhoeae in Portugal, IV National Meeting of Public Health, Lisbon, Portugal, 2-3 October
          * 2014, The role of inter-species recombination of the ftsI gene on the dissemination of altered penicillin-binding protein 3 mediated resistance in Haemophilus influenzae and Haemophilus haemolyticus (2014 ASA Travel Award) , 15th Annual Meeting of Australian Society for Antimicrobials, Melbourne, Australia, 20-22 February
          * 2014, Genomic features of ulcerogenic Helicobacter pylori strains isolated from children, XXVIIth International Workshop on Helicobacter & Microbiota in Inflammation & Cancer, European Helicobacter Study Group (EHSG), Rome, Italy, 10-13 September
          * 2013, Insights into the molecular characterization of Chlamydia trachomatis plasmid, 6th Biennial Meeting of the Chlamydia Basic Research Society, San Antonio, Texas, USA, 19-22 March
          * 2013, Effect of long-term laboratory propagation on Chlamydia trachomatis genome dynamics, 6th Biennial Meeting of the Chlamydia Basic Research Society, San Antonio, Texas, USA, 19-22 March
          * 2012, Positive selection in the evolution of Helicobacter pylori outer membrane proteins, XXVth International Workshop on Helicobacter and Related Bacteria in Chronic Digestive Inflammation and Gastric Cancer, Ljubljana, Slovenia, 13-15 September
          * 2011, Transcriptomic analysis of plasmid and plasmid-related chromosomal ORFs in Chlamydi atrachomatis strains with different cell-appetence, 5th Biennial Meeting of the Chlamydia Basic Research Society, Redondo Beach, California, USA, 18-21 March
          * 2011, Normalization strategies for real-time expression data in Chlamydia trachomatis, 5th Biennial Meeting of the Chlamydia Basic Research Society, Redondo Beach, California, USA, 18-21 March
          * 2011, Molecular features underlying the higher ecological success of C. trachomatis E and F genotypes, 5th Biennial Meeting of the Chlamydia Basic Research Society, Redondo Beach, California, USA, 18-21 March
          * 2010, Time course of ionic and gap junctional remodelling induced by short-term rapid atrial pacing, Arrhythmia Meeting 2010, Lisbon, Portugal, February
          * 2010, Alterations in atrial ion channel and connexin gene expression induced by autonomic stimulation: a potential substrate for neurogenic atrial fibrillation, European Society of Cardiology (ESC) Congress 2010, Stockholm, Sweden, 28 August to 1st September
          * 2009, ompA variants in STI: purifying selection or escape from immune pressure?, 4th Biennial Meeting of the Chlamydia Basic Research Society, Little Rock, EUA, 20-23 March
          * 2009, Evolutionary Dynamics of Chlamydia trachomatis Key Antigen, National Congress of Microbiology and Biotechnology (MICROBIOTEC'09), Vilamoura, Portugal, 28-30 November
          * 2008, Lymphogranuloma venereum: unusual infections during 2007 in Portugal, 6th Meeting of the European Society for Chlamydia Research 2008, Aarhus, Denmark, 1-4 July
          * 2008, Clonal trait of the two most prevalent C. trachomatis serovars, 6th Meeting of the European Society for Chlamydia Research 2008, Aarhus, Denmark, 1-4 July
          * 2007, Use of PCR in the diagnosis of early syphilis, National Congress of Microbiology and Biotechnology (MICRO'07-BIOTEC'07), Lisbon, Portugal, 29 November to 2 December
          * 2007, Transcriptomics of the 9 pmp family for Chlamydia trachomatis reference and clinical E strains, 3rd Biannual Meeting of Chlamydia Basic Research Society, Louisville, USA, 23-26 March
          * 2007, Comparative gene expression analysis of the pmp family for Chlamydia trachomatis reference versus clinical strains , National Congress of Microbiology and Biotechnology (MICRO'07-BIOTEC'07), Lisbon, Portugal, 29 November to 2 December
          * 2007, Chlamydia trachomatis genotypes and infection rates in Lisbon, 1991-2005, 17th European Congress of Clinical Microbiology and Infectious Diseases and 25th International Congress of Chemotherapy, Munich, Germany, 31 March to 3 April
          * 2006, Trends in Chlamydia trachomatis and Neisseria gonorrhoeae infections, 12th International Congress on Infectious Diseases, Lisboa, Portugal, 15-18 June
          * 2006, Genomic and Transcriptomic analyses of Chlamydia trachomatis membrane proteins - presented at the , 1st INSA's Young Researcher Day, Lisbon, Portugal, 18 May
          * 2005, Transcriptomics of the Chlamydia trachomatis nine polymorphic membrane protein family , 2nd Biannual Meeting of the Chlamydia Basic Research Society, Indianapolis, 23-25 April
          * 2005, Genomic analysis of the nine polymorphic membrane protein genes for the 19 Chlamydia trachomatis reference serovars and recent clinical isolates , 2nd Biannual Meeting of the Chlamydia Basic Research Society, Indianapolis, 23-25 April
          * 2005, Comparative genomics and molecular characterization of the nine polymorphic membrane proteins for the 18 Chlamydia trachomatis serovars , Congresso Nacional de Microbiologia e Biotecnologia, MICRO'05-BIOTEC'05, Póvoa de Varzim, Portugal, 30 November to 3 December
          * 2005, Comparative developmental transcriptome analysis of the nine polymorphic membrane proteins for serovars representing two Chlamydia trachomatis biovars, National Congress of Microbiology and Biotechnology (MICRO'05-BIOTEC'05), Póvoa de Varzim, Portugal, 30 November to 3 December

        Pedido provisório de patente

          * European Patent entitled "SURFACTANT-BASED HYDROGEL, METHODS AND USES THEREOF" (Application number: EP24160080.8)

        Conjunto de dados

          * Recurrent Campylobacter jejuni infections with in vivo selection of resistance to macrolides and carbapenems - assembly dataset, This dataset comprises the genome assemblies of the first isolate collected from each clinical case (A1 and B1), together with the respective annotation.
          * Genome-scale approach to study the genetic relatedness among Brucella melitensis strains - wgMLST schema for Brucella melitensis, wgMLST schema for Brucella melitensis

        Outra produção

          * 2022, Human Genetics - Oncobiology (didactic material)

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona