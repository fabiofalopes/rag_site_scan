# Response for https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
          PT: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883 EN: https://www.ulusofona.pt/en/teachers/eloi-joao-faria-figueiredo-4883
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
        fechar menu : https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/eloi-joao-faria-figueiredo-4883
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Eloi Figueiredo

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4883
              elo***@ulusofona.pt
              BC11-6963-9ECF: https://www.cienciavitae.pt/BC11-6963-9ECF
              0000-0002-9168-6903: https://orcid.org/0000-0002-9168-6903
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/63d308ec-677e-4c1c-a23e-5edc70461775
      : https://www.ulusofona.pt/

        Resume

        PhD in Civil Engineering (2010) and Full Professor at the Faculty of Engineering of the Lusófona University, in Lisbon. Eloi has dedicated his academic career teaching courses in the field of static and dynamic structural analysis, seismic engineering, and design of reinforced and prestressed concrete structures. In terms of scientific research, he has worked mainly on structural health monitoring (SHM) and management of bridges, with focus on damage identification based on machine learning techniques and finite element modeling. He is currently Associated Editor of the Structural Health Monitoring: An International Journal, and co-offers courses and short courses on SHM. Recently, he has been awarded with an EEA Grant to study the impact of climate change on the structural health of bridges (ClimaBridge Project). He is leader of the Civil Research Group at Lusófona University rooted in the civil engineering field to promote sustainable and resilient infrastructure. In terms of publications, Eloi has over 100 publications on SHM through books, book chapters, peer-reviewed journals, and conference proceedings; and over 70 opinion articles to promote science in our society. He has also been invited, for several occasions, to be speaker in conferences, seminars, and international meetings. The scientific research has been done in collaboration with several institutions in the European Union, United States, Brazil, United Kingdom, and Norway.

        Graus

            * Licenciatura
              Licenciatura em Engenharia Civil
            * Mestrado
              Masters of Science in Structures of Civil Engineering
            * Doutoramento
              Doctor of Philosophy in Civil Engineering
            * Título de Agregado
              Engenharia Civil

        Publicações

        Artigo em revista

          * 2024-02, Bayesian calibration for Lamb wave propagation on a composite plate using a machine learning surrogate model, Mechanical Systems and Signal Processing
          * 2024, Impact of climate change on long-term damage detection for structural health monitoring of bridges, Structural Health Monitoring
          * 2023-09-13, Transfer Learning for Structural Health Monitoring in Bridges That Underwent Retrofitting, Buildings
          * 2023-06, A Roadmap for an Integrated Assessment Approach to the Adaptation of Concrete Bridges to Climate Change, Journal of Bridge Engineering
          * 2023-03, Damage quantification using transfer component analysis combined with Gaussian process regression, Structural Health Monitoring
          * 2023-01, Transfer Learning to Enhance the Damage Detection Performance in Bridges When Using Numerical Models, Journal of Bridge Engineering
          * 2023, A roadmap for an integrated assessment approach for climate change adaptation of concrete bridges, Journal of Bridge Engineering
          * 2022-11-04, Smartphone Application for Structural Health Monitoring of Bridges, Sensors
          * 2022-11, Three decades of statistical pattern recognition paradigm for SHM of bridges, Structural Health Monitoring
          * 2022-11, Damage Detection Approach for Bridges under Temperature Effects using Gaussian Process Regression Trained with Hybrid Data, Journal of Bridge Engineering
          * 2022-07, Reliability of probabilistic numerical data for training machine learning algorithms to detect damage in bridges, Structural Control and Health Monitoring
          * 2022-03, 3D structural vibration identification from dynamic point clouds, Mechanical Systems and Signal Processing
          * 2022-02, Investigation on the dynamic impact factor of a concrete filled steel tube butterfly arch bridge, Engineering Structures
          * 2021-02-23, Damage-sensitive feature extraction with stacked autoencoders for unsupervised damage detection, Structural Control and Health Monitoring
          * 2021-01, Autoregressive model extrapolation using cubic splines for damage progression analysis, Journal of the Brazilian Society of Mechanical Sciences and Engineering
          * 2020-11, Nonnegative matrix factorization-based blind source separation for full-field and high-resolution modal identification from video, Journal of Sound and Vibration
          * 2020-05, Spatio-temporal decomposition of 2D travelling waves from video measurements, Mechanical Systems and Signal Processing
          * 2019-11, Deep principal component analysis: An enhanced approach for structural damage identification, Structural Health Monitoring
          * 2019-07, Finite Element–Based Machine-Learning Approach to Detect Damage in Bridges under Operational and Environmental Variations, Journal of Bridge Engineering
          * 2019, Output-only structural damage detection based on transmissibility measurements and kernel principal component analysis, Journal of Communication and Information Systems
          * 2017-08, Agglomerative concentric hypersphere clustering applied to structural damage detection, Mechanical Systems and Signal Processing
          * 2017-04, A Global Expectation–Maximization Approach Based on Memetic Algorithm for Vibration-Based Structural Damage Detection, IEEE Transactions on Instrumentation and Measurement
          * 2017-03, Genetic-based EM algorithm to improve the robustness of Gaussian mixture models for damage detection in bridges, Structural Control and Health Monitoring
          * 2016-09, A global expectation-maximization based on memetic swarm optimization for structural damage detection, Structural Health Monitoring: An International Journal
          * 2016, Machine learning algorithms for damage detection: Kernel-based approaches, Journal of Sound and Vibration
          * 2016, A novel unsupervised approach based on a genetic algorithm for structural damage detection in bridges, Engineering Applications of Artificial Intelligence
          * 2015, Single side damage simulations and detection in beam-like structures, Journal of Physics: Conference Series
          * 2015, Damage detection in structures using a transmissibility-based Mahalanobis distance, Structural Control and Health Monitoring
          * 2015, Damage detection and quantification using transmissibility coherence analysis, Shock and Vibration
          * 2014, An evaluation of a methodology for detection, localization, and quantification of changes in nonlinear systems based on experimental measurements, Ingegneria Sismica
          * 2014, A Bayesian approach based on a Markov-chain Monte Carlo method for damage detection under unknown sources of variability, Engineering Structures
          * 2013, Linear approaches to modeling nonlinearities in long-term monitoring of bridges, Journal of Civil Structural Health Monitoring
          * 2012, Use of time-series predictive models for piezoelectric active-sensing in structural health monitoring applications, Journal of Vibration and Acoustics, Transactions of the ASME
          * 2011, Machine learning algorithms for damage detection under operational and environmental variability, Structural Health Monitoring
          * 2011, Integration of SHM into bridge management systems: Case study-Z24 bridge, Structural Health Monitoring 2011: Condition-Based Maintenance and Intelligent Structures - Proceedings of the 8th International Workshop on Structural Health Monitoring
          * 2011, Influence of the autoregressive model order on damage detection, Computer-Aided Civil and Infrastructure Engineering
          * 2010, Autoregressive modeling with state-space embedding vectors for damage detection under operational variability, International Journal of Engineering Science
          * 2010, Autoregressive modeling with state-space embedding vectors for damage detection under operational and environmental variability, Proceedings of the 5th European Workshop - Structural Health Monitoring 2010
          * 2010, An experimental investigation of change detection in uncertain chain-like systems, Journal of Sound and Vibration
          * 2010, A structural decomposition approach for detecting, locating, and quantifying nonlinearities in chain-like systems, Structural Control and Health Monitoring
          * 2009, A mobile-agent-based wireless sensing network for structural monitoring applications, Measurement Science and Technology
          * 2008, Data normalization and nonlinear damage identification using auto-associative neural networks and factor analysis, Proceedings of the 4th European Workshop on Structural Health Monitoring
          * 2008, A mobile-agent based wireless sensing network for structural health monitoring applications, Materials Forum
          * 2007, An insight on the influence of damping in seismic isolation, Proceedings of the 11th International Conference on Civil, Structural and Environmental Engineering Computing, Civil-Comp 2007

        Tese / Dissertação

          * 2019, Mestrado, Dimensionamento de um muro cais para os Açores
          * 2018, Mestrado, Reconhecimento de padrões estruturais, construtivos e materiais nas Pontes da Casa Eiffel em Portugal
          * 2018, Mestrado, Estruturas mistas de aço-betão e de betão armado em edifícios correntes : dimensionamento e custo
          * 2018, Mestrado, Deteção de dano em pontes integrando algoritmos de aprendizagem, modelos de elementos finitos e dados da monitorização estrutural
          * 2018, Mestrado, Caraterização e análise sísmica da passagem superior do Campo Grande
          * 2017, Mestrado, Estudo do comportamento dos materiais lateríticos em pavimentos rodoviários
          * 2017, Mestrado, Aplicação de algoritmos de aprendizagem para apoiar o processo de gestão das pontes em Angola
          * 2017, Mestrado, Análise de soluções de reforço de estruturas de betão armado
          * 2017, Doutoramento, Output-only methods for damage identification in structural health monitoring
          * 2016, Mestrado, Estudo sobre a influência das paredes de alvenaria num edifício alto em Belém do Pará
          * 2016, Mestrado, Estudo comparativo da regulamentação de segurança e ações nacional com os eurocódigos estruturais através de esforços internos num viaduto
          * 2014, Mestrado, Dimensionamento de pontes rodoviárias de betão armado e pré-esforçado : análise da regulamentação nacional e europeia
          * 2012, Mestrado, Applicability of the Statistical Pattern Recognition Paradigm for Structural Health Monitoring of Bridges
          * 2010, Doutoramento, Damage identification in civil engineering infrastructure under operational and environmental conditions
          * 2006, Mestrado, Monitorização e avaliação do comportamento de obras de arte

        Livro

          * 2020, Engenharia Civil: Uma perspetiva sobre a formação e a profissão, Carlos Matias Ramos; Figueiredo, Eloi, Edições Universitárias Lusófonas
          * 2019, Data Mining in Structural Dynamic Analysis, Figueiredo, Eloi

        Capítulo de livro

          * 2023, Hybrid Training of Supervised Machine Learning Algorithms for Damage Identification in Bridges
          * 2023, Does Climate Change Impact Long-Term Damage Detection in Bridges?
          * 2023, App4SHM – Smartphone Application for Structural Health Monitoring
          * 2020, Damage Quantification in Composite Structures Using Autoregressive Models
          * 2018, Machine Learning Algorithms for Damage Detection

        Edição de livro

          * 2013, Católica Editora

        Artigo em conferência

          * Smartphone application for structural health monitoring, 10th European Workshop on Structural Health Monitoring
          * Ensaios dinâmicos e modelação da ponte sobre o Rio Itacaiúnas, Betão Estrutural - BE2018
          * 2023-06, Resilience Enhancement Of University Teaching Buildings To Climate Change ¿ Buildingadapt Project, 2nd International Conference on Construction, Energy, Environment and Sustainability
          * 2015, Clustering studies for damage detection in bridges: A comparison study
          * 2015, Applicability of linear and nonlinear principal component analysis for damage detection
          * 2014, Transmissibility-based damage detection using linear discriminant analysis
          * 2013, Structural condition assessment of bridges: Past, present, and future - A Portuguese perspective
          * 2012, Application of modal filters for damage detection in the presence of non-linearities
          * 2012, Applicability of a Markov-chain Monte Carlo method for damage detection on data from the Z-24 and Tamar suspension bridges
          * 2010, Time series predictive models of piezoelectric active-sensing for SHM applications
          * 2010, SHMTools: A new embeddable software package for SHM applications
          * 2010, Machine learning algorithms to damage detection under operational and environmental variability
          * 2009, Structural health monitoring algorithm comparisons using standard data sets
          * 2009, A mobile agent-based wireless sensing network for SHM-field study at the Alamos Canyon Bridge

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona