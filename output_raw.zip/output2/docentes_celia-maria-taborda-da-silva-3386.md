# Response for https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
          PT: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386 EN: https://www.ulusofona.pt/en/teachers/celia-maria-taborda-da-silva-3386
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
        fechar menu : https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/celia-maria-taborda-da-silva-3386
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Célia Taborda

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3386
              cel***@ulusofona.pt
              C61F-AB0B-01BA: https://www.cienciavitae.pt/C61F-AB0B-01BA
              0000-0002-2547-2480: https://orcid.org/0000-0002-2547-2480
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/7f6efb5d-f58e-4947-b317-a6f92091cc51
      : https://www.ulusofona.pt/

        Resume

        Célia Taborda Silva is Associate Professor, Subdirector of the PhD in Communication and Activisms at Lusófona University in Porto, integrated researcher at CICANT - Centre for Research in Applied Communication, Culture, and New Technologies, and researcher associate at CEAUP - Centre of African Studies of the University of Porto. She is the co-principal investigator of the project “FEMglocal - Global feminist movements: Interactions and Contradictions” (PTDC/COM-CSS/4049/2021 / DOI 10.54499/PTDC/COM-CSS/4049/2021). She is also President of the General Assembly of the Center of African Studies and Vice-President of Portuguese Association of Vine and Wine (APHVIN/GEHVID). Previously she was Professor Assistent at Catolic University of Porto. Célia Taborda Silva concluded her PhD in Contemporary History (2005) at the University of Porto, Faculty of Arts and Humanities, with a thesis entitled: "Social movements in the Douro during the implantation of Liberalism (1834-1855). The previous master dissertation is a study of social and economic history: "The monastery of Ganfei. Property, production and rents during the Ancien Regime". Author of books, book chapters and several articles in national and international scientific journals, her research interests include: history, social movements, ativisms, communication, society and politics. Simultaneously, she participated in diverse international and national conferences (some as invited speaker) and integrated diverse scientific committees and events organization.

        Graus

            * Doutoramento
              História
            * Mestrado
              História

        Publicações

        Artigo em revista (magazine)

          * 2015, A crise Irlandesa (The Irish crisis), Veris

        Artigo em revista

          * 2023-06-30, #MeToo em Portugal- uma análise temática do movimento através de artigos de opinião (#MeToo in Portugal: a thematic analysis of the movement through opinion articles), Cuadernos.info
          * 2023, #MeToo em Portugal: uma análise temática do movimento através de artigos de opinião, Cuadernos.info
          * 2022-06-15, Feminismo para os 99%. Um manifesto, (Feminism for the 99%. A manifest), de Cinzia Arruzza, Tithi Bhattacharya e Nancy Fraser. Tradução de Eurídice Gomes. Lisboa: Objectiva, 2019, 136 pp., ex aequo - Revista da Associação Portuguesa de Estudos sobre as Mulheres
          * 2022-03-25, Movimentos de resistência ao liberalismo no Douro (Resistance movements to liberalism in the Douro), 1820-Revista de Ciência Política
          * 2021, Democracy and Popular Protest in Europe: The Iberian Case (2011), European Journal of Social Sciences
          * 2021, A questão vinhateira e as mobilizações sociais no Douro oitocentista (The wine issue and social mobilizations in the 19th century Douro) , Atas do Congresso Douro e Porto – Memória com Futuro (pp.46-57). Porto: IVDP
          * 2020-07, Social Movements in Europe: from the past to the present, European Journal of Social Science Education and Research
          * 2020-02-01, Quintas com História na região do vinho verde. Património e Enoturismo (Farms with History in the Vinho Verde region. Heritage and Wine Tourism) , Vinho Verde. História e Património. Porto: APHVIN/GEHVID,
          * 2019, Quintas com história na região do vinho verde. Património e Enoturismo. Vinho Verde - História e Património - History and Heritage., Aphvin
          * 2019, Civic Participation and Demonstrations in Portugal (2011-2012)., European Journal of Multidisciplinary Studies,
          * 2019, Quintas com história na região do vinho verde. Património e Enoturismo.(Houses with history in the white wine region. Heritage and Wine Tourism)., Vinho Verde - História e Património - History and Heritage. Porto:Aphvin, Porto
          * 2018-07-17, Protests in Europe in Times of Crisis -The Case of Greece, Ireland and Portugal, European Journal of Social Sciences
          * 2018, Os levantamentos populares durienses e a formação da junta de Vila Real durante a Maria da Fonte (Popular uprisings in Douro and the formation of the Vila Real council during Maria da Fonte)
          * 2017-07-01, Social Networks and Civic Mobilizations (Portugal, 2012), Academic Journal of Interdisciplinary Studies
          * 2017, Alberto Sampaio e a política oitocentista (Alberto Sampaio and 19th century politics), Vinho Verde. História e Património
          * 2016, Redes sociais e mobilizações públicas. O movimento de 15 de Setembro
          * 2016, Potencialidades da pesquisa na internet para a investigação qualitativa
          * 2015-12-25, Public Sphere and Collective Action. the Portuguese Movement of the "15th September", Mediterranean Journal of Social Sciences
          * 2015-04-01, Workers Protests in Northern Portugal in the Transition from the Monarchy to the I Republic, Mediterranean Journal of Social Sciences
          * 2014-08, Social Movements in Contemporary Portugal, European Journal of Social Sciences Education and Research
          * 2014, Em defesa do vinho do Porto: o papel das elites durienses oitocentistas (In defense of Port Wine: the role of the 19th century Douro elites), Douro. Vinho, História, Património
          * 2013-10-01, Popular Protest in Portugal: The Douro Region in First Half of Nineteenth Century, Academic Journal of Interdisciplinary Studies
          * 2012, From Dictatorship to Democracy: the political propaganda in Portugal in the 20th century, Mediterranean journal of Social Sciences
          * 2012, A alteração do espaço e quotidiano citadino: o operariado do Porto oitocentista, Babilónia
          * 2011, Perspectivas acerca do conceito "Acontecimento" (Perspectives on the concept "Event"), Caleidoscópio
          * 2010, Mosteiro de Ganfei na rota dos peregrinos a Santiago de Compostela (Monastery of Ganfei on the pilgrims' route to Santiago de Compostela) , Dinâmicas de Rede no Turismo Cultural e Religioso
          * 2009, Reflexos do Liberalismo no Mosteiro de Salzedas (Reflections of Liberalism in the Monastery of Salzedas), Douro - Estudos & Documentos
          * 2009, Casas de Turismo Rural com História no Douro (Rural Tourism Houses with History in the Douro), Enoturismo e Espaço Rural
          * 2008, O papel das mulheres minhotas nas revoltas populares da primeira metade do século XIX (The role of Minho women in the popular revolts of the first half of the 19th century) , Estudos Regionais
          * 2004, Os levantamentos populares durienses e a formação da Junta de Vila Real durante a "Maria da Fonte" (The Duriense popular uprisings and the formation of the Junta de Vila Real during the "Maria da Fonte"), História
          * 2004, Manifestações durienses em torno da política vinhateira liberal na primeira metade do século XIX (Douro manifestations around liberal wine politics in the first half of the 19th century), Douro.Estudos & Documentos
          * 1998, As movimentações populares de 1846 em Viana e seu distrito (The popular movements of 1846 in Viana and its district) , Cadernos Vianenses
          * 1997, Guerrilheiros e Bandidos no Douro na primeira metade do século XIX (Guerrillas and Bandits in the Douro in the first half of the 19th century), Douro. Estudos & Documentos
          * 1994, A exploração de um domínio senhorial: o mosteiro de Ganfei durante o Antigo Regime (The exploitation of a manorial domain: the monastery of Ganfei during the Ancien Regime), Estudos Regionais

        Tese / Dissertação

          * 1993, Mestrado, O Mosteiro de Ganfei : Propriedade, Produção e Rendas no Antigo Regime 1629- 1683 e 1716- 1822

        Livro

          * 2023, História dos Ativismos Feministas em Portugal, Cerqueira, Carla; Taborda, Célia; Pereira, Ana Sofia, CICANT
          * 2023, História dos Ativismos Feministas em Portugal (History of Feminist Activism in Portugal), Pereira, Ana Sofia; Camila Lamartine; Cerqueira, Carla; Taborda, Célia; Cardoso, Daniel; Drummond, Daniela; Babo, Isabel; et al, Edições Universitárias Lusófonas

        Capítulo de livro

          * 2024, Movimentos feministas glocais: ações de resistência nas redes e nas ruas (Glocal feminist movements: resistance actions on the networks and in the streets), Cidadania Digital e Culturas do Contemporâneo
          * 2023, Luso-Mozambican Diplomatic Cooperation in the Case of the Terrorist Conflict in Cabo Delgado , Portugal and the Lusophone World, Springer Nature Singapore
          * 2023, Communicating for change: strategies used by Portuguese feminist groups - sucess and challenges, Communicating for change: strategies used by Portuguese feminist groups - sucess and challenges
          * 2023, Communicating for change: Strategies used by Portuguese feminist groups—Success and challenges, The normative imperative: Sociopolitical challenges of strategic and organizational communication, LabCom Books
          * 2022, The Economic Crisis of 2008 and its Social Impact in Europe, Ciências Socialmente Aplicáveis: Integrando Saberes e Abrindo Caminhos , IV, Editora Artemis
          * 2022, Challenges of the Intergenerational Feminist Movement(s): Some Reflections
          * 2022, Associativismo e movimentos sociais. Um olhar sobre os movimentos associativos de 2017, em Portugal (Associativism and social movements. A look at the associative movements of 2017 in Portugal), Ativismos em rede e Plataformas colaborativas , Húmus
          * 2022, A Relação entre a Greve e a Sindicalização: um estudo de caso sobre a perceção dos portugueses (The relationship between the strike and unionization: a case study on the perception of the Portuguese), Ciências humanas e sociais aplicadas: competências para o desenvolvimento humano1, 1, Atena
          * 2019, Redes sociais e mobilizações públicas. O movimento de 15 de Setembro (Social networks and public mobilizations. The September 15 movement), Ciências Sociais Aplicadas: Entendendo as Necessidades da Sociedade 2, 2, Atena Editora
          * 2019, Protestos no feminino na Europa: das "Marias da Fonte" às marchas mundiais das mulheres (Women's Protests in Europe: from "Marias da Fonte" to World Women's Marches), The overarching issues of the european space/Grandes problemáticas do espaço europeu , Flup
          * 2019, Os movimentos sociais em perspetiva histórica ( Social movements in historical perspective), The Overarching Issues of the European Space = Grandes Problemáticas do Espaço Europeu : A strategic (re)positioning of environmental and socio-cultural problems? Um (re)posicionamento estratégico das questões ambientais e socioculturais?, FLUP
          * 2019, Da História ao Turismo. A rota do vinho verde. (From History to Tourism. The white wine route)
          * 2019, Civic Participation and Demonstrations in Portugal (2011-2012), Recent Ideas and Research in Social Sciences , EUSER
          * 2018, Manifestações públicas e cidadania. Os protestos portugueses da última década (Public demonstrations and citizenship. The Portuguese protests of the last decade), The overarching issues of the european space/Grandes problemáticas do espaço europeu , FLUP
          * 2017, Crise e contestação na Europa. A propósito das manifestações portuguesas de 2012 (Crisis and contestation in Europe. About the Portuguese demonstrations of 2012), The Overarching Issues of the European Space = Grandes Problemáticas do Espaço Europeu , Faculdade de Letras da Universidade do Porto
          * 2016, Movimentos sociais: um dos grandes desafios do espaço europeu? (Social movements: one of the great challenges of the European space?), Grandes problemáticas do espaço europeu , Faculdade de Letras do Porto
          * 2015, O decreto de extinção das ordens religiosas: impacto nos mosteiros cistercienses do Douro (The decree on the extinction of religious orders: impact on Cistercian monasteries in the Douro) , Cister no Douro, Museu de Lamego
          * 2014, Insighting the city: Digital Paths in Historical Porto, Porto As a Tourism Destination, 1, Media XXI - Formalpress
          * 2010, Movimentos Sociais Oitocentistas (Eighteenth-century Social Movements ), História do Douro e do Vinho do Porto, 4, Afrontamento
          * 2006, Movimentos sociais no Douro na primeira metade do século XIX (Social movements in the Douro in the first half of the 19th century), O Douro Contemporâneo, Gehvid

        Edição de livro

          * 2022, Edições Universitárias Lusófonas.
          * 2019, EUSER
          * 2019, EUSER
          * 2016, 3, 1
          * 2015, 1, 1ª, Direção Regional de Cultura do Norte/Vale do Varosa
          * 2015, 1, 1ª, Direção Regional de Cultura do Norte/Museu de Lamego
          * 2005, Gehvid
          * 1994, Fragmentos

        Artigo em jornal

          * 2012-03-15, Clivagens sociais no Douro oitocentista (Social cleavages in the 19th century Douro), O Arrais

        Artigo em conferência

          * The economic crisis of 2008 and its social impact in Europe, 52 nd International Scientific Conference on Economic and Social Development
          * O contributo do mosteiro de Ganfei para a qualidade do vinho do Alto Minho (The contribution of the monastery of Ganfei to the quality of the wine of Alto Minho), I Congresso Internacional: Vinhas e Vinhos
          * Movimentações absolutistas no período de implantação do liberalismo ( Absolutist movements in the period of implantation of liberalism), IV Congresso Histórico de Guimarães: Do Absolutismo ao Liberalismo
          * From Dictatorship to Democracy in Portugal: The use of communication as a political strategy. , ICHSS 2012
          * EDITORIAL
          * Dos "antigos" aos "novos" movimentos sociais (From the "old" to the "new" social movements), VII Congresso de Sociologia: Crises e reconfigurações
          * Conflitualidade operária no Porto Oitocentista (Workers' Conflictuality in 19th Century Oporto), Congresso de História do Movimento Operário e dos Movimentos Sociais em Portugal
          * A voz dos operários nortenhos no advento da I República (The voice of northern workers at the advent of the First Republic) , Congresso Internacional - Outras Vozes na República
          * A extinção dos mosteiros cistercienses do Douro (The extinction of the Cistercian monasteries of the Douro), Mosteiros Cistercienses: passado, presente, futuro
          * A exploração vinícola num mosteiro beneditino do Alto Minho - Ganfei (The wine exploration in a Benedictine monastery of Alto Minho - Ganfei), O Vinho na Festa da Cultura
          * A comunicação como estratégia política da Ditadura e da Democracia (Communication as a political strategy of Dictatorship and Democracy), VI Congresso Sopcom: Sociedade dos Media: Comunicação, Política e Tecnologia.
          * 2022-07-01, Challenges of the Intergenerational Feminist Movement(s): Some Reflections. , 24th International Conference on Human-Computer Interaction,
          * 2020-11-19, The Globalization of Women`s protests: the case of the World March of Women, 62nd International Scientific Conference on Economic and Social Development
          * 2019-05-25, Da História ao Turismo. A rota do vinho verde, Congresso XIV Jornadas Internacionais ¿Grandes Problemáticas do Espaço Europeu¿
          * 2016, Redes sociais e mobilizações públicas. O movimento de 15 de Setembro ((Social networks and public mobilizations. The September 15 movement), Congresso Internacional Ibero americano em investigação qualitativa
          * 2015, Ação colectiva no Douro oitocentista: a propósito da "Maria da Fonte" (Collective action in the 19th century Douro: the "Maria da Fonte" revolt), Conferências do Museu de Lamego
          * 2013, A promoção turística através do património cultural (Tourist promotion through cultural heritage) , Casa Nobre: um património para o futuro

        Resumo em conferência

          * 2023-06-05, The National within the Transnational: The #MeToo movement in Portugal, IAMCR2023
          * 2023-06-05, The (Re-)Start of a Portuguese #MeToo: Tensions and re-mobilizations on Twitter, IAMCR2023
          * 2023-06-05, Ambivalences in opinion discourses about the #MeToo movement in the Portuguese media, IAMCR2023
          * 2023-05-12, Once Upon a Time... A Historical Chronology on the Singularities of Portuguese Feminism(s), FEMCORUS mid-term symposium "Rewired and revamped? Media and trans/national feminisms in Europe and beyond
          * 2023-04-05, Educar para a igualdade e diversidade no ensino secundário: contributos de um booklet para a recuperação da memória histórica sobre os feminismos em Portugal (Educating for equality and diversity in secondary education: contributions of a booklet to recover historical memory about feminisms in Portugal), XII Congresso Português de Sociologia
          * 2022-12-06, Movimento feminista como forma de resistência à cultura hegemónica: entre as redes e as ruas (Feminist movement as a form of resistance to hegemonic culture: between the networks and the streets), VIII Congresso Internacional sobre Culturas
          * 2022, Feminismo Glocal no Ciberespaço: a Greve Feminista Internacional em Portugal (Glocal Feminism in Cyberspace: the International Feminist Strike in Portugal), XVII Congresso IBERCOM

        Gravação áudio

          * 2023, Podcast Voices in Network (13 episodes)

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona