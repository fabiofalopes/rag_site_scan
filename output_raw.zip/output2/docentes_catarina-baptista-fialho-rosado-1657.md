# Response for https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
          PT: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657 EN: https://www.ulusofona.pt/en/teachers/catarina-baptista-fialho-rosado-1657
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
        fechar menu : https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/catarina-baptista-fialho-rosado-1657
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Catarina Baptista Fialho Rosado

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p1657
              cat***@ulusofona.pt
              2610-42BF-7BA7: https://www.cienciavitae.pt/2610-42BF-7BA7
              0000-0002-6429-6213: https://orcid.org/0000-0002-6429-6213
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/bed2dc4f-0bc8-440f-8ee3-0fb5ee4e8c25
      : https://www.ulusofona.pt/

        Resume

        Catarina Rosado has received her PhD in Pharmaceutical Technology at Cardiff University, UK. She is currently Associate Professor at ECTS of Universidade Lusófona. She has established her research at CBIOS- Universidade Lusófona, leading the Development of Delivery Systems research domain, but has collaborations with other Portuguese and foreign universities. Her research is focused on the study of the impact of formulations on transdermal penetration and also in the development of non-invasive in vivo strategies to assess efficacy and safety of innovative ingredients for topical drugs and cosmetics. Catarina is also interested in the application of lipidic biomaterials as innovative excipients of topical and transdermal formulations., and in the impact of nutrition on human skin, namely on barrier function, skin pathologies and ageing. Catarina Rosado has been involved in the supervision of several MSc and PhD students, and has hosted in her research lab postgraduate students from various countries. She has regularly been invited to lecture in Masters and Postgraduate programs in other national and international universities.

        Graus

            * Licenciatura
              Ciências Farmacêuticas
            * Doutoramento
              PhD

        Publicações

        Preprint

          * 

        Journal article

          * 2023-08-08, Technological Aspects and Potential Cutaneous Application of Wine Industry by-Products, Applied Sciences
          * 2023-07-05, Exploring Stearic-Acid-Based Nanoparticles for Skin Applications—Focusing on Stability and Cosmetic Benefits, Cosmetics
          * 2023-04-11, Mixed Edge Activators in Ibuprofen-Loaded Transfersomes: An Innovative Optimization Strategy Using Box–Behnken Factorial Design, Pharmaceutics
          * 2023-03-25, Effect of an Emollient Emulsion Containing 15.0% of Caprylic/Capric Triglyceride on the Urocanic Acid of the Stratum Corneum, Life
          * 2023-03-09, In Vitro Photoprotection and Functional Photostability of Sunscreen Lipsticks Containing Inorganic Active Compounds, Cosmetics
          * 2023-01-05, Photoprotective Efficacy of the Association of Rosmarinic Acid 0.1% with Ethylhexyl Methoxycinnamate and Avobenzone, Cosmetics
          * 2023, Mixed Edge Activators in Transfersomes: an Innovative Optimization, Pharmaceutics
          * 2023, Methods for cutaneous penetration assessment of organic UV filters - a review, Biomedical and Biopharmaceutical Research
          * 2022-12-21, Phytocompounds Recovered from the Waste of Cabernet Sauvignon (Vitis vinifera L.) Vinification: Cytotoxicity (in Normal and Stressful Conditions) and In Vitro Photoprotection Efficacy in a Sunscreen System, Cosmetics
          * 2022-12, Rosmarinic Acid Multifunctional Sunscreen: Comet Assay and In Vivo Establishment of Cutaneous Attributes, Cosmetics
          * 2022-10-23, Kefir and the Gut–Skin Axis, International Journal of Environmental Research and Public Health
          * 2022-07-19, The Impact of Kefir on Epidermal Water Homeostasis in Healthy Human Skin, Life
          * 2022-06, Impact of Portuguese propolis on keratinocyte proliferation, migration and ROS protection: Significance for applications in skin products, International Journal of Cosmetic Science
          * 2022-05, Characterization of lipid extracts from the Hermetia illucens larvae and their bioactivities for potential use as pharmaceutical and cosmetic ingredients, Heliyon
          * 2022-03-16, Dietary Supplements and the Skin: Focus on Photoprotection and Antioxidant Activity—A Review, Nutrients
          * 2022-02-28, Prospecting In Vitro Antioxidant and Photoprotective Properties of Rosmarinic Acid in a Sunscreen System Developed by QbD Containing Octyl p-Methoxycinnamate and Bemotrizinol, Cosmetics
          * 2022-01-15, Nanodelivery Strategies for Skin Diseases with Barrier Impairment: Focusing on Ceramides and Glucocorticoids, Nanomaterials
          * 2022-01-09, Microalgae as a Sustainable, Natural-Oriented and Vegan Dermocosmetic Bioactive Ingredient: The Case of Neochloris oleoabundans, Cosmetics
          * 2022-01-05, Influence of the Mixtures of Vegetable Oil and Vitamin E over the Microstructure and Rheology of Organogels, Gels
          * 2022, Potential Use of Lipid Extracts from the <i>Hermetia Illucens</i> Larvae as Pharmaceutical and Cosmetic Ingredients, SSRN Electronic Journal
          * 2021-12-31, Single versus mixed edge activators in caffeine-loaded transfersomes: physicochemical and cytotoxicity assessment, Journal Biomedical and Biopharmaceutical Research
          * 2021-12-26, An overview of violence and sexual abuse in children: global data, policy responses, and multidisciplinary approaches in health care, Journal Biomedical and Biopharmaceutical Research
          * 2021-11-13, Homemade Kefir Consumption Improves Skin Condition—A Study Conducted in Healthy and Atopic Volunteers, Foods
          * 2021-11-04, Probiotics in the gut-skin axis – the case of kefir, Journal Biomedical and Biopharmaceutical Research
          * 2021-06-26, An Overview on Topical Administration of Carotenoids and Coenzyme Q10 Loaded in Lipid Nanoparticles, Antioxidants
          * 2021-05-11, Characterization of Kefir Produced in Household Conditions: Physicochemical and Nutritional Profile, and Storage Stability, Foods
          * 2021-04, Acceptability of kefir produced by fermentation of Portuguese milk with CIDCA AGK1 grains in a sample of Portuguese consumers, Biomedical and Biopharmaceutical Research Journal
          * 2021-02-17, Skin impacts from exposure to ultraviolet, visible, infrared, and artificial lights – a review, Journal of Cosmetic and Laser Therapy
          * 2021-01, Ex vivo penetration analysis and anti-inflammatory efficacy of the association of ferulic acid and UV filters, European Journal of Pharmaceutical Sciences
          * 2021, Bacterial nanocellulose-hyaluronic acid microneedle patches for skin applications: In vitro and in vivo evaluation, Materials Science and Engineering C
          * 2020-11-03, Analytical tools for urocanic acid determination in human samples: A review, Journal of Separation Science
          * 2020-11, Preliminary evaluation of the antimicrobial activity of different Hermetia illucens larvae extracts for application as a cosmetic ingredient, Biomedical and Biopharmaceutical Research Journal
          * 2020-10, In vitro water resistance evaluation of a bioactive sunscreen containing distinct film/ barrier-forming agents, Biomedical and Biopharmaceutical Research Journal
          * 2020-07-29, In vivo SPF from multifunctional sunscreen systems developed with natural compounds—A review, Journal of Cosmetic Dermatology
          * 2020-06-29, Bioactive Compounds from Hermetia Illucens Larvae as Natural Ingredients for Cosmetic Application, Biomolecules
          * 2020-06-10, Assessment of the Potential Skin Application of Plectranthus ecklonii Benth., Pharmaceuticals
          * 2020-04-26, Is the Botryococcus braunii Dry Biomass an Adjuvant for Anti-UVB Topical Formulations?, Scientia Pharmaceutica
          * 2020-02-13, Topical Drug Delivery Systems Based on Bacterial Nanocellulose: Accelerated Stability Testing, International Journal of Molecular Sciences
          * 2020, Butyrospermum parkii butter increased the photostability and in vivo SPF of a molded sunscreen system, Journal of Cosmetic Dermatology
          * 2019-11-07, The Synergistic Behavior of Antioxidant Phenolic Compounds Obtained from Winemaking Waste’s Valorization, Increased the Efficacy of a Sunscreen System, Antioxidants
          * 2019-08-10, Ionic Liquid-Polymer Nanoparticle Hybrid Systems as New Tools to Deliver Poorly Soluble Drugs, Nanomaterials
          * 2019-06, Determination of relevant endpoints to evaluate the in vivo barrier function in cutaneous health, Journal Biomedical and Biopharmaceutical Research
          * 2019-05-03, Another Reason for Using Caffeine in Dermocosmetics: Sunscreen Adjuvant, Frontiers in Physiology
          * 2019-04, Main features and applications of organogels in cosmetics, International Journal of Cosmetic Science
          * 2018-12, SPF enhancement provided by rutin in a multifunctional sunscreen, International Journal of Pharmaceutics
          * 2018-06, Influence of two choline-based ionic liquids on the solubility of caffeine, Journal Biomedical and Biopharmaceutical Research
          * 2018, Safety and Antioxidant Efficacy Profiles of Rutin-Loaded Ethosomes for Topical Application, AAPS PharmSciTech
          * 2018, Evaluation of Industrial Sour Cherry Liquor Wastes as an Ecofriendly Source of Added Value Chemical Compounds and Energy, Waste and Biomass Valorization
          * 2018, Active ingredients, mechanisms of action and efficacy tests antipollution cosmetic and personal care products, Brazilian Journal of Pharmaceutical Sciences
          * 2017-12-21, Applicability of Ionic Liquids in Topical Drug Delivery Systems: A Mini Review, Journal of pharmacology & clinical research
          * 2017-12, Permeation of Ionic Liquids through the skin, Journal Biomedical and Biopharmaceutical Research
          * 2017-12, Carbohydrates in Ankistrodesmus braunii biomass cultivated in tubular photobioreactors, Journal Biomedical and Biopharmaceutical Research
          * 2017-10-18, Efficiency of Nisin as Preservative in Cosmetics and Topical Products, Cosmetics
          * 2017, Choline- versus imidazole-based ionic liquids as functional ingredients in topical delivery systems: cytotoxicity, solubility, and skin permeation studies, Drug Development and Industrial Pharmacy
          * 2017, About the in vivo quantitation of skin anisotropy, Skin Research and Technology
          * 2016-12, Novel 3D “active” representations of skin biomechanics, Journal Biomedical and Biopharmaceutical Research
          * 2016-12, Comparison of sunscreens Containing Titanium Dioxide Alone Or In Association With Cocoa, Murumuru Or Cupuaçu Butters, Journal Biomedical and Biopharmaceutical Research
          * 2016-10, Unsaponifiable matter from oil of green coffee beans: cosmetic properties and safety evaluation.
          * 2016, Stability and safety of quercetin-loaded cationic nanoemulsion: In vitro and in vivo assessments, Colloids and Surfaces A: Physicochemical and Engineering Aspects
          * 2016, Safety and efficacy evaluation of gelatin-based nanoparticles associated with UV filters, Colloids and Surfaces B: Biointerfaces
          * 2016, Rutin increases critical wavelength of systems containing a single UV filter and with good skin compatibility, Skin Research and Technology
          * 2016, Gelatin-based microspheres crosslinked with glutaraldehyde and rutin oriented to cosmetics, Brazilian Journal of Pharmaceutical Sciences
          * 2016, Cutaneous biocompatible rutin-loaded gelatin-based nanoparticles increase the SPF of the association of UVA and UVB filters, European Journal of Pharmaceutical Sciences
          * 2015-06, Photostabilization of sunscreens by incorporation of tea as the external phase, Journal Biomedical and Biopharmaceutical Research
          * 2015-06, Cutiscan® - A new system of biomechanical evaluation of the skin in vivo - comparative study of use depending on the anatomical site, Journal Biomedical and Biopharmaceutical Research
          * 2015, Study of the effect of epidermal overhydration by occlusion, on the skin biomechanical behaviour assessed in vivo with the systems Cutometer®, Reviscometer® and CutiScan®, Journal Biomedical and Biopharmaceutical Research
          * 2015, Production and characterization of nanoparticles containing methanol extracts of Portuguese Lavenders, Measurement: Journal of the International Measurement Confederation
          * 2015, Novel insights for permeant lead structures through in vitro skin diffusion assays of Prunus lusitanica L., the Portugal Laurel
          * 2015, Integrated approach in the assessment of skin compatibility of cosmetic formulations with green coffee oil, International Journal of Cosmetic Science
          * 2015, Functional photostability and cutaneous compatibility of bioactive UVA sun care products, Journal of Photochemistry and Photobiology B-Biology
          * 2015, EXPLORING CUTANEOUS REACTIVITY UNDER DIFFERENT PERFUSION CONDITIONS WITH METHYL NICOTINATE, Journal of Vascular Research
          * 2014-12, Exploring human in vivo microcirculation with methyl nicotinate in different perfusion conditions, Journal Biomedical and Biopharmaceutical Research
          * 2014, Zinc intake and serum levels in Portuguese women living in Lisbon area, Journal Biomedical and Biopharmaceutical Research
          * 2014, Topical caffeine delivery using biocellulose membranes: a potential innovative system for cellulite treatment
          * 2014, Impact of stirring speed, glycerin and sodium chloride concentrations on photoprotective nanoemulsions
          * 2014, Design of polymeric nanoparticles and its applications as drug delivery systems for acne treatment, Drug Development and Industrial Pharmacy
          * 2014, Bacterial cellulose membranes as transdermal delivery systems for diclofenac: In vitro dissolution and permeation studies
          * 2014, Avaliação das propriedades sensoriais de uma formulação cosmética contendo óleo de café verde
          * 2014, Aplicação de sub-produtos da “ginginha” de Óbidos em formulações tópicas: um estudo preliminar
          * 2013-06, Evaluation of the sensory properties of a cosmetic formulation containing green coffee oi, Journal Biomedical and Biopharmaceutical Research
          * 2013-06, Application of Óbidos “Ginginha” by-products in topical formulations: Apreliminary study, Journal Biomedical and Biopharmaceutical Research
          * 2013, Safety of green coffee oil in cosmetic formulations: From in vitro to clinical studies, Toxicology Letters
          * 2013, Influência de duas técnicas diferentes no tamanho e potencial zeta de nanopartículas de poli(D.L-láctico-co-glicólico)
          * 2013, Hydrocortisone-loaded poly(epsilon-caprolactone) nanoparticles for atopic dermatitis treatment, Pharmaceutical Development and Technology
          * 2013, Drug carriers for oral delivery of peptides and proteins: Accomplishments and future perspectives, Therapeutic Delivery
          * 2013, Avaliação da função de barreira da pele pela análise Bi-compartimental de medições dinâmincas da PTEA : validação de novas condições analíticas
          * 2012-12, Skin Barrier Function Evaluation by Bi-compartmental Analisys of TEWL Dynamical Measurements: Validation of New Analytical Conditions, Journal Biomedical and Biopharmaceutical Research
          * 2012, In vitro and in vivo assessment of the effect of Laurus novocanariensis oil and essential oil in human skin, International Journal of Cosmetic Science
          * 2012, Bacterial cellulose membranes applied in topical and transdermal delivery of lidocaine hydrochloride and ibuprofen: In vitro diffusion studies
          * 2012, Evaluation of two barrier function modulation cosmetic formulations by dynamic tewl analysis
          * 2011-12, The influence of two different techniques on the particle size and zeta potencial of poly (D,L-Lactide-co-glycolide) nanoparticles, Journal Biomedical and Biopharmaceutical Research
          * 2011-06, Characterization of the efficacy of a moisturizer that restores the cutaneous barrier, Journal Biomedical and Biopharmaceutical Research
          * 2011, Is there any barrier impairment in sensitive skin?: A quantitative analysis of sensitive skin by mathematical modeling of transepidermal water loss desorption curves, Skin Research and Technology
          * 2011, Biocellulose Membranes as Supports for Dermal Release of Lidocaine
          * 2010, Influência do sistema de libertação na permeação de uma molécula hidrofílica
          * 2010, Avaliação da função barreira da pele utilizando a modelação matemática das curvas de PTEA : diferenças relacionadas com o envelhecimento cutâneo
          * 2009, Assessment of moisturizers and barrier function restoration using dynamic methods, Skin Research and Technology
          * 2009, Acerca da medição da hidratação 'profunda' da pele
          * 2008, Estudo da acção de um creme hidratante através de métodos estáticos e dinâmicos
          * 2008, Avaliação da eficácia de um creme contendo ureia na função de barreira cutânea
          * 2007, Caracterização da pele infantil e dos produtos cosméticos destinados a esta faixa etária
          * 2006, Assessment of dry skin using dynamic methods, Journal of Applied Cosmetology
          * 2006, A celulite : caracterização funcional e revisão dos principais compostos utilizados na abordagem cosmetológica
          * 2005, Modeling TEWL-desorption curves: A new practical approach for the quantitative in vivo assessment of skin barrier, Experimental Dermatology
          * 2005, Estudo do comportamento de dois modelos de evaporimetros em condições de utilização controlada : Medições Estáticas e Dinâmicas In Vivo
          * 2005, Comparative assessment of the performance of two generations of Tewameter®: TM210 and TM300, International Journal of Cosmetic Science
          * 2003, Solvent effects in permeation assessed in vivo by skin surface biopsy, BMC Dermatology
          * 2003, In vivo study of the physiological impact of stratum corneum sampling methods, International Journal of Cosmetic Science
          * 2003, Effect of vehicle pretreatment on the flux, retention, and diffusion of topically applied penetrants in vitro, Pharmaceutical Research

        Book

          * 2017, Dynamic quantification of the human skin barrier in sensitive skin syndrome, Rodrigues, L.M.; Silva, H.; Rosado, C.

        Book chapter

          * 2020, UV-screening from microalgae, Handbook of Microalgae-Based Processes and Products, Elsevier
          * 2020, Cosmetics Applications, Microalgae, Elsevier
          * 2017, Regarding the quantification of the human skin barrier in Sensitive Skin Syndrome, Sensitive Skin Syndrome, Second, CRC Press
          * 2017, Human epidermal barrier may be quantitatively described by compartmental analysis of water dynamics

        Conference paper

          * Pesquisa de propriedades anti-inflamatórias da planta Prunus lusitanica = Search anti-inflammatory properties of the plant Prunus lusitanica
          * Influence of the Triterpene Friedelin in the Transcutaneous Penetration of two model susbtances

        Conference abstract

          * 2023-09-14, Gut-Skin Axis - Effect of kefir , ESPEN Congress 2023
          * 2022-12, Phytochemical study and bioactivity assessment of extracts from Plectranthus ecklonii Benth, 70th International Congress and Annual Meeting of the Society for Medicinal Plant and Natural Product Research (GA)
          * 2022, Applicability of lipid extracts from Hermetia illucens larvae in antiageing cosmetic formulations, InnovDelivery'22
          * 2022, Antioxidant Essential Oils as Innovative Ingredients in Facial Masks, InnovDelivery'22
          * 2018-10-26, Application of ionic liquids-nanoparticles hybrid systems in food technology, II Lusofona¿s Nutrition Meeting
          * 2017-07, Ionic liquids as functional ingredientes in drug delivery systems, Encontro Ciência 2017
          * 2016-10, Functional Ingredients in delivery systems, II Scientific Conferences CBIOS

        Conference poster

          * 2024-02-14, May TransfersomILs redefine the hydroxycinnamic acids delivery to the skin?, XV Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2024-02-14, Lipid extract from larvae biomass: an added-value biomaterial to produce lipid nanoparticles to tackle atopic dermatitis, XV Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2024-02-14, Cerosomes at the forefront: a multifunctional strategy for addressing Xeroderma Pigmentosum, XV Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2023-11-10, TransfersomILs loading caffeic or p-coumaric acids: na innovative approach for cutaneous delivery, V Jornadas CBIOS
          * 2023-11-10, TransfersomILs for the skin delivery of ferulic acid: impact on permeation assays?, V Jornadas CBIOS
          * 2023-11-10, Development of gels incorporating nanoemulsions based on Hermetia illucens larvae extract: stability and skin compatibility studies., V Jornadas CBIOS
          * 2023-11, On the path to innovative nanotechnological formulations for skin diseases associated with barrier impairment., 9th International Electronic Conference on Medicinal Chemistry
          * 2023-07-13, Rutin-loaded cerosomes enhancing the delivery of a bioactive natural compound for the management of UV-induced skin rare diseases., III Bio.Natural - Bioactive Natural Products Research Conference
          * 2023-07-05, Using insect larvae biomass to produce innovative lipid nanoparticles: a bioinspired and sustainable approach to tackle atopic dermatitis, Ciência 2023
          * 2023-07-05, Enhancing Dermocosmetic Potential: Exploring Methanolic Extracts from Plectranthus spp. and their Bioactivity, Encontro Ciência 2023
          * 2023-07-05, Development of cerosomes loading rutin towards the management of UV-induced skin diseases., Ciência 2023
          * 2023-06-19, TransfersomILs: an innovative nanosystem for the cutaneous delivery of hydroxycinnamic acids, NanoMed Europe 2023
          * 2023-06-19, From insect larvae biomass to lipid-based nanocarriers: an advanced approach for the management of atopic dermatitis., NanoMed Europe 2023
          * 2023-06-19, Combining lipids extracted from larvae biomass and biobased ionic liquids to boost skin nanodelivery, NanoMed Europe 2023
          * 2023-06-19, A multifunctional vesicular nanosystem for the management of Xeroderma pigmentosum - a rare skin disease, NanoMed Europe 2023
          * 2023-03-19, Hermetia illucens larvae: Lipidic extracts as potential ingredients for dermocosmetic applications, 6th International Symposium on Medicinal and Aromatic Plants (6th SIPAM)
          * 2023-02-06, Optimization of rutin-loaded cerosomes: a step forward for the management of dermatological conditions, 4th SPLC-CRS Young Scientists Meeting
          * 2023-02-06, Exploring the innovative TransfersomILs for the cutaneous delivery of hydroxycinnamic acids, 4th SPLC-CRS Young Scientists Meeting
          * 2022-11-11, The Portuguese Physiology Roadmap ¿ From molecules to the individual ¿ perspectives from CBIOS
          * 2022-11-11, Probing the impact of TransferomILs containing rutin in skin physiology ¿ cytotoxicity studies, 2nd International Meeting of the Portuguese Society of Physiology
          * 2022-11-11, Optimization of Transfersomes for Ibuprofen delivery, 2nd International Meeting of the Portuguese Society of Physiology
          * 2022-11-11, New perspectives in the approach to skin barrier dysfunction - using lipid nanoparticles based on insect biomass to improve dexamethasone delivery, 2nd International Meeting of the Portuguese Society of Physiology
          * 2022-11, Extracts from Plectranthus spp. and evaluation of their ability to promote tissue protection, 2º Congresso Internacional de Fisiologia
          * 2022-10-21, Improving the performance of SLNs - combining lipids extracted from larvae biomass and choline-based ILs, 5º Encontro de Biotecnologia Medicinal/2nd Iberian Congress on Medicinal Biotechnology
          * 2022-08, Lipidic extracts from Hermetia illucens larvae as potential ingredients for dermocosmetic applications, 70th International Congress and Annual Meeting of the Society for Medicinal Plant and Natural Product Research (GA)
          * 2022-07, Methanolic extracts from Plectranthus spp. and their biological activity for dermocosmetics uses, 5th Meeting of Colégio Química Universidade Lisboa - "Forging bonds"
          * 2022-07, Biological activity study of Plectranthus spp. methanol extracts for dermocosmetics uses, 13th Postgraduate Students Meeting- iMed.ULisboa
          * 2022-06-30, Development of lipid nanoparticles from Hermetia illucens larvae extract for dexamethasone delivery for topical application, InnovDelivery - I Lusophone Metting on Innovative Delivery Systems
          * 2022-05, Lipid extracts from Hermetia illucens larvae as innovative ingredients in cosmetic formulations, The First African Conference on Natural Products and Related Fields
          * 2022-05, Enzymatic inhibition of methanolic Plectranthus spp. Extracts with skin traditional use, The First African Conference on Natural Products and Related Fields
          * 2022-05, Antioxidant Essential Oils impregnated in Novel Gelatin-based film Masks, The First African Conference on Natural Products and Related Fields
          * 2022-03-11, Characterization of lipid extracts from Hermetia illucens larvae and assessment of their potential use in cosmetic formulations, Cosmetinnov 2022
          * 2022-03-10, Differences in skin physiology between vegetarian-vegan and omnivores - an exploratory approach, Cosmetinnov 2022
          * 2022-03, Stratum corneum lipids as the basis of nanoparticles for epidermal regeneration. , COSMETINNOV
          * 2022-03, Development of lipid nanoparticles based on insect larvae biomass for skin delivery., COSMETINNOV
          * 2022, More Evidence on The Gut-Skin Axis Modulation by Kefir., 2nd International Meeting of the Portuguese Society of Physiology, Coimbra, Portugal
          * 2022, Kefir intake reduces the clinical severity in atopic dermatitis by improving epidermal ¿barrier¿., ISBS 2022 - World Congress on Biophysics and Imaging of the Skin, Berlin, Germany
          * 2021-11-03, Innovative transfersomes for the transdermal nanodelivery of ibuprofen., CIFARP 2021 - 13th International Congress of Pharmaceutical Sciences
          * 2021-11, Using lipids extracted from black soldier fly larvae for nanoparticles development - Preliminary studies., II Bio.Natural ¿ Bioactive Natural Products Research Meeting.
          * 2021-08-20, Pode a dieta influenciar a fisiologia da pele de indivíduos com peso normal? - Dados de comparação da composição corporal vegetariano-vegano e omnívoros , 33º Congresso Brasileiro Cosmetologia, 2021
          * 2021-08-18, Desenvolvimento de nanopartículas lipídicas baseadas na composição do estrato córneo para regeneração epidérmica, 33º Congresso Brasileiro de Cosmetologia
          * 2021-05-10, Atividade antimicrobiana de Extratos etanólicos de Plectranthus spp. e o seu potencial na cosmética, XXV COLAMIQC- VIRTUAL
          * 2021, Variabilidade na função de barreira da pele de indivíduos saudáveis, induzida pela ingestão de kefir., XXV Congresso Latino-Americano e Ibérico de Quimicos Cosmeticos-COLAMIQC- I, Venezuela
          * 2021, Pode a dieta influenciar a fisiologia da pele de indivíduos com peso normal? ¿ dados da comparação da composição corporal de vegetariano-vegano e omnívoros, 33º Congresso Brasileiro Cosmetologia
          * 2020-01, Ionic liquids as a strategy to improve drug delivery systems, 13º Encontro Nacional de Química Orgânica / 6º Encontro Nacional de Química Terapêutica
          * 2020, Impact of kefir consumption on cutaneous health assessed using an SLS-induced lesion model. , 55th Annual Congress of SBFIS, Brasil
          * 2019-10-10, Assessment of the impact of oral intake of the probiotic kefir in cutaneous health., Physioma 2019 - 1st International Meeting of the Portuguese Society of Physiology, Lisbon, Portugal
          * 2019-09-27, Extraction methods of bioactive compounds from Hermetia illucens larvae with cosmetic application., I Bio.Natural ¿ Bioactive Natural Products Research Meeting
          * 2019-02-25, Ionic liquids in drug delivery, COST CA17103 - Delivery of Antisense RNA Therapeutics
          * 2019-02-21, Ionic liquids-nanoparticle hybrid systems as tools to deliver poorly soluble drugs, 46th Controlled Release Society Annual Meeting & Exposition
          * 2019, Skin compatibility assessment of sodium alginate hydrogels loaded with PLGA nanoparticles for wound healing, I Bioactive Natural Products Research Meeting
          * 2019, Skin compatibility assessment of PLGA-nanoparticle loaded hydrogels for wound healing, Physioma 2019
          * 2018-01-14, Optimization of production of nanostrutured lipid carriers by solvent-evaporation double emulsion technique for topical drug delivery, XII Spanish-Portuguese Conference on Controlled Drug Delivery
          * 2016-10, Amino acid based ionic liquids as functional ingredients in topical formulations containing caffeine, II Scientific Conferences CBIOS
          * 2015-09, Ionic liquids as solubility/permeation enhancers for topical formulations: skin permeation and cytotoxicity characterization, 51st Congress of the European Societies of Toxicology
          * 2015-07, Ionic liquids as solubility/permeation enhancers for topical drug delivery systems, 19th European Symposium of Organic Chemistry
          * 2015-05, Study of the applicability of ionic liquids as excipients in topical formulations, V Congresso Nacional de Ciências Dermatocosméticas / IV Congresso da Sociedade Portuguesa de Ciências Cosmetológicas
          * 2014-10, Ionic liquids as functional ingredients in topical drug delivery systems, Ist Scientific Conferences CBIOS
          * 2012, Design of PLGA nanoparticles containing Azelaic Acid for Acne Treatment, Colloids and Nanomedicine
          * 2011, Pre-formulation study: selection of a method for production of PLGA nanoparticles for later encapsulation of azelaic acid, Nano2011.pt
          * 2011, Development of azelaic-acid PLGA nanoparticles by m-SESD method for topical treatment of acne, Nano2011.pt
          * 2011, Development of alginate beads and microparticles loaded with ibuprofen for transdermal delivery, IV Congresso Ibero-Americano de Ciências Farmacêuticas
          * 2011, Development and optimization process of PLGA nanoparticles obtained by m-SESD method, Nano2011.pt
          * 2011, Design and permeation studies of Alginate multiparticulate systems for transdermal drug delivery, 12th Annual Meeting of Skin Forum
          * 2011, Application of new drug delivery systems in encapsulation of lipophilic drugs for transdermal use, III Congresso Nacional de Ciêncas Dermacosméticas

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona