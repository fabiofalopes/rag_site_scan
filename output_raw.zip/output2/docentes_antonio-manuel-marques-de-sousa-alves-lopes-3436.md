# Response for https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
          PT: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436 EN: https://www.ulusofona.pt/en/teachers/antonio-manuel-marques-de-sousa-alves-lopes-3436
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
        fechar menu : https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/antonio-manuel-marques-de-sousa-alves-lopes-3436
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          António Lopes

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3436
              ant***@ulusofona.pt
              6914-951B-434C: https://www.cienciavitae.pt/6914-951B-434C
              0000-0003-2828-8475: https://orcid.org/0000-0003-2828-8475
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/9d5591a3-0542-46c7-bf87-ed2d67e40168
      : https://www.ulusofona.pt/

        Resume

        Antonio Manuel Marques de Sousa Alves Lopes. É Professor Auxiliar na Universidade Lusófona de Humanidades e Tecnologias. Membro colaborador no Centro de Investigação em Desporto, Saúde e Desenvolvimento Humano. Publicou 6 artigos em revistas especializadas e 17 trabalhos em actas de eventos. Possui 6 softwares, 2 processos ou técnicas e outros 10 itens de produção técnica. Recebeu 33 prémios e/ou homenagens. Actua na área de Ciências do Desporto e Novas Tecnologias. Nas suas actividades profissionais interagiu com 25 colaboradores em co-autorias de trabalhos científicos.

        Graus

            * Outros
              DEA - Fonaments Metodològics de la Recerca de l’Activitat Física i l’Esport
            * Doutoramento
              Doctorat Fonaments Metodològics Recerca de l’Activitat Física l’Esport
            * Pós-Graduação
              Mestrado em Desporto
            * Licenciatura
              Educação Física e Desporto
            * Doctorat
              EDUCAÇÃO FÍSICA E DESPORTO
            * Doutoramento
              Fonaments metodològics de la recerca de l’activitat física i l’esport
            * Licenciatura
              Curso Superior de Educação Física e Desporto

        Publicações

        Artigo em revista (magazine)

          * 2008-03-03, O Mundo virtual como Plataforma de Ensino e Formação para Treinadores, Revista CM - Revista Online Saúde Educação

        Artigo em revista

          * 2015-01, Using Voronoi diagrams to describe tactical behaviour in invasive team sports: an application in basketball, CPD
          * 2015, Using Voronoi diagrams to describe tactical behaviour in invasive team sports: An application in basketball, Cuadernos de Psicologia del Deporte
          * 2014, Observational software, data quality control and data analysis | Programas informáticos de registro, control de calidad del dato, y análisis de datos, Revista de Psicologia del Deporte
          * 2013, Measuring spatial interaction behavior in team sports using superimposed Voronoi diagrams, International Journal of Performance Analysis in Sport
          * 2013, Measuring spatial interaction behavior in team sports using superimposed Voronoi diagrams, International Journal of Performance Analysis in Sport
          * 2012, Detección de los patrones temporales del comportamiento defensivo de la selección de España en el torneo de Balonmano de los Juegos Olímpicos de Pekín 2008, Área de Balonmano - Revista de la Asociación de Entrenadores de Balonmano
          * 2011, The use of the virtual world Second Life© for the education of team handball sport agents – A new dimension in education and in sports promotion., EHF Web periodicals online
          * 2009, Use in sports coach education of a virtual world system for reproducing team handball movements, Journal of Virtual World Research - Pedagogy, Education and Innovation in 3-D Virtual Worlds
          * 2009, A INTERACÇÃO ENTRE FORMADOR E FORMANDOS NUM WEBINAR REALIZADO NO MUNDO VIRTUAL SECOND LIFE: UM ESTUDO EXPLORATÓRIO NO ANDEBOL, Revista Itinerários - Revista de Educação do Instituto Superior de Ciências Educativas
          * 2008, O Mundo Virtual Second Life : Uma Nova Dimensão a Várias Dimensões, Revista Itinerários
          * 2008, A utilização do Mundo Virtual Second Life© para a formação agentes desportivos de Andebol – Uma nova dimensão na formação e promoção da modalidade, Revista Técnica de Andebol
          * 2008, Sistema de criação de movimentos de Andebol em Second Life para Formação de Treinadores, Prisma.com Revista de Ciências da Informação e da Comunicação do CETAC

        Livro

          * 2013, Using spatial metrics to characterize behaviour in small-sided games, Lopes, A.; Fonseca, S.; Leser, R.; Baca, A.; Paulo, A.
          * 2012, Detecting hidden patterns in the dynamics of play in team sports, Camerino, O.; Jonsson, G.K.; Sánchez-Algarra, P.; Teresa Anguera, M.; Lopes, A.; Chaverri, J.

        Capítulo de livro

          * 2013, Part 7 - Systems - 36. Using spatial metrics to characterize behaviour in small-sided games, Performance Analysis of Sport IX, Routledge, Taylor & Francis Group
          * 2012, Chapter 2. Detecting hidden patterns in the dynamics of play in team sports, Mixed Methods Research in the Movement Sciences - Case Studies in Sport, Physical Education and Dance, 1, Routledge

        Artigo em conferência

          * System for Defining and Reproducing Handball Strategies in Second Life On-Demand for Handball Coaches Education, World Conference on Educational Multimedia, Hypermedia and Telecommunications 2009
          * Sistema de criação de movimentos de Andebol em Second Life para Formação de Treinadores, Conferência sobre Comunicação, Educação e Formação no Second Life 08
          * Interaction in 3D Virtual Worlds: An Integrated Approach of Emerging Technologies in Handball , 2011 EHF Scientific Conference Science and Analytical Expertise in Handball
          * Formação de andebol no Second Life - Estudo da interacção entre formador e formandos num webinar para alunos do ensino superior, IV SEMIME - Exclusão digital na sociedade da informação
          * Formação de Treinadores de Andebol: Estudo exploratório sobre a opinião dos treinadores sobre o recurso a plataformas de ensino à distância e mundos virtuais na sua formação, SEMINÁRIO “DESPORTO E CIÊNCIA”
          * Complementariedad metodológica en el estudio observacional de la defensa del equipo de balonmano español en los juegos olímpicos (Pekín 2008), XII Congreso de Metodología y de las Ciencias Sociales y de la Salud
          * Ball recovery in the handball tournament of the 2008 Beijing Olympic Games, the 7th International Conference on Methods and Techniques in Behavioral Research
          * A INTERACÇÃO ENTRE FORMADOR E FORMANDOS NUM WEBINAR REALIZADO NO MUNDO VIRTUAL SECOND LIFE: UM ESTUDO EXPLORATÓRIO NO ANDEBOL, 1º Congresso Revista Itinerários: A Educação Hoje

        Resumo em conferência

          * 2012, Using spatial metrics to characterize behaviour in small sided games, WCPAS IX - World Congress of Performance Analysis of Sport IX
          * 2012, O comportamento da defesa da selecção de Espanha no torneio de andebol nos Jogos Olímpicos de Pequim 2008 - Análise sequencial no método organizado de jogo de andebol em situação de 6x6, UIIPS Congresso Investigação e Desenvolvimento no IPS
          * 2011, O Andebol e a interacção em mundos virtuais: uma perspectiva integrada com tecnologias emergentes, III Congreso Internacional de Balonmano: "La formación multidisciplinar de los técnicos como clave para el éxito"
          * 2010, Sequential analysis of emergent defensive behaviour under different constrains in Handball, 11th European Workshop on Ecological Psychology (EWEP11)
          * 2010, Modelos de Formação de Treinadores: A inevitabilidade e influência do e-learning e dos mundos virtuais, III Congresso Internacional Luso-Brasileiro de Educação Física, Desporto e Lazer
          * 2010, Formação de treinadores de Andebol através do Mundo Virtual Second Life® - Work in Progress, 7º Congresso Técnico Científico de Andebol - O trabalho das posições específicas
          * 2010, Analysing complex behaviour in team sports by means of observational methodology: A case study from handball, 3rd International Congress Complex Systems in Medicine and Sport (ICCSMS2010)
          * 2009, Formação de treinadores de Andebol através do Mundo Virtual Second Life- Work in Progress, 6º Congresso Técnico Científico de Andebol
          * 2008, Formação de treinadores através do Mundo Virtual Second Life, 5º Congresso Técnico Científico de Andebol
          * 2008, Coaching Education through a Virtual World Learning Environment: A Team Handball Case in Second Life®, 13th European College of Sport Science
          * 2007, O Mundo Virtual como Plataforma de Ensino e Formação de Andebol para os Treinadores e Professores, Congresso do Desporto: Da Ciência à Consciência
          * 2005, O Ensino dos Meios Tácticos de Grupo no Andebol, 3º Congresso Técnico Científico de Andebol

        Outra produção

          * 2009, Site do CIDESD, Software
          * 2009, Site do 1º Congresso Internacional da Intervenção Pedagógica e Profissional, Software
          * 2009, Site da Faculdade de Educação Física e Desporto da ULHT, Software
          * 2009, Site Sub-área científica de Pedagogia do Desporto da ESDRM, Software
          * 2009, Sistema de Criação de Movimentos em Andebol, Produto
          * 2009, Livro de Resumos - Monografias dos Cursos de Educação Física e Desporto e Aptidão Física e Saúde de 2005 a 2008, Edição técnica
          * 2008, Site do Grupo de Investigação em Pegadagogia do Desporto, Software
          * 2008, Revista Técnica de Andebol - número 4, Edição técnica
          * 2008, Grupo de Investigação em Educação em Mundos Virtuais, Processo
          * 2008, Grupo de Discussão em Investigação de Observação e Análise de Jogo , Processo
          * 2007, Virtual-World-Based Handball Coach Education System, Software
          * 2007, Actas do 4º Congresso Técnico Científico de Andebol, Edição técnica
          * 2006, Actas do 3º Congresso Técnico Científico de Andebol, Edição técnica

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona