# Response for https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
          PT: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856 EN: https://www.ulusofona.pt/en/teachers/cristiana-de-campos-marques-7856
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
        fechar menu : https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/cristiana-de-campos-marques-7856
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Cristiana De Campos Marques

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p7856
              cri***@ulusofona.pt
              2E15-E571-C0D8: https://www.cienciavitae.pt/2E15-E571-C0D8
              0000-0002-9594-9352: https://orcid.org/0000-0002-9594-9352
      : https://www.ulusofona.pt/

        Resume

        Cristiana C. Marques completed her degree in Clinical Psychology from the Faculty of Psychology and Educational Sciences at the University of Coimbra in 2011. She is doing her PhD in Clinical Psychology at the same institution. She is a Researcher at the Center for Research in Neuropsychology and Cognitive-Behavioral Intervention (CINEICC) of the University of Coimbra and she holds recognition as a Clinical Psychologist accredited by the Portuguese Psychologists Association. Her main research topics include 1) the role of psychological processes underlying the development and maintenance of psychopathology, in different clinical presentations, including eating psychopathology; 2) the development and efficacy testing of psychological programs promoting mental health and reducing psychopathology, based on cognitive-contextual therapies such as Compassion-Based Interventions; 3) neuroimaging evidence related to cognitive processes. She has co-authored several articles in peer-reviewed international journals, book chapters, and conference abstracts. She has supervised several master's theses. Over the years, she has participated in numerous courses and workshops to enhance her clinical skills and knowledge in statistical analysis.

        Graus

            * Mestrado integrado
              Psicologia
            * Doutoramento
              Psicologia Clínica
            * Outros
              Compassion Focused Therapy Techniques in Action: Imagery, Psychotherapy and Life Transformation (Dr. Dennis Tirch and Laura Silberstein-Tirch), 16 hours
            * Outros
              Workshop Using ACT with Persistent Medical Conditions: An intermediate level workshop, focussing on creative hopelesness, and working with changed sense of self (Prof. David Gillanders), 12 hours (Org: CINEICC)
            * Outros
              MindKindful Course (mindfulness + compassionate training) (Prof. José Pinto-Gouveia), 24 hours (Org: CINEICC)
            * Outros
              Workshop The Science of Meditation (Dr. Diego Hangartner), 12 hours, (Org: CINEICC)
            * Outros
              Workshop Exploring and Resolving Fears, Blocks and Resistances, and Enhancing Compassion Motivation, Through Motivational Interviewing (Dr. Stan Steindl), 6 hours
            * Outros
              Workshop O terapeuta mindful e a comunicação compassiva [The mindful therapist and compassionate communication] (Dr. Ricardo J. Teixeira), 8 hours
            * Outros
              Workshop Structural Equation Modelling with Mplus 8 (Professor João Marôco), 12 hours
            * Outros
              Workshop New developments in mediation and moderation (Prof. Paul Jose), 8 hours
            * Outros
              1st European Training School of the European Network Riseup-PPD in Systematic reviews and meta-analysis using R; Cost Action CA18138
            * Curso médio
              Neurociência Afectiva Translacional
            * Curso médio
              Curso Avançado em Modelos de Equações Estruturais - Parte II (Prof. João Marôco)
            * Curso médio
              Curso Avançado em Modelos de Equações Estruturais: Desenvolvimento e Avaliação com o SPSS AMOS (Prof. João Marôco)
            * Outros
              Revisões sistemáticas e meta-análises
            * Outros
              Workshop "Advanced CFT for Eating Disorder" (Dr. Ken Goss)
            * Outros
              Workshop de Perturbações Alimentares na Adolescência: A Abordagem das Terapias de Terceira Geração
            * Outros
              Introduction to R for Statistical Analysis
            * Outros
              Introduction to dealing with missing data
            * Outros
              Women's Mental Health Research
            * Outros
              Minicurso Introdução à análise de dados de questionários com o R
            * Outros
              Curso Randomized Controlled Trials
            * Outros
              Working with shame and developing inner compassion (Paul Gilbert)
            * Outros
              Curso de Formação Pedagógica Inicial de Formadores

        Publicações

        Artigo em revista

          * 2024-02-08, Psychometric Properties and Measurement Invariance of the Portuguese Version of the Body and Appearance Self-Conscious Emotions Scale (BASES), European Journal of Psychological Assessment
          * 2024-01-22, A neural network underlying cognitive strategies related to eating, weight and body image concerns, Frontiers in Human Neuroscience
          * 2023-12-21, Online Compassion Focused Therapy for overeating: Feasibility and acceptability pilot study, International Journal of Eating Disorders
          * 2023-09-27, Ruminative response scale for eating disorders: bifactor model and measurement invariance in a Portuguese community sample, Eating Disorders
          * 2023-07, The Portuguese version of the Screen for Disordered Eating: Validity and reliability in middle aged and older women, European psychiatry : the journal of the Association of European Psychiatrists
          * 2023-07, Development and first validation of the Portuguese version of the Big Three Perfectionism Scale–Short Form (BTPS-SF), European psychiatry : the journal of the Association of European Psychiatrists
          * 2023-06-22, Determinants of psychotherapists' attitudes to online psychotherapy, Frontiers in Psychiatry
          * 2022-08-25, The Postpartum Obsessive-Compulsive Scale: Psychometric, Operative and Epidemiologic Study in a Portuguese Sample, International Journal of Environmental Research and Public Health
          * 2021-10-17, Southampton Mindfulness Questionnaire: Confirmatory Factor Analysis and Psychometric Properties Across Portuguese Clinical and Non-clinical Samples, Mindfulness
          * 2021-06-17, Fears of compassion scales in psychosis: confirmatory factor analysis and psychometric properties, Current Psychology
          * 2021-05-28, Reliability and Validity of the Schedule for Affective Disorders and Schizophrenia for School-Age Children-Present and Lifetime Version (K-SADS-PL): Portuguese Version, Child Psychiatry & Human Development
          * 2021-01-02, Self-disgust and urge to be thin in eating disorders: how can self-compassion help?, Eating and Weight Disorders - Studies on Anorexia, Bulimia and Obesity
          * 2019-10-17, Negative affect and eating psychopathology: the moderator effect of gender, Eating and Weight Disorders - Studies on Anorexia, Bulimia and Obesity
          * 2019-03-15, Engaging with the affiliative system through mindfulness: The impact of the different types of positive affect in psychosis, Journal of Clinical Psychology
          * 2018-08, Family systems, offspring and eating disorders: Can perfectionism close the gaps?, International Journal of Clinical Neurosciences and Mental Health
          * 2017-11, Psychological risk factors, cognitive-contextual approaches and neural correlates in eating disorders: an integrative review, International Journal of Clinical Neurosciences and Mental Health
          * 2017-04, Assessing suicide risk with the Clinical Interview for Psychotic Disorders (CIPD): Preliminary reliability and validity of the Suicide Risk Scale for Psychosis (SRS-P), European Psychiatry
          * 2017, Are perfectionism cognitions and cognitive emotion regulation strategies mediators between perfectionism and psychological distress?, Personality and Individual Differences
          * 2016-04, Perinatal depression screening, prevention and early intervention: recent advances in Portugal, International Journal of Clinical Neurosciences and Mental Health
          * 2015-08-03, Parental Resilience and Adolescence Depression: Moderating Effect of Children’s Psychosocial Functioning, European Proceedings of Social and Behavioural Sciences
          * 2015-01, Confirmatory Factor Analysis of the QRI Father's Version in a Portuguese Sample of Adolescents, Procedia - Social and Behavioral Sciences
          * 2015-01, Cognitive Emotion Regulation Strategies and Depressive Symptoms: Gender's Moderating Effect, Procedia - Social and Behavioral Sciences

        Capítulo de livro

          * 2018, Psicologia positiva, Psicologia na Medicina
          * 2018, Fundamentos da psicometria, Psicologia na Medicina
          * 2017, Self-Compassion and perinatal depression, Postpartum depression: Prevalence, risk factors and outcomes
          * 2017, Risk factors for postpartum depression: A dimensional and categorical approach, Postpartum depression: Prevalence, risk factors and outcomes
          * 2017, Prevalence and incidence of postpartum major depression (DSM 5) in Portuguese women, Postpartum depression: Prevalence, risk factors and outcomes
          * 2017, Mindfulness and perinatal depression, Postpartum depression: Prevalence, risk factors and outcomes
          * 2016, Risk factors for postpartum depression: dimensional and categorical approach, Postpartum Depression: Prevalence, Risk Factors and Outcomes, Nova Science Publishers

        Resumo em conferência

          * 2022-06, Further Validation of the Short Form of the Self-Compassion Scale in a sample of Portuguese Medicine Students
          * 2021-04, Further validation of the internet addiction test: Psychometric characteristics in a portuguese university sample
          * 2021-04, Eating disorder examination-questionnaire – 7: Construct validity in a sample of portuguese overweight women
          * 2020-07-07, The role of perfectionism, dysfunctional cognitive processes and content in postpartum OC phenomena, 28th European Congress of Psychiatry
          * 2020-07-07, The role of perfectionism self-presentation in the relationship between perfectionism and eating psychopathology, 28th European Congress of Psychiatry
          * 2020-07-07, The role of perfectionism and repetitive negative thinking in prenatal OC phenomena, 28th European Congress of Psychiatry
          * 2020-07-07, Psychometric properties of the HEXACO-60 in a sample of Portuguese adults from the general population, 28th European Congress of Psychiatry
          * 2020-07-07, Portuguese version of the Short-Fear of Dental Pain Questionnaire - Preliminary Psychometric Study, 28th European Congress of Psychiatry
          * 2020-07-07, Further validation of the Portuguese version of the Dental Fear Survey , 28th European Congress of Psychiatry
          * 2020-07-07, Portuguese version of the Sensitivity to Pain Traumatization Scale - Preliminary Psychometric Study, 28th European Congress of Psychiatry
          * 2019-04-30, Relation between the Big-Three and the HEXACO: broader conceptualizations of perfectionism and its psychological outcomes, 27th Congress of the European Psychiatric Association
          * 2019-04-30, Confirmatory factor analysis of the Portuguese version of the dirty dozen, 27th Congress of the European Psychiatric Association
          * 2019-04-09, Similarities and differences in the HEXACO dimensions and psychological distress across the Dark Triad, 27th Congress of the European Psychiatric Association
          * 2019-04-09, Portuguese validation of the Communication Assessment Tool, 27th Congress of the European Psychiatric Association
          * 2019-04-09, Further Validation of the Psychological Entitlement Scale, 27th Congress of the European Psychiatric Association
          * 2019-04-09, Confirmatory factor analysis and concurrent validity of the Portuguese version of the Patient Perception of Patient-Centeredness (PPCD-16), 27th Congress of the European Psychiatric Association
          * 2017-04-04, Portuguese Validation of the Perfectionism Self-Presentation Scale, 25th Congress of the European Psychiatric Association
          * 2017-04, The Portuguese validation of the impulsive sensation seeking scale
          * 2017-04, Further validation of the driver behaviour questionnaire-confirmatory factor analysis in a Portuguese sample
          * 2017-04, Confirmatory factor analysis of the postpartum depression screening scale-21 in a sample of Portuguese women
          * 2017-04, Confirmatory factor analysis of the perinatal depression screening scale-24
          * 2017-04, Confirmatory factor analysis of the Hewitt & Flett Multidimensional Perfectionism Scale-13 (H&F-MPS13)
          * 2017-04, Confirmatory factor analysis of NEO-FFI-20 in a Portuguese sample
          * 2016-04, Predictive ability of the Perinatal Depression Screening and Prevention Tool – Preliminary results of the dimensional approach, Proceedings of the 3rd IPLeiria¿s International Health Congress
          * 2016, Predictive ability of the Perinatal Depression Screening and Prevention Tool-Preliminary results of the categorical approach., Proceedings of the 3rd IPLeiria's International Health Congress

        Poster em conferência

          * 2019-08-21, The role of emotional competence skills in achieving positive relationships, 19th WPA World Congress of Psychiatry
          * 2019-04-02, Validity and reliability of the perinatal anxiety screening scale in a portuguese sample of pregnant women, 27th European Congress of Psychiatry
          * 2019-02-22, Further validation of the Illness and Help-Seeking Behaviour Scale, VIII IN4MED - International Scientific and Medical Congress
          * 2019, Validity and reliability od the Perinatal Anxiety Screening Scale in a portuguese sample of pregrant women, 27th European Congress of Psychiatry
          * 2019, Prevalence and incidence of perinatal depression in Portugal: ten years later, 27th European Congress of Psychiatry
          * 2019, Further validation of the Postpartum Depression Screening Scale-19, 27th European Congress of Psychiatry
          * 2019, The effects of prenatal maternal stress loneliness/helplessness, depressive symptoms, sleep difficulties and social support on child temperament in 3 months postpartum., 27th European Congress of Psychiatry
          * 2019, Prevalence and comorbidity of major depression and anxiety disorders in the postpartum, 27th European Congress of Psychiatry
          * 2018-09-13, Relação transgeracional do Perfeccionismo, 4o Congresso da Ordem dos Psicólogos Portugueses
          * 2017-03-23, QCE-15 - Contributo para a avaliação da inteligência emocional, 1as Jornadas da Unidade de Psicologia Clínica do CHUC
          * 2017-03-23, Perinatal Obsessive-Compulsive Scale (POCS): Estudo psicométrico e descritivo, 1as Jornadas da Unidade de Psicologia Clínica do CHUC
          * 2017-03-23, Lendo a mente nos olhos: versão portuguesa preliminar, 1as Jornadas da Unidade de Psicologia Clínica do CHUC
          * 2017, O efeito protetor da auto-compaixão no período perinatal, 1 as Jornadas da Unidade de Psicologia Clínica do CHUC
          * 2017, O Perfil de Estados de Humor no período perinatal., 1 as Jornadas da Unidade de Psicologia Clínica do CHUC
          * 2016, Mindfulness, self-compassion and psychological distress in pregnant women, 24th European Congress of Psychiatry
          * 2016, Facets of mindfulness questionnaire-10 -a shorter Portuguese version to evaluate mindfulness dimensions in pregnant women, 24th European Congress of Psychiatry
          * 2016, Does mindfulness and self-compassion in pregnancy influence depressive and anxiety symptoms levels in the postpartum? A preliminary prospective study, 18th European Conference on Personality
          * 2016, Validation of the depression, anxiety and stress scale-DASS-21 in a community sample of Portuguese pregnant women, 24th European Congress of Psychiatry
          * 2016, The role of mindfulness in lifetime history of depression: A study in Portuguese pregnant women, 24th European Congress of Psychiatry
          * 2016, Does Self-Compassion in pregnancy influences depressive and anxiety symptoms in the 3rd month postpartum? A preliminary prospective study., BABCP ACT SIG / ACBS UK & Ireland Chapter Contextual Behavioural Science Conference
          * 2016, Does Mindfulness in pregnancy influences depressive and anxiety symptoms in the 3rd month postpartum? A preliminary prospective study, BABCP ACT SIG / ACBS UK & Ireland Chapter Contextual Behavioural Science Conference
          * 2016, Confirmatory factor analysis of a 10 item solution of the Five Facet Mindfulness Questionnaire-15: A study with Portuguese pregnant women, 18th European Conference on Personality

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona