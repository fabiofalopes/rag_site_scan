# Response for https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
          PT: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655 EN: https://www.ulusofona.pt/en/teachers/andreia-sofia-pinto-de-sousa-4655
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
        fechar menu : https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/andreia-sofia-pinto-de-sousa-4655
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Andreia Pinto De Sousa

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4655
              and***@ulusofona.pt
              B418-2701-9059: https://www.cienciavitae.pt/B418-2701-9059
              0000-0001-8070-8970: https://orcid.org/0000-0001-8070-8970
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/1cde5099-44bf-4436-a5bf-32a5015b90e0
      : https://www.ulusofona.pt/

        Resume

        Andreia Pinto de Sousa holds a Ph.D. in Information and Communication (2017, Universidade de Aveiro and Universidade do Porto), M.Sc. in Multimedia (2011, Universidade do Porto), B.A. in Communication Design - Graphic Arts (2003, Universidade do Porto Faculdade de Belas Artes). Currently: Invited Assistant Professor, Universidade do Porto Faculdade de Belas Artes; Assistant Professor, Universidade Lusófona do Porto. Published journal articles, contributed to book sections, and organised and participated in academic events. Supervised 1 PhD thesis and 3 MSc dissertations, co-supervised 6, and guided several students in bachelor projects and internships. Is involved in various research projects as a specialist in interaction design. Expertise: human-computer interaction, digital health, well-being, communication, new media, technology, and design principles.

        Graus

            * Licenciatura
              Design de Comunicação - Artes Gráficas
            * Mestrado
              Multimédia
            * Especialização pós-licenciatura
              Arte Multimédia
            * Curso médio
              Formação Pedagógica de Formadores
            * Outros
              Interface Design for Mobile Devices
            * Curso médio
              English Language Program
            * Outros
              Bridging the Gap:Software Engineering meets Interaction Design
            * Outros
              Implementação e certificação de sistemas de gestão de IDI
            * Outros
              Business Process Modeling
            * Outros
              Construção e Desenvolvimento de Superficies Interactivas Multitoque
            * Outros
              Proposal Writing
            * Doutoramento
              Information and Communication in Digital Platforms
            * Outros
              Web Design - Wofenstein 3D vs Director
            * Outros
              Flash - Física Digital
            * Outros
              PD, Max/MSP
            * Outros
              Tecnologias Multimédia de Tempo Real (Max-Jitter)
            * Curso médio
              Formação Pedagógica de Monitores
            * Outros
              Seminário com Lev Manovich
            * Outros
              Novos Media_Novas Práticas
            * Outros
              Design for Health
            * Outros
              Curso de Medologias de Ensino Inovadoras
            * Outros
              Health Technology Transfer Models and Case Studies
            * Outros
              Desenhar um curso a distância

        Publicações

        Magazine article

          * 2018, Dos Media Eletrónicos aos Digitais, a Emergência das Artes Digitais e a Importância do Design de Interação, DL

        Journal article

          * 2020-12-30, Updating Bem-me-ker: An User-Centred Approach to Redesigning an Onboarding Application for Cancer Patients, Journal of Digital Media and Interaction
          * 2016, Habits and Behaviors of e-health Users: A Study on the Influence of the Interface in the Perception of Trust and Credibility, Procedia Computer Science

        Thesis / Dissertation

          * 2017-09-05, PhD, A interface na e-Health: proposta de princípios de design para a credibilidade e a confiança.
          * 2011, Master, Usabilidade para Idosos em Ambientes Inteligentes

        Book chapter

          * 2024, The Impact of Visual Design on Public Participation. Case Study in Cyberjournalism, Perspectives on Design and Digital Communication IV. Springer Series in Design and Innovation , 33, IV, Springer
          * 2023, WORK2BEWELL - Estudo para a recolha de dados de saúde e monitorização dos trabalhadores de chão de fábrica no contexto da indústria 4.0, Coleção DigiMedia , DigiMedia
          * 2023, Designing a Multimodal Application for People with Brain Injuries to Manage Their Daily Routine: A User-Centered Approach
          * 2022, WORK2BEWELL - Estudo para a coleta de dados de saúde dos trabalhadores da indústria 4.0, ehSemi 2022 : 2º seminário de estudantes em Tecnologias Digitais e Saúde/Bem-Estar: livro de resumos, UA Editora - Universidade de Aveiro
          * 2022, O lúdico como meio de prevenção da obesidade infantil, ehSemi 2022 : 2º seminário de estudantes em Tecnologias Digitais e Saúde/Bem-Estar: livro de resumos, Universidade de Aveiro
          * 2022, Cyberjournalism: The Influence of Design on Public Participation, Advances in Design and Digital Communication III. DIGICOM 2022., 27, Springer
          * 2021, Interface and emotions: Exploring the interface dimensions and emotional processes to Interface Design, Proceedings of the short papers of the 5th International Conference on Design and Digital Communication, Digicom 2021 , IPCA – Instituto Politécnico do Cávado e do Ave
          * 2020, Fisioterapia: dismetria dos membros inferiores - acompanhamento por parte do fisioterapeuta , ehSemi 2020 - 1º seminário de estudantes em Tecnologias Digitais e Saúde/Bem-Estar: livro de resumos, UA Editora _ Universidade de Aveiro
          * 2020, Acompanhamento médico de pacientes com depressão : comunicação segura através de mensagens privadas, ehSemi 2020 - 1º seminário de estudantes em Tecnologias Digitais e Saúde/Bem-Estar: livro de resumos, UA Editora - Universidade de Aveiro
          * 2016, Trust and Credibility Perception in e-Health: Interface Contributions, Encyclopedia of E-Health and Telemedicine, First

        Conference paper

          * YouNDigital: A Multidisciplinary Co-creation Strategy to Define Audiences, Users, and Contexts of Use of a Digital Newsroom
          * VR for Rehabilitation: The Therapist Interaction and Experience, HCI International 2022
          * User Interface, credibility and trust in e-Health: a Study Proposal aiming to investigate Design Principles for Trust, Internacional Conference on Health and Social Care Information Systems and Technologies
          * Girls4Cyber: A Game to Promote Awareness and Innovation in Cybersecurity, HCI INTERNATIONAL 2022. 24th International Conference on Human-Computer Interaction. Virtual Event, June 26-July 1
          * Designing a multimodal application for people with brain injuries to manage their daily routine: A user-centred approach, HCI International 2023
          * Com@Rehab: An Interactive and Personalised Rehabilitation Activity Based on Virtual Reality, 17th International Joint Conference on Biomedical Engineering Systems and Technologies
          * Changing Behaviours Through Design: An Educational Comic Brochure to Help Prevent Childhood Obesity, The Asian Conference on Media, Communication & Film 2022
          * A Interface na percepção de Confiança e Credibilidade na e-Health, DESIGNA 2013 INTERFACE Conferência Internacional de Investigação em Design
          * 2022, PROMOTING SOCIAL ACTIVITIES IN AN ONLINE CONFERENCE DURING COVID TIMES: THE CASE OF THE EHSEMI CONFERENCE, 5th International Conference on ICT, Society and Human Beings, ICT 2022, 19th International Conference on Web Based Communities and Social Media, WBC 2022 and 14th International Conference on e-Health, EH 2022 - Held at the 16th Multi Conference on Comput
          * 2020-11-06, Hogwarts Mystery: a convergência da obra literária no formato de videojogo para a criação de um ciberespaço colaborativo, 4ª Conferência Internacional de Design e Comunicação Digital
          * 2020-11-05, Produção cultural mediada por smartphones: uma abordagem pós-fenomenológica dos media, 4ª Conferência Internacional de Design e Comunicação Digital
          * 2017, A interface como mediadora e influenciadora nos processos de confiança e credibilidade online: dimensões e elementos influentes em websites de e-Health, IX Congresso Comunicação e Transformações Sociais

        Conference abstract

          * 2020-04, Dismetria dos membros inferiores: acompanhamento por parte do fisioterapeuta, ehSemi 2020 - 1º seminário de estudantes em Tecnologias Digitais e Saúde/Bem-Estar: Digital technologies and health & wellness workshop
          * 2014, Trust and Credibility in e-Health Interface, 2nd IPLeiria Internacional Health Congress | Challenges & Innovation in Health

        Artistic exhibition

          * 2004, ProjMAM2004, Faculdade de Engenharia da Universidade do Porto (Porto )

        Provisional application for patent

          * COMPUTER IMPLEMENTED SYSTEM AND METHOD

        Other output

          * 2023, Aplicação e-mergir no âmbito do projeto "SexHealth & ProstateCancer - Biopsychological Determinants of Sexual Health in Men with Prostate Cancer Contract done from 2022 to 2023 / Technical development", Concetualização e design da aplicação e-mergir no âmbito do projeto "SexHealth e ProstateCancer"
          * 2022-12, História dos Ativismos Feministas em Portugal, Design editorial do booklet: História dos Ativismos Feministas em Portugal
          * 2022-07, Website FEMglocal, Concetualização e Design do website FEMglocal
          * 2022-05, Identidade do projeto FEMglocal, Concetualização e desenvolvimento da identidade do projeto FEMglocal
          * 2022, Identidade Podcast Feminismos em Ação , Concetualização e desenvolvimento de identidade para o podcast Feminismos em Ação
          * 2019-09-01, Emotion Recognition Assessment , App for the assessment of the capacity of emotion recognition as an alternative to the "pen and paper" auto-evaluation of the TAS assessment.
          * 2012, Rede Mãe, Produto

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona