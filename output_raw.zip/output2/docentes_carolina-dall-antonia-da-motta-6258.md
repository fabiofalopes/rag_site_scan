# Response for https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
          PT: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258 EN: https://www.ulusofona.pt/en/teachers/carolina-dall-antonia-da-motta-6258
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
        fechar menu : https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carolina-dall-antonia-da-motta-6258
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carolina Dall Antonia Da Motta

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6258
              car***@ulusofona.pt
              BC1B-975D-C74F: https://www.cienciavitae.pt/BC1B-975D-C74F
              0000-0001-8421-2956: https://orcid.org/0000-0001-8421-2956
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/c8a5f641-4f38-4b91-98e2-470caea1a7db
      : https://www.ulusofona.pt/

        Resume

        Carolina Dall'Antonia da Motta is a Lecturer and researcher at Universidade Lusófona Lisboa. Integrated member of the Digital Human-Environment Interaction Lab and collaborator at the University of Coimbra, at the Center for Research in Neuropsychology and Cognitive and Behavioral Intervention (CINEICC) . Additionally, she holds multiple positions at Universidade Lusófona - Centro Universitário de Lisboa, as Assistant Professor, Director of the Master's in Forensic Psychology, Coordinator of Curricular Internships in Forensic Psychology, among other roles. She is also the President of Casa Qui, an IPSS. Carolina has an extensive scientific output, with 47 articles published in specialized journals, 11 book chapters, and 4 books. Carolina da Motta has collaborated with 157 colleagues in co-authoring scientific papers. She also organized one event and participated in 35 other events. As an acadeic supervisor, she co-supervises one doctoral thesis, supervised 8 master's dissertations, and co-supervised 12. She is involved in several research projects, funded and non-funded, acting as a Research Fellow, Co-Principal Investigator, Principal Investigator, and in other roles.

        Graus

            * Mestrado
              Mestrado Integrado em Psicologia
            * Outros
              Formação Pedagógica Inicial de Formadores
            * Outros
              MIT Leading Digital Transformation (Stage 1)
            * Outros
              Machine Learning: Leveraging Data (Stage 2)
            * Doutoramento
              Psicologia
            * Doutoramento
              Psicologia

        Publicações

        Artigo em revista

          * 2023-05, Neuropathic pain, cognitive fusion, and alexithymia in patients with multiple sclerosis: Cross-sectional evidence for an explanatory model of anxiety symptoms, Journal of Clinical Psychology
          * 2022-01-07, Experiential avoidance, uncompassionate self-responding, and peritraumatic depersonalization/derealization: A novel mediation model for war-related PTSD symptomatology, Journal of Clinical Psychology
          * 2021-10, The neurocognitive and functional profile of schizophrenia in a genetically homogenous European sample, Psychiatry Research
          * 2021, Mindful self-care scale (MSCS): Psychometric study in a Portuguese sample, SelfCare Journal
          * 2020-07-20, Rasch Measurement of the Brief Situational Test of Emotional Management in a Large Portuguese Sample, Journal of Psychoeducational Assessment
          * 2020-07-07, Rasch model analysis of the Situational Test of Emotional Understanding – brief in a large Portuguese sample, Current Psychology
          * 2020-05-06, Construct validity, sensitivity and specificity of the USCD Performance-based Skill Assessment 2 in a mixed Portuguese sample, Human Psychopharmacology: Clinical and Experimental
          * 2020-01-23, Portuguese version of the Posttraumatic Stress Disorder Checklist for DSM-5 (PCL-5): Comparison of latent models and other psychometric analyses, Journal of Clinical Psychology
          * 2019-12-18, Resumos da 2ª Mostra de Doutoramento em Psicologia, Psychologica
          * 2019-12-18, Escala das Formas do Autocriticismo e Autotranquilização para crianças, Psychologica
          * 2019-08-28, Assessment of neurocognitive function and social cognition with computerized batteries: Psychometric properties of the Portuguese PennCNB in healthy controls, Current Psychology
          * 2019-06-11, Life satisfaction: Study of the predictors in a mixed Portuguese sample, Psychology, Community & Health
          * 2019-03-02, The Role of Shame, Self-criticism and Early Emotional Memories in Adolescents’ Paranoid Ideation, Journal of Child and Family Studies
          * 2019, Forms of Self-Criticizing and Self-Reassuring Scale: Adaptation and Validation in a Sample of Portuguese Children
          * 2019, Forms Of Self-Criticizing And Self-Reassuring Scale: Adaptation And Validation In A Sample Of Portuguese Children, Psychologica
          * 2018-09-09, Psychosocial roots of paranoid ideation: The role of childhood experiences, social comparison, submission, and shame, Clinical Psychology & Psychotherapy
          * 2018-08-11, The Abbreviated Dysregulation Inventory: Dimensionality and Psychometric Properties in Portuguese Adolescents, Journal of Child and Family Studies
          * 2018-03, Model comparison and structural invariance of the Peritraumatic Dissociative Experiences Questionnaire in Portuguese colonial war veterans., Traumatology
          * 2018-01-25, Validation of the Community Integration Scale for Adults with Psychiatric Disorders (CIS-APP-34), Community Mental Health Journal
          * 2018-01, Validation studies of the Paranoia Checklist (Portuguese version) in mixed sample of patients and healthy controls, European Review of Applied Psychology
          * 2017, Preliminary validation of the Portuguese version of the university of Pennsylvania computerized neurocognitive battery (PennCNB) in a sample of healthy controls., European Psychiatry
          * 2017, Biting myself so I don’t bite the dust : prevalence and predictors of deliberate self-harm and suicide ideation in Azorean youths, Revista Brasileira de Psiquiatria
          * 2016, Paranoia Checklist (Portuguese Version): Preliminary studies in a mixed sample of patients and healthy controls [Abstract], BMC Health Services Research
          * 2016, Attitudes towards mental health problems scale : Confirmatory factor analysis and validation in the Portuguese population, American Journal of Psychiatric Rehabilitation
          * 2015-09, The prevalence of personality disorders in Portuguese male prison inmates: Implications for penitentiary treatment, Análise Psicológica
          * 2015-07, Is the offence the best defense? Influences of childhood experiences and paranoia in the aggression in Azorean youths || Atacar será a melhor defesa? A influência das experiências precoces e da paranoia na agressividade dos jovens açorianos, Revista de Estudios e Investigación en Psicología y Educación
          * 2015-01-29, Clinical change in anger, shame, and paranoia after a structured cognitive-behavioral group program: Early findings from a randomized trial with male prison inmates, Journal of Experimental Criminology
          * 2015, Paranoia in the General Population: a revised version of the General Paranoia Scale for Adults., Clinical Psychologist
          * 2015, Paranoia in the General Population : a revised version of the General Paranoia Scale for Adults
          * 2015, Mapping non suicidal self-injury in adolescence: Development and confirmatory factor analysis of the Impulse, Self-harm and Suicide Ideation Questionnaire for Adolescents (ISSIQ-A), Psychiatry research
          * 2015, Is the offence the best defense? Influences of childhood experiences and paranoia in the aggression in Azorean youths
          * 2015, Influence of Family and Childhood Memories in the Development and Manifestation of Paranoid Ideation, Clinical Psychology and Psychotherapy
          * 2015, Development and Validation of the Response to Stressful Situations Scale in the General Population, International Journal of Psychological and Behavioral Sciences
          * 2015, Clinical Change in Cognitive Distortions and Core Schemas After a Cognitive–Behavioral Group Intervention: Preliminary Findings from a Randomized Trial with Male Prison Inmates, Cognitive Therapy and Research
          * 2015, Atacar será a melhor defesa? A influência das experiências precoces e da paranóia na agressividade dos jovens Açorianos, Revista de Estudios e Investigación en Psicología y Educación
          * 2015, Ancoragem : um programa de psicoeducação para familiares de doentes com esquizofrenia
          * 2015, ANCORAGEM – UM PROGRAMA DE PSICOEDUCAÇÃO PARA FAMILIARES DE DOENTES COM ESQUIZOFRENIA, Revista de Estudios e Investigación en Psicología y Educación
          * 2015, Development of the Combat Distress Scale of the Combat Experiences Questionnaire (CEQ)., Journal of Affective Disorders
          * 2014-12, Development of Exposure to Combat Severity Scale of the Combat Experiences Questionnaire (CEQ), Journal of Anxiety Disorders
          * 2014-01-01, Emotional, cognitive and behavioral reactions to paranoid symptoms in clinical and nonclinical populations, Clinical Schizophrenia & Related Psychoses
          * 2014, Paranoia in the General Population: a revised version of the General Paranoia Scale for adolescents, European Scientific Journal
          * 2014, Paranoia as a continuum in the population, Asian Journal of Humanities and Social Sciences
          * 2014, Development of Exposure to Combat Severity Scale of the Combat Experiences Questionnaire (CEQ), Journal of Anxiety Disorders
          * 2014, Development and psychometric properties of the community integration scale of adults with psychiatric disorders, European Scientific Journal
          * 2013, From multimodal programs to a new cognitive-interpersonal approach in the rehabilitation of offenders, Aggression and Violent Behavior
          * 2009, Inventário de Evitamento de Young-Rygh: estudos de validação e estrutura factorial numa amostra da população geral. , Psychologica
          * 2009, Inventário de Evitamento de Young-Rygh: estudos de validação e estrutura factorial numa amostra da população clínica, Psychologica

        Tese / Dissertação

          * 2020, Doutoramento, Uncovering the endophenotypic factors on the impact of functional outcomes in schizophrenia: studies on different genetic risk samples from the Portuguese Population
          * 2007, Mestrado, Estudos psicométricos e da estrutura factorial do YRAI (Young-Rygh Avoidance Questionnaire).

        Livro

          * 2019, Ancoragem - Manual técnico de esquizofrenia para cuidadores, Barreto Carvalho, C.; Bulhões, M.; Cabral, J; da Motta, C. (BC1B-975D-C74F); Sousa, M.; Amaral, V, Almedina
          * 2017, Vamos sentir com o Necas! Programa de promoção de competências emocionais e sociais para o 1º ciclo do ensino básico., Barreto Carvalho, C.; Caldeira, S.N.; Peixoto, E.; Moniz, A.; da Motta, C. (BC1B-975D-C74F); Rebelo, E.; Cordeiro, G.; et al, Almedina
          * 2009, Programa “Um Dia na Prisão”, 1, Direcção Geral dos Serviços Prisionais, PGISP/Ministério da Justiça
          * 2009, O Meu Guia para a Liberdade, Direcção Geral dos Serviços Prisionais, PGISP/Ministério da Justiça

        Capítulo de livro

          * 2019, Inteligência Emocional: Investigação e Promoção de Competências (Cap. 9), Psicologia da Educação - Temas de Aprofundamento Científico para a Educação XXI, 1, 1, Climepsi
          * 2017, Questionário de Experiências de Combate, Psicologia Clínica e da Saúde - Instrumentos de Avaliação. , 1, Pactor
          * 2017, Inventário de Traços Psicopáticos em Jovens [Youth Psychopathic Traits Inventory], Psicologia Forense: Instrumentos de Avaliação, PACTOR
          * 2017, Inventário de Avaliação de Esquemas por Cenários Activadores ¿ Comportamento anti-social, Psicologia Forense: Instrumentos de Avaliação, Practor
          * 2017, IAECA-CA: Inventário de Avaliação de Esquemas por Cenários Activadores - Comportamento anti-social., Psicologia Forense - Instrumentos de Avaliação. , Pactor
          * 2015, A saúde mental das crianças e dos jovens: Do meio natural de vida às instituições de acolhimento e aos centros educativos. , Intervenção em sede de promoção e proteção de crianças e jovens, Coleção de Formação Contínua do Centro de Estudos Judiciários
          * 2015, A saúde mental das crianças e dos jovens: Do meio natural de vida às instituições de acolhimento e aos centros educativos [The mental health of children and youth: From the natural living environment to Host Institutions and Juvenile Justice Facilities]
          * 2014, Terapia Focada na Compaixão, Estratégias Psicoterápicas e a Terceira Onda em Terapia Cognitiva, 1, 1, Synopsis
          * 2014, Terapia Focada na Compaixão [Compassion Focused Therapy], Sinopsys
          * 2013, A eficácia das intervenções psicoeducacionais na reabilitação de menores agressores: dos programas multimodais ao Gerar Percursos Sociais., Violência, agressão e vitimação: práticas para a intervenção, Almedina
          * 2011, Inventário de Evitamento de YoungRygh (YoungRygh Avoidance Inventory), Instrumentos e Contextos de Avaliação Psicológica, Almedina

        Tradução

          * 2023, State Shame and Guilt Scale – 8 (SGGS-8)
          * 2022, Open and Engaged State Questionnaire (OESQ)
          * 2022, Intimate Partner Violence scale (IPV)
          * 2022, Escala de Violência Íntima e Afeto Traumático (VITA)
          * 2022, Clinician Administered PTSD Scale - 5 (CAPS-5), MAPS Public Benefit Corporation - Europe/USA
          * 2016, UCSD Performance-Based Skills Assessment (Patterson, T, 2008): Da Motta, C., Barreto Carvalho, C., Castilho, P. & Pato, M. (2016) Avaliação De Aptidões Baseada No Desempenho (UPSA-2-PT).
          * 2016, The University of Pennsylvania Computerized Neuropsychological Test Battery (versão portuguesa: da Motta, C. & Barreto-Carvalho, C., 2016)
          * 2016, Situational Test of Emotional Understanding - Brief (STEU-B) - MacCann & Roberts, 2008, versão portuguesa de da Motta, C.; Barreto Carvalho, C. & Castilho, P., 2016
          * 2016, Situational Test of Emotional Management - Brief (STEM-B) - MacCann & Roberts, 2008; versão portuguesa de da Motta, C.; Barreto Carvalho, C. & Castilho, P., 2016
          * 2015, Combat Experiences Questionnaires, APA PsycTests
          * 2012, MINI KID - Entrevista Neuropsiquiátrica para Crianças e Adolescentes
          * 2012, ECoV - Escala de Coping com a Vergonha (COSS-5 - Elison, Pulos, &, Lennon, 2006; Nathanson, 1992; versão portuguesa de da Motta, Ribeiro da Silva, Brazão, & Rijo, 2012).

        Artigo em jornal

          * 2017-03-23, Depressão leva crianças a agredirem-se a si próprias , Açoriano Oriental

        Manual

          * 2016, Programa de promoção de Inteligência Emocional para 1. º ciclo do ensino básico, Edições Almedina
          * 2000, Avaliação de Esquemas Precoces Mal-Adaptativos e Psicopatologia: exploração de diferentes metodologias de avaliação

        Artigo em conferência

          * The psychometric properties of the brief Other as Shamer Scale for Children (OAS-C) : preliminary validation studies in a sample of Portuguese children
          * Test yourself to be the best : implicações do auto-criticismo na ansiedade face aos testes
          * Forms of Self-Criticizing and Self-Reassuring Scale: Adaptation and early findings in a sample of Portuguese children
          * Como são vistos os problemas de saúde mental : A perceção de indivíduos com e sem perturbações psiquiátricas sobre o estigma e as atitudes negativas perante os problemas de saúde mental
          * Atacar será a melhor defesa? A influência das experiencias precoces e da paranoia na agressividade dos jovens açorianos
          * A prevenção do comportamento antisocial em turmas PIEF da Região Centro, 9º Congresso de Psicologia da Saúde
          * A new beginning : sintomatologia traumática na sobrevivência à doença oncológica : uma revisão de literatura
          * 2017-04, Relação entre propensão para o tédio e alexitimia em adolescentes, II Encontro Internacional Jovens Investigadores
          * 2014-09, Necessidades de intervenção em saúde mental em jovens delinquentes , IX Congresso Iberoamericano de Psicologia/ 2º Congresso da Ordem dos Psicólogos Portugueses
          * 2014, Terapia focada na compaixão com menores agressores: Um estudo piloto [Compassion Focused Therapy with young offenders: A pilot study], IX Congresso Iberoamericano de Psicologia/ 2º Congresso da Ordem dos Psicólogos Portugueses

        Resumo em conferência

          * 2021, Performance in Learning Tasks and Functional Skills: Insights for Assessment and Rehabilitation of Patients Diagnosed with Schizophrenia, XVI Congresso Internacional Galego-Português de Psicopedagogia
          * 2018-11, Vida +: The influence of parental practices in substance abuse, an Azorean qualitative study, Congreso Internacional SIPS: Pedagogía social, investigación y familias. XXXI Seminario Interuniversitario de Pedagogía Social
          * 2016, The psychometric properties of the brief Other as Shamer Scale for Children (OAS-C): preliminary validation studies in a sample of Portuguese children , BMC Health Services Research
          * 2016, Forms of Self-Criticizing and Self-Reassuring Scale: Adaptation and early findings in a sample of Portuguese children , BMC Health Services Research
          * 2015, Hallucinatory Activity In Schizophrenia: The Relationship With Childhood Memories, Submissive Behavior, Social Comparison, And Depression. , Proceedings from the International Conference on Applied Psychology
          * 2015, Atacar Será a Melhor Defesa? A Influência das Experiências Precoces e da Paranóia na Agressividade dos Jovens Açorianos, XIII CONGRESO INTERNACIONAL GALLEGO-PORTUGUÉS DE PSICOPEDAGOGÍA
          * 2015, ANCORAGEM – Um Programa de Psicoeducação para Familiares de Doentes com Esquizofrenia, XIII CONGRESO INTERNACIONAL GALLEGO-PORTUGUÉS DE PSICOPEDAGOGÍA
          * 2012, The Emotions Behind Early Maladaptative Schemas, 3rd European Forensic Child and Adolescent Psychiatry Congress
          * 2012, Reliable change after a structured 25 sessions cognitiverelational rehabilitation program with antisocial boys, 3rd European Society for Psychotherapy Research 2012 meeting
          * 2012, Personality disorders and criminal behavior: a study on the prevalence of personality disorders in Portuguese male prison inmates, 3rd European Society for Psychotherapy Research 2012 meeting
          * 2012, Exploring the Association Between Shame and Psychopathy in Youths, 3rd European Society for Psychotherapy Research 2012 meeting
          * 2012, Clinical change in prison inmates: improvements in anger, shame, paranoia and core beliefs after a 40 sessions group rehabilitation program, 3rd European Society for Psychotherapy Research 2012 meeting
          * 2011, Why do we need another group rehabilitation program? How GPS was born...". Presented at the Symposium "Growing ProSocial (GPS), a group rehabilitation program for antisocial youths: theoretical model, contents, and outcome studies in Portuguese inmate adolescents, 11th Annual International Association of Forensic Mental Health Services
          * 2011, Raiva e companhia: As emoções associadas à activação esquemática em jovens delinquentes, II Jornadas Internacionais do CINEICC
          * 2011, Intervenção estruturada com jovens antisociais: estudos preliminares da eficácia do Gerar Percursos Sociais (GPS) em contexto de centro educativo, II Jornadas Internacionais do CINEICC
          * 2011, How GPS works? Contents, modules, methodology and relationship issues, 11th Annual International Association of Forensic Mental Health Services
          * 2011, Growing ProSocial: Theoretical basis, contents, methodology, and relationship issues" Presented at the Symposium "A new group rehabilitation program for antisocial youths Growing ProSocial (GPS): theory, contents, and outcome studies in a sample of juvenile offenders., 7th International Congress of Cognitive Therapy
          * 2011, Growing ProSocial (GPS), a group rehabilitation program for antisocial youths: theoretical model, contents, and outcome studies in Portuguese inmate adolescents, 11th Annual International Association of Forensic Mental Health Services
          * 2011, First outcome studies: What can GPS change in adolescence of the Portuguese correctional service?" Presented at the Symposium "Growing ProSocial (GPS), a group rehabilitation program for antisocial youths: theoretical model, contents, and outcome studies in Portuguese inmate adolescents, 11th Annual International Association of Forensic Mental Health Services
          * 2011, First outcome studies: GPS efficacy in 80 Portuguese youth offenders" Presented at the Symposium "A new group rehabilitation program for antisocial youths Growing ProSocial (GPS): theory, contents, and outcome studies in a sample of juvenile offenders, 7th International Congress of Cognitive Therapy
          * 2011, Core schemas underlying antisocial behavior: schemas and disruptive emotions in antisocial adolescents" Presented at the Symposium "A new group rehabilitation program for antisocial youths Growing ProSocial (GPS): theory, contents, and outcome studies in a sample of juvenile offenders, 7th International Congress of Cognitive Therapy
          * 2011, Core schemas underlying anti-social behavior: schemas and disruptive emotions in anti-social adolescents. , 7th International Congress of Cognitive Psychotherapy
          * 2011, A new group rehabilitation program for antisocial youths Growing ProSocial (GPS): theory, contents, and outcome studies in a sample of juvenile offenders, 7th International Congress of Cognitive Therapy
          * 2011, A new group rehabilitation program for antisocial behavior Growing ProSocial (GPS): first outcome studies with prison inmates, 7th International Congress of Cognitive Therapy
          * 2008, Schema avoidance dimensions and strategies: Comparisons between normals and patients, 6th International Congress of Cognitive Psychotherapy

        Poster em conferência

          * 2020, A utilização das técnicas de avaliação dinâmica na esquizofrenia, 5.º Congresso Internacional de Educação, Psicologia e Neurociências – Sinapses
          * 2019-11, À descoberta do endofenótipo da esquizofrenia: estudo preliminar da neurocognição, cognição social e a capacidade funcional de doentes, familiares e controlos, II Mostra de Doutoramentos da FPCE-UC
          * 2019-08, Suffering In Paradise: Comparisons Between Patients Diagnosed With Schizophrenias Living In The Portuguese Islands And Mainland. , World Psychiatry Congress
          * 2019-08, Assessment of Emotional Management Ability: A Rasch Model Analysis Of The Brief Situational Test Of Emotional Management (Stem-B). , World Psychiatry Congress
          * 2018-04, O estudo das diferenças individuais utilizando baterias neurocognitivas computadorizadas: estudos preliminares da Bateria Neurocognitiva da Universidade da Pennsylvania, uMED 2018 - III Congresso Médico-Científico dos Açores
          * 2018-04, Experiência de sentimentos de vergonha na adolescência, 3.º Congresso Internacional de Educação, Psicologia e Neurociências – Sinapses
          * 2017-11, A utilização de baterias computadorizadas para estudo das diferenças individuais: validade de construto e critério da Bateria Neurocognitiva da Universidade da Pennsylvania numa amostra de controlo saudável, I Mostra de Doutoramentos da FPCE-UC
          * 2017-04, Preliminary validation of the Portuguese version of the University of Pennsylvania Computerized Neurocognitive Battery (PennCNB) in a sample of healthy controls, 25th European Congress of Psychiatry
          * 2016-05, The psychometric properties of the brief Other as Shamer Scale for Children (OAS-C): preliminary validation studies in a sample of Portuguese children, 3.º Congresso Internacional de Saúde do IPLeiria: Saúde, alterações demográficas e bem-estar
          * 2016-05, Paranoia Checklist (Portuguese Version): Preliminary studies in a mixed sample of patients and healthy controls, 3.º Congresso Internacional de Saúde do IPLeiria: Saúde, alterações demográficas e bem-estar
          * 2016-05, Forms of Self-Criticizing and Self-Reassuring Scale: Adaptation and early findings in a sample of Portuguese children, 3.º Congresso Internacional de Saúde do IPLeiria: Saúde, alterações demográficas e bem-estar
          * 2016, Descobrindo o endofenótipo da esquizofrenia : estudos das variáveis neuropsicológicas e da cognição social em amostras açorianas de diferentes graus de risco genético
          * 2014, Voices and Social Rank: Preliminary data on the Portuguese Validation of the Voice Rank Scale. , 3rd International Conference on Compassion Focused Therapy
          * 2014, The prevalence of mental disorders among male young offenders , 4th EFCAP Congress, Manchester, United Kingdom.
          * 2014, The effectiveness of a cognitive-behavioral group program in young adult male prison inmates: Clinical change in anger, shame, paranoia and core schemas. , 4th EFCAP Congress
          * 2014, Early Shame experiences, coping with shame and psychopathic traits in youth , 4.º congress of the European Association for Forensic Child and Adolescent Psychiatry, Psychology and other involved Professions - Youth, Risk and Mental Health: Multiple Roads to Recovery. Manchester. United Kingdom
          * 2013-09, Early shame experiences, shame and antisocial behavior, 43rd EACBT Annual Congress
          * 2012, Is there a link between psychopathy, social comparison and submissive behavior? , 3rd Joint Meeting of the European and the United Kingdom Chapters of the Society for Psychotherapy Research. Porto, Portugal.
          * 2011-10, Gerar Percursos Sociais, um programa de prevenção e reabilitação para indivíduos com comportamento anti-social: Estudo de resultados em contexto de Centro Educativo, I Seminário de Intervenção Psicológica com Crianças e Adolescentes
          * 2011-06, A new group rehabilitation program for anti-social behavior - Growing Pro-Social (GPS): first outcome studies with prison inmates, 7th International Congress of Cognitive Therapy
          * 2008-06, Schema Avoidance Dimensions and Strategies: comparisons between normals and patients, 6th International Congress of Cognitive Psychotherapy

        Outra produção

          * 2019, Item Response Theory Analysis of the Posttraumatic Stress Disorder Symptoms assessed by Posttraumatic Stress Disorder Checklist for DSM-5 (PCL-5)
          * 2016, Quando a dor alivia o sofrimento : autodano e adolescência, A secção Biologia é coordenada pelo Professor Universitário Armindo Rodrigues.. […]. Um aspeto fundamental na avaliação do AD refere-se ao método utilizado (instrumentos de autorrelato, entrevistas, questões avulsas, anonimato, etc.), bem como o cuidado tido na adequação das propriedades psicométricas dos instrumentos de medida desenvolvidos noutros países a nossa população. Assim, e com o intuito

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona