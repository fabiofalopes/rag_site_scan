# Response for https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
          PT: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890 EN: https://www.ulusofona.pt/en/teachers/eliana-cristina-veiga-carraca-4890
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
        fechar menu : https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/eliana-cristina-veiga-carraca-4890
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Eliana V. Carraça

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4890
              eli***@ulusofona.pt
              CB16-DB29-5144: https://www.cienciavitae.pt/CB16-DB29-5144
              0000-0002-5789-811X: https://orcid.org/0000-0002-5789-811X
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/0597acd9-808d-4049-a228-b489108bda3a
      : https://www.ulusofona.pt/

        Resume

        Eliana V. Carraça is an Assistant Professor at Faculdade de Educação Física e Desporto, Universidade Lusófona, Lisboa, Portugal, and a senior researcher at CIDEFES (Centro de Investigação em Desporto, Educação Física, Exercício e Saúde) in Universidade Lusófona. She is a clinical exercise physiologist, with a master in exercise and health, and received her Ph.D. in Health and Fitness in 2012. She has also received a Best Master Student award in 2009. Her research revolves around the field of motivational, self-regulatory and behavioural predictors of physical activity, eating behaviour and weight management. She is especially interested in the interplay and cross-behavioural regulation between physical activity and eating-self regulation, especially at the mechanistic level. She explores the mediating role of motivational dynamics (based on self-determination theory) and potential interactions with other psychological and non-psychological factors that might contribute to physical activity/exercise function as a gateway behaviour for healthy eating. Additionally, she has been involved in the design of health behaviour change interventions applying self-determination theory (in overweight/obese women, recreational runners, and now on breast cancer survivors). She has published 60 international peer-reviewed articles (h-index Scopus 22; h-index Google Scholar 35; 3904 citations), 10 national articles, was a co-author of 4 international and 3 national book chapters, and has received 6 awards and/or honours. In her professional activities interacted with 113 collaborator(s) in the co-authorship of scientific papers and book chapters. She is currently the principal investigator of PAC-WOMAN (PTDC/SAU-DES/2865/2020), a national project that is testing two physical activity behaviour change interventions for post-menopausal breast cancer survivors on aromatase inhibitors. She is also the co-responsible investigator in a survey-based research project on beliefs, motivations and practices related to health behaviours in cancer rehabilitation: Clinicians¿ and patients¿ perspectives. In the past, she has integrated the EASO (European Association for the Study of Obesity) Physical Activity Working Group, which drafted the first EASO recommendations for physical activity in adults with overweight or obesity, in collaboration with several leading researchers in the field of Obesity; co-coordinated the KoR (Keep on Running) national project, a digital (brief) intervention study designed to increase sustained adherence to recreational running in a naturalistic environment, and participated in the SPOTLIGHT project, funded by the European Commission (FP7), and in several FCT-funded projects (the PESO Study, the "Physical Activity and the Self-Regulation of Eating Behaviour and Body Weight" project, the Open-Access Repository of Self-Regulation Measures for Exercise, Eating, and Weight Control). In her curriculum Ciência Vitae, the most frequent terms are: Physical Activity/Exercise, Obesity, Weight Management, Cancer, Eating Behaviour, Body Image, Self-Determination Theory, Motivation, Psychological Wellbeing, Health Behaviour Change, Self-Regulation, Systematic Reviews, Mediators, Predictors, Sustained Adherence.

        Graus

            * Ensino secundário
              Área científico-natural - Agrupamento I
            * Licenciatura
              Ciências do Desporto, menção de Educação Física e Desporto Escolar
            * Mestrado
              Mestrado em Exercício e Saúde
            * Doutoramento
              Motricidade Humana, Especialidade em Saúde e Condição Física

        Publicações

        Journal article

          * 2024-02-15, Home-based exercise interventions’ impact on breast cancer survivors’ functional performance: a systematic review, Journal of Cancer Survivorship
          * 2024, Validation of the Portuguese Version of the Perceived Physical Literacy Instrument, Journal of Physical Activity and Health
          * 2024, A Healthier Movement Behavior Profile is associated with Body-Congruent Food Choices through Self-determined Motivations to Exercise and Regulate Eating, European Journal of Sport Science
          * 2023-11-15, Food Reward Associations with Motivational Eating Behavior Traits and BMI in Portuguese Former Elite Athletes, Journal of the Science of Food and Agriculture
          * 2023-10-11, Implementation determinants of physical activity interventions in primary health care settings using the TICD framework: a systematic review, BMC Health Services Research
          * 2023-07-14, Physical literacy assessment in adults: A systematic review, PLOS ONE
          * 2023-07-05, Promoting physical activity through supervised vs motivational behavior change interventions in breast cancer survivors on aromatase inhibitors (PAC-WOMAN): protocol for a 3-arm pragmatic randomized controlled trial, BMC Cancer
          * 2023-06-06, Providing office workers with height-adjustable workstation to reduce and interrupt workplace sitting time: protocol for the Stand Up for Healthy Aging (SUFHA) cluster randomized controlled trial, Trials
          * 2023-05-03, Theory-based physical activity and/or nutrition behavior change interventions for cancer survivors: a systematic review, Journal of Cancer Survivorship
          * 2023-01-02, Experiência profissional e formação académica dos profissionais de exercício físico: relação das pressões no trabalho com as necessidades psicológicas básicas no contexto laboral, Retos
          * 2023-01-01, Questionnaires Measuring 24-Hour Movement Behaviors in Childhood and Adolescence: Content Description and Measurement Properties—A Systematic Review, Journal of Physical Activity and Health
          * 2022-11-18, Effects of fitspiration content on body image: a systematic review, Eating and Weight Disorders - Studies on Anorexia, Bulimia and Obesity
          * 2022-05, Changes in food reward and intuitive eating after weight loss and maintenance in former athletes with overweight or obesity, Obesity
          * 2022-04-29, Dimensões da Literacia Física em Estudantes Universitários e sua Relação com a Atividade Física Presente e Passada: Estudo Exploratório, Observacional (Dimensiones de la Literacia Física en Estudiantes Universitarios y su Relación con la Actividad Física, Retos
          * 2022-03-11, Questionnaires measuring movement behaviours in adults and older adults: Content description and measurement properties. A systematic review, PLOS ONE
          * 2021-12-17, Benefits to Performance and Well-Being of Nature-Based Exercise: A Critical Systematic Review and Meta-Analysis, Environmental Science & Technology
          * 2021-12-15, Effects of Exercise during Pregnancy on Postpartum Depression: A Systematic Review of Meta-Analyses, Biology
          * 2021-10-01, Effectiveness of a lifestyle weight-loss intervention targeting inactive former elite athletes: the Champ4Life randomised controlled trial, British Journal of Sports Medicine
          * 2021-08-01, Motivational Strategies Used by Exercise Professionals: A Latent Profile Analysis, Journal of Physical Activity and Health
          * 2021-07-03, Effect of exercise training before and after bariatric surgery: A systematic review and meta-analysis, Obesity Reviews
          * 2021-06-02, Exercise training in the management of overweight and obesity in adults: Synthesis of the evidence and recommendations from the European Association for the Study of Obesity Physical Activity Working Group, Obesity Reviews
          * 2021-05-07, Systematic Review of Psychological and Behavioral Correlates of Recreational Running, Frontiers in Psychology
          * 2021-05-06, Effect of exercise training on weight loss, body composition changes, and weight maintenance in adults with overweight or obesity: An overview of 12 systematic reviews and 149 studies, Obesity Reviews
          * 2021-05-06, Effect of exercise training on psychological outcomes in adults with overweight or obesity: A systematic review and meta-analysis, Obesity Reviews
          * 2021-05-06, Effect of exercise on cardiometabolic health of adults with overweight or obesity: Focus on blood pressure, insulin resistance, and intrahepatic fat—A systematic review and meta-analysis, Obesity Reviews
          * 2021-05-05, Effective behavior change techniques to promote physical activity in adults with overweight or obesity: A systematic review and meta-analysis, Obesity Reviews
          * 2021-05-05, Effect of exercise training interventions on energy intake and appetite control in adults with overweight or obesity: A systematic review and meta-analysis, Obesity Reviews
          * 2021-05-03, Effect of different types of regular exercise on physical fitness in adults with overweight or obesity: Systematic review and meta-analyses, Obesity Reviews
          * 2021-01-22, Running prevalence in Portugal: Socio-demographic, behavioral and psychosocial characteristics, PLOS ONE
          * 2021-01, Adaptation and validation of the Portuguese version of the regulation of eating behavior scale (REBSp), Appetite
          * 2021, Motivação para o exercício, autoeficácia para a alimentação e apreciação corporal em adultos fisicamente ativos, Gymnasium
          * 2021, Keep on running: a randomized controlled trial to test a digital evidence-based intervention for sustained adoption of recreational running: rationale, design and pilot feasibility study., Health Psychology and Behavioral Medicine
          * 2020-11, A Motivational Pathway Linking Physical Activity to Body-Related Eating Cues, Journal of Nutrition Education and Behavior
          * 2020-07-26, The Dark Side of Motivational Practices in Exercise Professionals: Mediators of Controlling Strategies, International Journal of Environmental Research and Public Health
          * 2020-04-15, Efeitos psicológicos da música em praticantes de exercício: Uma revisão sistemática, Cuadernos de Psicología del Deporte
          * 2020-03-31, Motivação dos nutricionistas/dietistas: antecedentes e consequências para a prática clínica, Acta Portuguesa de Nutrição
          * 2020-02-12, Successful weight loss maintenance: A systematic review of weight control registries, Obesity Reviews
          * 2020-01-21, Champ4life Study Protocol: A One-Year Randomized Controlled Trial of a Lifestyle Intervention for Inactive Former Elite Athletes with Overweight/Obesity, Nutrients
          * 2020, The Effects of the Type of Exercise and Physical Activity on Eating Behavior and Body Composition in Overweight and Obese Subjects, Nutrients
          * 2019-09-13, Behavioural and psychological pretreatment predictors of short- and long-term weight loss among women with overweight and obesity, Eating and Weight Disorders - Studies on Anorexia, Bulimia and Obesity
          * 2019-08-26, Effects of exercise motivations on body image and eating habits/behaviours: A systematic review, Nutrition & Dietetics
          * 2019-08-01, Sedentary Time, Physical Activity, Fitness, and Physical Function in Older Adults: What Best Predicts Sleep Quality?, Journal of Aging and Physical Activity
          * 2019-05, Weight-Focused Physical Activity Is Associated with Poorer Eating Motivation Quality and Lower Intuitive Eating in Women, Journal of the Academy of Nutrition and Dietetics
          * 2019, Perceived Environmental Supportiveness Scale: Portuguese Translation, Validation and Adaptation to the Physical Education Domain, Motriz: Revista de Educação Física
          * 2019, Diferenças na satisfação das necessidades psicológicas básicas, motivações e estratégias motivacionais utilizadas entre professores de Educação Física Pré e Pós Remoção da nota de Educação Física da média final do Ensino Secundário., Ibero-American Journal of Exercise and Sports Psychology
          * 2018-06, Lack of interest in physical activity - individual and environmental attributes in adults across Europe: The SPOTLIGHT project, Preventive Medicine
          * 2018-05, What is the effect of diet and/or exercise interventions on behavioural compensation in non-exercise physical activity and related energy expenditure of free-living adults? A systematic review, British Journal of Nutrition
          * 2018-04-09, Translation and validation of the perceived locus of causality questionnaire (PLOCQ) in a sample of portuguese physical education students, Motriz: Revista de Educação Física
          * 2018, “Educação Física, hoje? Vou menos por “querer” e mais porque “tem que ser”: Repercussões do Decreto-Lei nº 139/2012 na satisfação das necessidades psicológicas básicas e na qualidade da motivação dos alunos do ensino secundário., Boletim SPEF
          * 2018, Psychosocial Pretreatment Predictors of Weight Control: A Systematic Review Update, Obesity Facts
          * 2018, O papel da atividade física na regulação das motivações para a alimentação e dos hábitos alimentares., Boletim SPEF
          * 2017-02, A bifactor exploratory structural equation modeling representation of the structure of the basic psychological needs at work scale, Journal of Vocational Behavior
          * 2017-01, Prevalence of personal weight control attempts in adults: a systematic review and meta-analysis., Obesity reviews : an official journal of the International Association for the Study of Obesity
          * 2017, Um modelo motivacional do envolvimento dos jovens nas aulas de educação física., Retos
          * 2017, Orientação para a magreza em mulheres: Associações com a motivação e prática de exercício físico., GYMNASIUM
          * 2016-10-18, mHealth Technologies to Influence Physical Activity and Sedentary Behaviors: Behavior Change Techniques, Systematic Review and Meta-Analysis of Randomized Controlled Trials, Annals of Behavioral Medicine
          * 2015, Successful behavior change in obesity interventions in adults: A systematic review of self-regulation mediators, BMC Medicine
          * 2015, Nutrição e Exercício Físico - Estratégias de perda de peso., Ata Portuguesa de Nutrição
          * 2015, Contar ou não contar, eis a questão! Associações com a satisfação das necessidades psicológicas básicas e motivação dos alunos na educação física., Boletim SPEF
          * 2014-12, Short- and long-term theory-based predictors of physical activity in women who participated in a weight-management program., Health education research
          * 2014, Prevalence of body shape concerns and associated factors among brazilian early adolescents, Human Movement
          * 2014, O programa PESO: Descrição dos resultados principais., Fatores de Risco
          * 2014, Atividade física: um bom exercício na regulação do comportamento alimentar., Fatores de Risco
          * 2013, The association between physical activity and eating self-regulation in overweight and obese women, Obesity Facts
          * 2012-08, Physical Activity Predicts Changes in Body Image during Obesity Treatment in Women, Medicine & Science in Sports & Exercise
          * 2012, Physical activity predicts changes in body image during obesity treatment in women, Medicine and Science in Sports and Exercise
          * 2012, Exercise, physical activity, and self-determination theory: A systematic review, International Journal of Behavioral Nutrition and Physical Activity
          * 2011, Motivational “spill-over” during weight control: Increased self-determination and exercise intrinsic motivation predict eating self-regulation., Sport, Exercise, and Performance Psychology
          * 2011, Exercise autonomous motivation predicts 3-yr weight loss in women, Medicine and Science in Sports and Exercise
          * 2011, Dysfunctional body investment versus body dissatisfaction: Relations with well-being and controlled motivations for obesity treatment, Motivation and Emotion
          * 2011, Body image change and improved eating self-regulation in a weight management intervention in women, International Journal of Behavioral Nutrition and Physical Activity
          * 2010, Mediators of weight loss and weight loss maintenance in middle-aged women, Obesity
          * 2010, Helping overweight women become more active: Need support and motivational regulations for different forms of physical activity, Psychology of Sport and Exercise
          * 2009, Motivational "Spill-Over" During Weight Control: Increased Self-Determination and Exercise Intrinsic Motivation Predict Eating Self-Regulation, Health Psychology
          * 2008-05, Body Image and Quality of Life Predict Success in a 12-Month Weight Control Program, Medicine & Science in Sports & Exercise
          * 2007-05, Predictors of Successful Weight Control, Medicine & Science in Sports & Exercise

        Thesis / Dissertation

          * 2018, Master, Análise dos efeitos de aulas de zumba vs rpm na motivação, vitalidade, resposta afetiva e perceção de esforço
          * 2017, Master, Qual a associação entre a qualidade da motivação dos alunos e o seu envolvimento comportamental nas aulas de educação física? : análise comparativa de alunos cuja nota educação física conta ou não para a média
          * 2017, Master, Associação entre a remoção da nota de educação física da classificação final do secundário e a satisfação das necessidades psicológicas básicas, a qualidade da motivação e as estratégias motivacionais utilizadas pelos professores
          * 2016, Master, Frustração das necessidades psicológicas básicas na educação física e associação com a atividade física atual
          * 2016, Master, A influência da contagem de nota de educação física e da motivação na prática atual de atividade física: fase pré e pós decreto-lei nº139-2012
          * 2014, Master, Será que a perceção que os alunos têm das estratégias motivacionais empregues pelos professores de Educação Física está associada à satisfação/frustração das suas necessidades psicológicas básicas?
          * 2014, Master, As diferenças na motivação e no envolvimento nas aulas de Educação Física entre os alunos que praticam desporto organizado e os que não praticam
          * 2014, Master, A satisfação das necessidades básicas e a qualidade da motivação: influência da ponderação da nota de Educação Física para a média de ingresso ao Ensino Superior
          * 2013, Master, Relação entre as Pressões Laborais Percecionadas e a Qualidade da Motivação dos Professores de Educação Física
          * 2013, Master, Relação entre a motivação dos alunos percecionada pelos professores de Educação Física e a qualidade da sua própria motivação para o trabalho
          * 2013, Master, A qualidade da motivação dos alunos e o empenho nas aulas de Educação Física
          * 2013, Master, A influência da classificação de educação física na média final e sua associação com a perceção de satisfação das necessidades psicológicas básicas dos alunos do ensino secundário
          * 2012, PhD, The role of body image in the context of obesity treatment and associated behaviors in women

        Book chapter

          * 2019, Internal and external predictors of engaging in and adhering to physical activity., APA Handbook of Sport and Exercise Psychology, 2(14), 1, American Psychological Association
          * 2018, Abordagem Psicológica e Psiquiátrica na Obesidade., Tratamento não cirúrgico da Obesidade do Adulto: Recomendações da Sociedade Portuguesa para o Estudo da Obesidade, Sociedade Portuguesa para o Estudo da Obesidade
          * 2017, Pedagogia do Exercício., Manual do Técnico de Exercício Físico., Manz
          * 2015, Sociocultural Routes to Unhealthy Body Image Investment. , Body Image: Social Influences, Ethnic Differences and Impact on Self-Esteem., Nova Publishers
          * 2013, Body Image Investment and Self-Regulation of Weight Control Behaviors. , Handbook on Body Image: Gender Differences, Sociocultural Influences and Health Implications., Nova Publishers
          * 2011, Physical Wellness, Health Care, and Personal Autonomy

        Conference abstract

          * 2020, Characterisation of body composition and health outcomes in former athletes with overweight/obesity, ECO/ICO
          * 2020, Champ4Life study protocol: A 1-year randomized controlled trial of a lifestyle intervention for inactive former elite athletes with overweight/obesity, ECO/ICO
          * 2020, A High Physical Activity/Low Sitting Profile is associated with more Self-determined Motivations to Exercise and Regulate Eating, ECO/ICO
          * 2019-06, Carraça, E.V., Rodrigues, B., Teixeira, D.S. (2019). A motivational route linking physical activity to internal eating cues. Revista Portuguesa de Cirurgia, Suplemento Novembro:32., Congresso da Sociedade Portuguesa para o Estudo da Obesidade
          * 2017, Carraça, E.V., Santos, I., Mata, J., Teixeira, P.J. (2017). A systematic review update of psychosocial pretreatment predictors of weight control. Obesity Facts, 10(suppl 1):157.
          * 2017, Carraça, E.V., Mackenbach, J.D., Lakerveld, J., Rutter, H., Oppert, J-M., Bourdeaudhuij, I., Compernolle, S., Roda, C., Bardos, H., Teixeira, P.J. (2017). "O que caracteriza os indivíduos que não estão interessados em fazer atividade física? Atributos individuais e ambientais dos participantes do Projeto Europeu Spotlight". Revista Portuguesa de Cirurgia, Suplemento Novembro:31.
          * 2016, Marques, M., Teixeira, P., Palmeira, A., Carraça, E., Santos, I., Meis, J. (2016). Digital weight management lifestyle interventions in adults: Systematic review of behavior change theories and techniques. Bulletin of the European Health Psychology Society, 18 (suppl.):440.
          * 2015, Teixeira, P., Marques, M., Carraça, E., Rutter, H., Oppert, J., De Bourdeaudhuij, I., Lakerveld, J., Brug, J. (2015). A systematic review of self-regulation mediators of success in obesity interventions: the SPOTLIGHT project. Bulletin of the European Health Psychology Society, 17 (suppl.):623.
          * 2015, Marques, M., Antunes, M., Silva, M., Carraça, E., Palmeira, A., Markland, D., Teixeira, P. (2015). An open-access digital repository of self-regulation measures for health behaviors. Bulletin of the European Health Psychology Society, 17 (suppl.):865.
          * 2014, Santos, I., Mata, J., Carraça E.V., Silva, M.N., Sardinha, L.B., Teixeira P.J. (2014). Three-year weight management in overweight women: A signal detection analysis of behavioural and psychological predictors. Obesity Facts, 7(suppl 1):134.
          * 2014, Carraça, E.V., Teixeira, P.J. (2014). "Avaliar o estádio de prontidão para a mudança é importante para ajudar os doentes na perda de peso?". Revista Portuguesa de Cirurgia, Suplemento Outubro:35.
          * 2014, Carraça E.V., Leong S.L., Horwath C.C., Teixeira P.J. (2014). “I eat better when physically active”: The mediating role of autonomous regulations towards eating. Obesity Facts, 7(suppl 1):129.
          * 2013, Teixeira, P.J., Carraça, E.V., Marques, M.M., Rutter, H., Oppert, J.M., Bourdeaudhuij. I., Brug, J.,Lekerveld, J. (2013). A systematic review of self-regulation mediators of success in obesity interventions: the SPOTLIGHT project. Obesity Facts, 6: 11-12.
          * 2013, Marques, M.M., Carraça, E.V., Teixeira, P.J. (2013). Self-regulation mediators of success in obesity interventions: A systematic review for the SPOTLIGHT project. Psychology & Health, 28(suppl 1).
          * 2013, Carraça, E.V. (2013). "As mudanças na prática de exercício físico". Revista Portuguesa de Cirurgia, Suplemento Novembro:16.
          * 2012, Silva, M.N., Santos, I., Carraca, E.V., Vieira, P.N., Teixeira, P.J. (2012). Motivational correlates of exercise behavior among long-term weight loss maintainers. Obesity Facts, 5 (supp. 1):193.
          * 2012, Carraça, E.V., Silva, M.N., Vieira, P.N., Minderico, C.S., Sardinha, L.B., Teixeira, P.J. (2012). Body image enhancement mediates 12- and 36-month positive changes in body weight and psychological well-being in women undergoing obesity treatment. Obesity Facts, 5 (supp. 1):217.
          * 2012, Carraça, E.V., Silva, M.N., Markland, D., Teixeira, P.J. (2012). Self-determination and long-term exercise adherence. In Symposium: “Getting the Chronically Inactive off the Couch: Does Theory Work?”. Medicine and Sciences in Sports and Exercise, 44:S379.
          * 2011, Carraça, E.V. (2011). Imagem Corporal, Atividade Física e Comportamento Alimentar: Influências Regulatórias. In Simpósio: Força de vontade vs. Vontade Própria no comportamento alimentar e gestão do peso. Revista Portuguesa de Cirurgia, Suplemento Novembro:17.
          * 2011, Carraça E.V., Tomás, R., Silva, M.N., Vieira, P.N., Sardinha, L.B., Teixeira, P.J. (2011). Baseline behavioral and psychosocial predictors of attrition and long-term weight loss in a weight management program for overweight and obese women. Obesity Reviews, 12 (supp. 1):240.
          * 2010, Teixeira, P.J., Mata, J., Palmeira, A.L., Silva M.N., Vieira P.N., Carraça, E.V., Sardinha L.B. (2010). Psychologycal predictors of weight gain. Obesity Reviews, 11 (suppl.1):17.
          * 2010, Silva M.N., Vieira P.N., Coutinho S.R., Carraça E.V., Santos, T., Markland, D., Sardinha L.B., Teixeira P.J. (2010). Autonomous motivation for exercise, exercise levels, and 3-year weight change: results from a randomized controlled intervention. Obesity Reviews, 11 (suppl.1):224.
          * 2010, Carraça, E.V., Silva, M.N., Coutinho, S.R., Vieira, P.N., Sardinha L.B., Teixeira, P.J. (2010). Alterações da imagem corporal e comportamento alimentar durante uma intervenção de controlo ponderal. Endocrinologia, Diabetes & Obesidade, 4(4):248.
          * 2010, Carraça, E.V., Silva M.N., Coutinho S.R., Vieira P.N., Sardinha L.B., Teixeira P.J. (2010). The Role of Improved body image mediates the effects of a behavioral weight loss intervention on the eating self-regulation of overweight and obese women. Obesity Reviews, 11 (suppl.1):300.
          * 2009, Vieira P.N., Silva M.N., Andrade A.M., Carraça, E.V., Santos T.C., Sardinha L.B., Teixeira, P.J. (2009). The Portuguese Weight Control Registry: Study Description and Initial Data. Obesity, 17 (Supp 2): S314.
          * 2009, Silva, M.N., Vieira, P.N., Coutinho, S.R., Palmeira, A.L., Carraça. E.V., Mata, J., Sardinha, L.B., Teixeira, P.J. (2009). Self-Determination and Exercise Intrinsic Motivation as Mediators of Physical Activity During a Weight Loss Program: One-Year Results from a Randomized Controlled Trial. Obesity Facts, 2 (Supp 2): 29.
          * 2009, Silva, M.N., Vieira, P.N., Carraça, E.V., Palmeira, A., Coutinho, S.R., Santos, T., Sardinha, L.B., Teixeira, P.J. (2009). Promoting autonomy and intrinsic motivation for physical activity in overweight and obese women. The 8th Annual Conference of the International Society for Behavioral Nutrition and Physical Activity ISBNPA:151. FMH Edições Lisbon, Portugal.
          * 2009, Silva M.N.; Markland, D; Vieira P.N., Coutinho S.R., Palmeira A.L., Carraça E.V., Sardinha L.B., Teixeira P.J. (2009). Mediators of Different Types of Physical Activity During Behavioral Obesity Treatment. Obesity, 17 (Supp 2): S273.
          * 2009, Carraça, E.V., Markland, D., Silva, M.N., Vieira, P.N., Coutinho, S.R., Teixeira, P.J. (2009). Autonomous vs. Controlled regulation mediates the relationship between body image and psychological well-being in overweight and obese women. Obesity Facts, 2 (Supp 2): 242.
          * 2009, Carraça, E.V., Markland, D., Silva, M.N., Coutinho, S.R., Vieira, P.N., Sardinha, L.B., Teixeira, P.J. (2009). Relationships between body image, exercise behavioural regulations, and moderate and vigorous physical activity, in a weight management intervention in women. The 8th Annual Conference of the International Society for Behavioral Nutrition and Physical Activity ISBNPA:217. FMH Edições Lisb
          * 2009, Carraça, E.V. (2009). O papel da regulação externa na imagem corporal e regulação do comportamento alimentar. In Simpósio/Symposium: “Diga-me o que fazer...!: A regulação externa e a motivação para a alimentação e exercício físico”. Endocrinologia, Diabetes & Obesidade, 3(supp):16.
          * 2009, Carraça E.V., Silva M.N., Coutinho S.R., Vieira P.N., Palmeira A.L., Sardinha L.B., Teixeira P.J. (2009). The Role of Personality Causality Orientations in Overweight Women Seeking Behavioral Weight Loss Treatment. Obesity, 17 (Supp 2): S273.
          * 2009, Andrade, A.M., Silva, M.N., Carraça, E.V., Mata, J., Coutinho, S.R., Sardinha, L.B., Teixeira, P.J. (2009). The effect of lifestyle physical activity on weight change is mediated by improved eating self-regulation. The 8th Annual Conference of the International Society for Behavioral Nutrition and Physical Activity ISBNPA:180. FMH Edições Lisbon, Portugal.
          * 2009, Andrade, A.M., Coutinho, S.R., Silva, M.N., Carraça, E.V., Mata, J., Sardinha, L.B., Sardinha, L.B., Teixeira, P.J. (2009). Eating self-regulation mediates the association of physical activity with weight change during weight change during weight management in women. Obesity Facts, 2 (Supp 2): 212.
          * 2008, Tomás RA, Teixeira PJ, Silva MN, Vieira PN, Santos TC, Minderico CS, Castro MC, Coutinho SR, Marcelino M, Carraça E, Sardinha LB. (2008). Body image and quality of life predict success in a 12-month weight control program. Medicine and Science in Sports and Exercise, 40 (5): S84.
          * 2008, Teixeira, P.J., Silva. M.N., Vieira, P.N., Coutinho, S.R., Carraça, E.V., Santos, T.C., Sardinha, L.B. (2008). Does it pay off to promote autonomy and intrinsic motivation during behavioral weight control? Results from a randomized controlled trial in women. Obesity, 16 (Supp 1): S310.
          * 2008, Carraça, E., Teixeira, P.J., Silva, M.N., Vieira, P.N., Castro, M.M., Coutinho, S.C., Santos, T.C., Sardinha, L.B. (2008). Lifetime participation in physical activity: does it predict exercise adherence during behavioral obesity treatment in women? European College of Sport Science, 286.
          * 2008, Carraça EV, Silva MN, Vieira PN, Coutinho SR, Castro MM, Minderico CS, Teixeira PJ. (2008). Associations of Body Image with Obesity Level and With 12-Month Weight Change During a 12-Month Behavioral Weight Management Program in Women. Obesity, 16 (Supp 1): S159.
          * 2008, Carraça E, Teixeira P, Silva M, Vieira P, Castro M, Coutinho S, Santos T, Sardinha L. (2008). Physical Activity and Exercise History: Associations with Success in a Weight Management Program for Overweight and Obese Women. International Journal of Obesity, 32 (Sup. 1): S171.
          * 2007, Teixeira, P.J., Silva, M.N., Vieira, P.N., Minderico, C.S., Castro, M.M., Carraça, E., Marcelino, M., Susana, A., Santos, T. and Sardinha, L.B. (2007). A new randomized controlled trial for obesity treatment based on self-determination theory and motivational interviewing: intervention description. International Journal of Obesity, 31(suppl.): S159.
          * 2007, Sardinha, L.B., Teixeira, P.J., Going, S.B., Tomás, R., Carraça, E., Silva, M.N., Palmeira, A.L., and Lohman, T.G. (2007). Predictors of successful weight control: cross-cultural moderators of treatment outcomes. Medicine and Science in Sports and Exercise, 39 (5) Suppl: S161.
          * 2007, Carraça. E.V., Teixeira, P.J., Vieira, P.N., Silva, M.N., Castro, M.M., Meyer, N.L., Sardinha, L.B. (2007). História da Actividade Física e Exercício: associação com o sucesso num programa de controlo ponderal em mulheres com excesso de peso. Endocrinologia, Diabetes & Obesidade 1:34.
          * 2006, Marcelino M.A., Teixeira P.J., Silva M.N., Minderico C.S., Vieira P.N., Castro M.M., Carraça E.V., Meyer N.L. e Sardinha, L.B. (2006). Associação entre o exercício físico auto-relatado e a perda de peso em mulheres num programa de controlo de peso. Endocrinologia, Metabolismo & Nutrição 16:259.
          * 2006, Carraça E.V., Teixeira P.J., Silva M.N., Minderico C.S., Vieira P.N., Marcelino M.A., Meyer N.L. e Sardinha, L.B. (2006). Associações entre história do peso e tentativas anteriores de perda de peso e o sucesso num programa de controlo de peso em mulheres com excesso de peso ou obesidade. Endocrinologia, Metabolismo & Nutrição 16:268.

        Other output

          * 2023, PAC-WOMAN - Promoting physical activity in breast cancer survivors on aromatase inhibitors

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona