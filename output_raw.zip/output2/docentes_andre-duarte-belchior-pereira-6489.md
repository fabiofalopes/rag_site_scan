# Response for https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
          PT: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489 EN: https://www.ulusofona.pt/en/teachers/andre-duarte-belchior-pereira-6489
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
        fechar menu : https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/andre-duarte-belchior-pereira-6489
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          André Pereira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6489
              p64***@ulusofona.pt
              3014-CACC-2E29: https://www.cienciavitae.pt/3014-CACC-2E29
              0000-0003-3239-4086: https://orcid.org/0000-0003-3239-4086
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/3cd96f69-e024-4dae-821f-c91f5f30d25b
      : https://www.ulusofona.pt/

        Resume

        Graus

            * Mestrado integrado
              Medicina Veterinária
            * Doutoramento
              Ciências Biomédicas
            * Pós-Graduação
              I Curso Pós-Graduado One Health Saúde Humana, Saúde Animal e Saúde Ambiental
            * Outros
              Design Thinking Course
            * Outros
              Value Creation Course
            * Outros
              Project Management Course
            * Outros
              Research Skills Development Course
            * Outros
              Phylogenetic and Population Genetic Tools for Vectors and Bector-borne Pathogens

        Publicações

        Journal article

          * 2023-07-19, The estimated distribution of autochthonous leishmaniasis by Leishmania infantum in Europe in 2005-2020, PLOS Neglected Tropical Diseases
          * 2023-01, A global perspective on non-autochthonous canine and feline Leishmania infection and leishmaniosis in the 21st century, Acta Tropica
          * 2022-08-16, Non-Endemic Leishmaniases Reported Globally in Humans between 2000 and 2021—A Comprehensive Review, Pathogens
          * 2022-05-26, The current epidemiology of leishmaniasis in Turkey, Azerbaijan and Georgia and implications for disease emergence in European countries, Zoonoses and Public Health
          * 2022, Ácaros trombiculídeos: Revisão de uma parasitose negligenciada em animais de companhia, Revista Lusófona de Ciência e Medicina Veterinária
          * 2021-12, Efficacy of a spot-on formulation containing moxidectin 2.5%/imidacloprid 10% for the treatment of Cercopithifilaria spp. and Onchocerca lupi microfilariae in naturally infected dogs from Portugal, Parasites & Vectors
          * 2021-10, Leishmania infantum strains from cats are similar in biological properties to canine and human strains, Veterinary Parasitology
          * 2021-08-14, Human seroprevalence of Toscana virus and Sicilian phlebovirus in the southwest of Portugal, European Journal of Clinical Microbiology & Infectious Diseases
          * 2021-06, Leishmaniases in the European Union and Neighboring Countries, Emerging Infectious Diseases
          * 2021-04, Preliminary comparative analysis of the resolving power of COX1 and 16S-rDNA as molecular markers for the identification of ticks from Portugal, Veterinary Parasitology: Regional Studies and Reports
          * 2021, Leishmania infection in cats and feline leishmaniosis: An updated review with a proposal of a diagnosis algorithm and prevention guidelines, Current Research in Parasitology & Vector-Borne Diseases
          * 2020-11-13, Giardia duodenalis infection in dogs from the metropolitan area of Lisbon, Portugal: prevalence, genotyping and associated risk factors, Journal of Parasitic Diseases
          * 2020-04-21, Monitoring Leishmania infection and exposure to Phlebotomus perniciosus using minimal and non-invasive canine samples, Parasites & Vectors
          * 2020-03-10, Identification of trypanosomatids and blood feeding preferences of phlebotomine sand fly species common in Sicily, Southern Italy, PLOS ONE
          * 2020-01, Phylogenetic insights on Leishmania detected in cats as revealed by nucleotide sequence analysis of multiple genetic markers, Infection, Genetics and Evolution
          * 2020, Prevalence and Risk Factor Analysis of Haemoplasmas Infection in Cats from Lahore, Pakistan Journal of Zoology
          * 2019-09-11, Antibody Response to Toscana Virus and Sandfly Fever Sicilian Virus in Cats Naturally Exposed to Phlebotomine Sand Fly Bites in Portugal, Microorganisms
          * 2019-09, An unusual case of feline leishmaniosis with involvement of the mammary glands, Topics in Companion Animal Medicine
          * 2019, Geographic dispersal and genetic diversity of tick-borne phleboviruses (Phenuiviridae, Phlebovirus) as revealed by the analysis of L segment sequences, Ticks and Tick-borne Diseases
          * 2019, Detection of Rickettsia conorii israelensis DNA in the Blood of a Cat and a Dog From Southern Portugal, Topics in Companion Animal Medicine
          * 2019, Antibody response to Phlebotomus perniciosus saliva in cats naturally exposed to phlebotomine sand flies is positively associated with Leishmania infection, Parasites and Vectors
          * 2018, Evaluation of oxfendazole in the treatment of zoonotic Onchocerca lupi infection in dogs, PLoS Neglected Tropical Diseases
          * 2017, Tick-borne bacteria and protozoa detected in ticks collected from domestic animals and wildlife in central and southern Portugal., Ticks and tick-borne diseases
          * 2017, Serological association between Leishmania infantum and sand fly fever Sicilian (but not Toscana) virus in sheltered dogs from southern Portugal, Parasites & Vectors
          * 2017, Multiple Phlebovirus (Bunyaviridae) genetic groups detected in Rhipicephalus, Hyalomma and Dermacentor ticks from southern Portugal, Ticks and Tick-Borne Diseases
          * 2017, Leishmaniose em Portugal, Pragas e Ambiente
          * 2017, Cercopithifilaria sp II in Vulpes vulpes: new host affiliation for an enigmatic canine filarioid, Parasitology Research
          * 2016, Preliminary report on the prevalence of Angiostrongylus vasorum infection in dogs from Portugal adopting a commercially available test kit for serological analysis, Veterinary Parasitology: Regional Studies and Reports
          * 2016, Parasitic zoonoses associated with dogs and cats: a survey of Portuguese pet owners' awareness and deworming practices, Parasites & Vectors
          * 2016, Molecular detection of tick-borne bacteria and protozoa in cervids and wild boars from Portugal, Parasites & Vectors
          * 2015, Onchocerca lupi Nematode in Cat, Portugal, Emerging Infectious Diseases
          * 2012, Dermatite de origem parasitária provocada por Sarcoptes scabiei var. canis em canídeos, Revista de Medicina Veterinária da Associação de Estudantes da FMV/ULHT

        Thesis / Dissertation

          * 2021, PhD, Reservoirs of zoonotic leishmaniosis: the role played by domestic cats
          * 2016, Master, Deteção molecular de bactérias, protozoários e vírus em ixodídeos colhidos em animais domésticos e silváticos do centro e sul de Portugal Continental

        Conference abstract

          * 2018, Pereira A, Parreira R, Critstóvão J, Campino L, Maia C. (2018). Infeção por Leishmania em gatos da Área Metropolitana de Lisboa. 9.as Jornadas Científicas do Instituto de Higiene e Medicina Tropical. 12 de dezembro, Lisboa, Portugal.

        Conference poster

          * 2023, Zúquete S, Gazelle P, Belas A, Fonseca J, Pereira A, Ramilo DW, Munhoz A, Delgado ILS. (2023). Caracterização molecular de Hepatozoon canis em Portugal. II Encontro de Investigação da FMV Universidade Lusófona. 19 de maio. Lisboa, Portugal.
          * 2023, Zúquete S, Gazelle P, Belas A, Fonseca J, Pereira A, Ramilo DW, Munhoz A, Delgado ILS. (2023). Caracterização molecular de Hepatozoon canis em Portugal. 10º Encontro de Formação da Ordem dos Médicos Veterinários 14-16 abril, Lisboa, Portugal.
          * 2023, Santos C, Alves M, Monteiro MC, Rocha A, Cruz A, Ramalhete B, Trindade B, Delgado ILS, Maia C, Ramilo DW, Pereira A. (2023). Infeção por helmintes pulmonares e gastrointestinais em gatos (Felis catus) da área metropolitana de Lisboa. II Encontro de Investigação da FMV Universidade Lusófona. 19 de maio. Lisboa, Portugal.
          * 2023, Pereira A, Parreira R, Cristóvão J, Campino L, Maia C. (2023). Primeiro registo da deteção molecular de Leishmania major e de híbridos de Leishmania major/Leishmania donovani sensu lato em gatos na Europa. 10º Encontro de Formação da Ordem dos Médicos Veterinários 14-16 abril, Lisboa, Portugal.
          * 2023, Monteiro MC, Alves M, Rocha A, Cruz A, Ramalhete B, Trindade B, Santos C, Delgado ILS, Maia C, Ramilo DW, Pereira A. (2023). Prevalência da infeção por parasitas gastrointestinais e pulmonares em gatos (Felis catus) da área metropolitana de Lisboa. 10º Encontro de Formação da Ordem dos Médicos Veterinários 14-16 abril, Lisboa, Portugal.
          * 2023, Monteiro M, Alves M, Cruz A, Ramalhete B, Rocha A, Trindade B, Santos C, Parreira R, Maia C, Ramilo DW, Pereira A. (2023). Lungworms and gastrointestinal parasites in domestic cats from the Lisbon Metropolitan Area, Portugal: Prevalence and risk factors. 48th World Small Animal Veterinary Association Congress and the 28th FECAVA Eurocongress. 27-29 de setembro. Lisboa, Portugal.
          * 2023, Delgado ILS, Pereira A, Ciobanu B, Videira M, Marques C, Ramilo DW. (2023). Caracterização molecular de ácaros da família Trombiculidae obtidos de um gato errante de Lisboa. II Encontro de Investigação da FMV Universidade Lusófona. 19 de maio. Lisboa, Portugal.
          * 2023, Canejo-Teixeira R, Cabral P, Pereira A, Santana A. (2023). Feasibility of the radiographic assessment of the remporomandibular join (TMJ) using the parallax effect - A preliminary study. IVRA EVDI Joint Conference. 18-23 de junho, Dublin, Irlanda.
          * 2023, Campana S, Fernandes G, Patrício R, Alves M, Lecis R, Ropio J, Valença A, Pereira A, Silveira L, Pista Â, Gomes JP, Nunes A, Belas A. (2023). Salmonella spp. Serovars islated from healthy Leopard geckos (Eublepharis macularius) in Lisbon, Portugal. II Encontro de Investigação da FMV Universidade Lusófona. 19 de maio. Lisboa, Portugal.
          * 2023, 11. Pereira A, Parreira R, Cristóvão J, Campino L, Maia C. (2023). O papel dos gatos domésticos na epidemiologia da leishmaniose zoonótica. 10º Encontro de Formação da Ordem dos Médicos Veterinários 14-16 abril, Lisboa, Portugal.
          * 2022, Pereira A, Parreira R, Cristóvão J, Campino L, Maia C. (2022). Molecular characterisation of Leishmania spp. In cats from Portugal. CIISA Congress. 11 e 12 de novembro, Lisboa, Portugal.
          * 2022, 13. Marques C, Costa P, Cruz JT, Delgado I, Portela G, Munhoz A, Waap H, Pereira A, Ramilo DW. (2022). Deteção de ácaros trombiculídeos (Acari: Trombiculidae) em gatos errantes (in vivo) e no meio ambiente (ex vivo) em Lisboa e Santarém. XVIII Congresso Internacional Veterinário Montenegro. 4 e 5 de novembro, Santa Maria da Feira, Portugal.
          * 2020, Pereira A, Parreira R, Campino L, Maia C. (2020). First evidence of Leishmania major infection in a cat in Western Europe. Encontro de Ciência e Tecnologia em Portugal. 2-4 de novembro, Lisboa, Portugal.
          * 2020, Pereira A, Cristóvão J, Lestinova T, Spitova T, Parreira R, Volf P, Campino L, Maia C. (2020). Avaliação da exposição de gatos domésticos a picadas de Phlebotomus perniciosus e sua associação com a infeção por Leishmania. XI Jornadas Científicas do Instituto de Higiene e Medicina Tropical. 10 de dezembro, Lisboa, Portugal.
          * 2019, Pereira A, Parreira R, Cristóvão J, Castelli G, Bruno F, Vitale F, Campino L, Maia C. (2019). Assessment of genetic diversity of Leishmania donovani complex strains isolated from cats. Encontro de Ciência e Tecnologia em Portugal. 8-10 de julho, Lisboa, Portugal.
          * 2019, Pereira A, Parreira R, Campino L, Maia C. (2019). Feline antibody response to Phlebotomus perniciosus saliva and its association with Leishmania infection. NOVA Science Day. 18 de setembro, Lisboa, Portugal.
          * 2019, Maia C, Campino L, Ayhan N, Cristóvão JM, Pereira A, Charrel R. (2019). Human seroprevalence of Toscana virus and sandfly fever Sicilian virus in Setúbal district, Portugal. 10th International Symposium on Phlebotomine Sandflies. 15-19 de julho, Galápagos, Equador.
          * 2019, Maia C, Afonso MO, Bruno de Sousa C, Ayhan N, Cristóvão JM, Pereira A, Parreira R, Capinha C., Charrel R, Campino L. (2019). Phlebotomine sand fly survey in Algarve region, south of Portugal, 2018: molecular screening of Leishmania and Phlebovirus, and blood meal identification. 10th International Symposium on Phlebotomine Sandflies. 15-19 de julho, Galápagos, Equador.
          * 2018, Cruz C, Cristóvão J, Cachola P, Pereira A, Campino L, Maia C. (2018). Leishmania infantum infection in stray cats from Faro district, south of Portugal. Joint Meeting of the Belgian Society of Parasitology and Protistology (BSPP), Irish Society of Parasitology (ISP), the British Association for Veterinary Parasitology (BAVP) and the European Veterinary Parasitology College (EVPC) ‘Advances in
          * 2018, Cortes S, Pereira A, Vasconcelos J, Paixão J, Quivinja J, Afonso J, Cristóvão L, Campino L. (2018). Leishmaniasis in Angola – An emerging disease?. Ninth European & Developing Countries Clinical Trials Partnership Forum. 17 a 21 de setembro, Lisboa, Portugal
          * 2017, Pereira A, Parreira R, Figueira L, Nunes M, Cotão AJ, Vieira ML, Campino L, Maia C. (2017). Molecular detection of phlebovirus in ticks from southern Portugal. 4th Conference on Neglected Vectors and Vectors and Vector-Borne Diseases (EurNegVec): with MC and WG Meeting of the COST Action TD1303. 11-13 de setembro, Chania, Grécia.
          * 2017, Pereira A, Otranto D, Cristóvão JM, Colella V, Campino L, Maia C. (2017). Seroprevalência de Leishmania em cães de caça da região do Algarve. XIII Congresso Hospital Veterinário Montenegro. 18 e 19 de fevereiro, Santa Maria da Feira, Portugal.
          * 2017, 25. Maia C, Cruz C, Cristóvão JM, Cachola P, Brancal H, Martins A, Pereira A, Campino L. (2017). Leishmania infection in cats from three canine leishmaniasis endemic foci from Portugal. XIII Congresso Hospital Veterinário Montenegro. 18 e 19 de fevereiro, Santa Maria da Feira, Portugal
          * 2016, Pereira A, Martins A, Brancal H, Vilhena H, Silva P, Pimenta P, Diz-Lopes D, Neves N, Coimbra M, Alves A, Cardoso L, Maia C. (2016). A survey of portuguese pet owners' awareness about parasitc zoonoses associated with dogs and cats. XXIX Congress Società Italiana di Parassitologia & European Veterinary Parasiology College. 21-24 de junho, Bari, Itália.
          * 2016, Pereira A, Azevedo P, Campos A, Fonseca S, Maia C. (2016). Infeção canina por Cyniclomyces guttulatus. VII Encontro de Formação da Ordem dos Médicos Veterinários. 26 e 27 de novembro, Lisboa, Portugal
          * 2016, 27. Sousa S, Pereira A, Parreira R, Maia C. (2016). Caracterização genética de Giardia duodenalis em cães da região de Lisboa. VII Encontro de Formação da Ordem dos Médicos Veterinários. 26 e 27 de novembro, Lisboa, Portugal

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona