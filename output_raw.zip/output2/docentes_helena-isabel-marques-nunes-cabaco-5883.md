# Response for https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
          PT: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883 EN: https://www.ulusofona.pt/en/teachers/helena-isabel-marques-nunes-cabaco-5883
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
        fechar menu : https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/helena-isabel-marques-nunes-cabaco-5883
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Helena Isabel Marques Nunes Cabaço

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5883
              p58***@ulusofona.pt
              D01D-34B6-6C79: https://www.cienciavitae.pt/D01D-34B6-6C79
              0000-0001-7213-2879: https://orcid.org/0000-0001-7213-2879
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/120daf6b-8d89-47f3-9061-53f983046dab
      : https://www.ulusofona.pt/

        Resume

        Helena Nunes Cabaço is a Biochemistry graduate from the Faculty of Sciences at the University of Lisbon (2002). She earned her Ph.D. in Biomedical Sciences from the Faculty of Medicine, University of Lisbon, in 2010. Her doctoral research, developed at the Human Immunodeficiency and Immune Reconstitution Lab at the Institute of Molecular Medicine (iMM), focused on Immunology and Human T cell development, particularly on the development of regulatory T cells in the human thymus, earning her the Basic Research Award from NEDAI (Núcleo de Estudos de Doenças Auto-Imunes) of the Portuguese Society of Internal Medicine. Following her Ph.D., she embarked on a post-doctoral journey in 2011 at iMM, concentrating on Immunology and HIV infection. In this role, she led a project funded by the Gilead Genesis Program in 2015, exploring the impact of HIV-2 infection on human T cell development. In 2017, she assumed the role of Senior Post-Doctoral Researcher at the Prudêncio Lab (Plasmodium Infection & Anti-malarial Interventions) at iMM, where she played a pivotal role in evaluating the immune response during the clinical trial of a novel malaria vaccine candidate (PbVac). This work earned the prestigious 2020 Pfizer Award in Clinical Investigation. Helena has an extensive academic background, having conducted research in Immunology and Neurosciences at renowned institutions worldwide, including the Mayo Clinic (Minnesota, USA), Universidad Miguel Hernandez (Alicante, Spain), Instituto Gulbenkian de Ciência (Lisbon, Portugal), Baylor College of Medicine (Texas, USA), and Erasmus MC University (Rotterdam, The Netherlands). Throughout her career, she has made significant contributions to the scientific literature, with numerous peer-reviewed articles, many of which she authored as first or co-first author, appearing in reputable journals, including Science Translational Medicine. Helena holds the position of Assistant Professor at Universidade Lusófona de Humanidades e Tecnologias, where she is the regent teacher of the Immunology class for Biology and Biochemistry courses. She has further demonstrated her commitment to education by supervising numerous BSc and MSc students and serving on the jury for MSc and Ph.D. theses. She also contributed to the Thesis Committee of students from the Lisbon BioMed PhD Program. Helena has also been involved in organizing various Meetings and Events in the field of Immunology, along with community-oriented initiatives such as the Open International Immunology Day and workshops for children in elementary schools focusing on Vaccines and Science. In 2017, Helena received an Entrepreneurship award from Healthcare City. In 2020, she organized and coordinated a Task Force at iMM for establishing a Biobank collection of samples from COVID-19 patients. Her current research interests focus on the development of malaria vaccines and the investigation of the ensuing immune response.

        Graus

            * Doutoramento
              Biomedical Sciences
            * Licenciatura
              Biochemistry

        Publicações

        Preprint

          * 

        Journal article

          * 2023-12-13, SARS-CoV-2 decreases malaria severity in co-infected rodent models, Frontiers in Cellular and Infection Microbiology
          * 2023-12, Variable long-term protection by radiation-, chemo-, and genetically-attenuated Plasmodium berghei sporozoite vaccines, Vaccine
          * 2023-11-24, The effect of dosage on the protective efficacy of whole-sporozoite formulations for immunization against malaria, npj Vaccines
          * 2022-09-08, Five decades of clinical assessment of whole-sporozoite malaria vaccines, Frontiers in Immunology
          * 2022-02-11, Human CD4 T Cells From Thymus and Cord Blood Are Convertible Into CD8 T Cells by IL-4, Frontiers in Immunology
          * 2022-02-10, Expression of Human Endogenous Retroviruses in the Human Thymus Along T Cell Development, Frontiers in Virology
          * 2022, Impact of dietary protein restriction on the immunogenicity and efficacy of whole-sporozoite malaria vaccination
          * 2021-10-29, Excreted Trypanosoma brucei proteins inhibit Plasmodium hepatic infection, PLOS Neglected Tropical Diseases
          * 2021-05-16, A guide to investigating immune responses elicited by whole-sporozoite pre-erythrocytic vaccines against malaria, The FEBS Journal
          * 2020-11-10, Seroprevalence of anti-SARS-CoV-2 antibodies in COVID-19 patients and healthy volunteers up to 6 months post disease onset, European Journal of Immunology
          * 2020-05-20, An open-label phase 1/2a trial of a genetically modified rodent malaria parasite for immunization against Plasmodium falciparum malaria, Science Translational Medicine
          * 2019-11-08, Trypanosoma brucei infection protects mice against malaria, PLOS Pathogens
          * 2017-05-17, HIV-2 infection is associated with preserved GALT homeostasis and epithelial integrity despite ongoing mucosal viral replication, Mucosal Immunology
          * 2015-08-03, Regulatory T-Cell Development in the Human Thymus, Frontiers in Immunology
          * 2015-01, Human regulatory T-cell development is dictated by Interleukin-2 and -15 expressed in a non-overlapping pattern in the thymus, Journal of Autoimmunity
          * 2014-12, Thymic HIV-2 infection uncovers post-transcriptional control of viral replication in human thymocytes.
          * 2013, Repairing thymic function, Current Opinion in Organ Transplantation
          * 2011, Differentiation of human thymic regulatory T cells at the double positive stage, European Journal of Immunology
          * 2011, CD4+ recent thymic emigrants are infected by HIV in vivo, implication for pathogenesis, AIDS
          * 2010, Foxp3 induction in human and murine thymus precedes the CD4+ CD8+ stage but requires early T-cell receptor expression, Immunology and Cell Biology

        Thesis / Dissertation

          * 2010-11-19, PhD, Development of regulatory T cells in the human thymus : one step beyond; Desenvolvimento de células T reguladoras no timo humano
          * 2002-10, Degree, CD39 Expression and B Cell Differentiation

        Conference poster

          * 2023-03-29, Differential Binding in human thymic regulatory T cells refine whole-genome analyses of complex immune diseases, XLVIII Annual Meeting of the Portuguese Society for Immunology
          * 2022-12-05, Nunes-Cabaço H, Prudêncio M; "Age-dependent Impact of Malaria on Thymic Function", British Society for Immunology Congress 2022, Liverpool, UK
          * 2021-10-09, Can Trypanosoma brucei be a new ally in the fight against malaria? , 32nd Molecular Parasitology Meeting
          * 2021-05-25, Nunes-Cabaco H, Moita D, Rôla C, Mendes AM, Prudêncio M; "Impact of protein deficiency on the immunogenicity and efficacy of malaria vaccination", EMBL Conference: BioMalPar XVII: Biology and Pathology of the Malaria Parasite
          * 2021-05-20, Nunes-Cabaço H, Moita D, Rôla C, Mendes AM, Prudêncio M; "Impact of protein deficiency on the immunogenicity and efficacy of malaria vaccination", XLVII Annual Meeting of the Portuguese Society for Immunology
          * 2019-06-15, New malaria vaccine candidate against Plasmodium vivax using genetically modified rodent Plasmodium parasites, SPI XLV Meeting, Sociedade Portuguesa de Imunologia
          * 2019-05-17, Cunha-Barreto A, Mendes AM, Nunes-Cabaço H, Prudêncio M; "Evaluation of tissue-associated cellular immune responses to PbVAC, a P. berghei-based whole-sporozoite malaria vaccine candidate, in rhesus macaques", XLV Annual Meeting of the Portuguese Society for Immunology, Coimbra, Portugal
          * 2019-05, New insights into interferon-mediated immune responses elicited by Plasmodium liver stage infection, XLV Annual Meeting of the Portuguese Society for Immunology
          * 2017-03-13, Tokunaga Y, Nunes-Cabaço H, Sousa AE; "Differentiation of FOXP3+ regulatory T cells in the human thymus: unbiased approaches circumventing sequential-gating strategy", 7th International Kyoto T Cell Conference (KTCC), Kyoto University, Kyoto, Japan
          * 2017-03-13, Ramalho-dos-Santos A, Martins L, Caramalho I, Barata J, Sousa AE, Nunes-Cabaço H; "IL-4 induces coreceptor reversal in CD4-committed human thymocytes", 7th International Kyoto T Cell Conference (KTCC), Kyoto University, Kyoto, Japan
          * 2016-06-01, Ramalho-dos-Santos A, Martins L, Caramalho I, Barata J, Sousa AE, Nunes-Cabaço H; "A Role for IL-4 in CD4 T cell Plasticity", Portuguese Society for Immunology XLII Annual Meeting, IGC, Lisbon, Portugal
          * 2016-06-01, Antão A, Foxall RB, Matoso P, Pires AR, Serra-Caetano A, Sousa AE, Nunes-Cabaço H*, Rocha C*; "In vitro infection of lymphoid tissues by HIV-2", Portuguese Society for Immunology XLII Annual Meeting, IGC, Lisbon, Portugal
          * 2015-10-26, Mendes-Passos V, Foxall RB, Matoso P, Pires AR, Tendeiro R, Pinheiro AI, Soares RS, Sousa AE and Nunes-Cabaço H; "Host Restriction Factors OF Retroviral Replication in the Human Thymus", Portuguese Society for Immunology XLI Annual Meeting, ICVS, Braga, Portugal
          * 2015-04-09, Helena Nunes-Cabaço, Vânia Mendes-Passos, Russell B. Foxall, Paula Matoso, Ana R. Pires, Rita Tendeiro, Ana I. Pinheiro, Rui S. Soares, Ana E. Sousa; "Host restriction factors of retroviral replication in the human thymus", 1st International Venice Thymus Meeting 2015, San Servolo Island, Venice, Italy
          * 2014-05-05, Nunes-Cabaço H, Matoso P, Foxall RB, Tendeiro R, Pires AR, Pinheiro AI, Soares RS, Sousa AE.; "Infection of the human thymus by HIV-2", 9th ENII EFIS/EJI Summer School on Advanced Immunology, Porto Conde, Alghero, Sardinia, Italy
          * 2013-12-19, Nunes-Cabaço H, Matoso P, Foxall RB, Tendeiro R, Pire AR, Soares RS, Pinheiro AI, Sousa AE; "Infection of the human thymus by HIV-2", Thymus@Porto II IBMC, Porto, Portugal
          * 2012-03-26, Nunes-Cabaço H, Tendeiro R, Foxall RB, Soares RS, Pinheiro AI, Matoso P, Sousa AE; "HIV-2 has a reduced ability to infect the human thymus", Frontiers in HIV Pathogenesis, Therapy and Eradication Whistler, British Columbia, Canada
          * 2011-10-14, Nunes-Cabaço H, Caramalho I, Sepúlveda N, Sousa AE; "Differentiation of human thymic regulatory T-cells at the double positive stage", Thymus@Porto, IBMC, Porto, Portugal
          * 2009-09-28, Nunes-Cabaço H, Ribot JC, Caramalho I, Serra-Caetano A, Silva-Santos B, Sousa AE; "Foxp3 induction in human and murine thymus precedes the CD4+CD8+ stage but requires early TCRalpha expression", Portuguese Society for Immunology XXXV Annual Meeting, IMM, Lisbon, Portugal
          * 2007-04-11, Nunes Cabaço H & Sousa AE; "Dynamics of Foxp3, CD25 and CD127 expression in the human thymus", World Immune Regulation Meeting – Special Focus on Regulatory Cells, Davos, Switzerland
          * 2004-06-10, Nunes Cabaço H, Haury M, Fairen A, Parra P.; "A Transgenic Mouse Expressing GFP in the Cortical Subplate and Hippocampal Pyramidal Cells at Different Time Points", FENS (Federation of European Neuroscience Societies) Forum 2004, Lisbon, Portugal
          * 2004-04-14, Nunes Cabaço H, Haury M, Fairen A, Parra P.; "A Transgenic Mouse Expressing GFP in the Cortical Subplate and Hippocampal Pyramidal Cells at Different Time Points", Symposium "New Insights on Developmental Neurobiology", Cadiz, Spain

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona