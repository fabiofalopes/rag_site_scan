# Response for https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
          PT: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520 EN: https://www.ulusofona.pt/en/teachers/catia-margarida-dos-santos-pereira-de-oliveira-5520
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
        fechar menu : https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/catia-margarida-dos-santos-pereira-de-oliveira-5520
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Cátia Margarida Dos Santos Pereira De Oliveira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5520
              cat***@ulusofona.pt
              521F-18BB-F4AD: https://www.cienciavitae.pt/521F-18BB-F4AD
              0000-0001-7510-4873: https://orcid.org/0000-0001-7510-4873
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/2bed9526-66a1-4949-adcb-4776b0154fa8
      : https://www.ulusofona.pt/

        Resume

        Cátia Oliveira, PhD, is an assistant professor, cognitive-behavioural psychologist, supervisor, and sex therapist. She develops research on the topics of sexual health, namely sexual problems. She completed her undergraduate in Psychology, Cognitive Behavioural (CBT) Clinical Psychology in 2004 at the University of Coimbra, finished her Master's in Clinical Psychology, area of Clinical Sexology in 2008 at the University of Trás-os-Montes e Alto Douro, and obtained her PhD in Clinical Psychology in 2013 at the University of Aveiro. She received a grant for PhD and postdoc studies regarding the influence of biopsychosocial variables in the context of sexual pain. Through the years, she maintained professional training at the clinical level, especially in several CBT approaches, namely Mindfulness, DBT and the Third Wave of CBT. She is a main researcher of the HEI-Lab: Digital Human-Environment Interaction Lab from Lusófona University and a collaborator member of the Research Group in Human Sexuality (Faculty of Psychology and Educational Sciences of Porto University). She participated in several funded projects, namely a randomized control study on "Efficacy in the Psychological Treatment of Erectile Dysfunction: Cognitive-Behavioral Therapy Versus Medication". She was also Co-Pi of the project "NeuroThermoSex: The cerebral and autonomical correlates of the role of Oxytocin in the sexual behaviour: fMRI, fMRI and EGG study combined with thermal imaging" and is now Co-PI of the project "Anthesis-A transdiagnostic approach to sexual distress: testing a pilot online intervention". She has published several papers and book chapters on human sexuality and presented several scientific works at international meetings. She contributes to several editorial boards ranked as Q1 and Q2, namely The Journal of Sexual Medicine and the Journal of Sex Research. She collaborated as a member of the scientific committees of several international and national congresses related to sexuality. She's been working for 19 years in private practice with adults, with continuous clinical supervision, and she's the Director of the Psychology Service at Porto Lusófona University. She is the Deputy Director of the Masters in Clinical and Health Psychology and Assistant Professor at Porto Lusófona University, teaching mainly Clinical and CBT Curricular Units in the Master's and Ph.D. Courses. She is the supervisor of 2 ongoing PhD and five ongoing Master Thesis. In the last years, she has participated in several Juris of post-graduate degrees and supervised several Master Thesis. She is also a clinical supervisor of several master students in their clinical internships.

        Graus

            * Licenciatura
              [Psychology]. Psicologia.
            * Mestrado
              [Clinical Psychology]. Psicologia Clínica.
            * Doutoramento
              [Clinical Psychology]. Psicologia Clínica.
            * Título de especialista
              [Specialist in Clinical and Health Psychology]. Especialista em Psicologia Clínica e da Saúde.
            * Título de especialista
              [Advanced Specialist in Sexology]. Especialista Avançada em Sexologia.
            * Pós-Graduação
              [Clinical Psychology]. Psicologia Clínica.
            * Título de especialista
              [Dialectical Behavioral Therapy – DBT Intensive Plus]. Terapia Comportamental Dialéctica – DBT Intensive Plus.
            * Título de especialista
              [Specialized Training in Mindfulness – Teacher Training]. Formação Especializada em Mindfulness – Teacher Training.
            * Diploma de especialização
              [Specialized Course in Acceptance and Commitment Therapy]. Curso Especializado em Terapia pela Aceitação e Compromisso.
            * Diploma de especialização
              [Dialectical Behavior Therapy: Assess and Intervene]. Terapia Comportamental Dialética: Avaliar e Intervir.
            * Outros
              [Workshop Process-based CBT]. Workshop TCC Baseada em Processos.
            * Outros
              [5 day Silence Retreat]. Retiro de Silêncio de 5 dias.
            * Diploma de especialização
              [Empowering people with OCD to choose to change across the lifespan]. Capacitar as pessoas com POC a escolher mudar ao longo da vida.
            * Outros
              Workshop “Sex Made Simple”.
            * Diploma de especialização
              [Workshop Mindfulness Self-Compassion]. Atenção Plena e Auto-Compaixão.
            * Diploma de especialização
              [Mindfulness in its experiential component, MBCT and Mindfulness with Children and Adolescents]. Mindfulness na sua componente experiencial, MBCT e Mindfulness com Crianças e Adolescentes.
            * Outros
              [Workshop The Resolution of Therapeutic Impasses]. A Resolução de Impasses Terapêuticos.
            * Outros
              [Workshop New Developments in Neuropsychophysiology of Sexual Response]. Novos desenvolvimentos na neuropsicofisiologia da resposta sexual.
            * Diploma de especialização
              [Formação em Lisrel]. Training in Lisrel.
            * Diploma de especialização
              [Acceptance and Commitment Therapy]. Terapia de Aceitação e Compromisso.
            * Diploma de especialização
              [Training in Mindfulness]. Formação em Mindfulness.
            * Outros
              [Workshop 3rd Generation Therapies: Model of Compassion]. Terapias da 3ª Geração: Modelo da Compaixão.
            * Diploma de especialização
              [Training in Mindfulness]. Formação em Mindfulness.
            * Diploma de especialização
              [Training in Sex Therapy]. Formação em Terapia Sexual.
            * Diploma de especialização
              [Psychophysiological Assessment of Sexual Response]. Avaliação Psicofisiológica da Resposta Sexual.
            * Diploma de especialização
              [Motivational Interview]. Entrevista Motivacional.
            * Diploma de especialização
              [Personality Disorders]. Perturbações da Personalidade.
            * Diploma de especialização
              [Paraphilias and Gender Identity Disorders]. Parafilias e Perturbações de Identidade de Género.
            * Diploma de especialização
              [Social Phobia]. Fobia Social.
            * Diploma de especialização
              [Mood Disorders]. Perturbações do Humor.
            * Diploma de especialização
              [Eating Behavior Disorders]. Perturbações do Comportamento Alimentar.
            * Diploma de especialização
              [Sexual and Reproductive Health in the Difference]. Saúde Sexual e Reprodutiva na Diferença.
            * Diploma de especialização
              [Professional Training Course in Social Competencies]. Curso de Formação Profissional em Competências Sociais.
            * Diploma de especialização
              [Suicide, Attempted Suicide and Parasuicide]. Suícidio, Tentativa de Suicídio e Parassuícidio.
            * Diploma de especialização
              [Obsessive-Compulsive Disorder]. Perturbação Obsessivo-Compulsiva.
            * Diploma de especialização
              [Introduction to 3rd Generation Cognitive-Behavioral Psychotherapies]. Introdução às Psicoterapias Cognitivo-Comportamentais de 3ª Geração.
            * Outros
              [Workshop “Anxiety Disorders: Obsessive-Compulsive Disorder and Hypochondria”]. Workshop “Distúrbios da Ansiedade: Perturbação Obsessivo-compulsivo e Hipocondria”.
            * Diploma de especialização
              [Suicide, Attempted Suicide, and Parasuicide]. Suicídio, Tentativa de Suícidio e Parassuicidio.
            * Diploma de especialização
              [Professional Training Course in Social Skills]. Curso de Formação Profissional em Competências Sociais.
            * Diploma de especialização
              [Sexual and Reproductive Health in Difference]. Saúde Sexual e Reprodutiva na Diferença.
            * Outros
              [Workshop “Assessment and Treatment of Eating Disorders”]. “Avaliação e Tratamento das Perturbações do Comportamento Alimentar”.
            * Outros
              [Workshop “Assessment and Treatment of Mood Disorders”]. “Avaliação e Tratamento das Perturbações de Humor”.
            * Outros
              [Workshop Assessment and Treatment of Social Phobia]. Avaliação e Tratamento da Fobia Social.
            * Outros
              [Workshop Assessment and Treatment of Panic Disorders]. Avaliação e Tratamento das Perturbações de Pânico.
            * Outros
              [Workshop Assessment and Treatment of Post Traumatic Stress Disorders]. Avaliação e Tratamento das Perturbações de Stress Pós-traumático.
            * Outros
              [Workshop Assessment and Treatment of Obsessive-Compulsive Disorders]. Avaliação e Tratamento das Perturbações Obsessivos-compulsivas.
            * Outros
              [Workshop Paraphilias and Gender Identity Disorders]. Parafilias e Perturbações da Identidade de Género.
            * Outros
              [Psychopharmacology Workshop]. Psicofarmacologia.
            * Outros
              [Personality Disorders Workshop]. Perturbações da Personalidade.
            * Outros
              [Workshop Anxiety Disorders in Children and Adolescents]. Perturbações da Ansiedade em Crianças e Adolescentes.
            * Outros
              [Psychotic Disorders Workshop]. Perturbações Psicóticas.
            * Outros
              [Generalized Anxiety Disorders Workshop]. Perturbações de Ansiedade Generalizada.
            * Outros
              [Workshop Schema Therapy: New Strategies for Difficult Personality Disorders]. Terapia do Esquema: Novas Estratégias para Transtornos Difíceis da Personalidade.
            * Outros
              [Motivational Interviewing Workshop: Accepting What Is Instead of Demanding What Should Be]. Entrevista Motivacional: Aceitar o que é em vez de exigir o que devia ser.
            * Outros
              [Workshop The Psychophysiology of sex]. A Psicofisiologia do Sexo.
            * Diploma de especialização
              [Psychophysiology of the female and male sexual response and respectively defined in an experimental context]. Psicofisiologia da resposta sexual feminina e masculina e respectiva medição em contexto experimental.
            * Pós-Graduação
              [Clinical Sexology]. Sexologia Clínica.
            * Outros
              [Workshop New View Approach to Sex Therapy]. Nova Visão da Terapia Sexual.
            * Outros
              [Workshop Mindfulness in Medicine and Psychology - A first Hand and Clinical Applications]. Mindfulness em Medicina e Psicologia - Uma primeira mão e aplicações clínicas.
            * Outros
              [Workshop Working with Shame and Developing Inner Compassion]. Trabalhando com a Vergonha e Desenvolvendo a Compaixão Interior.
            * Outros
              [Workshop Current Approaches to teaching Mindfulness in Empirically Supported Interventions]. Abordagens Atuais para o Ensino de Mindfulness em Intervenções Empiricamente Apoiadas.
            * Outros
              [Acceptance and Commitment Therapy Workshop - ACT: From theory to practice]. Terapia de Aceitação e Compromisso - ACT: Da teoria à prática.
            * Outros
              [Workshop Modeling Structural Equations with Interactive LISREL: A Practical and Simple Introduction]. Modelação em Equações Estruturais com LISREL Interativo: Uma Introdução Prática e Simples.
            * Diploma de especialização
              [Experiential mindfulness, mindfulness based cognitive therapy and mindfulness for children and adolescents]. Mindfulness experiencial, terapia cognitiva baseada em mindfulness e mindfulness para crianças e adolescentes.
            * Outros
              [Female-Male Sexual Equity and the Good Enough Sex Model]. Equidade sexual entre homens e mulheres e o modelo sexual bom o suficiente.

        Publicações

        Journal article

          * 2021, [Psychosocial and behavioral aspects of women's sexual pleasure: A scoping review]. Aspectos psicossociais e comportamentais do prazer sexual feminino: uma scoping review.
          * 2021, [How relevant is the systemic oxytocin concentration for human sexual behavior? A Systematic review]. Quão relevante é a concentração sistêmica de ocitocina para o comportamento sexual humano? Uma Revisão Sistemática.
          * 2020-10-28, [The role of anterior and posterior insula in male genital response and in visual attention: an exploratory multimodal fMRI study]. O papel da ínsula anterior e posterior na resposta genital masculina e na atenção visual: um estudo exploratório multimodal de ressonância magnética funcional., Scientific Reports
          * 2020-02, [Self-Compassion, Emotion Regulation, and Female Sexual Pain: A Comparative Exploratory Analysis]. Autocompaixão, Regulação Emocional e Dor Sexual Feminina: Uma Análise Exploratória Comparativa., The Journal of Sexual Medicine
          * 2018-02-08, [Pain Intensity and Sexual Functioning in Men with Genital Pain: The Mediation Role of Sexually Related Thoughts]. Intensidade da Dor e Funcionamento Sexual em Homens com Dor Genital: O Papel Mediador dos Pensamentos Relacionados à Sexualidade., Journal of Sex & Marital Therapy
          * 2016-12-27, [Cognitive Factors and Male Genital Pain: A Preliminary Study]. Fatores Cognitivos e Dor Genital Masculina: Um Estudo Preliminar., International Journal of Sexual Health
          * 2015-11-07, [Sexual Functioning and Cognitions During Sexual Activity in Men With Genital Pain: A Comparative Study]. Funcionamento Sexual e Cognições Durante a Atividade Sexual em Homens com Dor Genital: Um Estudo Comparativo., Journal of Sex & Marital Therapy
          * 2015, [Cognitive factors on male sexual pain: the role of pain catastrophizing and automatic thoughts during sexual activity]. Fatores cognitivos na dor sexual masculina: o papel da catastrofização da dor e pensamentos automáticos durante a atividade sexual.
          * 2014-11, [Predictors of Men's Sexual Response to Erotic Film Stimuli: The Role of Affect and Self-Reported Thoughts]. Preditores da resposta sexual dos homens aos estímulos de filmes eróticos: o papel do afeto e dos pensamentos auto-relatados., The Journal of Sexual Medicine
          * 2014-11, [Affective and Cognitive Determinants of Women's Sexual Response to Erotica]. Determinantes afetivos e cognitivos da resposta sexual feminina ao erotismo., The Journal of Sexual Medicine
          * 2013-09, [The Role of Trait-Affect, Depression, and Anxiety in Women With Sexual Dysfunction: A Pilot Study]. O Papel do Traço-Afeto, Depressão e Ansiedade em Mulheres com Disfunção Sexual: Um Estudo Piloto., Journal of Sex & Marital Therapy
          * 2013-07, [Cognitive Structures in Women with Sexual Dysfunction: The Role of Early Maladaptive Schemas]. Estruturas cognitivas em mulheres com disfunção sexual: o papel dos esquemas desadaptativos precoces., The Journal of Sexual Medicine
          * 2013-03-22, [Gender Differences in Sexual Arousal and Affective Responses to Erotica: The Effects of Type of Film and Fantasy Instructions]. Diferenças de gênero na excitação sexual e nas respostas afetivas ao erotismo: os efeitos do tipo de filme e as instruções de fantasia., Archives of Sexual Behavior
          * 2013, [Self-Esteem, Dyadic Adjustment and Sexual Functioning in Women with Sexual Pain]. Autoestima, Ajuste Diádico e Funcionamento Sexual em Mulheres com Dor Sexual., The Journal of Sexual Medicine.
          * 2013, [Attention, Pain Catastrophizing and Perception of Significant Other Responses in Women with Sexual Pain]. Atenção, Catastrofização da Dor e Percepção de Outras Respostas Significativas em Mulheres com Dor Sexual., The Journal of Sexual Medicine.
          * 2011, [Women's Subjective and Pshysiological Sexual Response to Erotica: The Role of Affective and Cognitive Determinants]. A Resposta Sexual Subjetiva e Fisiológica das Mulheres ao Erotismo: O Papel dos Determinantes Afetivos e Cognitivos.
          * 2011, [Trait-Affect and Sexual Functioning in Women: The Mediational Role of Psychopathology]. Traço-Afeto e Funcionamento Sexual em Mulheres: O Papel Mediador da Psicopatologia.
          * 2011, [Psychosocial Determinants of Sexual Pain in Portuguese Women: An Exploratory Study]. Determinantes Psicossociais da Dor Sexual em Mulheres Portuguesas: Um Estudo Exploratório.
          * 2010, [Women’s Affective, Cognitive, and Sexual Response to Different Types of Films and Instructions During Exposure to Erotica]. Resposta Afetiva, Cognitiva e Sexual das Mulheres a Diferentes Tipos de Filmes e Instruções Durante a Exposição ao Erótico.
          * 2010, [Women's Sexuality & Mindfulness]. Sexualidade Feminina e Mindfulness.
          * 2010, [Trait-Affect, Psychopathology and Sexual Functioning: Differences between Sexually Functional and Dysfunctional Men and Women]. Traço-Afeto, Psicopatologia e Funcionamento Sexual: Diferenças entre Homens e Mulheres Sexualmente Funcionais e Disfuncionais.
          * 2010, [Predictors of Men’s Sexual Response to Erotica: the Role of Beliefs, Sociosexuality, Sexual Inhibition/Excitation, Affect, and Automatic thoughts]. Preditores da resposta sexual dos homens ao erotismo: o papel das crenças, sociossexualidade, inibição/excitação sexual, afeto e pensamentos automáticos.
          * 2010, [Gender Differences in Subjective Sexual Response to Erotic Films: an Exploratory Study with Undergraduate Portuguese Students]. Diferenças de Género na Resposta Sexual Subjetiva a Filmes Eróticos: um Estudo Exploratório com Estudantes de Licenciatura Portuguesa.
          * 2010, [Gender Differences in Sexual Arousal and Emotional Response to Erotica: the Effect of Type of Film and Instructions]. Diferenças de gênero na excitação sexual e na resposta emocional ao erotismo: o efeito do tipo de filme e das instruções.
          * 2008, [Female Sexual Dysfunction: The Role of Schemas and Affect]. Disfunção Sexual Feminina: O Papel dos Esquemas e do Afeto.
          * 2007, [Cognitive and Emotional Factors on Female Sexual Dysfunction: Schemas and Affect]. Fatores Cognitivos e Emocionais na Disfunção Sexual Feminina: Esquemas e Afeto.

        Thesis / Dissertation

          * 2013, PhD, [Psychosocial determinants of sexual pain in Portuguese women]. Determinantes Psicossociais da Dor Sexual Na Mulher Portuguesa.
          * 2008, Master, [The Role of Cognitive-Emotional Factors in Female Sexual Dysfunctions: Schemas and Affect]. O Papel dos Factores Cognitivo-Emocionais nas Disfunções Sexuais Femininas: os Esquemas e o Afecto.

        Book chapter

          * 2023, Perturbação de dor genitopélvica/penetração, Intervenção psicológica em sexologia clínica, Pactor
          * 2015, [Pain as a Sexual Disorder]. A Dor como Perturbação Sexual. , A Dor: Uma Visão Multidisciplinar , 1, 1, Coisas de Ler
          * 2014, [Sexual Pain: Contextualization, Assessment and Treatment]. Dor Sexual: Contextualização, avaliação e Tratamento., Terapia da Sexualidade:Temas base para actuação , 2, 1, Zangodini Editora

        Conference paper

          * [Women’s affective and cognitive determinants of subjective and physiological sexual arousal in response to sexual stimuli]. Determinantes afetivos e cognitivos das mulheres da excitação sexual subjetiva e fisiológica em resposta a estímulos sexuais.
          * [Women’s affective and cognitive determinants of subjective and physiological sexual arousal in response to sexual stimuli]. Determinantes afetivos e cognitivos das mulheres da excitação sexual subjetiva e fisiológica em resposta a estímulos sexuais.
          * [Women¿'s Affective, Cognitive, and Sexual Response to Different Types of Films and Instructions During Exposure to Erotica]. Resposta Afetiva, Cognitiva e Sexual das Mulheres a Diferentes Tipos de Filmes e Instruções Durante a Exposição ao Erótico.
          * [Women's Sexuality & Mindfulness]. Sexualidade Feminina e Mindfulness., 10thCongress of the European Federation of Sexology (FES)
          * [Women's Affective, Cognitive, and Sexual Response to Different Types of Films and Instructions during Exposure to Erotica]. Resposta Afetiva, Cognitiva e Sexual das Mulheres a Diferentes Tipos de Filmes e Instruções Durante a Exposição ao Erotismo.
          * [Trait-affect and sexual functioning: differences between women with and without sexual dysfunction]. Afeto-traço e funcionamento sexual: diferenças entre mulheres com e sem disfunção sexual.
          * [Trait-Affect, Psychopathology and Sexual Functioning: Differences between Sexually Functional and Dysfunctional Men and Women]. Traço-Afeto, Psicopatologia e Funcionamento Sexual: Diferenças entre Homens e Mulheres Sexualmente Funcionais e Disfuncionais., 10thCongress of the European Federation of Sexology (FES)
          * [Trait-Affect and Sexual Functioning in Women: The Mediational Role of Psychopathology]. Traço-Afeto e Funcionamento Sexual em Mulheres: O Papel Mediador da Psicopatologia., 20th World Congress for Sexual Health
          * [The Role of the Cognitive-Emotional Factors on Female Sexual Dysfunction: Schemas and Affect]. O Papel dos Fatores Cognitivo-Emocionais na Disfunção Sexual Feminina: Esquemas e Afetos., V World Congress of Behavioral and Cognitive Therapies.
          * [The Role of Trait-Affect, Sexual Beliefs, and Automatic Thoughts on Women’s Sexual Pain]. O Papel do Afeto-Traço, Crenças Sexuais e Pensamentos Automáticos na Dor Sexual das Mulheres.
          * [The Role of Self-Esteem, Dyadic Adjustment and Sexual Functioning in Women With Sexual Pain]. O Papel da Auto-Estima, Ajuste Diádico e Funcionamento Sexual em Mulheres com Dor Sexual.
          * [The Role of Mindfulness Facets in Women’s Sexual Pain]. O papel das facetas da atenção plena na dor sexual das mulheres., 11o Congresso da Federação Europeia de Sexologia (EFS)
          * [The Role of Emotions and Psychopathology on Women’s and Men’s Sexual Functioning]. O Papel das Emoções e da Psicopatologia no Funcionamento Sexual de Mulheres e Homens.
          * [The Role of Cognitive-Emotional Factors in Female Sexual Dysfunctions: Schemas and Affect]. O Papel dos Fatores Cognitivo-Emocionais nas Disfunções Sexuais Femininas: os Esquemas e o Afecto., 1as Jornadas em Psicologia Clínica na Universidade de Trás-os-Montes e Alto Douro
          * [The Role of Beliefs, Sociosexuality, Affect, and Automatic Thoughts on Men’s Sexual Response to Erotic]. O Papel das Crenças, Sociossexualidade, Afeto e Pensamentos Automáticos na Resposta Sexual dos Homens ao Erótico.
          * [The Role of Attention, Catastrophizing and Perception of Significant Other Responses in Sexual Pain]. O papel da atenção, catastrofização e percepção de outras respostas significativas na dor sexual.
          * [The Influence of Cognitive-Emotional Factors on Female Sexual Dysfunction]. A Influência de Fatores Cognitivo-Emocionais na Disfunção Sexual Feminina.
          * [Subjective sexual arousal and emotional responses to erotica in a sample of undergraduate Portuguese students]. Excitação sexual subjetiva e respostas emocionais ao erotismo em uma amostra de estudantes universitários portugueses., II Annual Meeting of IBILI
          * [Subjective sexual arousal and emotional responses to erotica in a sample of undergraduate Portuguese students]. Excitação sexual subjetiva e respostas emocionais ao erotismo em uma amostra de estudantes universitários portugueses.
          * [Psychosocial Factors of Sexual Pain in Women: An Exploratory Study]. Fatores Psicossociais da Dor Sexual na Mulher: um Estudo Exploratório., I Congresso Investigadores em Psicologia - Spin-Offs e Desafios Profissionais em Tempos de Crise.
          * [Psychosocial Determinants of Sexual Pain in Portuguese Women]. Determinantes Psicossociais da Dor Sexual na Mulher Portuguesa.
          * [Psychosocial Determinants of Sexual Pain in Portuguese Women: An Exploratory Study]. Determinantes Psicossociais da Dor Sexual em Mulheres Portuguesas: Um Estudo Exploratório., 20th World Congress for Sexual Health
          * [Predictors of Men’s Sexual Response to Erotica: the Role of Beliefs, Sociosexuality, Sexual Inhibition/Excitation, Affect, and Automatic thoughts]. Preditores da resposta sexual dos homens ao erotismo: o papel das crenças, sociossexualidade, inibição/excitação sexual, afeto e pensamentos automáticos.
          * [Predictors of Men’s Sexual Response to Erotica: the Role of Beliefs, Sociosexuality, Sexual Inhibition/Excitation, Affect, and Automatic thoughts]. Preditores da Resposta Sexual dos Homens ao Erotismo: o Papel das Crenças, Sociossexualidade, Inibição/Excitação Sexual, Afeto e Pensamentos Automáticos., 10th Congress of the European Federation of Sexology (FES)
          * [Mindulness and Sexual Pain]. Mindfulness e Dor Sexual.
          * [Gender differences in subjective sexual response to erotic films: An exploratory study with undergraduate Portuguese students]. Diferenças de género na resposta sexual subjetiva a filmes eróticos: um estudo exploratório com estudantes de graduação portuguesa.
          * [Gender differences in sexual arousal and emotional response to erotica: The effect of type of film and instructions]. Diferenças de gênero na excitação sexual e na resposta emocional ao erotismo: O efeito do tipo de filme e instruções.
          * [Gender differences in sexual arousal and emotional response to erotica: The effect of type of film and instructions]. Diferenças de género na excitação sexual e resposta emocional ao erotismo: o efeito do tipo de filme e instruções., International Academy of Sex Research (IASR)
          * [Gender Differences in Sexual Arousal and Emotional Response to Erotica: the Effect of Type of Film and Instructions]. Diferenças de gênero na excitação sexual e na resposta emocional ao erotismo: o efeito do tipo de filme e das instruções.
          * [Female Sexual Dysfunction: The Role of Schemas and Affect]. Disfunção Sexual Feminina: O Papel dos Esquemas e Afeto., 10thCongress of the European Federation of Sexology (EFS)
          * [Erectile Dysfunction Treatment: CBT versus Medication – Preliminary Findings]. Tratamento da Disfunção Erétil: TCC versus Medicação – Achados Preliminares.
          * [Cognitive-Emotional Factors and Sexual Pain in Women]. Fatores Cognitivos-Emocionais e Dor Sexual em Mulheres.
          * [Cognitive and Emotional Factors on Female Sexual Dysfunction: Schemas and Affect]. Fatores Cognitivos e Emocionais na Disfunção Sexual Feminina: Esquemas e Afeto.
          * [Cognitive Schemas and Sexual Dysfunction in Women]. Esquemas Cognitivos e Disfunção Sexual em Mulheres.

        Conference abstract

          * 2023, SAÚDE MENTAL NO ENSINO SUPERIOR: VANTAGENS E DESAFIOS NA IMPLEMENTAÇÃO DE PROGRAMAS BASEADOS NO MINDFULNESS, XVI Congresso Internacional de Psicologia Clínica
          * 2023, PROMOÇÃO DA SAÚDE MENTAL NO ENSINO SUPERIOR: PROGRAMA PLENAMENTE, XVI Congresso Internacional de Psicologia Clínica
          * 2023, O PAPEL DA AUTOCOMPAIXÃO NOS NÍVEIS DE BEM-ESTAR EM ESTUDANTES DO ENSINO SUPERIOR, XVI Congresso Internacional de Psicologia Clínica
          * 2019, Posterior Insula: relationship between visual attention and genital response, 24th Congress of the World Association for Sexual Health (WAS) & XII Congreso Nacional de Educación Sexual y Sexología
          * 2019, Altered Functional Connectivity of the Anterior Insula in Psychogenic Erectile Dysfunction, 24th Congress of the World Association for Sexual Health (WAS) & XII Congreso Nacional de Educación Sexual y Sexología
          * 2017, Frontoparietal And Salience Networks Alterations In Psychogenic Erectile Dysfunction., 23º Congresso da World Association for Sexual Health
          * 2017, Brain in Pain: Body Mapping, Pain Visualisation and Mapping the Invisible, 23º Congresso da World Association for Sexual Health, em Praga.
          * 2017, Brain Dynamics Of The Inhibition Of Genital Response In Psychogenic Erectile Dysfunction. , 23º Congresso da World Association for Sexual Health

        Conference poster

          * 2023, The Impact of Sexual Subjectivity and Personality Factors on Women With Sexual Pain., IV CINEICC International Congress
          * 2023, Mental Health in Higher Education Students: from Prevention to treatment, IV CINEICC International Congress
          * 2023, Anthesis program: a randomized controlled trial of an Internet-based intervention for sexual distress., 7th Conference European Society for Research on Internet Interventions
          * 2023, An Invitation to Dialogue about Anthesis: a randomized controlled trial of an Internet-based Intervention for sexual, the 7th Conference European Society for Research on Internet Interventions (ESRII),
          * 2022, The Impact of Sexual Attraction and Self-Efficacy in the Presence of Female Sexual Pain. , 52nd European Association for Behavioural and Cognitive Therapies - EABCT 2022
          * 2022, Sexual Attraction and Sexual Self-Efficacy in Women with Sexual Pain. , 52nd European Association for Behavioural and Cognitive Therapies - EABCT 2022
          * 2022, Psychological Factors Associated with Premature Ejaculation. , 16th Congress of the European Federation of Sexology
          * 2022, Personality Factors and Attachment Styles in Men with Premature Ejaculation, 52nd European Association for Behavioural and Cognitive Therapies - EABCT 2022
          * 2022, Influence of Sexual Distress on Sexual Functioning and Sexual Satisfaction in The Portuguese Female Population, 16th Congress of the European Federation of Sexology,
          * 2022, Female sexual self-efficacy in the Portuguese population: A validation study, 16th Congress of the European Federation of Sexology,
          * 2021, [The Big O: Comparing Anorgasmic, Multi-orgasmic and Single Orgasmic Women on Mindfulness, Sensation Seeking, Body Image and Partner Communication]. The Big O: Comparando mulheres anorgásmicas, multiorgásmicas e orgásticas solteiras em atenção plena, busca de sensações, imagem corporal e comunicação com parceiros.
          * 2021, [Female Sexual Pain: Associated sociodemographic and Biopsychosocial Variables]. Dor Sexual Feminina: Variáveis Sociodemográficas e Biopsicossociais Associadas.
          * 2019-10, [The female orgasm: sexual inhibition/excitation, sexual functioning and relationship factors]. O orgasmo feminino: inibição/excitação sexual, funcionamento sexual e fatores de relacionamento., 24th Congress of the World Association for Sexual Health (WAS) & XII Congreso Nacional de Educación Sexual y Sexología
          * 2019-10, [The Big O: Discovering the differences between multi-orgasmic, single-orgasmic and anorgasmic women]. The Big O: Descobrindo as diferenças entre mulheres multiorgásmicas, monorgásmicas e anorgásmicas., 24th Congress of the World Association for Sexual Health (WAS) & XII Congreso Nacional de Educación Sexual y Sexologia
          * 2019-07, [What happens when you throw Cognition in the mix? A bigger picture for Female Orgasm]. O que acontece quando colocamos a Cognição à mistura? Uma imagem maior do orgasmo feminino., WCBCT 2019
          * 2019-07, [What Makes The Difference Between Female Orgasmic Experiences? Analyzing The Differences Between Multi-orgasmic, Single-orgasmic and Anorgasmic Women]. O que faz a diferença entre experiências orgásmicas femininas? Analisando as diferenças entre mulheres multiorgásmicas, monorgásmicas e anorgásmicas., WCBCT 2019
          * 2019-07, [Validation of the Significant Other Response to Sexual Pain Scale in Portugal]. Validação da Escala de Outras Respostas Significativas à Dor Sexual em Portugal., WCBCT 2019
          * 2019-07, [Sociodemographic and Biopsychosocial Factors in Women with Sexual Pain]. Fatores Sociodemográficos e Biopsicossociais em Mulheres com Dor Sexual., WCBCT 2019
          * 2019, [The Path of Sexual Pleasure and Female Orgasm: Individual and Relational Aspects]. O Caminho do Prazer Sexual e o Orgasmo Feminino: Aspectos Individuais e Relacionais., 24th Congress of the World Association for Sexual Health (WAS) & XII Congreso Nacional de Educación Sexual y Sexología
          * 2019, [Psychometric Characteristics of Sexual Five-Facet Mindfulness Questionnaire in a Portuguese Sample]. Características Psicométricas do Questionário de Mindfulness Sexual de Cinco Faces em uma Amostra Portuguesa.
          * 2019, [Are Chronic Pain and Sex Incompatible?]. A dor crônica e o sexo são incompatíveis?, I International Seminar of The Doctoral Programme In Human Sexuality – Past, Present & Future of Sexuality Research,
          * 2018-10, [What sociodemographic and biopsychosocial variables are involved in female sexual pain?]. Que variáveis sociodemográficas e biopsicossociais estão envolvidas na dor sexual feminina?, 24th Congress of the World Association for Sexual Health (WAS) & XII Congreso Nacional de Educación Sexual y Sexología
          * 2018-10, [Disentangling Female Orgasm with braids: the interplay among determinants]. Desembaraçando o orgasmo feminino com tranças: a interação entre os determinantes., 24th Congress of the World Association for Sexual Health (WAS) & XII Congreso Nacional de Educación Sexual y Sexología
          * 2018, [What if there's more to Female Orgasm? The interplay of Cognitive, Affective and Physical determinants]. E se houver mais no orgasmo feminino? A interação dos determinantes cognitivos, afetivos e físicos., I International Seminar of The Doctoral Programme In Human Sexuality – Past, Present & Future of Sexuality Research,
          * 2018, [The Role of Sexual Inhibition/Excitation and the Quality of Relationships in Female Orgasm]. O Papel da Inibição/Excitação Sexual e a Qualidade dos Relacionamentos no Orgasmo Feminino., I International Seminar of The Doctoral Programme In Human Sexuality – Past, Present & Future of Sexuality Research, Porto, Portugal.
          * 2018, [Self-compassion, body image, emotion regulation and sexual and relational satisfaction on female sexual pain: An exploratory comparative analysis]. Autocompaixão, imagem corporal, regulação emocional e satisfação sexual e relacional na dor sexual feminina: uma análise comparativa exploratória., 44th Annual Meeting of the International Academy of Sex Research
          * 2018, [Psychosocial Determinants of Female Sexual Pain: an exploratory comparative analysis on the role of self-compassion, body image, emotion regulation and sexual and relational satisfaction]. Determinantes psicossociais da dor sexual feminina: uma análise comparativa exploratória sobre o papel da autocompaixão, imagem corporal, regulação emocional e satisfação sexual e relacional., 14th Congress of the European Federation of Sexology,
          * 2018, [Psychosocial Determinants of Female Multiple and Single Orgasms]. Determinantes Psicossociais dos Orgasmos Múltiplos e Únicos Femininos., 44th Annual Meeting of the International Academy of Sex Research,
          * 2016, [Sexually-related thoughts mediate the association between Sexual dysfunction and Pain intensity in Men with genital pain]. Pensamentos sexualmente relacionados mediam a associação entre disfunção sexual e intensidade da dor em homens com dor genital.
          * 2016, [Pain catastrophizing and sexually-related thoughts in male sexual pain]. Catastrofização da dor e pensamentos sexualmente relacionados na dor sexual masculina., CiênciaViva 2016 & 42nd Annual Meeting of the International Academy of Sex Research
          * 2016, [Comparing brain networks in men with and without psychogenic erectile dysfunction usinf fMRI: A pilot study]. Comparando as redes cerebrais em homens com e sem disfunção erétil psicogênica usando fMRI: Um estudo piloto., 42nd Annual Meeting of the International Academy of Sex Research
          * 2015, [Sexual Functioning and Pain Intensity in men with genital pain: The mediation effect of sexually-related thoughts]. Funcionamento Sexual e Intensidade da Dor em Homens com Dor Genital: O Efeito Mediador de Pensamentos Relacionados à Sexualidade., III Congresso Internacional do CINEICC & III Congresso Nacional da APTC
          * 2015, [Psychosocial Factors in Male Sexual Pain: The Role of Catastrophizing and Automatic Thoughts During Sexual Activity]. Fatores Psicossociais na Dor Sexual Masculina: O Papel da Catastrofização e dos Pensamentos Automáticos Durante a Actividade Sexual.
          * 2013, [The Role of Self-Esteem, Dyadic Adjustment and Sexual Functioning in Women With Sexual Pain]. O Papel da Auto-Estima, Ajuste Diádico e Funcionamento Sexual em Mulheres com Dor Sexual.
          * 2013, [Self-Esteem, Dyadic Adjustment and Sexual Functioning in Women with Sexual Pain]. Autoestima, Ajuste Diádico e Funcionamento Sexual em Mulheres com Dor Sexual.
          * 2013, [Attention, Pain Catastrophizing and Perception of Significant Other Responses in Women with Sexual Pain]. Atenção, Catastrofização da Dor e Percepção de Outras Respostas Significativas em Mulheres com Dor Sexual.
          * 2012, [The Role of Trait-Affect, Sexual Beliefs, and Automatic Thoughts on Women’s Sexual Pain]. O Papel do Afeto-Traço, Crenças Sexuais e Pensamentos Automáticos na Dor Sexual das Mulheres.
          * 2012, [The Role of Mindfulness Facets in Women’s Sexual Pain]. O papel das facetas da atenção plena na dor sexual das mulheres.
          * 2012, [Mindulness and Sexual Pain]. Mindfulness e Dor Sexual.
          * 2012, [Cognitive-Emotional Factors and Sexual Pain in Women]. Fatores Cognitivos-Emocionais e Dor Sexual em Mulheres.
          * 2011, [Women’s subjective and physiological sexual response to erotica: The role of affective and cognitive determinants]. A resposta sexual subjetiva e fisiológica das mulheres ao erotismo: o papel dos determinantes afetivos e cognitivos., 20th WAS World Congress for Sexual Health
          * 2011, [Trait-Affect and Sexual Functioning in Women: The Mediational Role of Psychopathology]. Traço-Afeto e Funcionamento Sexual em Mulheres: O Papel Mediador da Psicopatologia.
          * 2011, [Psychosocial Determinants of Sexual Pain in Portuguese Women: An Exploratory Study]. Determinantes Psicossociais da Dor Sexual em Mulheres Portuguesas: Um Estudo Exploratório.
          * 2010, [Women’s affective and cognitive determinants of subjective and physiological sexual arousal in response to sexual stimuli]. Determinantes afetivos e cognitivos das mulheres da excitação sexual subjetiva e fisiológica em resposta a estímulos sexuais., II Annual Meeting of IBILI& Academy of Sex Research (IASR)
          * 2010, [The Role of Beliefs, Sociosexuality, Affect, and Automatic Thoughts on Men’s Sexual Response to Erotic]. O Papel das Crenças, Sociossexualidade, Afeto e Pensamentos Automáticos na Resposta Sexual dos Homens ao Erótico.
          * 2010, [Subjective sexual arousal and emotional responses to erotica in a sample of undergraduate Portuguese students]. Excitação sexual subjetiva e respostas emocionais ao erotismo numa amostra de estudantes universitários portugueses., II Annual Meeting of IBILI & International Academy of Sex Research (IASR)
          * 2010, [Predictors of Men’s Sexual Response to Erotica: the Role of Beliefs, Sociosexuality, Sexual Inhibition/Excitation, Affect, and Automatic thoughts]. Preditores da Resposta Sexual dos Homens ao Erotismo: o Papel das Crenças, Sociossexualidade, Inibição/Excitação Sexual, Afeto e Pensamentos Automáticos.
          * 2010, [Gender differences in sexual arousal and emotional response to erotica: The effect of type of film and instructions]. Diferenças de género na excitação sexual e resposta emocional ao erotismo: o efeito do tipo de filme e instruções., II Annual Meeting of IBILI & International Academy of Sex Research (IASR)
          * 2010, [Cognitive Schemas and Sexual Dysfunction in Women]. Esquemas Cognitivos e Disfunção Sexual em Mulheres., 6th World Congress of Cognitive Behavior Therapy
          * 2007, [Cognitive and Emotional Factors in female sexual dysfunctions: Schemas and Affect]. Fatores Cognitivos e Emocionais nas Disfunções Sexuais Femininas: Esquemas e Afetos.

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona