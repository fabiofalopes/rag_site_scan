# Response for https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
          PT: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052 EN: https://www.ulusofona.pt/en/teachers/filipe-soares-branco-da-costa-luz-2052
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
        fechar menu : https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/filipe-soares-branco-da-costa-luz-2052
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Filipe Soares Branco Da Costa Luz

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p2052
              fil***@ulusofona.pt
              611F-FE93-68CE: https://www.cienciavitae.pt/611F-FE93-68CE
              0000-0002-3608-8417: https://orcid.org/0000-0002-3608-8417
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/3d95249f-7a01-49b6-841d-cbead56991c8
      : https://www.ulusofona.pt/

        Resume

        Filipe Luz holds a PhD in Communication Sciences by the New University of Lisbon being Associate Professor at School of Communication, Architecture, Arts and Information Technologies of University Lusófona. Filipe Luz has a strong experience at coordination level, being actually the Director of the Erasmus Mundus Joint Master Degree in games: REPLAY, director of the MSc studies "Game Design and Playable Media"; director of "Videogames" BA studies; vice-director of Communication Design BA; and is also member of the direction board of R&D Unit "Hei-Lab - Digital Human Environment Interface Labs". Filipe Luz is External Assessor at doctoral programme "Performative and Media-based Practices" at Stockholm University of Arts (Sweden), participates in academic juries and supervises doctoral and master's thesis. He lectures digital post-production for film, television, games, and animation, and also does research activities in R&D projects of communication science, Design and arts. His work at MovLab (Laboratory of Interactions and Interfaces), where he integrates technologies such as Motion Capture, Animation, VR or Stereoscopic Photography, it's an example of the cross-media projects that evolve him in academic or professional work for the Communication, Cultural and Creative Industries or communication areas. Filipe Luz is the Principal Investigator and Co-Investigator in several International Projects, such as the European Joint Master Degree RE_PLAY (n.101128161, 2023-2028, 4.4M), EPIC-WE (HORIZON-CL2-2022-HERITAGE-01-09 n. 101095058, 2023-26, 3.0M), GameIn (2022.07939.PTDC, 2023-25, 250K), PlayersALL (EXPL/COM-OUT/0882/2021, 2022-23, 60k), TEGA Training the Educators to Facilitate the Teaching and Assessment of Abstract Syllabus by the Use of Serious Games (2020-1-UK01-KA203-079248, 250K), Erasmus+ ID-Games Co-Create assistive games for people with Intellectual Disability to enhance their inclusion (2019-1-EL01-KA204-062517, 250K), Erasmus + Game-Based Learning For Deaf Students (LISBOA-01-0145-FEDER-032022, 250K), Erasmus+ Youth for Youth (2020-2-HU01-KA205- 079126, 250K), among others.

        Graus

            * Licenciatura
              Design Industrial
            * Outros
              Alias Maya
            * Outros
              Orad Cyberset
            * Postgraduate Certificate
              Discreet Combustion 3
            * Curso de Especialização Tecnológica
              Avid Nitris DS
            * Outros
              Especialização em Virtools 3.0
            * Curso de Especialização Tecnológica
              Vicon Iq (Motion Capture)
            * Curso de Especialização Tecnológica
              Motion Builder
            * Doutoramento
              Ciências da Comunicação
            * Outros
              Games Creator Odissey (Rational Game Design)
            * Curso de Especialização Tecnológica
              Maya Essentials 6: Lights and Rendering
            * Curso de Especialização Tecnológica
              Photorealistic Lighting with Maya and Nuke
            * Curso de Especialização Tecnológica
              Nuke 6.3 New Futures
            * Curso de Especialização Tecnológica
              Nuke 5.0
            * Curso de Especialização Tecnológica
              Maya Essentials 2: Polygonal Modeling Techniques
            * Curso de Especialização Tecnológica
              Fundamentals of Video: Cameras and Shooting
            * Licenciatura
              Design Industrial
            * Doutoramento
              Doutoramento em Ciências da Comunicação. Especialidade em Cultura Contemporânea e Novas Tecnologias
            * Mestrado
              Ciências da Comunicação
            * Doutoramento
              Ciências da Comunicação

        Publicações

        Artigo em revista (magazine)

          * 2021, Impactos do ensino remoto no ensino superior privado em Portugal: competências socioemocionais e digitais
          * 2012-11-27, O "Berço da Vida" em S3D, Produção Profissional

        Edição de número de revista

          * Videogames and narratives, 2
          * International Journal of Games and Social Impact, 1(1), 1

        Artigo em revista

          * 2023-09-29, The Novelty of Collaboration: High School Students Learning and Enjoyment Perceptions When Playing Cooperative Modern Board Games, European Conference on Games Based Learning
          * 2023-09-29, Barriers and Hindrances to the Effective Use of Games in Education: Systematic Literature Review and Intervention Strategies, European Conference on Games Based Learning
          * 2023-06-15, Game-Based Learning in Higher Education Using Analogue Games, International Journal of Film and Media Arts
          * 2023-06-06, Providing office workers with height-adjustable workstation to reduce and interrupt workplace sitting time: protocol for the Stand Up for Healthy Aging (SUFHA) cluster randomized controlled trial, Trials
          * 2022-03-23, 2022- Impactos do ensino remoto no ensino superior privado em Portugal: competências socioemocionais e digitais, Revista Lusófona de Educação
          * 2022, A cidadania digital e a Covid-19: perceções de estudantes do ensino superior em Portugal., Humanismo e Desafios da Cidadania
          * 2021-11-25, Soundspace VR: spatial navigation using sound in virtual reality, Virtual Reality
          * 2021, The Challenges and Opportunities of Analogue Game-Based Learning
          * 2021, M. Covid-19 e ensino remoto: perceções de estudantes do ensino superior em Portugal , JUS.XXI
          * 2020-12-18, INFLUENZA: A Board Game Design Experiment on Vaccination, Simulation & Gaming
          * 2020-08-19, Adaptive Non-Immersive VR Environment for Eliciting Fear of Cockroaches: A Physiology-Driven Approach Combined with 3D-TV Exposure, International Journal of Psychological Research
          * 2020-08, Developing a participatory game creation e-course in the field of Intellectual Disability, 2020 IEEE Conference on Games (CoG)
          * 2020-06, GAMES AND CULTURE: NOTES ON DESIGN, ART AND EDUCATION, INTERNATIONAL JOURNAL OF FILM AND MEDIA ARTS
          * 2020, Influenza : a board game design experiment on vaccination
          * 2020, Adaptive Non-immersive VR Environment for eliciting fear of cockroaches: a biofeedback approach combined with 3D-TV, International journal of psychological research
          * 2018-09-01, A Apropriação nos novos media e a (I)maturidade dos videojogos, Revista Lusófona de Educação
          * 2016-02, Fotografia Estereoscópica do Séc. XIX, Arte, Tecnologia, Comunicação
          * 2016, Animation Documentaries and Reality Cross-Boundaries, International Journal of Film and Media Arts
          * 2014-07-14, A Aparência de Real em Documentários Animados, Interact Revista Online de Arte, Cultura e Tecnologia
          * 2010, Digital animation: Repercussions of new media on traditional animation concepts, Lecture Notes in Computer Science (including subseries Lecture Notes in Artificial Intelligence and Lecture Notes in Bioinformatics)
          * 2010, Digital Animation: Repercussions of New Media on Traditional Animation Concepts, Edutainment 2010: Springer-Verlag
          * 2009, Videojogos: narrativas, espectáculo e imersão, VIII Simpósio Brasileiro de Jogos e Entretenimento Digital - Cultura
          * 2009, Robosonic: Randomness-Based Manipulation of Sounds Assisted by Robots, Intelligent Technologies for Interactive Entertainment
          * 2008, Realidade Aumentada para Espaços Interactivos, Engenharia Informática & Sistemas de Informação
          * 2008, Agentes ou Jogadores? Os monstros estranhamente reais dos jogos de computadores, Prisma.com
          * 2006, Design Digital: Do traço ao pixel, Design» in Caleidoscópio – Revista de Comunicação e Cultura

        Tese / Dissertação

          * 2013, Doutoramento, O Movimento na animação para uma reclassificação digital
          * 2006, Mestrado, Mediação Digital como Jogo:Transparência e Imersão

        Livro

          * 2009, Jogos de Computador e Cinema: Avatares, narrativas e efeitos, 1, Luz, Filipe Soares Branco da Costa, Edições universitárias Lusófona

        Capítulo de livro

          * 2020, Introductory Note, Revista Lusófona de Educação, 46, 46, Publicações Universitárias Lusófona
          * 2018, Nota Introdutória, REVISTA LUSÓFONA DE EDUCAÇÃO, 40, 40, Publicações Universitárias Lusófona
          * 2012, Sf e Animé: Os Monstros Encantadores do Ground Zero, Cibercultura e Ficção, Documenta
          * 2012, SF e Animé, Os monstros encantadores do pós-guerra
          * 2005, Virtual Scenography - The making of digital environments, New Media Production: Issues and Strategies, Cofac

        Edição de livro

          * 2021, Universidade Lusófona

        Relatório

          * 2020, People with Intellectual Disability in Portugal Report, http://videojogos.ulusofona.pt/pdfs/25_Sousa_Luz_ID_GamesReport.pdf
          * 2008, RELATÓRIO DE PROGRESSO, http://movlab.ulusofona.pt/evolutio/

        Manual

          * 2012, Tutoriais Pós-Produção Nuke
          * 2011, Tutoriais de Pós-Produção Vídeo
          * 2011, Tutoriais de Animação
          * 2008, Tutoriais de Motion Capture
          * 2006, Tutoriais de Virtools
          * 2004, Tutoriais de Modelação e Animação 3d

        Recurso online

          * 2017-10, Lusófona Videogames GitHub Page, https://github.com/VideojogosLusofona

        Artigo em conferência

          * Visual effects for film and videogames: From nineteen-century stereo cards to the newest digital mattepainting, Stereo and Immersive Media 2015
          * The Digitalization of Analogue Stereo Photographs and the Creation of the Digital Stereo Archive, Archiving 2019: Digitization, Preservation and Access
          * THE IMPACT OF PERCEIVED CHALLENGE ON NARRATIVE IMMERSION IN RPG VIDEO GAMES: A PRELIMINARY STUDY, 16th International Conference on Game and Entertainment Technologies 2023
          * Searching for the Awe Effect, Archaeologies of Media and Film
          * SF e Animé: Os monstros encantadores do período pós-guerra. [no Prelo], Colóquio Ficção e Cibercultura
          * Robosonic: Manipulação de Sons Aleatória Assistida por Robots, 6º Sopcom, Sociedade dos Media: Comunicação, Política e Tecnologia
          * Realism in Gameplay: Digital Fiction and Embodiment, 2nd ACM Workshop on Story Representation, Mechanism and Context - SRMC08
          * Palácio de Cristal Londres, obra de Arthur Benarus, A Terceira Imagem - A Fotografia Estereoscópica em Portugal e o Desejo do 3D
          * O vale da estranheza, notas sobre o realismo das criaturas “vivas” nos jogos digitais e a sua relação com o jogador, ARTECH 2008 | Nas Fronteiras do Imaginário
          * O Movimento desfragmentado da Animação Japonesa: A ilusão animé, 7º Sopcom - Meios Digitais e Indústrias Criativas Os Efeitos e os Desafios da Globalização
          * Jogadores ou espectadores? Pontos de vista no cinema e nos videojogos, Videojogos 2009
          * Fotografia Estereoscópica do Séc.XIX: As experiências de efeito de espectáculo nas origens da fotografia e do cinema, AVANCA | CINEMA 2015
          * Ensino de Videojogos em Portugal: Promover o talento, a investigação e a indústria, 1º SEVj – Seminário sobre Ensino de Videojogos.
          * Digital Film Post-Production Remediates Stereoscopic Photography from 1860, ECREA, 2014, Lisboa - Communication for Empowerment: Citizens, Markets, Innovations
          * Augmented Reality for Games, 3rd International Conference on Digital Interactive Media in Entertainment and Arts (DIMEA 2008)
          * Animação Digital: Reflexos dos novos médias nos conceitos tradicionais de animação, 8º Lusocom, Comunicação, Espaço Global e Lusofonia
          * A construção da percepção em imagem digital e o desenvolvimento de novas formas de literacia visual, 6º Sopcom, Sociedade dos Media: Comunicação, Política e Tecnologia
          * 2023-07-09, GameIN: Proposing Methodological Disruptions in the Study of Inclusive Games, IAMCR 2023 Lyon - Inhabiting the planet: Challenges for media, communication and beyond
          * 2023, Playing Pong without a TV Screen: an Alternative controller game
          * 2022-11-21, Improving the CS Curriculum of a Top-Down Videogames BA
          * 2022-11, AN ACCESSIBLE AND INCLUSIVE FUTURE FOR TABLETOP GAMES AND LEARNING: PARADIGMS AND APPROACHES
          * 2021-07-05, COVID-19 AND REMOTE TEACHING: CHALLENGES FOR POST-PANDEMIC TEACHING?
          * 2021-04-09, REMEDIATION MEDIA: FROM XIX. CENTURY STEREOSCOPIC APPARATUS INTO VFX COMPOSITING, IVGC 2021 – TRANSFORMATIONS OF VISUAL EFFECTS II
          * 2021, Strengthening the Bond Between University and Society through the Promotion of Well-Being and Digital Inclusion in Avances en Educación Superior e Investigación, XVIII FORO INTERNACIONAL SOBRE EVALUACIÓN DE LA CALIDAD DE LA INVESTIGACIÓN Y LA EDUCACIÓN SUPERIOR (FECIES)
          * 2021, GBL for Psychological Intervention Related Skills: What Challenges? What Paths?
          * 2020-12-11, Formação online e capacitação para a utilização, criação e co-criação de jogos como estratégia de inclusão de pessoas com deficiência intelectual: Experiências de um projeto europeu, V Encontro do Obervatório da Deficiência e Direitos Humanos (ODDH) - A deficiência face à crise pandémica: Desafios e respostas
          * 2020-05, Conceção de um e-course sobre processos participativos na criação de jogos como estratégia de capacitação na área da Deficiência Intelectual. , 5.º Encontro sobre Jogos e Mobile Learning, EJML 2020.
          * 2017, The spectacle of stereoscopy: historical analysis and inputs to the creation of a digital archive of analog stereoscopic photography , Stereo visual culture
          * 2017, Biomechanics and Animation, IX Congresso Sopcom
          * 2012, Deleite no obsoleto: o hype vintage da estereoscopia, 7º Sopcom - Meios Digitais e Indústrias Criativas Os Efeitos e os Desafios da Globalização
          * 2008, Gouveia et al., "Uncanny valley, notes about realism in digital creatures and their relation with players" ["O Vale da Estranheza, notas sobre o realismo das criaturas "vivas" nos jogos digitais e a sua relação com o jogador"], Artech 2008 Proceedings, 4th International Conference on Digital Arts, nov.08, Universidade Católica do Porto, pp. 150-57., 4th International Conference on Digital Arts, Nov.08, Universidade Católica do Porto

        Resumo em conferência

          * 2021-07-17, Covid-19 e ensino remoto - perceções de estudantes do ensino superior em Portugal, I Congresso Internacional sobre Metodologia: Desafios Metodológicos Atuais (Qualis2021).
          * 2021-07-07, 2021 - Covid-19 e ensino remoto: perceções de estudantes do ensino superior em Portugal, I Congresso Internacional sobre Metodologia: Desafios Metodológicos Atuais (Qualis2021).
          * 2021, Designing a therapeutic game for maximized entertainment, 25th Annual International CyberPsychology, CyberTherapy & Social Networking Conference (CYPSY25)
          * 2020, Virtual museum to promote accessibility to art and cultural heritage: quantitative study on user experience within a virtual reality task, 13th International Conference on Disability, Virtual Reality & Associated Technologies, ICDVRAT 2020
          * 2019-05, O Jogo como ferramenta pedagógica para o educador social - um estudo exploratório, Congresso HDHCG 2019
          * 2018-04-19, Biofeedback Game Design, Play2Learn 2018

        Poster em conferência

          * 2019, Perim, C., Gonçalves, M., Luz, Filipe (2019). Gamification as a pedagogical tool for Social Education classes, Milt: Media Literacy for Leaving Together

        Prefácio / Posfácio

          * 2023, INTERNATIONAL JOURNAL OF GAMES AND SOCIAL IMPACT

        Exposição artística

          * 2008, Videoclip Bad Mirror, Galiza(Santiago de Compostela)

        Programa de rádio / tv

          * 2007-04-21, Cenografia Virtual, Dois (RTP 2)

        Gravação vídeo

          * 2013, O Meu Avô, COFAC
          * 2011, Tempestade
          * 2010, N@vegador, Universidade Lusófona de Humanidades e Tecnologias
          * 2010, Ao Deus Dará - Videoclip
          * 2009, Gabiru
          * 2007, Tonight - videoclip, Banda - Micro Audio Waves
          * 2007, Down by Flow - Videoclip, Micro Audio Waves

        Arte visual

          * Premiere
          * Outono (Vfx Shot)
          * Misteriosa Velocidade - Videoclip
          * Carlos Relvas Studio VR - The first photographic studio of Carlos Relvas
          * Bridion - Sugammadex
          * Bad Mirror - Videoclip
          * Alarga a tua vida - Anúncio TV
          * A rainha do ferro velho - Anúncio TV
          * A Escolinha do Jeremias

        Outra produção

          * 2014, Vice-Presidente da Assembleia Geral da Sociedade Portuguesa de Ciências dos Videojogos
          * 2014, Tese de Doutoramento - O Movimento na animação para uma reclassificação digital
          * 2014, DODU - Papel de Natal (Trabalho de Pós-produção/DCP), Manutenção de obra artística
          * 2009, Vem nadar com o Gabiru, Software
          * 2009, O meu Galo Gabiru, ULHT
          * 2008, Perfect Shift, Software
          * 2008, Bumper Bob, Software
          * 2005, Teses de Mestrado - Mediação Digital Como Jogo: Transparência e imersão
          * 2005, Em Fractura-Terminal, Manutenção de obra artística
          * 2005, Des (a) parecer - Graça Sarsfield, Manutenção de obra artística
          * 2005, Cola - colecção de trabalhos audiovisuais da Lusófona : ficção, ULHT
          * 2005, Cola - colecção de trabalhos audiovisuais da Lusófona : Experimentação, ULHT

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona