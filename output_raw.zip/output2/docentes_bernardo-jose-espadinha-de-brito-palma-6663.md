# Response for https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
          PT: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663 EN: https://www.ulusofona.pt/en/teachers/bernardo-jose-espadinha-de-brito-palma-6663
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
        fechar menu : https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/bernardo-jose-espadinha-de-brito-palma-6663
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Palma Bb E Brito Palma B

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6663
              ber***@ulusofona.pt
              B715-C901-1A15: https://www.cienciavitae.pt/B715-C901-1A15
              0000-0002-4230-9802: https://orcid.org/0000-0002-4230-9802
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/4bcff20d-4a2b-4d9a-ac6b-dae71b1e27db
      : https://www.ulusofona.pt/

        Resume

        Bernardo Brito Palma has a PhD in Molecular Toxicology. He is Assistant Professor at Escola de Ciências e Tecnologias da Saúde (ECTS), Universidade Lusófona. He's responsible for the subject of Genetics in the degree of Nutrition Sciences and for the subjects of Human Genetics and Clinical Biochemistry for Pharmaceutical Sciences Master degree. He is a Research colaborator at Center for Biosciences & Health Technologies (CBIOS). He also exerts functions in the dinamization and development of the knowledge transfer center (KTC) at the ECTS.

        Graus

            * Doutoramento
              Chemistry and Pharmaceutical Sciences, Molecular Toxicology
            * Licenciatura
              Licenciatura em Bioquímica
            * Outros
              CAP - Curso de Aptidão Profissional
            * Outros
              A Norma NP EN ISO/IEC 17025:2018
            * Outros
              Drug Disposition & Safety Assessment
            * Pós-Graduação
              Introdução à Toxicologia
            * Outros
              Formação de Liderança em Segurança, Valores e Crenças
            * Outros
              Saber E´STAR em Segurança - Formação de Formadores
            * Outros
              High-throughput (HT) Drug Metabolism/Disposition
            * Outros
              Temas Atuais em Boas Práticas de Laboratório (BPL)

        Publicações

        Journal article

          * 2023, Food Contact Materials: contaminants and associated risks from the reports published in the RASFF portal (2020-2022), Biomedical and Biopharmaceutical Research
          * 2018-12-06, Probing the Role of the Hinge Segment of Cytochrome P450 Oxidoreductase in the Interaction with Cytochrome P450., International journal of molecular sciences
          * 2016-06-18, Cytochrome P450 expression system for high-throughput real-time detection of genotoxicity: Application to the study of human CYP1A2 variants., Mutation research. Genetic toxicology and environmental mutagenesis
          * 2016-04-14, Prototype Systems Containing Human Cytochrome P450 for High-Throughput Real-Time Detection of DNA Damage by Compounds That Form DNA-Reactive Metabolites., Chemical research in toxicology
          * 2013-02-01, Functional characterization of eight human CYP1A2 variants: the role of cytochrome b5., Pharmacogenetics and genomics
          * 2010-07-01, Alkylating potential of oxetanes., Chemical research in toxicology
          * 2010-02-02, Functional characterization of eight human cytochrome P450 1A2 gene variants by recombinant protein expression., The pharmacogenomics journal
          * 2006-12-08, The stimulatory role of human cytochrome b5 in the bioactivation activities of human CYP1A2, 2A6 and 2E1: a new cell expression system to study cytochrome P450-mediated biotransformation (a corrigendum report on Duarte et al. (2005) Mutagenesis 20, 93-100)., Mutagenesis
          * 2005-04-20, Escherichia coli BTC, a human cytochrome P450 competent tester strain with a high sensitivity towards alkylating agents: involvement of alkyltransferases in the repair of DNA damage induced by aromatic amines., Mutagenesis
          * 2005-02-22, The stimulatory role of human cytochrome b5 in the bioactivation activities of human CYP1A2, 2A6 and 2E1: a new cell expression system to study cytochrome P450 mediated biotransformation., Mutagenesis

        Thesis / Dissertation

          * 2017-10-16, PhD, Development of Human Cytochrome P450 Competent Genotoxicity Tester Bacterial Systems for High Throughput Screening - Functional Characterization of Human Cytochrome P450 1A2 Polymorphic Variants
          * 2003-10-14, Degree, Development of new bacteria strains to study xenobiotics biotransformation: Coexpression of Human Cytchrome b5, Cytchrome P450 and NADPHCytchrome P450 reductase, to use in mutagenicity assays

        Book

          * 2021, Cytochromes P450: Drug Metabolism, Bioactivation and Biodiversity 2.0, Palma, BB, {MDPI

        Conference paper

          * 2005-01-01, The role of protein-protein interactions in the stimulation of the bioactivation of mutagens by CYP1A2, 2A6 and 2E1 in the presence of cytochrome b5: A new cell system to study the cytochrome P450 mediated biotransformation, 14th International Conference on Cytochromes P450: Biochemistry, Biophysics, and Bioinformatics

        Conference abstract

          * 2024-02, Pesticide Residues in Food: A Study of 2022 RASFF Portal Findings, 54th Meeting of the Portuguese Society of Pharmacology, 42nd Meeting of Clinical Pharmacology and 23rd Meeting of Toxicology

        Conference poster

          * 2023-11-25, Exploring the Multifaceted Potential of EPCU in Targeting Tumorigenesis and Hormone Regulation, 2nd Asian Student Council Symposium, ISBC, online
          * 2023-11-12, Occurrence of contaminants in food contact materials: analysis of RASFF reports., 5th European Lifestyle Medicine Congress, Budapest, Hungary.
          * 2023-11-10, Mediterranean food pattern and nutritional status of children/adolescents who practice sports. , 5as Jornadas CBIOS, Lisbon, Portugal.
          * 2023-11-10, Identification and characterization of contaminants of food contact materials and associated risks: Analysis of the reports published in RASFF portal from 2020 to 2022, V Jornadas CBIOS, Lisbon, Portugal.
          * 2020-09-12, Brito Palma, B.; Rueff, J.; Kranendonk, M.; "Prototype Systems Containing Human Cytochrome P450 For High-Throughput Real-Time Detection of Genotoxicity", Environmental Mutagenesis & Genomics Society Virtual Annual Meeting
          * 2019-09-08, Brito Palma, B.; Sardo, I.; Pires, C.; Costa, J.; Palma, D.; Martins, C.; "Comparison of negative control historic data of the Bacterial Reverse Mutation Test (Ames Test): Implications in assays acceptance and results evaluation.", 55th Congress of the European Societies of Toxicology (EUROTOX 2019)
          * 2017-10-02, Brito Palma, B.; Kranendonk, M.; "Development of Human Cytochrome P450 Competent Genotoxicity Tester Bacterial Systems for High Throughput Screening - Functional Characterization of Human Cytochrome P450 1A2 Polymorphic Variants", 3rd Genetics Workshop NOVA Health, Universidade NOVA de Lisboa
          * 2016-05-14, Brito Palma, B.; Kranendonk, M.; "Human Cytochrome P450 competent High-Throughput Test for the Detection of Genotoxic/Electrophilic Reactive Metabolites", 1st NOVA Biomedical Engineering Workshop
          * 2015-10-09, Brito Palma, B.; Kranendonk, M.; "Prototype Development of Human Cytochrome P450 competent High Throughput Test for the Detection of Genotoxic/Electrophilic Reactive Metabolites", 1st Genetics Workshop NOVA Health
          * 2012-06-17, Brito Palma, B.; Silva e Sousa, M.; Urban, P.; Rueff, J.; Kranendonk, M.; "Functional Characterization Of Eight Human CYP1A2 Variants: The Role Of Cytochrome b5", 19th International Symposium on Microsomes and Drug Oxidations / 12th European Regional ISSX Meeting
          * 2009-05-17, Brito Palma, B.; Silva e Sousa, M.; Lastdrager, J.; Rueff, J.; Vermeulen, N.P.E.; Kranendonk, M.; "Human Cytochrome P450 1A2: Comprehensive Study of Eight Polymorphic Variants", 11th European Regional ISSX Meeting
          * 2005-01-01, Kranendonk, M.; Duarte, M.P.; Brito Palma, B.; Gilep, A.A.; Oliveira, J.S.; Usanov, S.A.; Rueff, J.; "The role of protein-protein interactions in the stimulation of the bioactivation of mutagens by CYP1A2, 2A6 and 2E1 in the presence of cytochrome b5: A new cell system to study the cytochrome P450 mediated biotransformation.", 14t h International Conference on Cytochromes P450: Biochemistry, Biophysics, and Bioinformatics
          * 2004-07-04, Duarte, M.P.; Brito Palma, B.; Laires, A.; Oliveira, J.S.; Rueff, J.; Kranendonk, M.; "The stimulatory role of human cytochrome B5 in the bioactivation activities of human CYP1A2, 2A6 and 2E1: A new cell-system for the study of human 12 cytochrome P450 mediated biotransformation", 15th International Symposium on Microssomes and Drug Oxidations
          * 2003-04-27, Duarte, M.P.; Brito Palma, B.; Laires, A.; Oliveira, J.S.; Rueff, J.; Kranendonk, M.; "BTC, a Human P450 containing Escherichia coli Tester Strain with a High Sensitivity towards Alkylating Agents", 8th International Society for Study of Xenobiotics (ISSX)

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona