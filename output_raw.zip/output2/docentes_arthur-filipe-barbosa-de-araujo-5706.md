# Response for https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
          PT: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706 EN: https://www.ulusofona.pt/en/teachers/arthur-filipe-barbosa-de-araujo-5706
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
        fechar menu : https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/arthur-filipe-barbosa-de-araujo-5706
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Arthur Araujo

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5706
              p57***@ulusofona.pt
              4015-E089-6E3A: https://www.cienciavitae.pt/4015-E089-6E3A
              0000-0002-5016-974X: https://orcid.org/0000-0002-5016-974X
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/ee737e97-74a7-4d36-aa07-d0ebd9f7e2ca
      : https://www.ulusofona.pt/

        Resume

        Arthur Araújo is a PhD in tourism studies by the University of Aveiro (Portugal) and currently teaches at Lusófona University. He teaches disciplines such as Crisis and Disaster Management in Tourism, for Masters’ students, and a variety of disciplines for graduate students, such as Research Methodology and Tourism and Sustainability, and Nautical Tourism. Arthur has published works mainly in neurotourism, tourism sustainability, film tourism, destination imagery, and resilience and competitiveness. Recent publications have appeared in Annals of Tourism Research, Journal of Travel and Tourism Marketing and British Food Journal. In the industry, Arthur has experiences in Brazil and Spain, in areas such as tourism accessibility, inbound tourism statistics and educational tourism. He is also a member of the Centre for Transdisciplinary Development Studies (CETRAD) of the University of Trás-os-Montes and Alto Douro (UTAD) and of the ART&TUR International Film Tourism Festival Jury.

        Graus

            * Licenciatura
              Degree in Tourism
            * Mestrado
              Master's in Management
            * Doutoramento
              PhD in Tourism
            * Outros
              Digital Marketing
            * Outros
              Introduction to Structural Equation Modelling using AMOS
            * Outros
              Quantitative data analysis with SPSS
            * Outros
              Qualitative Analysis with the Support of NVivo and WebQDA

        Publicações

        Journal article

          * 2024, Demystifying neurotourism: An interdisciplinary approach and research agenda, European Journal of Tourism Research
          * 2023-06-29, Resilience and individual competitive productivity: the role of age in the tourism industry, Humanities and Social Sciences Communications
          * 2023-05-09, The Zika virus crisis during the 2016 Rio Olympic Games: a media cover analysis, Humanities and Social Sciences Communications
          * 2022-12-19, How Do Hospitality Workers Perceive Their Work Skills before and after the Lockdown Imposed by the COVID-19 Pandemic?, Social Sciences
          * 2022-10-18, Hotel workers' perceptions on soft and hard skills in Porto, Portugal, Journal of Human Resources in Hospitality & Tourism
          * 2022-06-01, How to Employ Zipf's Laws for Content Analysis in Tourism Studies?, International Journal of Hospitality & Tourism Systems
          * 2022-02-23, Willingness to Pay for Sustainable Destinations: A Structural Approach, Sustainability
          * 2022-02-21, Accessing Neuromarketing Scientific Performance: Research Gaps and Emerging Topics, Behavioral Sciences
          * 2021-07-21, Film tourism meets slum tourism: How negative portrayals can foster a controversial tourist phenomenon, Journal of Tourism & Development
          * 2021-03-15, Mapping smart experiences in tourism: A bibliometric approach, European Journal of Tourism Research
          * 2021-02-23, Country Performance Analysis of Swiss Tourism, Leisure and Hospitality Management Research, Sustainability
          * 2020-08-01, Destination Brand Gnosis (DBGNOSIS): An innovative tool for tourism research, Revista Turismo: Estudos e Práticas
          * 2020-07-10, A Imagem Cognitiva do Destino Turístico: O caso da cidade do Porto, A Imagem Cognitiva do Destino Turístico: O caso da cidade do Porto
          * 2020-04-21, Spanish Economic-Financial Crisis: Social and Academic Interest, Journal of Business Cycle Research
          * 2020, Pilgrimage or tourism Travel motivation on Way of Saint James, International Journal of Tourism Anthropology
          * 2019-09-05, Health and Sport. Economic and Social Impact of Active Tourism, European Journal of Investigation in Health, Psychology and Education
          * 2019-07-01, Understanding the role of destination imagery in mountain destination choice. Evidence from an exploratory research, European Journal of Tourism Research
          * 2019-05-17, Food tourism destinations’ imagery processing model, British Food Journal
          * 2019-04-30, La comunicación 2.0 en el sector turístico español. Análisis de las webs oficiales de promoción turística, International Journal of Marketing, Communication and New Media
          * 2019-01, A destination imagery processing model: Structural differences between dream and favourite destinations, Annals of Tourism Research
          * 2018-12-12, Green Jobs: The Present and Future of the Building Industry. Evolution Analysis, Social Sciences
          * 2015-05-19, Negative Film Plot and Tourists´ Image and Intentions: The Case ofCity of God, Journal of Travel & Tourism Marketing
          * 2012, Gestão sustentável da cadeia de abastecimento no turismo: Uma proposta baseada no turismo comunitário, Revista Turismo & Desenvolvimento

        Book

          * 2013, Films and destination image: when violence is based on history, 1, de Araújo, Arthur Filipe Barbosa, Lap Lambert Academic Publishing

        Book chapter

          * 2022, Tourists' Willingness to Pay for Environmental and Sociocultural Sustainability in Destinations: Underlying Factors and the Effect of Age, Transcending Borders in Tourism Through Innovation and Cultural Heritage, Springer International Publishing
          * 2021, Medical Tourism: Analysis and Expectations Worldwide, Advances in Marketing, Customer Relationship Management, and E-Services, IGI Global
          * 2021, Company Internships: Filling the Gap Between University Training and Business Reality, Handbook of Research on Human Capital and People Management in the Tourism Industry, IGI Global
          * 2020, Young Ideas to Improve Organizational Resilience in Turbulent and Changing Environments, Dynamic Strategic Thinking for Improved Competitiveness and Performance, IGI Global
          * 2020, Spanish and Portuguese MICE Tourists' Profile, Accelerating Knowledge Sharing, Creativity, and Innovation Through Business Tourism, IGI Global
          * 2018, Film tourism y la imagen de destinos, La Imagen y promoción de los destinos turísticos, Thomson Reuters
          * 2018, Destination Brand Gnosis (DBGnosis) software: cuando analizar big data es primordial para gestionar el destino turístico, Las fuentes de información turística en foco , Thomson Reuters - Aranzadi

        Conference paper

          * The role of cinema on the tourist destination image formation process: opportunities and challenges for the tourism stakeholders , Jornadas de Turismo do ISCE
          * The effects of negative plot films on destination image: the case of Brazil, 5th Annual Global Management Conference
          * The Quality of Business Relationships in the Tourism System: An Imaginary Organisation Approach, International Conference on Innovation and Entrepreneurship in Marketing and Consumer Behaviour
          * O papel do cinema na formação da imagem de destinos turístico, TMS Management Studies International Conference
          * Films’ impacts on tourist demand: a systematic review, Contemporary Perspectives in Tourism and Hospitality Research
          * Film-induced slum tourism: a literature review and model proposal, International Conference: Tourism, Destination Image and Place Branding
          * Effective methodological tools applied to modelling the influence of relational efforts on performance, European Conference on Research Methodology
          * Educação inclusiva na atividade turística: o caso to programa "Turismo acesível - Pernambuco sem barreiras", VIII Congresso Internacional de Tecnologia na Educação
          * Ecoturismo e o modelo de turismo comunitário: Uma análise da atividade turística na Prainha do Canto Verde-CE, XI Seminário Internacional de Turismo
          * Cinema and slum tourism motivations: a qualitative approach, TTRA Europe Chapter 2017
          * Análise do cumprimento dos programas de marketing turístico do Plano Estratégico de Turismo de Pernambuco, XI Encontro Nacional de Turismo com Base Local
          * Análise de adequação do Plano Nacional de Turismo aos preceitos establecidos pela Lei Geral do Turismo, XI Seminário Internacional de Turismo
          * 2023-05-31, Neuroscience on Marketing Applied do Tourism: A Mixed-Method Systematic Review on Neurotourism, Diversity and Sustainability: Opportunities and Threats | 2023
          * 2021-09-09, Sustainability factors influencing tourists’ destination choice during the covid-19 pandemic, Global Tourism Conference 2021
          * 2021-05-19, Hotel Workers' Perceptions on Soft Skills During the Covid-19 Pandemic, 4th International Conference on Tourism Research ICTR 2022
          * 2020-11-05, ¿Puede la generación z contribuir a la resiliencia de las empresas? Un estudio en la industria de lujo, XXII Seminario Hispano Luso de Economía Empresarial
          * 2020-06-16, The Way of Saint James from travellers' and tourism scholars' perspective, 6th Euro-Asia Tourism Studies Association (EATSA) International Conference
          * 2020-06-16, Slum tourism motivations induced by cinema: A structural model, 6th Euro-Asia Tourism Studies Association (EATSA) International Conference
          * 2019-09-24, Slum tourism: a sub-product of social inequality motivated by cinema, Sustainable Tourism in the Digital World
          * 2018-09-20, Developing a model of film-induced slum tourism motivations: an exploratory, qualitative, approach , 13th European Conference on Innovation and Entrepreneurship
          * 2017, Between dreams and sweet memories: the imagery of dream and favourite destinations, 9th International Tourism Congress

        Conference poster

          * 2018, Slum tourism motivations: a mixed methods approach – updated , 13th European Conference on Innovation and Entrepreneurship
          * 2017, Slum tourism motivations: a mixed methods approach, Encontro com a Ciência e Tecnologia em Portugal 2017
          * 2017, Slum tourism motivations: A mixed methods approach, Research day

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona