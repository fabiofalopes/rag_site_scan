# Response for https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
          PT: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057 EN: https://www.ulusofona.pt/en/teachers/goncalo-alves-gato-lopes-6057
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
        fechar menu : https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/goncalo-alves-gato-lopes-6057
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Gonçalo Gato

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6057
              p60***@ulusofona.pt
              0018-0663-E262: https://www.cienciavitae.pt/0018-0663-E262
              0000-0002-6888-2674: https://orcid.org/0000-0002-6888-2674
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/a0e07f6f-e5b7-44d5-982e-da5e5ea2d514
      : https://www.ulusofona.pt/

        Resume

        Gonçalo Gato was born in Lisbon, Portugal. His works have been performed in UK, Canada, Germany, France, Portugal and Brazil. He was one of the Panufnik Composers associated with the London Symphony Orchestra in 2016-17 and became Young Composer in Residence at Casa da Música during the year 2018. He is currently a Soundhub Associate at the LSO. As a composer, Gonçalo has worked with some of UK¿s foremost orchestras: the London Symphony Orchestra, which publicly rehearsed Fantasia (2017), the BBC Symphony Orchestra, whose musicians premiered his octet Vacuum Instability (2013), and the Britten Sinfonia, developing the piece Colour Matters (2016) after having been shortlisted in the OPUS 2016 competition. He has also worked with distinguished ensembles such as Remix Ensemble (Portugal), ensemble recherche (Germany), CHROMA Ensemble (UK) and Sond¿Ar-te Electric Ensemble (Portugal). François-Xavier Roth, Peter Rundel, Baldur Brönnimann and Richard Baker, feature among the conductors which have performed his music. Before moving to London in 2011, Gonçalo was awarded first prize on two occasions: in 2011 with the piece Vectorial-modular, for orchestra, and in 2008 with the piece Derivação, for piano. As composer-researcher, Gonçalo has been most active in the field of computer-assisted composition. He recently finished his doctoral degree at the Guildhall School of Music and Drama under the supervision of Julian Anderson, researching how the use of computerised processes affects compositional decision-making. This research led to the publication of a chapter in the OM Composer's Book 3 (2016), published by IRCAM (Paris), an institution where he has received training and at which he was invited to present ongoing research. He is now exploring computer-assisted orchestration as the orchestra has become an important medium to express his musical ideas.

        Graus

            * Doutoramento
              Doctor of Music
            * Licenciatura
              Química Aplicada
            * Mestrado
              Music
            * Licenciatura
              Música
            * Outros
              OpenMusic Experts
            * Ensino secundário
              Curso Complementar
            * Outros
              Interagir, composer et improviser avec des agents génératifs

        Publicações

        Magazine article

          * 2013-10-07, Vectorial Harmony, The Ear Reader
          * 2012, Composers' Forum: 'Três Formas' para trio de palhetas, Double Reed News

        Musical performance

          * 
          * 

        Journal article

          * 2024, Composition: let's talk about listening, again, Nova Contemporary Music Journal
          * 2006, Expression, purification, crystallization and preliminary X-ray analysis of the human RuvB-like protein RuvBL1, Acta Crystallographica Section F: Structural Biology and Crystallization Communications
          * 2005-11-07, Dioxygen reduction by multi-copper oxidases; a structural perspective, Dalton Transactions
          * 2005, Dioxygen reduction by multi-copper oxidases; a structural perspective, Dalton Transactions

        Thesis / Dissertation

          * 2016-06-11, PhD, Algorithm and Decision in Musical Composition
          * 2010-07-07, Master, Morphological Aspects of Rhythm in Musical Composition

        Book chapter

          * 2023, O compositor frente à realidade sonora, A Experiência Sonora: Da Linearidade à Circularidade, Documenta (Sistema Solar)
          * 2023, Introducing sound to animation students, Teaching Sound for the 21st Century, CILECT
          * 2021, Manual and algorithmic procedures in soundscape composition, Audiovisual e Indústrias Criativas: Presente e Futuro, 1, McGraw Hill
          * 2016, Folk material transformations and elaborations in 'A Vida é Nossa' (2013), The OM Composer's Book, 3, Editions DELATOUR FRANCE/Ircam-Centre Pompidou

        Online resource

          * 2014-12-24, IRCAM Forum 2014 Demo Patches, https://discussion.forum.ircam.fr/t/ircam-forum-2014-demo-patches/1592

        Conference paper

          * Composition: let's talk about listening, again, Nova Contemporary Music Meeting 2023
          * 2021-06-24, Manual and algorithmic procedures in soundscape composition, 8th International Congress of Audiovisual Researchers

        Conference abstract

          * 2023, The composer as producer, 25º Encontro de Engenharia de Áudio - Audio Engineering Society
          * 2016-11-24, Computer-assisted composition based on a XVII century madrigal, Old is New

        Preface / Postscript

          * 2020, NowState CD

        Audio recording

          * 2023, Wandering
          * 2020-06-11, NowState
          * 2020-06-11, Equilíbrio
          * 2020-06-11, Elementos
          * 2020-06-11, Dégradé
          * 2020-06-11, Derivação
          * 2020-06-11, A Walk in the Countryside
          * 2020-06-11, #Where_we're_going
          * 2011, Transformação, for trumpet
          * 2009, Derivação, for piano

        Musical composition

          * 2020-08, 128 Bits, piano
          * 2020, Travessia, Electroacoustic, stereo, 11 min
          * 2018-09, Ex machina colores, orchestra, 8 min
          * 2018-08, #where_we're_going, Ensemble, 8 min
          * 2018-07, Elementos, piano trio, 8 min
          * 2018, NowState, piano, 9min
          * 2017, Fantasia, symphony orchestra, 3min 30s
          * 2017, Equilíbrio, fl., cl., vln., vlc., pno., electr.
          * 2016, A Walk in the Countryside, solo flute
          * 2015, Comendador u m’eu quitei, soprano, tenor and ensemble (fl., cl., vln., vlc., pno.)
          * 2015, Agnostos, symphony orchestra
          * 2014, Two Different Pieces, violin and piano
          * 2014, Canti Firmi, fl. (+ a. fl.), ob., cl. (+ b. cl.), perc., pno., vln., vla., vlc., 4 min
          * 2013, Vacuum Instability, fl., cl. (+ cl. bx.), fg., tpt., trbn., vla., vlc., pno., 7min 30s
          * 2012, To the Muses, soprano and piano
          * 2012, Dégradé, fl. (+ picc.), cl. (+ cl. bx.), vln., vlc., pno., 8 min
          * 2011, Vectorial-modular, 2(+ picc.).2(+ cor. ing.).2(+ cl. bss.).2 – 2.2 – 1.1 – archi, 8min
          * 2011, Shapes, string quartet
          * 2011, Cradle Song, tenor sax. and soprano voice
          * 2011, (kind of) A waltz, 4-hand piano, 2 min
          * 2010, Imponderabilidade, tenor sax, piano
          * 2010, Configurazioni, fl., cl., vln., vlc., piano
          * 2009, Três formas, ob., cl., bsn.
          * 2009, Transformação, solo trumpet, 3 min
          * 2009, Singularidade, fl., cl., cl. bx., sax. alto, fg., tpa., tpt., gtr., vln., piano, 4 min
          * 2009, Recta e Curva, 2 fl. (+ picc.), ob., 2 cl., fg., vc., 7min 30s
          * 2008, Looking Around, orchestra. 2.2.2.2 – 2.2 – 0.1 – archi, 6min
          * 2008, Libertação, 2 fl., 2 cl., cl. bx., sax. alto, sax. tenor, fg., trbn. tenor, 2 vlns., 2 vla., vc., cb., 4min 30s
          * 2008, Derivação, piano, 10min
          * 2007, Sobrecer, string orchestra, 5min
          * 2007, Pedra de Vento, fl., ob., cl., cl. bx., sax. alto, trpa., tpt., trbn. tenor, marimba, vla., cb., piano, 3min 30s
          * 2007, Aquecimento Global, fl., cl., sax. sop., sax. alto, fg., trbn. tenor, vln., 2 vlas., vlc., cb., 8min
          * 2006, Tríptico, clarinet, 12min
          * 2006, Cinco Cores, wind quintet, 8min

        Artistic performance

          * 2020-09-07, Elementos, for piano trio [concert], Christuskirche, Freiburg, Germany
          * 2019-01-18, NowState, for piano [concert], Purcell Room, Southbank Centre, London, UK
          * 2019-01-17, Equilíbrio, for ensemble and electronics [concert], O'culto da Ajuda, MISO Music, Lisbon, Portugal
          * 2018-12-09, Ex machina colores, for orchestra [concert], Casa da Música, Porto, Portugal
          * 2018-11-04, #where_we're_going, for ensemble [concert], Casa da Música, Porto, Portugal
          * 2018-10-09, Elementos, for piano trio [concert], Casa da Música, Porto, Portugal
          * 2017-11-06, A Walk in the Countryside, for flute [concert], ISCM 2017, Vancouver, Canada
          * 2017-10-21, Equilíbrio, for ensemble and electronics [concert], O'Culto da Ajuda, MISO Music, Lisbon, Portugal
          * 2017-04-20, Fantasia, for orchestra [public rehearsal], LSO St. Luke's, London, UK
          * 2016-06-10, A Walk in the Countryside, for flute [concert], Morat Institut, Freiburg, Germany
          * 2015-09-30, Comendador u m'eu quitei, for soprano, tenor and ensemble [concert], Gulbenkian Foundation, Lisbon, Portugal
          * 2015-01-08, A Vida é Nossa, for symphonic wind band [Concert], Universidade de Aveiro, Aveiro, Portugal
          * 2015-01-07, A Vida é Nossa, for symphonic wind band [concert], Conservatório de Música de Coimbra, Coimbra, Portugal
          * 2014-07-11, Canti Firmi, for ensemble [concert], Silk Street Music Hall, London, UK
          * 2014-06-07, A Vida é Nossa, for symphonic wind band [concert], Auditório da Escola Superior de Música de Lisboa, Lisbon, Portugal
          * 2014-05-30, Twoo Different Pieces, for violin and piano [concert], Natal, Brazil
          * 2014-05-28, Two Different Pieces, for violin and piano [concert], Salvador da Bahia, Brazil
          * 2014-05-26, Two Different Pieces, for violin and piano [concert], Rio de Janeiro, Brazil
          * 2014-02-02, A Vida é Nossa, for symphonic wind band [concert], Casa da Música, Porto, Portugal
          * 2013-03-15, Vacuum Instability, for ensemble [concert], BBC Maida Vale Studios, London, UK
          * 2012-11-20, Shapes, for string quartet, The Forge, Camden, London, UK
          * 2012-07-05, Dégradé, for ensemble [concert], Silk Street Music Hall, London, UK
          * 2012-06, Por um Rio, electroacoustic tape [dance performance], Teatro Meridional, Lisbon, Portugal
          * 2012-02, Por um Rio, electroacoustic tape [dance performance], Teatro Joaquim de Almeida, Almada, Portugal
          * 2011-11-04, Por um Rio, electroacoustic tape [dance performance], Balleteatro, Porto, Portugal
          * 2011-09-24, Por um Rio, electroacoustic tape [dance performance], Cinema Teatro Joaquim de Almeida, Montijo, Portugal
          * 2011-05-20, Configurazioni, for ensemble and electronics [concert], Goethe Institut, Lisbon, Portugal
          * 2010-07-22, Vectorial-modular, for orchestra [concert], Auditório Municipal da Póvoa de Varzim, Portugal
          * 2010-07, Transformação, for trumpet [concert], Casa da Música, Porto, Portugal
          * 2008-07-26, Derivação, for piano, Auditório Municipal da Póvoa de Varzim, Portugal
          * 2008, Mudos, short opera [opera performance], São Luiz Teatro Municipal, Lisbon, Portugal
          * 2008, Looking Around, for orchestra [public rehearsal], Universidade de Algarve, Faro, Portugal

        Other output

          * 2021, Finlândia em Concerto, Programme notes for Casa da Música's symphonic event featuring Magnus Lindberg's 'First Piano Concerto' (1991) and Jean Sibelius' 'Third Symphony' (1907).
          * 2021, Copland, Strauss, Elgar and Mendelssohn, Programme notes for Casa da Música's symphonic concert featuring Aaron Copland's 'Fanfare for the Common Man', Richard Strauss' 'Serenade for winds', op.7, Edward Elgar's 'Serenade for Strings' and Felix Mendelssohn's 'Fourth symphony', op.90, em A major, “Italian”.
          * 2018-12-09, 'Bruckner and Haas' concert programme notes, Text featured on the concert leaflet, containing the programme note of my composition 'Ex machina colores', as well as Bruckner's Third Symphony and Haas' Second Violin Concerto.
          * 2018-11-04, 'À volta do Barroco' concert programme notes, Text featured on the concert leaflet, containing the programme note of my composition '#where_we're_going'', as well as Johannes Maria Staud's 'Auf die Stimme der weißen Kreide'.
          * 2018-10-09, 'Trio Adamastor' concert programme notes, Text featured on the concert leaflet, containing the programme note of my composition 'Elementos', as well as Franz Schubert's piano trio n. 2 in E flat major.

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona