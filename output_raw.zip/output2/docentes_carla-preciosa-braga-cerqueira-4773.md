# Response for https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
          PT: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773 EN: https://www.ulusofona.pt/en/teachers/carla-preciosa-braga-cerqueira-4773
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
        fechar menu : https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carla-preciosa-braga-cerqueira-4773
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carla Cerqueira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4773
              p47***@ulusofona.pt
              131A-C7F5-460A: https://www.cienciavitae.pt/131A-C7F5-460A
              0000-0001-6767-3793: https://orcid.org/0000-0001-6767-3793
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/b558643e-105c-4aa9-b39c-9780c58a664b
      : https://www.ulusofona.pt/

        Resume

        Carla Cerqueira is graduated in Social Communication from the University of Minho (Portugal), having worked some time as a journalist. She did a specialization in Communication Sciences - Information and Journalism, from the same institution, and since 2007 she is dedicated to research in the field of feminist media studies. She holds a PhD in Communication Sciences - specialization in Communication Psychology from the University of Minho (2012), funded by Portuguese Foundation for Science and Technology. During six years she was a Postdoctoral researcher in Communication Sciences at the Communication and Society Research Centre (CECS), University of Minho, Portugal; at the Department of Media, Communication and Culture, Autonomous University of Barcelona, Spain; and at the Department of Social Sciences, Erasmus University of Rotterdam, Netherlands and she was an Assistant Professor at Lusófona University of Porto, Porto. From 2019 to August 2020 was is a full-time researcher at the Communication and Society Research Centre (University of Minho). Currently she is an Associate Professor at Lusófona University, integrated researcher at CICANT - The Centre for Research in Applied Communication, Culture, and New Technologies and collaborator researcher at CECS - Communication and Society Research Centre. She is the director of the PhD in Communication and Activisms, Lusofona University. She integrates diverse national and international projects. Currentley she is the principal investigator of the project "FEMGlocal - Glocal feminist movements: interactions and contradictions (PTDC/COM-CSS/4049/2021) and the project "Network Voices: Women's participation in development processes" (COFAC/ILIND/CICANT/1/2021). She is also a team member of the funded projects YouNDigital - Youth, News and Digital Citizenship (PTDC/COM-OUT/0243/2021); MigraMediaActs - Migrations, media and activisms in Portuguese language: decolonising mediascapes and imagining alternative futures (PTDC/COM-CSS/3121/2021) and SPECULUM - Filming and looking at oneself in the mirror: the use of self-writing by Portuguese-speaking documentary filmmakers (EXPL/ART-CRT/0231/2021). She integrates "Making Young Researchers' Voices Heard for Gender Equality" (CA20137) and "LGBTI+ Social and Economic (in)equalities¿ (CA19103). Author of several books, book chapters and articles in national and international scientific journals, her research interests include gender, feminisms, intersectionality, feminist and human rights NGOs and media studies. Simultaneously, she participated in diverse international and national conferences (some as invited speaker) and integrated diverse scientific committees and events organization. She is part of the team of trainers and experts of the Commission for Citizenship and Gender Equality. She is also part of the group of experts from EIGE - European Institute for Gender Equality. She was vice-chair of the Gender and Communication Section of the European Communication Research and Education Association (ECREA) and Gender and Communication YECREA representative. Currently she is part of the Ethics Committee of ECREA. She has participated as a researcher and consultant in several academic and social funded projects in the area of Gender Equality and Media. Since 2012 she was also invited to join the Opinion Board of RTP (Radio and Television of Portugal is the public service broadcasting organization of Portugal) as a representative of NGOs that are part of the Advisory Board of CIG - Commission for Citizenship and Gender Equality. She is the Research & Policy Committee chair of GAMAG - Global Alliance on Media and Gender. She maintains an active involvement with diverse Portuguese non-governmental organizations that work with gender, feminisms and human rights. She integrates the board of APEM - Portuguese Association for Women's Studies and Civitas Braga.

        Graus

            * Licenciatura
              Social Communication
            * Pós-Graduação
              Communication Sciences - Information and Journalism
            * Outros
              English Scientific Writing (15 hours)
            * Outros
              English Conversation B2 (50 hours)
            * Outros
              English B2 (50 hours)
            * Outros
              English B1 (50 hours)
            * Outros
              Designing and Producing a Documentary in Two Times (8 hours)
            * Outros
              Initial Pedagogical Formation
            * Outros
              NOISE Summerschool - Network of Interdisciplinary Women’s Studies in Europe”
            * Outros
              Free Currents of Feminism (8 hours)
            * Outros
              NVivo 8 (16 hours)
            * Outros
              Seminar on Gender and Information (12 hours)
            * Outros
              I Course of Introduction to Medical-Legal and Forensic Sciences for Journalism
            * Outros
              Spanish course A2 (50 hours)
            * Doutoramento
              Communication Sciences
            * Outros
              IdeLab Training (Business Ideas)
            * Outros
              Summer School of Young Researchers from SOPCOM
            * Outros
              Summer School of Young Researchers from Sopcom
            * Outros
              IV National Encounter of E-APEM Network
            * Outros
              Workshop on Paryicipatory Visual Methodologies
            * Outros
              I Summer School in Gender and Sexualities
            * Outros
              Summer School of Young Researchers of SOPCOM
            * Pós-doutoramento
              Looking inside citizenship and gender equality: the (dis)connections between newsroom culture and NGOs communication strategies
            * Mestrado
              Comunicação, Arte e Cultura

        Publicações

        Magazine article

          * 2017, Políticas do Olhar
          * 2016, De otro género: reflexiones para un periodismo más incluyente y plural [The other gender: reflections for a more inclusive and plural journalism], VI Encuentro de la Red de Periodistas con Visión de género

        Journal issue

          * Políticas do olhar [Politics of Gaze], 1
          * Mídia, Gênero & Direitos Humanos [Media, gender & Human Rights]
          * Interseccionalidade, Comunicação e Cultura: (Entre)Cruzamentos de Matrizes de Opressão e Privilégio [Intersectionality, Communication and Culture: Crossovers Matrices of Oppression and Privilege], 35
          * Fotografia e Género [Photography and Gender], 32

        Journal article

          * 2024-02-07, “Journalists are Prepared for Critical Situations … but We are Not Prepared for This”: Empirical and Structural Dimensions of Gendered Online Harassment, Journalism Practice
          * 2023-11-30, The Trajectories That Remain to Be Told: Civic Participation, Immigrant Organizations, and Women’s Leadership in Portugal, Social Sciences
          * 2023-11-01, Editorial Introduction to New Directions in Gender Research, Social Sciences
          * 2023-08-25, Communicating through Cyberfeminism: Communication Strategies for the Construction of the International Feminist Strike in Portugal, Social Sciences
          * 2023-08-23, Journalists are Prepared for Critical Situations ... but We are Not Prepared for This: Empirical and Structural Dimensions of Gendered Online Harassment, Journalism Practice
          * 2023-06-30, #MeToo em Portugal- uma análise temática do movimento através de artigos de opinião (#MeToo in Portugal: a thematic analysis of the movement through opinion articles), Cuadernos.info
          * 2023-05-30, Entre Ciberfeminismo e Artivismo: Feminismo em Portugal no Dia Internacional Para a Eliminação da Violência Contra as Mulheres, Vista
          * 2023-04-25, cobertura do movimento #Elenão na mídia mainstream e alternativa, Comunicação & Informação
          * 2023, Where are the researches on gender in Communication? An analysis of production in Portuguese, Intercom: Revista Brasileira de Ciências da Comunicação
          * 2023, Onde estão as pesquisas sobre gênero na Comunicação? Uma análise da produção em língua portuguesa, Intercom: Revista Brasileira de Ciências da Comunicação
          * 2023, Communicating through Cyberfeminism
          * 2023, #MeToo em Portugal: uma análise temática do movimento através de artigos de opinião, Cuadernos.info
          * 2023, #MeToo em Portugal: uma análise temática do movimento através de artigos de opinião , Cuadernos.info
          * 2022-12-28, Intergenerational Perspectives on Media and Fake News During Covid-19: Results From Online Intergenerational Focus Groups, Media and Communication
          * 2022-12-27, Ser empreendedora em Portugal, Cadernos de Gestão e Empreendedorismo
          * 2022-05-11, Muted Voices: The Underrepresentation of Women in COVID-19 News in Portugal, Social Sciences
          * 2022, “Ideologia de gênero” como instrumento político nos jornais do Brasil e de Portugal, Revista Estudos Feministas
          * 2022, “Challenging it softly”: a feminist inquiry into gender in the news media context
          * 2022, “Challenging it softly”: a feminist inquiry into gender in the news media context
          * 2022, Reflections around comic gaze : from the female gaze in the early years of cinema to the performance servitudes, by Jesper Just
          * 2022, Reflections around comic gaze : from the female gaze in the early years of cinema to the performance servitudes, by Jesper Just
          * 2022, Muted voices: the underrepresentation of women in COVID-19 news in Portugal
          * 2022, Intergenerational Perspectives on Media and Fake News During Covid-19: Results From Online Intergenerational Focus Groups
          * 2021-12-15, Desigualdades sociais e medidas de ação afirmativa: entre avanços, resistências, incompreensões e novos desafios, ex aequo - Revista da Associação Portuguesa de Estudos sobre as Mulheres
          * 2021-05-16, Da teoria à prática: as questões de género nos planos curriculares dos cursos superiores de comunicação, Cadernos de Educação, Tecnologia e Sociedade
          * 2021, La inclusión del feminismo en la agenda setting durante las dictaduras españolas y portuguesas., RIHC. Revista Internacional de Historia de la Comunicación
          * 2020-12-11, Gender asymmetries in Portuguese trade unions: The case of the CGTP-IN, European Journal of Women's Studies
          * 2020-02-27, Migração feminina brasileira e a experiência do envelhecimento em Portugal: sexismo e outros "ismos" [Brazilian female migration and the aging experience in Portugal: sexism and other “isms”], Equatorial – Revista do Programa de Pós-Graduação em Antropologia Social
          * 2020, Migração feminina brasileira e a experiência do envelhecimento em Portugal: sexismo e outros “ismos”
          * 2018-11-29, Recensão: Moda e Feminismos em Portugal. O Género Como Espartilho [Cristina Duarte, 2017, Lisboa, Temas e Debates – Círculo de Leitores], Sociologia, Problemas e Práticas
          * 2018-05-25, “Challenging it softly”: a feminist inquiry into gender in the news media context, Feminist Media Studies
          * 2018-05, As jornalistas de desporto em Portugal: minorita´rias e com pouco poder, Estudos em Comunicação
          * 2018, (Des)fazer género, (des)construir futuros: diálogos sobre linguagem inclusiva e literacia crítica mediática
          * 2018, (Des)Fazer género, (des)construir futuros. Diálogos sobre linguagem inclusiva e literacia crítica mediática [(Un)Doing gender, (Un)building futures. Dialogues on inclusive language and critical media literacy], Faces de Eva
          * 2017-11-30, PENSAR O GÉNERO NA PUBLICIDADE: PERCEPÇÕES DE ESTUDANTES DO ENSINO SUPERIOR PORTUGUÊS [Thinking Gender in advertising: Portuguese higher education Students’ Perceptions], Gênero & Direito
          * 2017-11-30, MÉDIA, GÉNERO E DIREITOS HUMANOS: DIÁLOGOS (IM)POSSÍVEIS [Media, gender and human rights: (im)possible dialogues], Gênero & Direito
          * 2017-11-30, MULHERES, EMPODERAMENTO E AUTOESTIMA: A INFLUÊNCIA DOS BLOGS DE MODA NA IDENTIDADE PLUS SIZE [Women, Empowerment and Self-Esteem: The Influence of Fashion Blogs on Plus Size Identity], Gênero & Direito
          * 2017-11-30, A VIOLÊNCIA CONTRA AS MULHERES COMO UMA VIOLAÇÃO DOS DIREITOS HUMANOS: DO POSITIVADO AO NOTICIADO [Violence against women as a violation of human rights: from law to news coverage], Gênero & Direito
          * 2017-06-15, Ensaio sobre Cegueiras: cruzamentos intersecionais e (in)visibilidades nos media [Blindness essay: intersectional crossings and (in)visibility in the media], ex aequo - Revista da Associação Portuguesa de Estudos sobre as Mulheres
          * 2017-06, Resenha livro: Política no feminino, Cuestiones de género: de la igualdad y la diferencia
          * 2017, Pontos de vista [Viewpoints], Vista
          * 2017, Interview with Ruth Rosengarten. “Feminist photography today is diverse and fairly elastic, rather than fixated on the old binaries”, Comunicação e Sociedade
          * 2017, Entrevista com Ruth Rosengarten. “Atualmente a fotografia feminista é diversa e bastante elástica, ao invés de se fixar nos velhos binarismos”, Comunicação e Sociedade
          * 2017, Disarranging our album: photography and gender, Comunicação e Sociedade
          * 2017, Desarrumando o nosso álbum: fotografia e género, Comunicação e Sociedade
          * 2017, Abrindo a Caixa de Pandora - a Participação Política das Mulheres, as Desigualdades de Género e a Ação Positiva [Opening Pandora's Box - Women's Political Participation, Gender Inequalities, and Positive Action],, JOURNAL OF STUDIES ON CITIZENSHIP AND SUSTAINABILITY
          * 2016-11, Além dos tamanhos: o corpo e a moda nos blogs [Beyond sizes: body and fashion on blogs], dObra[s] – revista da Associação Brasileira de Estudos de Pesquisas em Moda
          * 2015-06-29, Entre a norma e a exceção: assimetrias de género nas newsmagazines portuguesas [Between the norm and the exception: gender asymmetries in portuguese newsmagazines], Comunicação e Sociedade
          * 2015-06, Between the norm and the exception: gender asymmetries in portuguese newsmagazines, Comunicação e Sociedade
          * 2015-06, A Cobertura Jornalística do Dia Internacional das Mulheres na Imprensa Portuguesa: Mudanças, Persistências e Reconfigurações, Novos Olhares
          * 2015-02, VII. Our place in history: Young feminists at the margins, Feminism & Psychology
          * 2015, Where's Wally? (In)visibilities about women and politics in journalistic reception practices | Onde está o Wally? (In)visibilidades sobre mulheres e política nas práticas de recec¸ão jornalística, Observatorio
          * 2015, A cobertura jornalística do Dia Internacional das Mulheres na imprensa portuguesa: mudanças, persistências e reconfigurações (The press coverage of the International Women’s Day in the Portuguese press: changes, persistences and reconfigurations), Novos Olhares
          * 2014, ‘Questões de género nas revistas generalistas de informação em Portugal: cruzamentos temáticos na Sábado e Visão’ [Gender issues in Portuguese generalist newsmagazines: Thematic intersections at Sábado and Visão], Calidoscópio
          * 2014, Leer, Interpretar y (Re)construir: Percepciones de Jóvenes sobre las Mujeres en la Política [Reading, Interpreting and (Re)constructing: Youth Perceptions about Women in Politics], Revista Communication Papers
          * 2014, Aceitar, rejeitar ou questionar? Análise crítica de discursos de jovens sobre políticas de igualdade [Accept, reject or question? Critical analysis of youth discourses on gender policies], Media & Jornalismo
          * 2012, Políticas para a igualdade entre homens e mulheres nos media: da (inov)ação legislativa à mudança social, Ex aequo
          * 2012, Políticas para a Igualdade entre homens e mulheres nos media: da (inov)ação legislativa à mudança social [Policies for equality between men and women in the media: from (innov) legislative action to social change], Ex Aequo
          * 2009, Mulheres & Blogosfera: contributo para o estudo da presença feminina na "rede" [Women & Blogosphere: contribution to the study of the female presence in the network], Ex aequo
          * 2008, A Imprensa e a Perspectiva de Género. Quando elas são notícia no Dia Internacional da Mulher [The Press and the Gender Perspective. When they are news on the International Women's Day], OBS
          * 2008, A Imprensa e a Perspectiva de Género. Quando elas são notícia no Dia Internacional da Mulher, Observatório (OBS) Journal

        Thesis / Dissertation

          * 2018, PhD, Os estereótipos também envelhecem?: uma análise descolonial das intersecções entre racismo, sexismo e idadismo, a partir das vivências de migrantes brasileiras em Portugal
          * 2018, PhD, O envelhecimento na imprensa portuguesa: uma Visão genderizada dos idosos
          * 2015, Master, A revolução fashion: os blogs como instrumentos de consolidação da identidade plus size
          * 2012, PhD, Quando elas (não) são notícia: mudanças, persistências e reconfigurações na cobertura jornalística sobre o Dia Internacional da Mulher em Portugal (1975-2007)

        Book

          * 2023, História dos Ativismos Feministas em Portugal, Pereira, Ana Sofia; Camila Lamartine; Cerqueira, Carla; Taborda, Célia; Cardoso, Daniel; Drummond, Daniela; Babo, Isabel; et al, Edições Universitárias Lusófonas
          * 2022, Violência online no jornalismo: Guia de prevenção e boas práticas, Silveirinha, Maria João; Miranda , João; Sampaio-Dias, Susana; Garcez, Bibiana; Subtil, Filipa ; Cerqueira, Carla; Amaral, Inês, ICNova
          * 2017, Referencial de formação – (In)formar para a Igualdade e para a Cidadania [Training reference - (In) training for Equality and Citizenship], Cerqueira, Carla, ISMAI
          * 2014, Igualdade ou algo do género... na publicidade: roteiro de boas práticas [Equality or something like it…in advertising. Good practices guide], Magalhães, Sara I.; Cerqueira, Carla Preciosa Braga; Jorge, Ana Margarida Reis, UMAR - União de Mulheres Alternativa e Resposta
          * 2014, De outro género: propostas para a promoção de um jornalismo mais inclusivo [On the other gender: proposals for the promotion of a more inclusive journalism], Cerqueira, Carla Preciosa Braga; Magalhães, Sara; Cruz-Santos, Anabela; Cabecinhas, Rosa; Nogueira, Conceição, Universidade do Minho. Centro de Estudos de Comunicação e Sociedade (CECS)
          * 2013, Contributos para comunicar com igualdade [Contributions to communicating with equality], Cerqueira, Carla, ACEP

        Book chapter

          * 2023, Communicating for change: strategies used by Portuguese feminist groups - sucess and challenges, Communicating for change: strategies used by Portuguese feminist groups - sucess and challenges
          * 2022, Wikipédia no feminino: o caso da enciclopédia em língua portuguesa, CIESPAL
          * 2022, Wikipédia no feminino: o caso da enciclopédia em língua portuguesa, CIESPAL
          * 2022, Intersectional feminism through digital activism. The 8M strike between Portugal and Brazil, Redes sociales en tiempos de la COVID-19: narrativas, bulos, algoritmos y marcos normativos, McGraw-Hill
          * 2022, Intergenerational approaches to disinformation and clickbait: participatory workshops as co-learning based spaces, Handbook of Media Misinformation
          * 2022, Communication and activist literacy for social change in feminist movements
          * 2022, Challenges of the Intergenerational Feminist Movement(s): Some Reflections
          * 2020, O femicídio na intimidade e os media: serão estes parte do problema ou da solução? [Femicide in intimacy and the media: are they part of the problem or the solution?], Violências de Género na Intimidade, ISMAI
          * 2020, Género e jornalismo: Representações e (in)visibilidades, Propostas para um tratamento informativo livre de tópicos sexistas [Gender and journalism: Representations and (in)visibilities, Proposals for a news treatment free of sexist topics], Co(m) Género. Cadernos de Comunicación e Xénero, Vía láctea editorial
          * 2020, A cobertura noticiosa das lutas feministas nos jornais Folha de S.Paulo e Público [The news coverage of the feminist struggles in the Folha de S.Paulo and Público newspapers], Direitos Humanos na América Latina: Desafios contemporâneos, Cortez Editora
          * 2020, "Gender Ideology" in Journalistic Coverage in Brazil and Portugal: Comparing Discursive Political Disputes, Gender Performativities in Democracy Under Threat, 1, Grácio Editor
          * 2020, "Breaking Silences: Vanessa Fernandes' Black Cinema/Quebrando silêncios: o cinema negro de Vanessa Fernandes", On the Edge of Portuguese Cinema: Study on Afro-descendant cinema produced in Portugal/À Margem do Cinema Português: Estudo sobre o cinema afrodescendente produzido em Portugal, Fundação Calouste Gulbenkian
          * 2019, Olhar de outro género para as notícias, Universidade do Minho. Centro de Estudos de Comunicação e Sociedade (CECS)
          * 2019, Olhar de outro género para as notícias [Looking differently at the news], Literacias cívicas e críticas: refletir e praticar [Civic and critical literacies: reflecting and practicing], CECS
          * 2019, Estrategias, dinámicas y desafíos de la comunicación en las organizaciones del Tercer Sector [Strategies, dynamics and challenges of communication in Third Sector organizations], Comunicación para el cambio social: propuesta para la acción, Tirant Lo Blanch
          * 2019, An Intersectional feminist perspective on research: what changes and how we do it, Investigación joven con perspectiva de género IV, Universidad Carlos III de Madrid. Instituto Universitario de Estudios de Género
          * 2018, Desigualdades de género em foco: interseções entre produção e receção de conteúdos jornalísticos [Gender inequalities in focus: intersections between production and reception of journalistic contents], Desigualdades Sociais e Políticas Públicas - Homenagem a Manuel Carlos Silva [Social Inequalities and Public Policies - Tribute to Manuel Carlos Silva], Edições Húmus
          * 2017, Violência de Género nos Media: Percurso, Dilemas e Desafios [Gender violence in media: route, dilemmas and challenges], Iscsp - Instituto Superior de Ciências Sociais e Polí­ticas
          * 2017, The place for gender research in contemporary Portuguese science and higher education policies within the context of neo-liberalism, Springer-Verlag
          * 2017, Slutwalk goes glocal: estratégias de difusão online no caso português [Slutwalk goes glocal: Strategies for disseminating information online in Portugal], Vozes plurais: a comunicação das organizações da sociedade civil [Plural voices: the communication of civil society organisations], LASICS
          * 2017, Comunicar para transformar: reflexões em torno das ONG de cidadania, igualdade de género e/ou feminismos [Communicating to transform: reflections concerning citizenship, gender equality and/or feminist NGOs], Vozes plurais: a comunicação das organizações da sociedade civil [Plural voices: the communication of civil society organisations], Documenta
          * 2016, La cobertura periodística del Día Internacional de las Mujeres en la prensa portuguesa: cambios, persistencias y reconfiguraciones [The journalistic coverage of the International Women’s Day in Portuguese press: changes, persistences and reconfigurations], Incom-Uab Publicacions
          * 2016, Gender and media: where do we stand today?, Universidade do Minho. Centro de Estudos de Comunicação e Sociedade (CECS)
          * 2015, Trilhando caminhos para uma informação jornalística mais inclusiva [Paths for more inclusive information], Mulheres e Media. Reflexões no Alvito, APEM
          * 2015, Modos de olhar as mulheres refugiadas [Ways to look at refugee women], Os media e a crise dos refugiados. Agenda de Atividades
          * 2015, As estratégias de comunicação das ONGs de cidadania, igualdade de género e/ou feministas: interconexões entre media mainstream e media sociais [The communication strategies of citizenship, gender equality and/or feminists NGOs: interconnections between mainstream media and social media], coleção Relações Públicas e comunicação organizacional – Dos fundamentos às práticas [Public relations and organizational communication - From concepts to practices], Livros Labcom
          * 2015, As estratégias de comunicação das ONGs de cidadania, igualdade de género e/ou feministas: interconexões entre media mainstream e media sociais
          * 2014, Os média, os públicos e os discursos de género: (in)visibilidades, linguagens e protagonistas
          * 2013, (In)visibilidades da cobertura noticiosa do Dia Internacional das Mulheres em Portugal [(In) visibilities of the news coverage of International Women's Day in Portugal], Romper as fronteiras. A interseccionalidade nas questões de género/feministas [Break the boundaries. Intersectionality in gender / feminist issues], APEM
          * 2012, Media and the (im)permeability of public sphere to gender, Democracia, Mass Media e Esfera Pública, Universidade do Minho. Centro de Estudos Humanísticos (CEHUM)
          * 2011, As representações de género nas revistas portuguesas de informação generalista - em busca de uma cidadania inclusiva [The gender representations in the Portuguese magazines of general information: in search of an inclusive citizenship], Congresso Nacional "Literacia, Media e Cidadania", CECS-UM
          * 2010, A visibilidade do Dia Internacional da Mulher na agenda mediática nacional [The visibility of International Women's Day in the national media agenda], Quem tem medo dos feminismos - Actas do Congresso Feminista 2008, 1, Nova Delphi

        Edited book

          * 2022, Edições Universitárias Lusófonas.
          * 2017, Documenta
          * 2016, Universidade do Minho. Centro de Estudos de Comunicação e Sociedade (CECS)

        Book review

          * “Preto e Branco: a Naturalização da Discriminação Racial” [Black and White: The Naturalization of Racial Discrimination]
          * “Género y Comunicación” [Gender and Communication]
          * Resenha do livro ‘La comunicación en clave de igualdad de género’
          * Recensão do livro ‘Género y Comunicación’, de Juan F. Plaza e Cármen Delgado
          * Recensão do livro "Preto e Branco: a naturalização da discriminação racial
          * Matria [Matria]
          * La comunicación en clave de igualdad de género [Communication in the key of gender equality]
          * El papel de los medios de comunicación para la igualdad de género [The role of the media for gender equality]
          * A política no feminino [Politics in feminine]
          * "Quem tem medo dos feminismos: Congresso Feminista 2008 [Who is afraid of feminisms: Feminist Congress 2008]
          * "Mulheres e Crime: Crime: perspetivas sobre intervenção, violência e reclusão" [Women and Crime: Perspectives on Intervention, Violence and Reclusion]
          * "Moda e Feminismos em Portugal: o género como espartilho" [Fashion is Feminisms in Portugal: gender as a corset]
          * "Feminismos: percursos e desafios" (1947-2007) [Feminisms: paths and challenges (1947-2007)]
          * "Desigualdades e Políticas de género" [Inequalities and Gender Policies]

        Translation

          * 2011, O intercâmbio polémico em fóruns de discussão online: o exemplo dos debates sobre as opções de acções e bónus no jornal Libération [The controversial exchange in online discussion forums: the example of the debates on stock options and bonuses in the newspaper Libération], Revista Comunicação e Sociedade, CECS
          * 2009, Tradução do artigo "O intercâmbio polémico em fóruns de discussão online: o exemplo dos debates sobre as opções de acções e bónus no jornal Libération"

        Newsletter article

          * 2013, Interview about gender equality in media, Informative Report "Por Outras Palavras, Projeto Europeu IN OTHER WORDS

        Encyclopedia entry

          * Women's Alternative News Sites, The International Encyclopedia of Gender, Media, and Communication
          * Feminist film analysis
          * Feminist Press, The International Encyclopedia of Gender, Media, and Communication

        Dictionary entry

          * 2015, Resenha do livro "MUlheres e crime: perspetivas sobre intervenção, violência e reclusão"

        Report

          * 2014, Relatório final - O género em foco: representações sociais nas revistas portuguesas de informação generalista [Final report - Gender in focus: social representations in Portuguese general newsmagazines], http://hdl.handle.net/1822/41751

        Working paper

          * 2021, How the portuguese media represented the first racialized female MP head of a political party

        Online resource

          * 2019-03-08, Article “Associativismo, participação e comunicação: dilemas e desafios” [Associativism, participation and communication: dilemmas and challenges], think tank Communitas, CECS. , http://www.communitas.pt/ideia/associativismoparticipacao- e-comunicacao-dilemas-e-desafios/

        Conference paper

          * O corpo: o protagonista da pós-modernidade [The body: the protagonist of postmodernity], 5º Congresso da Associação Portuguesa de Ciências da Comunicação Comunicação e Cidadania
          * Mudanças, persistências e reconfigurações: os discursos sobre o Dia Internacional da Mulher na Imprensa [Changes, persistence and reconfigurations: the discourses on International Women's Day in the Press], Colóquio Internacional “A Mulher em Debate – Passado e Presente
          * It’s normal unless it turns into physical aggression: a study of Portuguese Journalists’ perceptions of (gendered) online harassment
          * Constelações do Ativismo em rede: Livro de Atas do II Congresso Internacional de Net-Ativismo
          * As vozes femininas na blogosfera: um olhar sobre a realidade do Minho [The female voices in the blogosphere: a look at the reality of Minho], I Congresso Internacional de Ciberjornalismo
          * As políticas da UNESCO para a igualdade de género nos media: 1977-2007 [UNESCO policies for Gender equality in the media: 1977-2007], 5º Congresso da Associação Portuguesa de Ciências da Comunicação
          * As imigrantes brasileiras no jornalismo impresso regional [Brazilian immigrants in regional print journalism], 8º Congresso LUSOCOM
          * Aceitar, rejeitar ou questionar: uma análise crítica sobre as percepções das/os receptoras/es dos produtos mediáticos [Accept, reject or question: a critical analysis of the perceptions of the recipients of media products], Colóquio Internacional “A Mulher em Debate – Passado e Presente
          * A violência contra as mulheres nos meios de comunicação: uma análise ao caso brasileiro [Violence against women in the media: an analysis of the Brazilian case]
          * A liberdade (de expressão) que aprisiona (o vulnerável): um olhar sobre a publicidade televisiva brasileira [Freedom (of expression) which traps the vulnerable: a look at Brazilian TV advertising], Comunicação ibero-americana: os desafios da Internacionalização [Ibero-American communication: the internationalization challenges]
          * A imprensa e a perspectiva de género : as vozes femininas nas notícias de primeira página do Público e do Correio da Manhã [The Press and the Gender Perspective: Women's voices in the front page news from Público and Correio da Manhã]

        Conference abstract

          * 2023-06-29, News coverage on Feminism in Portuguese media: What voice does activism have?, IAMCR2023
          * 2023-06-05, The National within the Transnational: The #MeToo movement in Portugal, IAMCR2023
          * 2023-05-12, Once Upon a Time... A Historical Chronology on the Singularities of Portuguese Feminism(s), FEMCORUS mid-term symposium "Rewired and revamped? Media and trans/national feminisms in Europe and beyond
          * 2023-04-05, Educar para a igualdade e diversidade no ensino secundário: contributos de um booklet para a recuperação da memória histórica sobre os feminismos em Portugal, XII Congresso Português de Sociologia
          * 2022-12-06, Movimento feminista como forma de resistência à cultura hegemónica: entre as redes e as ruas, VIII Congresso Internacional sobre Culturas
          * 2022, Feminismo Glocal no Ciberespaço: a Greve Feminista Internacional em Portugal, XVII Congresso IBERCOM
          * 2022, Feminism and cyberactivism during pandemic: the 8M movement in Portugal, 11th European Feminist Research Conference

        Conference poster

          * 2008, The visual representation of the International Women’s Day in the media, 10º Congreso Internacional Interdisciplinar sobre las mujeres, Mundos de Mujeres/Women’s Worlds 2008

        Audio recording

          * 2023, Podcast Voices in Network (13 episodes)

        Dataset

          * Referências ao conflito israelo-palestiniano em imprensa Portuguesa 7Out-7Nov 2023, Recolha feita através da plataforma MediaCloud, a 8 de Novembro de 2023, por Daniel Cardoso, que recolhe referências ao conflito israelo-palestiniano no jornalismo digital em Portugal entre 7 de Outubro e 7 de Novembro de 2023.

        Other output

          * 2020, Desigualdades de género em tempos de pandemia, No contexto que vivemos é crucial pensar nos impactos da pandemia da COVID-19 na vida das pessoas, nomeadamente nas que se encontram em situação de maior vulnerabilidade, sendo que entre elas estão as mulheres. São várias as esferas que requerem uma análise com lentes de género e a cada dia que passa surge a necessidade de mais estudos nesta área. Estes devem promover uma reflexão sobre a situação
          * 2019, Associativismo, participação e comunicação: dilemas e desafios, Desde 2004 que foi instituído o Dia do Associativismo Jovem, o qual se celebra a 30 de abril. Esta efeméride surgiu como uma oportunidade para dar a conhecer o movimento associativo em geral (não apenas o associativismo jovem) e para reforçar a sua importância como espaço de cidadania participativa e de aprendizagem social. Apesar da sua proliferação nos últimos anos, e de em diversos casos se des
          * 2018, Interview as a specialist for the book "Um grito parado no ar – Comunicação e Criminalização dos Movimentos Sociais" (A scream frozen mid-air – Comunication and Criminalization of Social Movements), Interview as a specialist for the book "Um grito parado no ar – Comunicação e Criminalização dos Movimentos Sociais" (A scream frozen mid-air – Comunication and Criminalization of Social Movements), authorship by Cristian Góes, pp.52-58. Lapcom, UNB, Brasil.
          * 2017, Um grito parado no ar “Mídia, Misoginia e Golpe” (Media, Misogyny and Coup), Um grito parado no ar “Mídia, Misoginia e Golpe” (Media, Misogyny and Coup) , authorship by Michelly Santos de Carvalho, pp.39-44, Lapcom, Brasil.
          * 2013, Participation in the catalan magazine “Dones Digital"
          * 2013, Participation in the Catalonian News Agency with Gender Perspective “La Independent”

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona