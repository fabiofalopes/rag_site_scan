# Response for https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
          PT: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378 EN: https://www.ulusofona.pt/en/teachers/ana-sofia-gregorio-fernandes-3378
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
        fechar menu : https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-sofia-gregorio-fernandes-3378
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ana Fernandes

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3378
              ana***@ulusofona.pt
              CC14-508D-F103: https://www.cienciavitae.pt/CC14-508D-F103
              0000-0001-6350-0641: https://orcid.org/0000-0001-6350-0641
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/861e698b-9e57-4c56-867d-ad483b180281
      : https://www.ulusofona.pt/

        Resume

        Ana S. Fernandes has a degree in Pharmaceutical Sciences (2004), a PhD in Toxicology (2010), and was recognised with the European Registered Toxicologist title (2018). She is an Associate Professor at Universidade Lusófona. She is also the Board Director for Education & Society of CBIOS Research Center. Since 2007 on, she has published over 85 full papers in peer-reviewed international journals, 5 book chapters, and three dissemination publications. A. Fernandes reviewed approx. 80 papers published in international journals (since 2012; Publons profile: publons.com/a/1324213/). She was the guest editor of three special issues and is currently editing two other issues. In addition, A. Fernandes is author/co-author of more than 95 oral communications and over 150 posters in international and national meetings. She has received 12 awards/honors. A. Fernandes has supervised three PhD theses (completed) and is currently supervising five PhD and three master students. In addition, she has previously supervised 26 master dissertations and several research trainees, including five post-doc, six visiting PhD students and over 30 undergraduates. She participated in several Academic Juries (five PhD, 18 MSc and 45 MPharm). In addition, A. Fernandes has integrated the Evaluation Panel of different calls for research fellowships (CBIOS/FCT), scientific missions (COST actions), and research projects (Croatian Science Foundation - Hrzz-epp; Wellcome Trust/DBT India Alliance Fellowships). She has participated in 10 research projects grants and four contracts. She was the National delegate for the Management Committee of the COST Actions Action BM1203 - EU-ROS (2013-2016) and CA16112-NutRedOx (2017-2020), in which she worked also as Manager of Science Communication. She is a member of the Scientific Council of the School of Health Sciences and Technologies of Universidade Lusófona where she served also as Vice-President (2012-2014). A. Fernandes is also a member of the National Observatory for Emerging Risks of ASAE (The Portuguese Economic and Food Safety Authority, 2018) and an Expert of the Evaluation Group of Veterinary Medicines (GAMV) of Direção Geral de Alimentação e Veterinária (DGAV, 2018). She is the coordinator of the Advanced Training in Fundamentals of Cell Culture (six editions, between 2012-2023) and of the Cell Migration Workshop (2018, 2019, 2022). Finally, Ana Fernandes has integrated the Organizing Committee of several international and national meetings and participates regularly in public outreach activities. Her main line of research is the study of the impact of redox modulators in cancer etiology and progression. She is actively interested in understanding the influence of cellular redox pathways in different features of cancer cells, including proliferation, motility and invasiveness. These studies could contribute to the comprehension of the redox biology of cancer and to the development of novel therapeutic and nutritional strategies.

        Graus

            * Licenciatura
              Ciências Farmacêuticas
            * Doutoramento
              Pharmacy, specialization in Toxicology

        Publicações

        Journal article

          * 2023-12-19, The Golgi Apparatus as an Anticancer Therapeutic Target, Biology
          * 2023-08, Consumers’ practices and safety perceptions regarding the use of materials for food preparation and storage: Analyses by age group, Food and Chemical Toxicology
          * 2023-07-19, Functional Foods for Health: The Antioxidant and Anti-Inflammatory Role of Fruits, Vegetables and Culinary Herbs, Foods
          * 2023-07, The Redox-Active Manganese(III) Porphyrin, MnTnBuOE-2-PyP5+, Impairs the Migration and Invasion of Non-Small Cell Lung Cancer Cells, Either Alone or Combined with Cisplatin, Cancers
          * 2023, Food Contact Materials: contaminants and associated risks from the reports published in the RASFF portal (2020-2022), Biomedical and Biopharmaceutical Research
          * 2023, Evaluation of the Lysyl Oxidase-Like 2 (LOXL2) inhibitory activity of pimaranes and their glycosyl derivatives, Journal Biomedical and Biopharmaceutical Research
          * 2022-12-15, The Dietary Isothiocyanate Erucin Reduces Kidney Cell Motility by Disturbing Tubulin Polymerization, Molecular Nutrition & Food Research
          * 2022-11, MnTnHex-2-PyP5+ Displays Anticancer Properties and Enhances Cisplatin Effects in Non-Small Cell Lung Cancer Cells, Antioxidants
          * 2022-07-13, Tumor-infiltrating lymphocytes in early breast cancer: an exploratory analysis focused on HER2+ subtype in Portuguese patients, Current Medical Research and Opinion
          * 2022-06, Impact of Portuguese propolis on keratinocyte proliferation, migration and ROS protection: Significance for applications in skin products, International Journal of Cosmetic Science
          * 2022-05-20, Redox-Active Molecules as Therapeutic Agents, Antioxidants
          * 2022-04, Polyphenols and Their Metabolites in Renal Diseases: An Overview, Foods
          * 2022-04, GOLGI: Cancer cell fate control, The International Journal of Biochemistry & Cell Biology
          * 2021-12-31, Single versus mixed edge activators in caffeine-loaded transfersomes: physicochemical and cytotoxicity assessment, Journal Biomedical and Biopharmaceutical Research
          * 2021-06-09, The Perception of Primary School Teachers Regarding the Pharmacotherapy of Attention Deficit Hyperactivity Disorder, International Journal of Environmental Research and Public Health
          * 2021-04, Systemic treatment of HER2-positive breast cancer patients with brain metastases: current status and exploratory case study in a Portuguese cohort, Biomedical and Biopharmaceutical Research Journal
          * 2021-02-19, LOXL2 Inhibitors and Breast Cancer Progression, Antioxidants
          * 2020-12, Gene expression and survival analysis in cancer research using online open access platforms: a comparative analysis, Biomedical and Biopharmaceutical Research Journal
          * 2020-09-22, Exploring Volatile Organic Compound Exposure and Its Association with Wheezing in Children under 36 Months: A Cross-Sectional Study in South Lisbon, Portugal, International Journal of Environmental Research and Public Health
          * 2020-09-16, In Vitro Antimicrobial Activity of Isopimarane-Type Diterpenoids, Molecules
          * 2020-07-02, Adverse Effects of Natural Products: A Brief Pre-Systematic Review, Current Nutraceuticals
          * 2020-06-24, Impact of the APE1 Redox Function Inhibitor E3330 in Non-Small Cell Lung Cancer Cells Exposed to Cisplatin: Increased Cytotoxicity and Impairment of Cell Migration and Invasion, Antioxidants
          * 2020-06-10, Assessment of the Potential Skin Application of Plectranthus ecklonii Benth., Pharmaceuticals
          * 2020-06-03, Natural Products: Optimizing Cancer Treatment through Modulation of Redox Balance, Oxidative Medicine and Cellular Longevity
          * 2020-01-19, Anti-Migratory and Pro-Apoptotic Properties of Parvifloron D on Triple-Negative Breast Cancer Cells, Biomolecules
          * 2019-12-20, An Overview on the Properties of Ximenia Oil Used as Cosmetic in Angola, Biomolecules
          * 2019-10-17, The SOD Mimic MnTnHex-2-PyP5+ Reduces the Viability and Migration of 786-O Human Renal Cancer Cells, Antioxidants
          * 2019-10-15, Pyridine-Containing Macrocycles Display MMP-2/9 Inhibitory Activity and Distinct Effects on Migration and Invasion of 2D and 3D Breast Cancer Models, International Journal of Molecular Sciences
          * 2019-09-10, Contaminants: a dark side of food supplements?, Free Radical Research
          * 2019-06, The association of housing conditions with wheezing in children up to 36 monthold: an observational study in Arco Ribeirinho region, Journal Biomedical and Biopharmaceutical Research
          * 2019-06, Cytotoxic effect of antioxidants found in food from plant origin on human osteosarcoma U2OS Cells, Journal Biomedical and Biopharmaceutical Research
          * 2018-12, Ceftriaxone: clinical review, consumption in Portugal and safety alerts, Journal Biomedical and Biopharmaceutical Research
          * 2018-10-25, The manganese(III) porphyrin MnTnHex-2-PyP5+ modulates intracellular ROS and breast cancer cell migration: Impact on doxorubicin-treated cells., Redox Biology
          * 2017-12, Cytotoxicity of N-nitrosoguanidines in a breast cancer cell model, Journal Biomedical and Biopharmaceutical Research
          * 2017-06-27, Development of a strategy to identify the characteristics of babie‘s rooms associated with volatile organic compounds and with the occurrence of wheezing, Journal Biomedical and Biopharmaceutical Research
          * 2017, The APE1 redox inhibitor E3330 reduces collective cell migration of human breast cancer cells and decreases chemoinvasion and colony formation when combined with docetaxel, Chemical Biology and Drug Design
          * 2017, European contribution to the study of ROS: A summary of the findings and prospects for the future from the COST action BM1203 (EU-ROS), Redox Biology
          * 2017, Corrigendum to "European contribution to the study of ROS: A summary of the findings and prospects for the future from the COST action BM1203 (EU-ROS)" [Redox Biol. 13 (2017) 94-162], Redox Biology
          * 2017, Choline- versus imidazole-based ionic liquids as functional ingredients in topical delivery systems: cytotoxicity, solubility, and skin permeation studies, Drug Development and Industrial Pharmacy
          * 2016-12, Xanthine Oxidase Inhibitory Activity of a Plectranthus saccatus aqueous extract, Journal Biomedical and Biopharmaceutical Research
          * 2016-01, Ochratoxin A-induced cytotoxicity, genotoxicity and reactive oxygen species in kidney cells: An integrative approach of complementary endpoints, Food and Chemical Toxicology
          * 2016, Unsaponifiable matter from oil of green coffee beans: cosmetic properties and safety evaluation, Drug Development and Industrial Pharmacy
          * 2016, Structure-based virtual screening toward the discovery of novel inhibitors of the DNA repair activity of the human apurinic/apyrimidinic endonuclease 1, Chemical Biology and Drug Design
          * 2016, Multicomponent Petasis-borono Mannich Preparation of Alkylaminophenols and Antimicrobial Activity Studies, ChemMedChem
          * 2016, Functionalized diterpene parvifloron D-loaded hybrid nanoparticles for targeted delivery in melanoma therapy, Therapeutic Delivery
          * 2016, EGF functionalized polymer-coated gold nanoparticles promote EGF photostability and EGFR internalization for photothermal therapy, PLoS ONE
          * 2016, Cutaneous biocompatible rutin-loaded gelatin-based nanoparticles increase the SPF of the association of UVA and UVB filters, European Journal of Pharmaceutical Sciences
          * 2016, Bioproduction of gold nanoparticles for photothermal therapy, Therapeutic Delivery
          * 2015-10, Role of the Copper(II) Complex Cu[15]pyN5in Intracellular ROS and Breast Cancer Cell Motility and Invasion, Chemical Biology & Drug Design
          * 2015-06, In vitro antioxidant properties of the diterpenes Parvifloron D and 7a-acetoxy-6ß- hydroxyroyleanone, Journal Biomedical and Biopharmaceutical Research
          * 2015, The human umbilical cord tissue-derived MSC population UCX® promotes early motogenic effects on keratinocytes and fibroblasts and G-CSF-mediatedmobilization of BM-MSCS when transplanted in vivo, Cell Transplantation
          * 2015, Production and characterization of nanoparticles containing methanol extracts of Portuguese Lavenders, Measurement: Journal of the International Measurement Confederation
          * 2015, Polymeric nanoparticles modified with fatty acids encapsulating betamethasone for anti-inflammatory treatment, International Journal of Pharmaceutics
          * 2015, Integrated approach in the assessment of skin compatibility of cosmetic formulations with green coffee oil, International Journal of Cosmetic Science
          * 2014-06, A didactic approach for quantification of diazepam tablets by UV spectrophotometry, Journal Biomedical and Biopharmaceutical Research
          * 2014, [15]aneN4S: Synthesis, thermodynamic studies and potential applications in chelation therapy, Molecules
          * 2014, Erratum: Mechanistic insights into the cytotoxicity and genotoxicity induced by glycidamide in human mammary cells (Mutagenesis (2013) 28:6 (721-729)), Mutagenesis
          * 2014, Design of polymeric nanoparticles and its applications as drug delivery systems for acne treatment, Drug Development and Industrial Pharmacy
          * 2014, Antimicrobial plant extracts encapsulated into polymeric beads for potential application on the skin, Polymers
          * 2013-06, Evaluation of the sensory properties of a cosmetic formulation containing green coffee oi, Journal Biomedical and Biopharmaceutical Research
          * 2013-06, CBiOS Science Sessions - 2013 - Proceedings, Journal Biomedical and Biopharmaceutical Research
          * 2013, Synthesis and biological activity of 6-selenocaffeine: Potential modulator of chemotherapeutic drugs in breast cancer cells, Molecules
          * 2013, Mechanistic insights into the cytotoxicity and genotoxicity induced by glycidamide in human mammary cells, Mutagenesis
          * 2013, Induction of sister chromatid exchange by acrylamide and glycidamide in human lymphocytes: Role of polymorphisms in detoxification and DNA-repair genes in the genotoxicity of glycidamide, Mutation Research - Genetic Toxicology and Environmental Mutagenesis
          * 2013, Induction of micronuclei and cytotoxic effects of ochratoxin A in Vero cells, Toxicology Letters
          * 2013, In vitro cytotoxicity assessment using three-dimensional cell cultures of MCF10A cells, Toxicology Letters
          * 2013, Effect of APE1 inhibitors on the cytotoxicity and genotoxicity of doxorubicin in MDA-MB-231 cells, Toxicology Letters
          * 2013, Differential effects of methoxyamine on doxorubicin cytotoxicity and genotoxicity in MDA-MB-231 human breast cancer cells, Mutation Research - Genetic Toxicology and Environmental Mutagenesis
          * 2013, Combined effect of the SOD mimic MnTnHex-2-PyP5+ and doxorubicin on the migration and invasiveness of breast cancer cells, Toxicology Letters
          * 2012-06, Evaluation of diterpenoids from P. ornatus as potential COX-1 inhibitors, Journal Biomedical and Biopharmaceutical Research
          * 2012-06, Evaluation of antioxidant and antimicrobial activities of green coffee oil in cosmetic formulations, Journal Biomedical and Biopharmaceutical Research
          * 2012, Genetic polymorphisms in detoxification and DNA repair genes and susceptibility to glycidamide-induced DNA damage, Journal of Toxicology and Environmental Health - Part A: Current Issues
          * 2012, Effect of DNA repair inhibitors on the cytotoxicity induced by glycidamide, Toxicology Letters
          * 2012, Development of pyridine-containing macrocyclic copper(II) complexes: Potential role in the redox modulation of oxaliplatin toxicity in human breast cells, Free Radical Research
          * 2012, Cytotoxic effects of cadmium in mammary epithelial cells: Protective role of the macrocycle [15]pyN 5, Food and Chemical Toxicology
          * 2012, Beneficial effects of mesenchymal stem cells conditioned media on skin regeneration, Toxicology Letters
          * 2011-06, Oxidative stress and antioxidant defences – a pedagogical review, Journal Biomedical and Biopharmaceutical Research
          * 2011, Two macrocyclic pentaaza compounds containing pyridine evaluated as novel chelating agents in copper(II) and nickel(II) overload, Journal of Inorganic Biochemistry
          * 2011, Genotoxic effects of doxorubicin in cultured human lymphocytes with different glutathione S-transferase genotypes, Mutation Research - Genetic Toxicology and Environmental Mutagenesis
          * 2010, Protective role of ortho-substituted Mn(III) N-alkylpyridylporphyrins against the oxidative injury induced by tert-butylhydroperoxide, Free Radical Research
          * 2010, Oxidative injury in V79 Chinese hamster cells: Protective role of the superoxide dismutase mimetic MnTM-4-PyP, Cell Biology and Toxicology
          * 2009, Cytotoxicity and chromosomal aberrations induced by acrylamide in V79 cells: Role of glutathione modulators, Mutation Research - Genetic Toxicology and Environmental Mutagenesis
          * 2007, Macrocyclic copper(II) complexes: Superoxide scavenging activity, structural studies and cytotoxicity evaluation, Journal of Inorganic Biochemistry

        Book chapter

          * 2021, Fruit and vegetable juices and Breast Cancer, Cancer: Oxidative Stress and Dietary Antioxidants, 2, Elsevier - Academic Press
          * 2018, Toxicodinâmica, Toxicologia Fundamental, Lidel
          * 2016, Redox Therapeutics in Breast Cancer: Role of SOD Mimics, Oxidative Stress in Applied Basic Research and Clinical Practice, Springer International Publishing
          * 2015, Biomarcadores em Toxicologia, Toxicologia Forense , 1, Pactor

        Other output

          * 2021-03-10, Increased Antibacterial Properties of Indoline-Derived Phenolic Mannich Bases, European Journal of Medicinal Chemistry

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona