# Response for https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
          PT: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189 EN: https://www.ulusofona.pt/en/teachers/carla-maria-cadete-vieira-ramos-melo-4189
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
        fechar menu : https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carla-maria-cadete-vieira-ramos-melo-4189
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carla Melo

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4189
              car***@ulusofona.pt
              9111-7328-DC0C: https://www.cienciavitae.pt/9111-7328-DC0C
              0000-0002-2645-7370: https://orcid.org/0000-0002-2645-7370
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/e5cdbc99-b0cf-4ed7-a11c-a61567c42b57
      : https://www.ulusofona.pt/

        Resume

        Carla Cadete (CC) holds a PhD in Design at Aveiro University (2009), a doctoral fellow of the Foundation for Science and Technology (FCT) and a BA in Communication Design (1991) at the Faculty of Fine Arts of the University of Porto. Current course leader (since 2015) and Associate Professor of Communication Design undergraduate degree at Lusófona University of Porto (ULP). Invited by the Organising Committee (IAFOR) for Abstract reviewer. The main research areas are Graphic Design, Editorial, Illustration and Social Design. Responsible for the digital magazine DL, a biannual publication from the Communication Design course. Researcher at the Hei-Lab Centre of Research. Since 2019, it has been working in a cooperative process with Pedro Hispano Hospital, within the educational project Learning with a Disease by the Pediatrics Service of Pedro Hispano Hospital (Project awarded). Principal Investigator (PI) of "Design as a medium of preventing childhood obesity" (approved on May 12, 2019, by the Ethics and Health Committee and by Pedro Hispano Administration Hospital). Coordinated several design exhibitions with international conferences at Guerra Junqueiro Museum and Porto subway, supported by Porto City Council. Graphic designer and illustrator since 1992 - Worked with several design studios and publishing companies. ¿Book Cover¿ Publisher: Logo author and cover designer (co-author) of ¿Literature Essentials¿ collections for Portuguese newspapers DN and JN and national bookstores. (https://bookcover.pt/). Book cover designer and illustrator of ¿'Era uma Vez o Porto¿', from Verso da História Publisher (recommended by the National Reading Plan, 2017). Author of the illustrations for lower school activity book collection ¿Perlim-pim-pim, Fio a Pavio (https://www.fnac.pt/ia668041/Carla-Cadete) Author of 'João e Maria' kindergarten logo and other graphic materials. In the last five years has developed several pedagogical practices carried out in an academic context at Lusófona University of Porto (ULP), with the focus area on Social Design. In the Communication Design bachelor, at ULP we encourage students to participate in international competitions, 'Skopje Poster Competition' and International 'Poster for Tomorrow' focus on social and environmental themes. The quality of work developed by students has been frequently recognized at an international level. Multi-disciplinary projects to help tackle today's global challenges ¿ A pencil for a school (NGO The big Hand); Associação Ajudar Moçambique (NGO) from Belmiro de Azevedo Foundation and Now_you_see_me_moria, a co-creation activity with the aim of raising awareness about humanitarian crises in Europe. The project has collected 449 posters from graphic designers and students all over the world, including Design Lusófona students through a book, a website and an Instagram profile (https://nowyouseememoria.eu/gallery/). CC has a strong professional relationship with Pedro Hispano Hospital, having developed projects through co-design work with undergraduate students in Communication Design. Also, she was recently invited to design the mascot for the Pediatrics Service (work in progress). She has shown leadership and management skills through the course she directs and through the projects she has coordinated, such as Yes!, the comics magazine, which involves two undergraduate courses and the HPH (https://www.flipsnack.com/kimada2020/yes_revista_bd_first-edition.html). In schools [2019/2020], she had developed a participatory design work with children [4-5 years old] by drawing with them with the aim of applying in games or other mediums of communication for the practice of healthy eating. Also coordinated a survey of 181 children [8-12 years] in two Porto Schools to assess visual language/illustration preference in this age group. These design practices have resulted in international peer-reviewed scientific articles with communications at national and international conferences.

        Graus

            * Licenciatura
              Communication Design Bachelor
            * Doutoramento
              Design

        Publicações

        Journal article

          * 2024, Empowering Design Students Towards Societal Impact: Collective Learning and Action, The International Journal of Design in Society
          * 2023, Bauhaus 100 Anos, 100 Objetos: Um Projeto Colaborativo entre a Academia, o Museu e a Indústria. , Revista Educação Gráfica
          * 2022-08-19, DESIGN PARTICIPATIVO - DESENHAR COM CRIANÇAS PARA A PRÁTICA DE UMA ALIMENTAÇÃO SAUDÁVEL, REVISTA FOCO
          * 2019, A Ilustração para a Infância em Portugal nas duas primeiras décadas do séc.XX, Projectica - Revista científica de Design

        Thesis / Dissertation

          * 2013, Master, Projecto editorial coleção infanto-juvenil
          * 2012-06, Master, XClusivo Design – Identidade Visual de uma Marca
          * 2012-06, Master, FIFA World Cup Portugal 2016
          * 2012-06, Master, Criação da Imagem Corporativa da empresa Lotus
          * 2009, PhD, O design dos jornais diários e generalistas portugueses

        Book

          * 2021, Um Conto de Natal / Charles Dickens (design cover), 11-2021, Book Cover
          * 2021, Sherlock Holmes/Um Estudo em Vermelho/Arthur Conan Doyle (design cover). "Literature Essentials collections" (20 titles) for Portuguese newspapers, Diário de Notícias and Jornal de Notícias and national bookstores., 1, Cadete, Carla, Book Cover
          * 2021, David Crockett/Enid Meadowcroft (design cover). "Literature Essentials collections" (+100 titles) for Portuguese newspapers, Diário de Notícias and Jornal de Notícias and national bookstores., 1, Cadete, Carla, Book Cover
          * 2021, As Aventuras de Tom Sawyer/Mark Twain (design cover). "Literature Essentials collections" (20 titles) for Portuguese newspapers, Diário de Notícias and Jornal de Notícias and national bookstores., 1, Cadete, Carla, Book Cover
          * 2021, Alice no País das Maravilhas/Lewis Carroll (design cover). "Literature Essentials" collections (+100 titles) for Portuguese newspapers, Diário de Notícias and Jornal de Notícias and national bookstores., 1, Cadete, Carla, Book Cover
          * 2021, A Pequena Fadette/George Sand (design cover). "Literature Essentials collections" (+100 titles) for Portuguese newspapers, Diário de Notícias and Jornal de Notícias and national bookstores., 1, Cadete, Carla, Book Cover
          * 2020, A Ilustração para a Infância em Portugal – 1910-2010, 1, Cadete, Carla, Book Cover
          * 2017, Tabuada - 1º Ciclo do Ensino Básico (Timetable, from form 2 to form 4), 1st, Verso da História / Clube do Professor
          * 2017, Perlimpimpim: Números e Operações (Perlimpimpim: Numbers and Operations for Preschool ), 1st, Verso da História/Clube do Professor
          * 2017, Perlimpimpim: Letras e Palavras (Perlimpimpim: Letters and Words for Preschool), 2017, Verso da História / Clube do Professor
          * 2017, Perlimpimpim: Cores e Formas (Perlimpimpim: Colours and Shapes for Preschool), 1, Verso da História/Clube do Professor
          * 2017, Fio a Pavio – 2º Ano Fichas de Matemática (Fio a Pavio – form 2, Math workbook), 1st, Verso da História / Clube do Professor
          * 2017, Fio a Pavio – 1º Ano Fichas de Matemática (Fio a Pavio – form 1, Math workbook), 2017, Verso da História / Clube do Professor
          * 2017, Fio a Pavio - 3º Ano Fichas de Matemática (Fio a Pavio – form 3, Math workbook), 1st, Verso da História / Clube do Professor
          * 2017, Era uma Vez o Porto (Once upon a Time in Porto), 1st, Verso da História

        Book chapter

          * 2023, Embracing a Collaborative Practice with a Stakeholder: A Challenge Extended from the Academy to the Labour Market, Advances in Design and Digital Communication IV, Springer Nature Switzerland
          * 2023, DESIGN PARTICIPATIVO – DESENHAR COM CRIANÇAS PARA A PRÁTICA DE UMA ALIMENTAÇÃO SAUDÁVEL, Avanços dos temas emergentes ligados à saúde, 1, Editora Reflexão Acadêmica

        Conference paper

          * 2024-11, Designing for a Sustainable Future: Empowering Undergraduate Communication Design Students through Pedagogical Practice, Eighteenth International Conference on Design Principles & Practices: Cultures of Transformative Design
          * 2024-05-22, Designing for Tomorrow: Inspiring Students to Shape a Better World, DESIGN COMMIT 2024 (DESIGN COMMIT 2024_ 1ST INTERNATIONAL CONFERENCE ON DESIGN AND INDUSTRY)
          * 2023-10-13, A multidisciplinary and collaborative approach: From the academy to the community, The Asian Conference on Media, Communication & Film 2023: Official Conference Proceedings
          * 2023-06-19, A Design project aimed to promote social change: From the classroom to the community., IAFOR ¿CE2023 The 2nd Paris Conference on Education
          * 2023-03-30, Make the World a Better Place: Design Skills in an Academic Context, The Asian Conference on Education & International Development (ACEID2023). Tokyo, Japan from Mar 27 - Mar 30, 2023.
          * 2022-10-17, Changing Behaviours Through Design: An Educational Comic Brochure to Help Prevent Childhood Obesity, 13th Asian Conference on Media, Communication & Film (MediAsia2022), Kyoto, Japan, October 17-20
          * 2022-07-07, The Role of Design: A Humanitarian Approach and an Opportunity to Prepare Students for the Real Working World, The European Conference on Arts, Design & Education (ECADE 2022) — IAFOR
          * 2022-05-19, Design Educators: Collective Agents of Change., International Research & Education in Design Conference 2022 — REDES2022
          * 2022-05-19, Design Activism: A humanitarian approach in an academic context, International Research & Education in Design Conference 2022 — REDES2022
          * 2022-05-12, Social Design in a curricular context: A collaborative practice with a humanitarian purpose, 4rd Interdisciplinary and Virtual Conference on Arts in Education (CIVAE 2022)
          * 2021-11-04, O design como meio de prevenção da obesidade infantil –processo criativo., DIGICOM
          * 2020-11-05, Design Participativo – desenhar com crianças para a prática de uma alimentação saudável., Digicom 2020
          * 2020-05-14, O design como agente social de mudança, 7th EIMAD — Meeting of Reseach in Music, Art and Design
          * 2019-11-16, Design as a Transforming Agent and a Mediating Subject, DIGICOM 2019 – 3rd International Conference on Design and Digital Communication
          * 2019-11-07, O design como agente transformador e disciplina mediadora. Design & Digital Communication., Proceedings of the 3rd International Conference (DIGICOM 2019)

        Conference abstract

          * 2022-02-03, O lúdico como meio de prevenção da obesidade infantil, ehSemi2022, 2nd students’ seminar in ehealth and wellbeing

        Conference poster

          * 2021-11-13, Multicomponent Online Exercise Training Improved Lower Body Strength of Older Adults Who used to exercise in in-person exercise programs prior the Outbreak, 4th Annual Meeting Strength and Conditioning for Human Performance
          * 2021-11-12, Multicomponent Online Exercise Training Improved Lower Body Strength of Older Adults Who used to exercise in in-person exercise programs prior the Outbreak., 4th Annual Meeting Strength and Conditioning for Human Performance

        Other output

          * 2022-02-20, Mascot for the Pediatrics Service of Pedro Hispano Hospital, Guest designer to the mascot for the Pediatrics Service of Pedro Hispano Hospital, Porto, Portugal. Approved by the Board of Directors and the Pediatrics Service of the Hospital on 26 April 2022
          * 2022-01, Protocol, Establishes a protocol between Lusófona University of Porto (degree in Communication Design) and the NGO The Big Hand. These partnerships aim to carry out pedagogical practices in a curricular context and often result in peer-reviewed scientific articles, or national and international Communications.
          * 2022, Designer of the book “CA2RE+ Collective Evaluation of Design Driven Doctoral Training, Designer of the book “CA2RE+ Collective Evaluation of Design Driven Doctoral Training”, Co-funding by the Erasmus+ Program of the European Union.
          * 2021-01, Protocol, Establishes a protocol between Lusófona University of Porto (degree in Communication Design) and Associação Ajudar Moçambique (Belmiro de Azevedo Foundation). These partnerships aim to carry out pedagogical practices in a curricular context and often result in peer-reviewed scientific articles, or national and international Communications.
          * 2020, Protocol, Establishes a protocol between Lusófona University of Porto (degree in Communication Design) and the Portuguese Red Cross. These partnerships aim to carry out pedagogical practices in a curricular context and often result in peer-reviewed scientific articles, or national and international Communications.
          * 2019-05, Protocol, These partnerships allow for pedagogical practices in the curricular context and resulted in the design logo, Facebook cover, T-Shirts and caps.

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona