# Response for https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
          PT: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795 EN: https://www.ulusofona.pt/en/teachers/alan-de-carvalho-dias-ferreira-6795
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
        fechar menu : https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/alan-de-carvalho-dias-ferreira-6795
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Prof. Doutor Alan Ferreira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6795
              310***@gmail.com
              321F-57D9-88C9: https://www.cienciavitae.pt/321F-57D9-88C9
              0000-0002-0139-4318: https://orcid.org/0000-0002-0139-4318
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/c5773097-d371-4cfd-bab1-17e0b9d340c7
      : https://www.ulusofona.pt/

        Resume

        Alan Ferreira. Realizou Pós-doutoramento na Faculdade de Desporto da Universidade do Porto (FADEUP) na área de Gestão do Desporto (2022). Concluiu o Doutoramento em Ciências do Desporto (Gestão do Desporto) pela Universidade Federal do Rio Grande do Sul (2018; Brasil), Master of Science in International Sport Management pela Johannes Gutenberg University (2019; Alemanha), mestrado em Ciências da Nutrição pela Universidade Federal da Paraíba (2010; Brasil), Licenciatura Plena em Educação Física (2008; Brasil) e Bacharelado em Nutrição (2007; Brasil). É Gestor de Projetos com certificação internacional Scrum. É professor da Universidade Lusófona e da Escola Superior de Desporto de Rio Maior (Instituto Politécnico de Santarém). Foi Professor Auxiliar no Instituto Universitário da Maia na área de Gestão e Gestão do Desporto e professor Adjunto no Instituto de Estudos Superiores de Fafe. Publicou 10 artigos em revistas especializadas nos últimos 3 anos. Possui 5 capítulos de livros e 1 livro. Organizou 4 eventos. Orientou 13 dissertações de mestrado e co-orientou 4. Recebeu 3 prémios e/ou homenagens. Atua nas áreas de Ciências Sociais com ênfase em Economia e Gestão e Ciências Médicas e da Saúde com ênfase em Ciências do Desporto.

        Graus

            * Pós-doutoramento
              Gestão do Desporto
            * Pós-doutoramento
              Análise de dados do Desporto
            * Doutoramento
              Doutoramento em Ciências do Movimento Humano
            * Pós-Graduação
              Master of Science in International Sport Management
            * Mestrado
              Mestrado em Ciências da Nutrição
            * Pós-Graduação
              Pós-graduado em Administração e Marketing
            * Licenciatura
              Licenciatura Plena em Educação Física
            * Bacharelato
              Bacharelado em Nutrição
            * Postgraduate Certificate
              Professional Scrum Master
            * Postgraduate Certificate
              Professional Product Owner
            * Pós-Graduação
              Professional Product Owner Advanced

        Publicações

        Artigo em revista (magazine)

          * 2023-11-24, Transformação Digital nos Clubes Desportivos, Revista de Gestão de Desporto
          * 2020, Os desafios da Gestão do Esporte na era do Big Data¿, Revista Gestão de Desporto
          * 2014-05-06, Avaliação do Consumo Alimentar de Atletas, Revista eletrônica - Nutrição em Pauta
          * 2013-11-04, Adequabilidade à Legislação de Suplementos Proteicos e de Creatina para Atletas, Nutrição em Pauta
          * 2012-06-04, Qual a segurança e eficácia dos Suplementos Nutricionais para Atletas, Brasília Médica

        Artigo em revista

          * 2023-04-30, Analysis and prediction of the participation of Brazilian Paralympic athletes in the Paralympic Games of London 2012 and Rio 2016, European Review of Business Economics
          * 2022-10-01, Esports and Physical Education: what's before and after the present discussion?, Cultura, Ciencia y Deporte
          * 2022-05-26, Porto Alegre e a Copa do Mundo FIFA 2014: do sonho à realidade, do planejamento à execução, Revista Conjecturas, ISSN:1657-5830
          * 2022-03-10, Fatores que determinam a adesão ao atletismo: um estudo comparativo entre Brasil, Portugal e Espanha, Revista Intercontinental de Gestão Desportiva
          * 2022-02-01, Customer satisfaction assessment and brand perception of a football school, Revista Intercontinental de Gestão Desportiva
          * 2021-07-14, Um método para o mapeamento e gestão de dados do financiamento do Esporte de Alto Rendimento no Brasil / A method for mapping and data managing of the Elite Sports funding in Brazil, Brazilian Journal of Development
          * 2020-10-01, Analyzing the Impact of School Sports Facilities on the Sports Taught in Brazilian Schools, Journal of Teaching in Physical Education
          * 2020-08-19, Factors Related to Sports Participation in Brazil: An Analysis Based on the 2015 National Household Survey, International Journal of Environmental Research and Public Health
          * 2020-07-17, Secular trend of sports practice of Brazilian children and young people in the decade of mega-sport events, Journal of Human Sport and Exercise
          * 2019-09-05, Managers Profile of the Table Tennis Federations in Brazil, Intercontinental Journal of Sport Management
          * 2018-11-06, UM MODELO PARA A GESTÃO DE INFORMAÇÕES DO ESPORTE DE ALTO RENDIMENTO NO BRASIL / A MODEL FOR THE MANAGEMENT INFORMATION OF ELITE SPORTS IN BRAZIL, E-Legis - Revista Eletrônica do Programa de Pós-Graduação da Câmara dos Deputados
          * 2018-10-01, Use of Information Technology for Elite Sports Information Management, Arquivos Brasileiros de Educação Física
          * 2018-10-01, Mapping of the financial resources used for the Elite Sports in Brazil, Arquivos Brasileiros de Educação Física
          * 2018-03-04, Financing of the Paralympic Sports In Brazil: Agreements, Cadernos de Educação Tecnologia e Sociedade
          * 2013-03-01, Transtorno Dismórfico Muscular, Conexões
          * 2012-03-01, Dismorfia muscular: A busca pelo corpo hiper musculoso, Motricidade
          * 2011, Dismorfia muscular: características alimentares e da suplementação nutricional, ConScientiae Saúde
          * 2010-10-21, Características Metodológicas De Estudos Realizados Na América Latina Usando Sensores De Movimento: Revisão Sistemática, Revista Brasileira de Ciência e Movimento
          * 2010, Effect of Creatine Supplementation in Maximal Strength and Electromyogram Amplitude of Physically Active Women, Revista Brasileira de Medicina do Esporte
          * 2009-05-02, Óleos de aplicação local intramuscular: epidemiologia do uso em praticantes de musculação , Revista Brasileira de Ciência e Movimento
          * 2008-04-02, Hipertensão Arterial em crianças de João Pessoa, Revista Brasileira de Ciências da Saúde
          * 2007-02-02, Esteróides anabólicos androgênicos, Revista Brasileira em Promoção da Saúde

        Livro

          * 2023, Transformação Digital nos Clubes Desportivos: Ferramenta de Diagnóstico e Intervenção na Maturidade Digital das Organizações Desportivas, 1, Ferreira, A.C.D; Silva, Alfredo, Editora do Instituto Politécnico de Santarém
          * 2017, References Project – References for Brazilian Elite Sports, 1, Ferreira, A.C.D; Reppold Filho, Alberto Reinaldo, Federal University of Rio Grande do Sul
          * 2010, Musculação: Aspectos fisiológicos, metodológicos e nutricionais., 1, Ferreira, A.C.D, Editora da Universidade Federal da Paraíba

        Capítulo de livro

          * 2023, Rede de Organizações e os Pilares da Governação no Desporto Brasileiro, Direito Desportivo na atualidade , 1, 1, Editora da Universidade Federal do Rio de Janeiro
          * 2023, MARKETING SOCIAL, OLIMPISMO E JOGOS OLÍMPICOS, Gestão do Esporte e os Valores Olímpicos, 1, 1, Editora Universidade Federal de Sergipe
          * 2023, GESTÃO DE DADOS PARA O DESENVOLVIMENTO DO ESPORTE, Gestão do Desporto na Era do Big Data, 1, 1, Editora Universidade Federal da Universidade do Rio Grande do Sul
          * 2023, Ciência de dados e a cultura data driven nas organizações desportivas, Lições em Gestão do Desporto, 1, 1, Quântica Editora
          * 2023, A Construção do Conhecimento Aplicado à Gestão do Esporte, Gestão do Conhecimento no Esporte, 1, 1, Atena Editora
          * 2021, Governança Esportiva no Brasil, Ciências do esporte e educação física: Pesquisas científicas inovadoras, interdisciplinares e contextualizadas, 1, 1, Atena Editora
          * 2020, Sports Participation in Brazil, Prime Archives in Environmental Research, 1, 1
          * 2017, Rede de informações do Esporte de Alto Rendimento Brasileiro, Projeto Referências - Referências para o Esporte de Alto Rendimento Brasileiro, 1, 1, Universidade Federal do Rio Grande do Sul
          * 2017, Eventos e Resultados Esportivos , Projeto Referências - Referências para o Esporte de Alto Rendimento Brasileiro, 1, 1, Universidade Federal do Rio Grande do Sul
          * 2017, Entidades e Governança , Projeto Referências - Referências para o Esporte de Alto Rendimento Brasileiro, 1, 1, Universidade Federal do Rio Grande do Sul
          * 2017, Business Intelligence, Projeto Referências - Referências para o Esporte de Alto Rendimento Brasileiro, 1, 1, Universidade Federal do Rio Grande do Sul
          * 2014, Bolsa-Atleta: evolução da legislação e os resultados do Programa Federal , Diagnóstico Nacional do Esporte, 1, 1, Ministério do Esporte

        Artigo em conferência

          * PROGRAMA ESPORTE E LAZER NA CIDADE (PELC): OS RESULTADOS NA CIDADE DO RECIFE, BRASIL, XX Congresso Português de Gestão do Desporto
          * Bolsa-Atleta: evolução da legislação e dos resultados do programa federal, 4ª Congresso Internacional do Conselho Regional de Educação Física
          * 2020-11, HIGHER EDUCATION ENTREPRENEURSHIP OBSERVATORY: THE CURRICULUM AND EMPLOYABILITY CONNECTION
          * 2020, Construção e validação de um instrumento de monitoramento de programas desportivos de lazer. , 10ª Jornada Internacional sobre Gestão do Esporte
          * 2019-11-23, Governança desportiva e gestão de informações: o caso da Confederação Brasileira de Tênis de Mesa, XX Congresso Português de Gestão do Desporto, 2019
          * 2019-11-23, Descrição e análise dos elementos envolvidos na gestão da escalada, XX Congresso Português de Gestão do Desporto, 2019

        Resumo em conferência

          * 2023-11-24, Participação desportiva informal na cidade do Porto: estudo misto sobre as barreiras intrapessoais, interpessoais e estruturais, XXIV Congresso Nacional de Gestão do Desporto - Associação Portuguesa de Gestão do Desporto.
          * 2023-11-24, Digital engagement: Categorizando os conteúdos das publicações das redes sociais dos clubes de futebol da Primeira Liga Portuguesa., XXIV Congresso Nacional de Gestão do Desporto - Associação Portuguesa de Gestão do Desporto.
          * 2023-09-14, Enhancing Recreational Sport Provision Through Municipal Council Action: a Mixed-method Study Using Self-determination Theory, 31st European Association for Sport Management Conference
          * 2023-06-10, Sports Analytics: Designing a Database Model to Analyse Brazilian Elite Sports Data, XIII Congreso Iberoamericano de Economía del Deporte (CIED) - Sociedad Española de Economía del Deporte
          * 2023-02-23, How sports results affect the cryptocurrencies valuation: a case study of the Porto Football Club fan token, II International Congress - CIEQV - RESEARCH TRENDS IN QUALITY OF LIFE
          * 2022-12-03, Competências Fundamentais do Gestor do Desporto: uma revisão sistemática, No XXII CONGRESSO NACIONAL DE GESTÃO DE DESPORTO: Desporto e Lazer no Território: Estratégias de Recuperação
          * 2022-11-30, Impacto da tecnologia na qualidade e nos comportamentos de consumo dos membros em diferentes modelos de negócio no Fitness, XXIII Congresso Nacional de Gestão do Desporto - Associação Portuguesa de Gestão do Desporto
          * 2022-11-29, Impacto da tecnologia na qualidade e nos comportamentos de consumo dos membros em diferentes modelos de negócio no fitness, XXIII CONGRESSO NACIONAL DE GESTÃO DE DESPORTO
          * 2022-11-17, The Impact Of Technology On Quality And Member ´s Behaviour In Different Fitness Business Models, International Conference on Technology in Physical Activity and Sport
          * 2022-10-20, Medindo o engajamento nas redes sociais: um estudo dos conteúdos postados pelos Personal Trainers portugueses, 13º Congresso Brasileiro de Gestão do Esporte
          * 2022-09-02, Sport Managers Fundamental Skills: A Systematic Review, European Association for Sport Management Conference, 2022
          * 2022-09-02, Identifying the Social Media Content That Best Engages Supporter Groups: a Comparative Study of Portuguese Football Clubs, European Association for Sport Management Conference, 2022
          * 2021-12-03, Estratégias digitais de atendimento e de marketing utilizadas por estúdios de Personal Training e Treinamento Funcional em virtude da Pandemia de COVID-19, XXII CONGRESSO NACIONAL DE GESTÃO DE DESPORTO: Desporto e Lazer no Território: Estratégias de Recuperação
          * 2021-12-03, Avaliação da Satisfação de Clientes e a Perceção da marca de uma escola de futebol, XXII CONGRESSO NACIONAL DE GESTÃO DE DESPORTO: Desporto e Lazer no Território: Estratégias de Recuperação
          * 2021-10-22, Validação de um modelo de gestão de dados do Esporte de Alto Rendimento, Fórum de Estudos Olímpicos 2021
          * 2021-03-10, PROGRAMAS ESPORTIVOS E DE LAZER: CONSTRUÇÃO DE UM INSTRUMENTO DE MONITORAMENTO A PARTIR DA CIDADE DE RECIFE-PE, 11º Congresso Brasileiro de Gestão do Esporte
          * 2021-03-10, NON-HOST EVENT LEVERAGING AT A MULTI-CITY MAJOR EVENT: THE 2014 BRAZIL FIFA WORLD CUP, 11º Congresso Brasileiro de Gestão do Esporte
          * 2021-03-10, Fatores que determinam a adesão ao atletismo: um estudo comparativo de modelos de negócio no Brasil, em Portugal e na Espanha, 11º Congresso Brasileiro de Gestão do Esporte
          * 2020-11, Patrocínio desportivo: um estudo qualitativo sobre as empresas portuguesas, XXI Congresso Nacional de Gestão de Desporto e IV Congresso Ibérico – APOGESD
          * 2020-09, Rock Climbing Management: Who Makes it Happen? , 28th European Sport Management Virtual Conference
          * 2020-09, Digital Media and Engagement in COVID-19 times: a preliminary study in Brazilian and Portuguese Football Clubs, 28th European Sport Management Virtual Conference
          * 2019-11, Ex-atletas como agentes promocionais e de relacionamento: o caso Embaixadores do Esporte da empresa Banco do Brasil, 10 Congresso Brasileiro de Gesta~o do Esporte, 2019
          * 2019-09-08, Construction of a Computerized Model for Information Management of Elite Sports in Brazil, European Association for Sport Management Conference, 2019
          * 2019-09, State Sponsorship of Elite Sports: a comparative study between Brazil and Portugal, European Association for Sport Management Conference, 2019
          * 2019-09, Analysis and Prediction of the Participation of Brazilian Paralympic Athletes in the Paralympic Games of London 2012 and Rio 2016: a Preliminary Study, European Association for Sport Management Conference, 2019
          * 2017-07, A Method to Establish the Current Situation of Elite Sport in Brazil, North American Society for Sport Management Conference, 2017
          * 2017-06-10, Profile of the Paralympic Athlete and the Factors Involved in the Sports Race, V Paralympic Congress, 2017
          * 2016-10-05, Método para Estabelecer a Situação Atual do Esporte de Alto Rendimento no Brasil, XVI Congresso de Ciências do Desporto e Educação Física dos Países de Língua Portuguesa, 2016
          * 2016-08-05, Federal funding available for elite sports in Brazil , International Convention on Science, Education and Medicine in Sport, 2016
          * 2015-08-13, A Method to Establish the Current Situation of Elite Sport in Brazil, The World Congress on Elite Sport Policy 2015

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona