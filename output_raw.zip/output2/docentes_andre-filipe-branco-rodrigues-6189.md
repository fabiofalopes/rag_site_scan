# Response for https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
          PT: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189 EN: https://www.ulusofona.pt/en/teachers/andre-filipe-branco-rodrigues-6189
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
        fechar menu : https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/andre-filipe-branco-rodrigues-6189
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          André Filipe Branco Rodrigues

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6189
              p61***@ulusofona.pt
              C012-43D7-9E9F: https://www.cienciavitae.pt/C012-43D7-9E9F
              0000-0003-2158-3180: https://orcid.org/0000-0003-2158-3180
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/243ee23f-7a98-4cbe-8959-3ec260d39afd
      : https://www.ulusofona.pt/

        Resume

        André Filipe Branco Rodrigues é licenciado e mestre em Engenharia Mecânica pela Escola de Ciências e Tecnologia da Universidade de Trás-os-Montes e Alto Douro. Desde agosto de 2020 é licenciado em Engenharia de Proteção Civil pela Universidade Lusófona do Porto. Possui, ainda, três pós graduações: Proteção Civil, Gestores de Emergência e Socorro e Gestão Municipal de Proteção Civil, pelo Instituto Superior de Ciências da Informação e Administração. Atualmente é aluno do doutoramento em Aerodinâmica, Riscos Naturais e Tecnológicos na Universidade de Coimbra com uma tese de doutoramento na área dos Incêndios Florestais. Exerce atividade de investigação na Universidade de Coimbra. É autor e coautor de vários trabalhos científicos sobre riscos naturais e tecnológicos e tem colaborado em diversos projetos de investigação. É Professor e Subdiretor de Cursos na Universidade Lusófona do Porto na área da Proteção Civil. É revisor convidado em seis revistas de destaque. André Rodrigues é bombeiro voluntário desde 2009 e possui mais de 30 cursos de formação profissional na área dos bombeiros e da proteção civil. Atualmente é Diretor Executivo da CFR - Consultoria, Formação e Regulação, Unipessoal Lda.. Formador externo da Escola Nacional de Bombeiros na área do Salvamento e Desencarceramento, Técnico de Fogo de Supressão pela Autoridade Nacional de Emergência e Proteção Civil e Técnico de Fogo Controlado pelo Instituto da Conservação da Natureza e das Florestas.

        Graus

            * Licenciatura
              Engenharia Mecânica
            * Mestrado integrado
              Engenharia Mecânica
            * Pós-Graduação
              Proteção Civil
            * Pós-Graduação
              Gestores de Emergência e Socorro
            * Pós-Graduação
              Gestão Municipal de Proteção Civil
            * Doutoramento
              Engenharia Mecânica
            * Outros
              Técnicas de Socorrismo
            * Outros
              Técnicas de Salvamento e Desencarceramento
            * Outros
              Curso de Instrução Inicial de Bombeiro
            * Outros
              Salvamento em Grande Ângulo
            * Outros
              Condução Fora de Estrada
            * Outros
              Formação Pedagógica Inicial de Formadores
            * Outros
              Condução em Emergência Pré-Hospitalar
            * Outros
              Tripulante de Ambulância de Socorro
            * Outros
              Segurança Contra Incêndios em Edifícios para Elementos dos Corpos de Bombeiros
            * Outros
              Operador de Serviço Básico de Salvamento e Luta Contra Incêndios em Aeronaves
            * Outros
              Equipas de Reconhecimento e Avaliação de Situação em Incêndios Florestais
            * Outros
              Salvamento e Desencarceramento - nível 2
            * Outros
              Salvamento e Desencarceramento - Formador
            * Outros
              Segurança e Comportamento do Incêndio Florestal
            * Outros
              Incêndios Florestais - nível 4
            * Outros
              Recertificação do curso de Tripulante de Ambulância de Socorro
            * Outros
              Análise de Incêndios e Uso do Fogo de Supressão
            * Outros
              Técnico de Fogo Controlado
            * Licenciatura
              Engenharia de Proteção Civil
            * Curso de doutoramento (conclusão de unidades curriculares)
              Engenharia Mecância
            * Outros
              Ética e Deontologia Profissional
            * Outros
              Workshop internacional sobre perigo de incêndio na microescala da Interface Urbano-Florestal
            * Outros
              UFCD9990: Comportamento do Fogo nos Espaços Rurais
            * Outros
              UFCD9986: Vigilância e Primeira Intervenção em Incêndios Rurais
            * Outros
              UFCD3127: Prevenção de Incêndios Rurais
            * Outros
              UFCD5377: Fogo Controlado – apoio
            * Outros
              Curso Internacional sobre comportamento de incêndio
            * Outros
              Curso Internacional sobre segurança pessoal no combate aos incêndios florestais
            * Outros
              Segurança contra incêndios no interface urbano-florestal
            * Outros
              Gestão de Conflitos
            * Outros
              Análisis de Radiosondeos
            * Outros
              Alterações Climáticas
            * Outros
              Formador de SBV/DAE
            * Outros
              Seminário Técnico sobre Proteção de Zonas Industriais a Incêndios Florestais
            * Outros
              Segurança em Atmosferas Potencialmente Explosivas - Diretiva ATEX
            * Diploma de especialização
              XII Curso de Gestão Civil de Crises
            * Outros
              Formador de TAT/TAS
            * Outros
              Workshop de Salvamento e Desencarceramento - Formador
            * Outros
              MOOC - Logística e Operações Humanitárias
            * Outros
              Webinar "Segurança e Resiliência ao fogo das zonas de infarce urbana-florestal"

        Publicações

        Artigo em revista

          * 2023-04, Fire propagating laterally over a slope with and without an embedded canyon, Fire Safety Journal
          * 2022-05-20, Interaction between two parallel fire fronts under different wind conditions, International Journal of Wildland Fire
          * 2021-09-30, Wildfire Risk Management in the District of Vila Real (Portugal), Proceedings of the Institution of Civil Engineers - Forensic Engineering
          * 2021-04-13, Fire downwind a flat surface entering a canyon by lateral spread, Fire Safety Journal
          * 2020-12-09, Wildfires in the Northern of Portugal: an Operational Case Study in Tabuaço, Proceedings of the Institution of Civil Engineers - Forensic Engineering
          * 2020-12-09, Mass Movement Risk in a Portuguese Municipality: Tabuaço Case Study, Proceedings of the Institution of Civil Engineers - Forensic Engineering
          * 2020-09-29, The Impact on Structures of the Pedrógão Grande Fire Complex in June 2017 (Portugal), Fire
          * 2020-06-16, Accident Scenarios Modelling with Hazardous Materials in Transportation Infrastructures, Proceedings of the Institution of Civil Engineers - Forensic Engineering
          * 2019-07-05, Effect of Canyons on a Fire Propagating Laterally Over Slopes, Frontiers in Mechanical Engineering

        Tese / Dissertação

          * 2016-01, Mestrado, Caracterização do comportamento mecânico do tecido ósseo cortical através de ensaios de flexão

        Capítulo de livro

          * 2023, CHALLENGES IN BATHING WATERS DROWNING RISK MANAGEMENT – A CASE STUDY IN THE MADEIRA ISLAND
          * 2019, Mecanismos de propagación de incendios a las industrias afectadas por los grandes incendios forestales en Portugal en el 15 de octubre de 2017, Incendios Forestales: Amenazas y oportunidades ante los desafíos de un entorno cambiante
          * 2019, FOREST FUEL MANAGEMENT IN WILDLAND URBAN INTERFACE AREAS, Incendios Forestales: Amenazas y oportunidades ante los desafíos de un entorno cambiante
          * 2018, The large fire of Pedrógão Grande (Portugal) and its impact on structures, Advances in forest fire research 2018, Imprensa da Universidade de Coimbra
          * 2018, Modelling of junction fires with analytical and numerical analysis of the phenomena, Advances in forest fire research 2018, Imprensa da Universidade de Coimbra
          * 2018, Effect of canyons on a fire propagating laterally over slopes, Advances in forest fire research 2018, Imprensa da Universidade de Coimbra

        Relatório

          * 2019-07, Risco de incêndio em festivais de verão e parques de campismo e caravanismo tendo a vista a segurança dos seus ocupantes
          * 2019-03, Análise da exposição a incêndios florestais e medidas de autoproteção de instalações da REN
          * 2019-01, Análise dos incêndios florestais ocorridos a 15 de outubro de 2017, https://www.portugal.gov.pt/pt/gc21/comunicacao/documento?i=analise-dos-incendios-florestais-ocorridos-a-15-de-outubro-de-2017
          * 2017-10, O complexo de incêndios de Pedrógão Grande e concelhos limítrofes, iniciado a 17 de junho de 2017, https://www.portugal.gov.pt/pt/gc21/comunicacao/documento?i=o-complexo-de-incendios-de-pedrogao-grande-e-concelhos-limitrofes-iniciado-a-17-de-junho-de-2017

        Artigo em conferência

          * The impact of a large fire on communities: the case of Pedrógão Grande (Portugal), 6th International Fire Behavior and Fuels Conference
          * O impacto do incêndio de Pedrógão Grande nas estruturas, 6as Jornadas de Segurança aos Incêndios Urbanos e 1as Jornadas de Proteção Civil
          * Junction Fires at Laboratory and Field Scales, EJIL - LAETA Young Researchers Meeting
          * Industrial facilities affected by the set of wildfires that occurred in Portugal on the 15th of October, 2017 – analysis of the conditions under which the fire reached the facilities, 6th International Fire Behavior and Fuels Conference
          * Impacto das condições meteorológicas na gestão de emergência de um acidente grave envolvendo matérias perigosas: caso de estudo na linha ferroviária de Leixões, 7as Jornadas de Segurança aos Incêndios Urbanos e 2as Jornadas de Proteção Civil
          * Análise comparativa do risco de Incêndio Rural com base no teor de humidade dos combustíveis medidos em Coimbra, Viseu, Viana do Castelo e Faro, 7as Jornadas de Segurança aos Incêndios Urbanos e 2as Jornadas de Proteção Civil
          * 2021-06-17, Caracterização do risco de Incêndio Rural no distrito de Vila Real, 7as Jornadas de Segurança aos Incêndios Urbanos e 2as Jornadas de Proteção Civil

        Resumo em conferência

          * 2022, Cenarização de nuvens tóxicas em acidentes com matérias perigosas na linha férrea de Leixões, IV Symposium Ibero-African-American on Risks

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona