# Response for https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
          PT: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841 EN: https://www.ulusofona.pt/en/teachers/carla-cristina-marques-galego-1841
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
        fechar menu : https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carla-cristina-marques-galego-1841
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carla Cristina Marques Galego

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p1841
              car***@ulusofona.pt
              C712-FE3E-7690: https://www.cienciavitae.pt/C712-FE3E-7690
              0000-0001-9425-3217: https://orcid.org/0000-0001-9425-3217
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/3657a1db-bf52-4b25-aa81-5437e0ce4aad
      : https://www.ulusofona.pt/

        Resume

        Carla Galego is a sociologist with a master's and doctoral degree in Education. She held a scholarship from the Foundation for Science and Technology (FCT) from 2007 to 2011, during which she completed part of her doctoral program at the Department of Social Sciences and Comparative Education at the University of California, Los Angeles (UCLA), USA. She also spent time at the University of Valencia, Spain, where she collected empirical data on the contexts and working conditions of the academic profession, leading to the attainment of a European Doctorate. Currently, she is an Assistant Professor at the Universidade Lusófona - Centro Universitário de Lisboa, where, in addition to teaching responsibilities, she holds managerial roles as the Director of the bachelor’s and master’s degree in educational sciences. She also serves as the vice-director of the Master's Degree in Comparative Education. Carla is a member of the University Council at Universidade Lusófona and is actively involved in the Scientific Council and Pedagogical Council of the Faculty of Social Sciences, Education, and Administration at the same institution. As an integrated researcher at the Center for Interdisciplinary Studies in Education and Development (CeiED), she has participated in several national and international projects aligned with her research interests. These interests encompass educational policies, comparative education, research methodology, and the academic profession, with a focus on teaching professionalism in higher education. Noteworthy projects include the "ReMase - Research Methodologies in Advanced Education" [Jan 2022-Jun 2023], funded by FCT (EXPL/CED-EDG/1130/2021), and the project "A Success Story? Portugal and PISA (2000-2018)" [Sep 2018-Mar 2022], funded by FCT (PTDC/CED-EDG/30084/2017), and the project "TO INN – From Tradition to Innovation in Teacher Training Institutions," Erasmus+ Project Reference: 573685-EPP-1-2016-1-ES-EPPKA2-CBHE-JP [Mar 2017-Feb 2019]. In the field of Comparative Education, she co-coordinated the project "The language I inhabit, the world I build: teaching Portuguese language and developing skills in Lusophone community countries" [May 2022-May 2023), funded by CeiED (Reference: PE-CEIED-3/001/2022). During the period from March 2022 to March 2023, she was part of the Peer Thematic Group "Digitally Competent Teachers in Designing Quality Learning Environments," affiliated with the Learning & Teaching Forum network of the European University Association. In recent years, inherent to her roles as the director of the undergraduate and master's programs in educational sciences, the theme of students' scientific initiation has become an additional focus of her research interests. She coordinated the project "Science Schools," funded under the Summer with Science program by FCT. She is one of the coordinators of ReLeCo PPGE - Public Policies, Governance, and Education, also co-coordinating the Workshops CeiED | Reflection and Academic Production, whose objective is to support Ph.D. students during the development of their thesis projects. Furthermore, she acts as a representative for Education teachers on the Coordinating Committee of the Doctoral College at CeiED. She is a member of the SPCE-SEC-Comparative Education Section of the Portuguese Society of Educational Sciences, the WCCES-World Council of Comparative Education Societies, and the Comparative CIES-International Society of Comparative and International Education (CIES). She was a member of the Ibero-American Network for Research on Educational Policies (RIAIPE) and held the position of Technical Director at the polling center "Sonda Lusófona" from 2002 to 2004.

        Graus

            * Licenciatura
              Sociologia
            * Mestrado
              Ciências da Educação
            * Doutoramento
              Educação
            * Outros
              Formação Pedagógica Inicial de Formadores

        Publicações

        Artigo em revista (magazine)

          * 2014-12, Profissão Académica e os contextos e condições de investigação em Portugal, Encruzilhada de um futuro incerto
          * 2014-12, Profissão Académica e o contexto e condições de investigação em Portugal: encruzilhada de um futuro incerto, Ensino Superior - Revista SNESup

        Artigo em revista

          * 2023-06-08, Teaching Research Methods Courses in Education: Towards a Research-Based Culture, Social Sciences
          * 2023-01-07, Teaching and Learning Research Methodologies in Education: A Systematic Literature Review, Education Sciences
          * 2016-05-07, Políticas educativas e ensino superior análise da internacionalização no contexto de trabalho da profissão acadêmica em Portugal, Revista Internacional de Educação Superior
          * 2016, Políticas Educativas e Ensino Superior: análise da internacionalização no contexto de trabalho da profissão académica em Portugal, RIESup - Revista Internacional de Ensino Superior
          * 2016, 1ª Conferência SPCE-SEC A Educação Comparada para além dos números: contextos locais, realidades nacionais, processos transnacionais (Reseña), Revista Latinoamericana de Educación Comparada, 9, pp. 104-107.
          * 2010, Do fim dos eleitos ao processo de bolonha: as políticas de educação superior em portugal (1970-2008)/ From the end of the elected to the bologna process: the higher education policy in portugal (1970-2008).
          * 2010, Do Fim dos Eleitos ao Processo de Bolonha: As Políticas de Educação Superior em Portugal (1970-2008), Ensino Em-Revista
          * 2010, Do Fim dos Eleitos ao Processo de Bolonha: As Políticas de Educação Superior em Portugal (1970-2008), Ensino Em-Revista
          * 2010, Do Fim dos Eleitos ao Processo de Bolonha: AS Políticas de Educação Superior em Portugal (1970-2008), Ensino Em-Revista
          * 2005, Emancipação, ruptura e inovação: o “focus group” como instrumento de investigação., Revista Lusófona de Educação
          * 2005, Emancipação, ruptura e inovação: o “focus group” como instrumento de investigação, Revista Lusófona de Educação
          * 2005, Emancipação, ruptura e inovação : o "focus group" como instrumento de investigação
          * 2001, Identidades Culturais Infantis: análise de um projecto educativo em contexto local, Revista Cultural Anais de Almada
          * 2001, Identidades Culturais Infantis: análise de um projecto educativo em contexto local, Revista Cultural Anais de Almada
          * 2001, Identidades Culturais Infantis: análise de um projecto educativo em contexto local, Anais de Almada

        Tese / Dissertação

          * 2014, A profissão académica nas universidades e as políticas de educação superior: os casos de Portugal e Espanha

        Livro

          * 2018, O outro lado do espelho: percursos de investigação (CeiED 2013-2017), Benavente, Ana; Teodoro, António; Serrão, Jacinto; Brás, José Gregório Viegas; Gonçalves, Maria Neves; Martins, Jorge; Figueira, Eduardo Álvaro do Carmo; et al, Edições Universitárias Lusófonas
          * 2005, A Mediação Sócio-Cultural: Um Puzzle em Construção, 1, Oliveira, Ana; Galego, Carla, Alto-Comissariado para a Imigração e Minorias Étnicas

        Capítulo de livro

          * 2023, Trajectories and challenges of the section of comparative education of the Portuguese society of education sciences., WCCES-Brill Book Series
          * 2023, Mother tongue teaching and skills development: an analysis of secondary education curricula in European countries and Brazil, Values Education and Beyond: Implications for Emotional Learning, WCCES-Brill Book Series
          * 2019, Teaching Comparative Education in Portugal, Encyclopedia of Teacher Education, Springer Singapore
          * 2019, 4. Universidade Lusófona de Humanidades e Tecnologias, Dimensión social. Datos sociodemográficos, datos universitarios, ámbito motivacional, vida y participación académica y social de los estudiantes de Educación , : Institut de Creativitat i Innovacions Educatives de la Universitat de València
          * 2018, Universidade Lusofona de Humanidades Tecnologias, Educación Superior y Formación del Profesorado: Gobernanza y Política Social, Pertinencia Curricular e Innovacíon Docente, Institut de Creativitat i Innovacions Educatives de la Universitat de València
          * 2016, A Universidade e os desafios académicos em Portugal e Espanha. Vozes vividas, vozes sentidas em tempos de crise., A Educação na Europa do Sul. Constrangimentos e Desafios em Tempos Incertos, Faculdade de Ciências Sociais e Humanas da Universidade Nova de Lisboa
          * 2011, Reforma do Ensino Superior e a Implementação do Processo de Bolonha em Portugal. Mudanças e Encruzilhadas, Reformas Educativas, Educación Superior y Globalización en Brasil, Portugal y España, Germania
          * 2010, Do "fim dos eleitos" ao processo de Bolonha. As políticas de Educação Superior em Portugal (1970-2008), A Educação Superior no Espaço Iberoamericano. Do Elitismo à Transnacionalização, Edições Universitárias Lusófonas
          * 2009, La regulación transnacional de las políticas educativas. El papel de los indicadores de comparación internacional en la construción de una agenda global de educación, Espejo y Reflejo: Políticas Curriculares y Evaluaciones Internacionales, Editorial Germania
          * 2009, Do fim dos eleitos ao processo de Bolonha. As políticas de Educação Superior em Portugal (1970-2008), A Educação Superior no Espaço Ibero-americano. Do Elitismo à Transnacionalidade, Liberlivro

        Edição de livro

          * 2009

        Tradução

          * 2005, Os mundos distorcidos de Ivan Illich e Paulo Freire, Edições Afrontamento
          * 2003, Privatização da educação pública: Carlos Alberto Torres em conversa com Henry M. Levin, Edições Universitárias Lusófonas

        Relatório

          * 2023-12, A língua que habito, o mundo que construo Ensino de língua portuguesa e desenvolvimento de competências em países da comunidade lusófona
          * 2023-11-29, Project ReMASE - Research Methods in Advanced Studies in Education - Final report

        Artigo em conferência

          * PISA and Literacy Concept: Analyse of the Centrality of Literacy as the Main Operative Concept in Student Assessment, European Conference on Educational Research (ECER)
          * Academic Profession in the EHEA context: academic freedom and production of knowledge in Portugal and Spain, CONSORTIUM OF HIGHER EDUCATION RESEARCHERS
          * A europeização da educação superior e a construção do espaço europeu de educação superior: contexto, percurso e mecanismos, XIV CONGRESO NACIONAL Y I IBEROAMERICANO DE EDUCACIÓN COMPARADA Educación, Supranacionalidad y Ciudadanía. Educación de ciudadanos en contextos supranacionales: aportaciones desde la Educación Comparada
          * 2021-07, PROMOTING SKILLS THROUGH MOTHER LANGUAGE TEACHING: A COMPARATIVE CURRICULAR ANALYSIS OF SKILLS DEVELOPMENT MODELS IN SECONDARY SCHOOL IN SIX COUNTRIES
          * 2021-07, HOW CAN MOTHER LANGUAGE TEACHING CONTRIBUTE TO THE DEVELOPMENT OF 21ST CENTURY SKILLS?
          * 2018-01-31, As representações sociais emergentes nas narrativas de professores universitários: um modelo de intervenção na educação superior privada, II Conferência Internacional de Educação Comparada

        Resumo em conferência

          * 2023-10, Reconfiguration of the academic profession: processes of change in the practice of higher education teachers, Atee winter conference 2023 - Teacher Professional Development in Times of Global and Glocal Transformations: International Perspectives and Challenges
          * 2023-03-06, Language and Learning: an interdisciplinary analysis of critical thinking skills through Portuguese language, INTED2023 - The 17th annual International Technology, Education and Development
          * 2023-03, DEVELOPING CRITICAL THINKING IN SECONDARY EDUCATION, INTED2023 - The 17th annual International Technology, Education and Development
          * 2022-11-17, Language, teaching and learning skills: a comparative analysis in Portuguese-speaking countries, 5th WCCES Symposium. The Future is here: Transforming with Urgency Education Systems for Equitable Rights to Quality Learning
          * 2022, Ensino de língua materna e desenvolvimento de competências. Uma análise comparada de programas de ensino de 6 países, 4th WCCES Symposium
          * 2021, Mother language teaching and skills development: an analysis of the curricula of the last year of secondary education in European countries and Brazil, 3rd International Conference on Advanced Research in Education (EDUCATIONCONF)
          * 2018-01-29, Reconfiguração da profissão académica em Portugal e Espanha: do professor que investiga ao investigador que ensina, II Conferência Internacional de Educação Comparada

        Outra produção

          * 2015, Newsletter- SPCE-SEC , Edição técnica
          * 2008, The Riape. Ibero-American Network of Educational Policies

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona