# Response for https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
          PT: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121 EN: https://www.ulusofona.pt/en/teachers/dulce-patricia-vale-de-vasconcelos-pinto-6121
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
        fechar menu : https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/dulce-patricia-vale-de-vasconcelos-pinto-6121
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Dulce Patrícia Vale De Vasconcelos Pinto

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6121
              dul***@ulusofona.pt
              1616-07B1-EEBF: https://www.cienciavitae.pt/1616-07B1-EEBF
              0000-0003-3732-3092: https://orcid.org/0000-0003-3732-3092
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/c7e93bc5-45aa-417b-a81f-734bd150524e
      : https://www.ulusofona.pt/

        Resume

        Dulce Patrícia Vale de Vasconcelos Pinto. Completed the Doutoramento in PhD in Applied Psychology in 2017/07/13 by Universidade do Minho Centro de Investigação em Psicologia, Mestrado in Master in Psychology in 2011/07/22 by Universidade do Minho Centro de Investigação em Psicologia and Licenciatura in Bachelor of Science in Psychology in 2008/09/09 by Universidade Catolica Portuguesa Faculdade de Filosofia e Ciencias Sociais. Is Assistente in Psiquilíbrios - Centro de Consulta Psicológica e Apoio Educativo, Assistant Professor in Universidade Lusófona do Porto Faculdade de Psicologia Educação e Desporto, Researcher in HEI-Lab Digital Human-Environment Interaction Lab, Universidade Lusófona, Assistente in Serviço de Psicologia da Universidade Lusófona do Porto (SPULP), Coordenadora Pedagógica do 3º Ano da Licenciatura em Psicologia [Pedagogical Coordinator of the 3rd year of the Bachelor Degree in Psychology] in Universidade Lusófona do Porto, Representante internacional do Mestrado em Justiça Juvenil e Proteção de Crianças e Jovens em Perigo [International Representative of the Master Degree in Juvenile Justice] in Universidade Lusófona do Porto, Coordenadora dos Estágios Curriculares do Mestrado em Psicologia Clínica e da Saúde [Coordinator of the Curricular Internships of the Master in Clinical and Health Psychology] in Universidade Lusófona do Porto and Assessor in Serviço de Psicologia da Universidade Lusófona do Porto (SPULP). Published 9 articles in journals. Has 3 section(s) of books. Organized 3 event(s). Participated in 47 event(s). Has received 3 awards and/or honors. Participates and/or participated as Integration into Research Grant Fellow in 1 project(s), PhD Student Fellow in 1 project(s), Research Fellow in 1 project(s) and Researcher in 1 project(s). Works in the area(s) of Social Sciences with emphasis on Psychology. In their professional activities interacted with 36 collaborator(s) co-authorship of scientific papers. In his curriculum Ciência Vitae the most frequent terms in the context of scientific, technological and artistic-cultural output are: Dropout; Therapeutic collaboration; Process research; Narrative therapy; Change process; Significant events; Therapeutic alliance; Marketing; Psychotherapy; Therapeutic relationship; Emotional disorders; Cognitive-behavior therapy; Efficacy; Psychophysiology; Syncrony; Good outcome; Poor outcome; Constructivist therapy; Depression; Conversation analysis; Systematic review; Successful aging; Development; Motivation; Case study; Psychology; Drugs abuse; Prevention; Qualitative research; Emotion-focused therapy; Assimilation of problematic experiences; Borderline personality disorder; Psychodynamic therapy; Anxiety; Academic adaption; Academic performance; Professional practice; Personal constructs therapy; Dialogical self; Peer review; Alliance ruptures; Research methods; Clinical practice; Communication; Psychotherapy integration; Databases; Online search; Information sources; Evaluation; Intervention; Family; Suicide; Child abuse; Parenting; Health education; Special education; Mental health; Training; Skills; Psychological assessment; Neuropsychology; Neuropsychiatry; Family therapy; Mental disorders; Ethics; Bioethics; Death; Publication; Semistructured interview; NVivo; Scientific writing; Human-environment interactions; Cognitive-emotional processes; Behavioral modelling; Design systems; Basic Psychology; Applied Psychology; Health; Education; Neuropsicofisiologia; Aprendizagem e cognição; Psicologia clínica e forense; Psicologia da educação; .

        Graus

            * Licenciatura
              Bachelor of Science in Psychology
            * Mestrado
              Master in Psychology
            * Doutoramento
              PhD in Applied Psychology
            * Outros
              Training in Emotion-Focused Therapy - Level 1
            * Outros
              Practical course on Vocational Orientation
            * Outros
              Advanced course on Attention Deficit Hiperactivity Disorder: Evaluation and Intervention
            * Outros
              English course - Level B2
            * Outros
              Mini-course on Generalized Linear Models and Applications
            * Outros
              Course on English for Academic Purposes
            * Outros
              Formação Pedagógica Inicial de Formadores [Initial Trainers Training Course]
            * Outros
              Training on Conversation Analysis
            * Outros
              Curso de Formação Profissional associado ao Estágio Profissional [Course of Professional Training associated with the Psychology Professional Internship]
            * Outros
              Training on the Therapeutic Collaboration Coding System (TCCS)
            * Outros
              Training on the Assimilation of Problematic Experiences Scale (APES)
            * Outros
              Training on the Rupture Resolution Rating System (3RS)
            * Outros
              Training on The Video Annotation Research Tool (ANVIL)
            * Outros
              Guidelines for Supervision Practices
            * Outros
              Psychological Intervention with Older Adults
            * Outros
              Psychological Intervention with LGBTQ People
            * Outros
              Psychological Intervention in Alcohol Related Problems
            * Outros
              Dilemmas in Practice: Professional Decision Making (For Supervisors)

        Publicações

        Journal article

          * 2022-12-28, Therapist's interventions immediately after exceeding the client's therapeutic zone of proximal development: A comparative case study, Psychotherapy Research
          * 2021, Therapist's responsiveness when using supporting or challenging interventions: An exploratory case study
          * 2021, Therapeutic collaboration and physiological syncrony in cognitive-behavior therapy: An exploratory case study
          * 2019-06-25, Therapist's actions after therapeutic collaboration breaks: A single case study, Psychotherapy Research
          * 2019, Colaboración terapéutica: Estudio comparativo de un caso de éxito y un caso de fracaso de terapia constructivista [Therapeutic collaboration: A comparative study of a good and a poor outcome of constructivist therapy], Revista Argentina de Clínica Psicológica
          * 2018-07-01, The Therapeutic Collaboration in Dropout Cases of Narrative Therapy: An Exploratory Study, Revista de Psicoterapia
          * 2018, The therapeutic collaboration in dropouts of narrative therapy: An exploratory study, Revista de Psicoterapia
          * 2016, Therapeutic collaboration and significant events to the client's change: A systematic review, International Journal of Psychology and Psychological Therapy
          * 2015-06, Colaboração terapêutica: Estudo comparativo dois casos de insucesso terapêutico - Um caso finalizado e de um caso de desistência [Therapeutic collaboration: A comparative case study of two poor outcomes - A completer and a dropout], Análise Psicológica

        Thesis / Dissertation

          * 2017-07-13, PhD, O desenvolvimento da colaboração terapêutica em casos clínicos de desistência [The therapeutic collaboration development in dropout clinical cases]
          * 2011-07-22, Master, O desenvolvimento da colaboração terapêutica: O estudo de caso de um "dropout" seguido em terapia narrativa [Therapeutic collaboration development: A case study of a narrative therapy dropout]
          * 2008-09, Degree, "Dar mais vida aos anos": O idoso motivado e o envelhecimento bem-sucedido ["Giving life to years": The motivated elderly and successful aging]

        Book chapter

          * 2024, Therapeutic Collaboration Coding System (TCCS), Developing Process Sensitivity: A Transtheoretical Path to Improving Psychotherapy Training and Clinical Outcomes, APA
          * 2021, Therapeutic collaboration and responsiveness in narrative therapy, Attuning to enhance therapist responsiveness, American Psychological Association
          * 2019, Prevenir a desistência em psicoterapia: A relevância da aliança terapêutica [Preventing dropout in psychotherapy: The therapeutic alliance relevance], Aliança terapêutica: Da teoria à prática clínica [Therapeutic alliance: From theory to clinical practice], 2, Psiquilíbrios Edições

        Translation

          * 2022, Os anos incríveis: Guia de resolução de problemas para pais de crianças dos 2 aos 8 anos de idade, Psiquilíbrios

        Conference poster

          * 2024-06-26, Therapists' burnout: The role of emotion regulation, self-compassion, and self-efficacy, 55th Annual International Meeting of the Society for Psychotherapy Research
          * 2024-04-09, Psychotherapy studies: The therapist, the client and the therapeutic relationship, I Jornadas em Psicologia: Práticas e Aplicações [1st Conferences in Psychology: Practices and Applications]
          * 2018-05, Colaboração terapêutica e sincronia psicofisiológica: O estudo de um caso de desistência [Therapeutic collaboration and psychophysiological syncrony: A case study of a dropout], IX Seminário de Investigação em Psicologia da Universidade do Minho [IX Research Seminar in Psychology of the University of Minho]
          * 2018-04, Therapeutic collaboration and the dyad's physiological syncrony in psychotherapy, 12º Simpósio da Fundação Bial [12th Symposium of the Bial Foundation]
          * 2016-06, Therapeutic collaboration and psychophysiological arousal: A comparative study of a dropout and a completer case, 3rd International Conference of the European Society for Cognitive and Affective Neuroscience
          * 2016-05, Microprocessos psicobiológicos em psicoterapia: Estudo de um caso de desistência [Psychobiological microprocesses in psychotherapy: A case study of a dropout], VII Seminário de Investigação em Psicologia da Universidade do Minho [VII Research Seminar in Psychology of the University of Minho]
          * 2016-05, Interações não colaborativas em psicoterapia: Análise de conversação dos esforços do terapeuta para restabelecer a colaboração [Non-collaborative interactions in psychotherapy: Conversation analysis of the therapist's efforts to reestablish collaboration], VII Seminário de Investigação em Psicologia da Universidade do Minho [VII Research Seminar in Psychology of the University of Minho
          * 2014-05, O desenvolvimento da colaboração terapêutica: Estudo comparativo de um caso de sucesso e de um caso de desistência em terapia narrativa [Therapeutic collaboration development: A comparative case study of a good outcome and a dropout of narrative therapy], V Seminário de Investigação em Psicologia da Universidade do Minho [V Research Seminar in Psychology of the University of Minho]
          * 2013-06, A systematic review protocol on therapeutic collaboration as a micro-process in significant change events in psychotherapy, XXIXth Annual Meeting of the Society for the Exploration of Psychotherapy Integration
          * 2013-05, O desenvolvimento da colaboração terapêutica: O estudo de caso de um dropout seguido em terapia narrativa [Therapeutic collaboration development: A case study of a narrative therapy dropout], IV Seminário de Investigação em Psicologia da Universidade do Minho [IV Research Seminar in Psychology of the University of Minho]
          * 2010-06, Formation of therapeutic alliance: Micro-analysis of therapist and client's interactions, 41st Annual Meeting of the Society for Psychotherapy Research

        Other output

          * 2019, The Therapeutic Collaboration Coding System (TCCS): Revised training manual, Unpublished, for internal use in training sessions on the TCCS
          * 2016-02-04, The Therapeutic Collaboration Coding System (TCCS): Training manual, Unpublished, for internal use in training sessions on the TCCS

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona