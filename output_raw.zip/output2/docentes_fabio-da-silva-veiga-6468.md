# Response for https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
          PT: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468 EN: https://www.ulusofona.pt/en/teachers/fabio-da-silva-veiga-6468
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
        fechar menu : https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/fabio-da-silva-veiga-6468
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Fábio Da Silva Veiga

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6468
              fab***@ulusofona.pt
              F313-5A02-C668: https://www.cienciavitae.pt/F313-5A02-C668
              0000-0002-9986-7813: https://orcid.org/0000-0002-9986-7813
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/525b5b0c-2a36-4bd8-b4ba-1f2a0427261e
      : https://www.ulusofona.pt/

        Resume

        Assistant Professor of Business Law at the Faculty of Law and Political Science at Universidade Lusófona (2021-current), full-time at Bachelor's, Master's and Doctorate levels. He was a guest professor (in public capacity) of Business Law at the School of Technology and Management of the Polytechnic of Leiria (2022). President of the Ibero-American Institute of Legal Studies - IBEROJUR. He was Professor of Business Law at the University of Almería, Spain (approved in PSI competition), 2020. He was Venia docendi Professor at the Faculty of Legal Sciences at the University of Las Palmas de Gran Canaria, Spain (2019). He was Professor of Business Law in the Master in Law at the European University of Madrid (2016-2017-2018). He served as Coordinator of the Post-doctorate in Public Law at the University of Santiago de Compostela (2017-2018-2019-2020). Doctor in Business Law (Market Legal Order) from the University of Vigo, Spain (2012-2017) with the maximum grade Suma Cum Laude, distinguished with the Extraordinary Doctoral Thesis Prize from the University of Vigo; Researcher of the Doctoral Program in Business Law at the University of Alcalá (Madrid, Spain) with a DPE Capes Scholarship (2015-2020). Completed an Advanced Scientific Internship at the Law School of the University of Minho, Portugal (2019). Master in Contract and Company Law, from the University of Minho - Braga, Portugal (2010-2014) - concentration area: Responsibility of Directors in the context of Insolvency. Specialist in Contract and Company Law from the University of Minho (2011); Postgraduate in Initiation to University Teaching from the New Professorship Training Program at the University of Vigo - Spain (2011/2012). He was a Guest Professor at the "Máster en Diritto Privato Europeo" at the Univesitá degli Studi Mediterranea di Reggio Calabria (2017-2019). Guest Professor of the Postgraduate Course in Constitutional Law at Faculdade Damásio, São Paulo (2017). Integrated Researcher at CEAD Francisco Suárez from Universidade Lusófona (since 2021). Last update: January 20, 2024.

        Graus

            * Doctor
              Ordenación Jurídica del Mercado
            * Especialização pós-licenciatura
              Formación a la Docencia Universitaria
            * Especialização pós-licenciatura
              Direito dos Contratos e da Empresa
            * Bacharelato
              Direito
            * Mestrado
              Direito dos Contratos e da Empresa

        Publicações

        Edição de número de revista

          * ULP Law Review, 16

        Artigo em revista

          * 2023-11-15, RESPONSABILIDADE SOCIAL DAS EMPRESAS E DIREITOS HUMANOS, Veredas do Direito – Direito Ambiental e Desenvolvimento Sustentável
          * 2023-10-25, O enquadramento do grau de insalubridade: uma análise das implicações nas negociações coletivas de trabalho, Revista Eletrônica do Tribunal Regional do Trabalho 9 Região
          * 2022-07-02, A responsabilidade civil subjetiva de agentes de tratamento de dados pessoais na ótica da Análise Econômica do Direito, Economic Analysis of Law Review
          * 2022, The creation of value by socially responsible companies from the legal perspective of the social interest, Studia Prawnicze., Rozprawy i Materialy - Studies in Law: Research Papers
          * 2022, O conceito de empresa na sociedade digitalizada: referência às fintech's, XI Congresso Internacional de Ciências Jurídico-Empresariais - Atas
          * 2020-08-06, O ENSINO FRATERNAL E HUMANISTA COMO PRESSUPOSTO DEMOCRÁTICO E A EFETIVA INTEGRAÇÃO DOS DIREITOS HUMANOS NA AGENDA EDUCACIONAL ATÉ 2030, Revista Direitos Humanos e Democracia
          * 2020-04-25, UBIQUIDADE CONSTITUCIONAL E DIREITOS FUNDAMENTAIS, Relações Internacionais no Mundo Atual
          * 2019-07-20, NOTAS SOBRE A ANÁLISE ECONÔMICA DO DIREITO E SUA UTILIZAÇÃO NA APLICAÇÃO DE DECISÕES JUDICIAIS, Relações Internacionais no Mundo Atual
          * 2019-01-17, A EVOLUÇÃO DA RESPONSABILIDADE CIVIL: DA OBJETIVAÇÃO DA RESPONSABILIDADE À PREVENÇÃO DE DANOS, Relações Internacionais no Mundo Atual
          * 2019, Open banking: expectativas e desafios para o mercado financeiro no Brasil, Administração de Empresas em Revista
          * 2019, Estruturalismo, Desenvolvimento e Legislação Comercial, Estruturalismo, desenvolvimento e legislação comercial
          * 2018-04-11, The capital markets union in the scope of the European financial system, Revista de Estudos Constitucionais, Hermenêutica e Teoria do Direito
          * 2018, A preservação do direito à informação na relação médico-paciente: estratégia pedagógica na educação em saúde. , Educação e Saúde: fundamentos e desafios
          * 2017-12, O IMPACTO DO BREXIT NA UNIÃO FINANCEIRA EUROPEIA, Revista de Direito da Empresa e dos Negócios
          * 2017-10, Eu, tu, as nanotecnologias e o outro: qual a contribuição do diálogo entre Buber e Ost para o homem?, Conpedi Law Review
          * 2017-07, The pioneering of the case of BES and the bank resolution, REVISTA DE DIREITO BANCÁRIO DO MERCADO DE CAPITAIS E DA ARBITRAGEM (Thomson Reuters)
          * 2017-06, O PIONEIRISMO DO CASO BES E DA RESOLUÇÃO BANCÁRIA, REVISTA QUAESTIO IURIS
          * 2017-01, Reorientação do princípio par conditio creditorum no processo de insolvência português, Cadernos de Dereito Actual
          * 2017, The pioneering of the case of BES and the bank resolution., REVISTA DE DIREITO BANCÁRIO DO MERCADO DE CAPITAIS E DA ARBITRAGEM
          * 2017, Reorientação do princípio par conditio creditorum no processo de insolvência português. , CADERNOS DE DEREITO ACTUAL (ONLINE)
          * 2017, O impacto do Brexit na União Financeira Europeia, Revista de Direito da Empresa e dos Negócios
          * 2016-07, A conexão da desconsideração da personalidade jurídica com a responsabilidade societária, Revista de Direito Empresarial (Thomson Reuters)
          * 2016-06, Pacta sund servanda e justiça: análise da peça 'o mercador de Veneza' de Shakespeare, Revista Jurídica - Unicuritiba
          * 2016-06, A responsabilidade subsidiária do diretor e as diferenças de interpretação no âmbito do direito comercial e tributário português, Revista Jurídica - Unicuritiba
          * 2016, The Revolution of the Tax System based on Flat Tax., ATHENS JOURNAL OF LAW
          * 2016, Empresa e Direitos Humanos: Da Governança Corporativa à Responsabilidade Social Corporativa., RJLB - REVISTA JURÍDICA LUSO-BRASILEIRA
          * 2016, A conexão da teoria da desconsideração da personalidade jurídica com a responsabilidade societária = The connection of theory disregard of the legal entity with the corporate responsability
          * 2015-10, Lobbies, grupos de interesse e sua intervenção nas políticas públicas: regulamentação e supervisão através do estudo do sistema americano, Revista Ballot
          * 2015, grupos de interesse e sua intervenção nas políticas públicas: regulamentação e supervisão através do estudo do sistema americano., Revista Ballot
          * 2015, Uma reavaliação do princípio par conditio creditorum nos processos de insolvência portugueses, RSDE. REVISTA SEMESTRAL DE DIREITO EMPRESARIAL
          * 2015, ASPECTOS PROCESSUAIS E PROCEDIMENTAIS DA CONVENÇÃO DA HAIA SOBRE ASPECTOS CIVIS DO SEQUESTRO INTERNACIONAL DE CRIANÇAS., CADERNOS DE DEREITO ACTUAL (ONLINE)
          * 2015, A HIPÓTESE INTEGRADORA DA GOVERNANÇA CORPORATIVA E DA RESPONSABILIDADE SOCIAL CORPORATIVA SOB O ENFOQUE DOS DIREITOS HUMANOS, Direito e Justiça - Aspectos Atuais e Problemáticos, Tomo III - Direito Privado.
          * 2014-08, O dever de cuidado dos administradores e a concepção da business judgement rule em ordenamentos jurídicos de civil law, Revista de Estudos Jurídicos da Universidade Estadual Paulista
          * 2013, Aspetos da Posição Dominante Correlatos ao Abuso de Atos Anticoncorrenciais no Mercado Europeu., Revista do Instituto do Direito Brasileiro
          * 2012, O dever de informação na relação médico-paciente e a responsabilidade médica., Orbis Revista Científica
          * 2012, A proteção jurídica da marca olfativa., Jus Societas
          * 2012, O interesse social: dos interesses dos shareholders aos interesses dos stakeholders., Âmbito Jurídico
          * 2012, A Responsabilidade Tributária Subsidiária por Violação dos Deveres de Administração. , Revista do Instituto do Direito Brasileiro
          * 2011, O dever de informação dos atos bancários na fase pré-contratual e a culpa in contrahendo. , Cadernos da Escola de Direito e Relações Internacionais da UniBrasil
          * 2011, A insolvência de pessoa singular: Estudos sobre a conduta do devedor como condição de exoneração do passivo restante., Âmbito jurídico
          * 2011, O dever de lealdade dos administradores: consequências no dever de não concorrência e não apropriação das oportunidades de negócios ? sob a perspectiva do direito português. , Âmbito Jurídico
          * 2010, O poder directivo do empregador versus o direito à reserva da intimidade da vida privada do trabalhador., Jus Societas

        Tese / Dissertação

          * 2014, Mestrado, A responsabilidade civil dos administradores na insolvência.
          * 2013, Mestrado, Responsabilidade civil dos administradores na insolvência
          * 2009, Licenciatura, Da aplicabilidade dos princípios do direito do trabalho na sentença.

        Livro

          * 2023, Temas Especiais do Direito Processual, 1, Veiga, Fábio da Silva; Garret, João Bahia Almeida; Anjos, Maria do Rosário, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Livro de Resumos do V Encontro Iberoamericano de Direito e Desenvolvimento, 1, Veiga, Fábio da Silva; Leitão, André Studart; Lima, Renata Albuquerque; Saleh, Paula, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Livro de Resumos do II Congresso Internacional Novos Desafios dos Direitos Humanos (II CINDHU), 1, Monteiro, Susana Sardinha; Cebola, Cátia Marques; Veiga, Fábio da Silva, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Legal Aspects of Artificial Intelligence Application in Medicine and Healthcare, 1, Veiga, Fábio da Silva; Zalucki, Mariusz, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Lavori atipici ed economia digitale – Prospettiva luso-italo-brasiliana – Contratos atípicos de emprego e economia digital – Perspectiva Luso–Ítalo-Brasileira, 1, Veiga, Fábio da Silva; Benevides, Camilla Martins dos Santos, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Estudos do Direito, desenvolvimento e acesso à justiça, 1, Veiga, Fábio da Silva; Leitão, André Studart; Lima, Renata Albuquerque; Saleh, Paula, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Estudos de Direito Luso-Brasileiro, 1, Veiga, Fábio da Silva; Lopes, Dulce; XAVIER, JOÃO PROENÇA, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Direitos fundamentais na perspectiva Ítalo-brasileira, Vol. IV, 4, Viglione, Filippo; Veiga, Fábio da Silva; Bennati, Francesca, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Direitos fundamentais na perspectiva Ítalo-brasileira, Vol. III, 3, Veiga, Fábio da Silva; Viglione, Filippo; Bennati, Francesca, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Direitos Humanos, Cidadania e Desenvolvimento Sustentável, 1, Monteiro, Susana Sardinha; Cebola, Cátia Marques; Veiga, Fábio da Silva, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2023, Book of 26rd Annual Meeting of Nanterre Network – Law and Culture, 1, Seul,Otmar; Dijoux, Stephanie; Veiga, Fábio da Silva, Instituto Iberoamericano de Estudos Jurídicos– IBEROJUR
          * 2022, Ética jurídica na era digital, 1, Veiga, Fábio da Silva; Amorim, José Campos; Anjos Azevedo, Patrícia, Instituto Iberoamericano de Estudos Jurídicos
          * 2022, LegalTech, Artificial Intelligence and the Future of Legal Practice. , 1, Veiga, Fábio da Silva; Mariusz Zalucki. Autor correspondente: Mariusz Zalucki, Instituto Iberoamericano de Estudos Jurídicos
          * 2022, Governança e inovação na perspectiva jurídica, 1, Veiga, Fábio da Silva; Cristóvam, José Sérgio da Silva; Padilha, Norma Sueli. Autor correspondente: Padilha, Norma Sueli, Instituto Iberoamericano de Estudos Jurídicos
          * 2022, Future Law, vol. III, 1, Veiga, Fábio da Silva; Paulo José Homem de Sousa Alves de Brito, Instituto Iberoamericano de Estudos Jurídicos
          * 2022, Estudos Jurídicos sobre Inteligência Artificial e Tecnologias, 1, Veiga, Fábio da Silva; Cebola, Cátia Marques; Monteiro, Susana Sardinha, Instituto Iberoamericano de Estudos Jurídicos
          * 2022, Diálogos dos direitos humanos, 1, Veiga, Fábio da Silva; Alves, Rodrigo Vitorino Sousa; Fonseca, Maria Hemilia, Instituto Iberoamericano de Estudos Jurídicos
          * 2021, Direitos Fundamentais na Perspectiva Ítalo-Brasileira - vol. II, II, Veiga, Fábio da Silva; Viglione, Filippo; Durante, Vincenzo. Autor correspondente: Durante, Vincenzo, Instituto Iberoamericano de Estudos Jurídicos
          * 2021, Derecho Transnacional Iberoamericano, Vol. II, 1, Veiga, Fábio da Silva; Bujosa Vadell, Lorenzo . Autor correspondente: Bujosa Vadell, Lorenzo , Tirant Lo Blanch
          * 2021, Derecho Iberoamericano en análisis., 1, Veiga, Fábio da Silva, Aranzadi-Thomson Reuters
          * 2021, Direitos Fundamentais na Perspectiva Ítalo-Brasileira - Vol. I, 1, Veiga, Fábio da Silva; Viglione, Filippo; Durante, Vincenzo. Autor correspondente: Durante, Vincenzo, Instituto Iberoamericano de Estudos Jurídicos
          * 2021, A responsabilidade dos administradores de sociedades - especial referência aos pressupostos da insolvência. , 1, Veiga, Fábio da Silva, Aranzadi-Thomsom Reuters
          * 2020, Studi sui Diritti Emergenti., 1, Veiga, Fábio da Silva, Instituto Iberoamericano de Estudos Jurídicos
          * 2020, Governança e Direitos Fundamentais - revistando o debate entre o público e o privado. , 1, Veiga, Fábio da Silva; Solon de Sá e Benevides; Francisco de Sales Gaudêncio, Instituto Iberoamericano de Estudos Jurídicos
          * 2020, Estudos de Direito, Desenvolvimento e Novas Tecnologias. , 1, Veiga, Fábio da Silva; Paulo José Homem de Sousa Alves de Brito; Rodrigo Régnier Chemim Guimarães. Autor correspondente: Paulo José Homem de Sousa Alves de Brito, Instituto Iberoamericano de Estudos Jurídicos
          * 2020, Desafios do Legaltech, 1, Veiga, Fábio da Silva; Anjos Azevedo, Patrícia; Amorim, José Campos, Instituto Iberoamericano de Estudos Jurídicos
          * 2020, Novos métodos disruptivos no direito., 1, Veiga, Fábio da Silva; Luiz Gustavo Levate; Marcelo Kokke Gomes. Autor correspondente: Luiz Gustavo Levate, Instituto Iberoamericano de Estudos Jurídicos
          * 2020, La fuerza institucional de la abogacía pública en el contexto europeo., 1, Veiga, Fábio da Silva, CESEG
          * 2020, Direitos fundamentais e inovações no Direito, 1, Veiga, Fábio da Silva; Martins, Flávio, Instituto Iberoamericano de Estudos Jurídicos
          * 2020, Análise Crítica do Direito Ibero-americano, 1, Veiga, Fábio da Silva; Paulo José Homem de Sousa Alves de Brito. Autor correspondente: Paulo José Homem de Sousa Alves de Brito, Instituto Iberoamericano de Estudos Jurídicos
          * 2019, Imágenes contemporáneas de la realización de los derechos en la cultura jurídica iberoamericana, 1, Veiga, Fábio da Silva; Laura Miraut Martín, Dykinson
          * 2019, Estudios de Derecho Iberoamericano, Vol. I, 1, Veiga, Fábio da Silva; Gabriel Martín Rodríguez, Dykinson
          * 2019, Book of 23rd Annual Meeting of Nanterre Network. Legal and interdisciplinary challenges in contemporary society, 1, Veiga, Fábio da Silva; Bujosa Vadell, Lorenzo ; Otmar Seul, Instituto Iberoamericano de Estudos Jurídicos e Universidad de Salamanca
          * 2019, Estudios de Derecho Iberoamericano, Vol. II, 1, Veiga, Fábio da Silva; Rodríguez Martín, Gabriel, La Casa del Abogado
          * 2019, Direito Constitucional: Estudo interdisciplinar Ibero-Americano. , 1, Veiga, Fábio da Silva, Instituto Iberoamericano de Estudos Jurídicos e Universidade Lusófona do Porto
          * 2018, II Congresso Ibero-americano de Intervenção Social "Direitos Sociais e Exclusão"., 1, Veiga, Fábio da Silva
          * 2018, Future Law , 1, Botelho, Catarina Santos; Veiga, Fábio da Silva, Universidade Católica Editora - Porto
          * 2018, Atualidades na Ciência Jurídica: Intercâmbio Iberoamericano, 1, Veiga, Fábio da Silva; Anjos, Maria do Rosário; Anjos Azevedo, Patrícia, Instituto Iberoamericano de Estudos Jurídicos e Instituto Politécnico da Maia
          * 2018, Derecho Transnacional Iberoamericano, 1, Veiga, Fábio da Silva; Bujosa Vadell, Lorenzo , Tirant Lo Blanch
          * 2017, Os Novos Horizontes do Constitucionalismo Global., 1, Barcelos: Instituto Politécnico do Cávado e do Ave
          * 2017, O Direito actual e as novas fronteiras jurídicas no limiar de uma nova era. , 1, Porto: Universidade Católica Editora
          * 2017, O Direito Atual e as Novas Fronteiras Jurídicas. , 1, Instituto Politécnico do Cávado e do Ave
          * 2017, Los desafíos Jurídicos a la gobernanza global: una perspectiva para los próximos siglos., 1, Brasília: Advocacia-Geral da União
          * 2017, Derecho, gobernanza e innovación: Dilemas jurídicos de la contemporaneidad en perspectiva transdisciplinar., 1, Miranda Gonçalves, Rubén, editor; Veiga, Fábio da Silva, editor; Silva, Maria Manuela Magalhães, editor, Porto: Universidade Portucalense
          * 2017, Paradigmas do Direito Constitucional Atual., 1, Barcelos: Instituto Politécnico do Cávado e do Ave
          * 2017, I Congresso Ibero-Americano de Intervenção Social - Cidadania e Direitos Humanos., 1, Carviçais: Lema d'Origem
          * 2016, O direito constitucional e o seu papel na construção do cenário jurídico global., 1, Barcelos: Instituto Politécnico do Cávado e do Ave
          * 2016, Livro de Resumo / Book of Abstracts do I Congresso de Direito Constitucional Internacional., 1
          * 2016, Dimensões dos Direitos Humanos. , 1, Silva, Maria Manuela Magalhães; Castilhos, Daniela Serra; Veiga, Fábio da Silva; Gonçalves, Rubén Miranda, Universidade Portucalense Infante D. Henrique

        Capítulo de livro

          * 2023, O Impacto da Blockchain no Direito Bancário , Estudios de Derecho y governança, 1, 1, Universidad Rey Juan Carlos e Instituto Iberoamericano de Estudos Jurídicos
          * 2023, El concepto de empresa en la sociedad digitalizada: especial referencia a las Fintech, Aspectos jurídicos de la actualidad en el ámbito del derecho digital, , 1, 1, Tirant Lo Blanch
          * 2023, Compliance como Mecanismo para Garantir a Ética e a Integridade no Exercício das Atividades das Instituições Privadas de Ensino Superior do Brasil, Estudios de Derecho y Gobernanza, 1, 1, Universidad Rey Juan Carlos e Instituto Iberoamericano de Estudos Jurídicos
          * 2022, Desafíos de la regulación de la inteligencia artificial, Los Derechos Humanos en la inteligencia artificial su integración en los ODS de la Agenda 2030, 1, 1, Aranzadi-Thomson Reuters
          * 2021, O dever de lealdade dos administradores conforme o dever de proteção do interesse social., Derecho Transnacional Iberoamericano, II, 1, Tirant Lo Blanch
          * 2021, O custo dos direitos e os deveres: outra perspectiva de análise sobre os direitos sociais., Future Law, Vol. II, II, 1, Instituto Iberoamericano de Estudos Jurídicos / Universidade Lusófona do Porto
          * 2021, La creación de valor de la empresa socialmente responsable en la perspectiva jurídica del Interés social., Derecho Iberoamericano en análisis, 1, 1, Aranzadi Thomson Reuters
          * 2020, Social interest: from shareholders’ interests to stakeholders’ interests, CONSTITUTIONAL RIGHT TO PROPERTY ? METHODS OF VIOLATION AND MEANS OF PROTECTION, 1, 1, Wydawnictwo C.H. Beck
          * 2020, Arbitragem e ordem pública económica, El derecho público y privado ante las nuevas tecnologías., 1, 1, Editorial Dykinson
          * 2020, A responsabilidade tributária dos administradores de sociedades e a contribuição do direito societário, Finanças públicas, orçamento e tributação: parâmetros normativos e concretização, 1, 1, ESENI editora
          * 2020, A criação de valor da empresa socialmente responsável na perspectiva jurídica do interesse social., Estudos de Direito, Desenvolvimento e Novas Tecnologias., 1, 1, Instituto Iberoamericano de Estudos Jurídicos / Universidade Lusófona do Porto
          * 2020, A educação no domínio dos direitos humanos: o ensino humanista como corolário da democracia e do estado de direito., Sociedade, Educação e violência, 1, 1, Quartier Latin
          * 2019, O poder de vigilância do empregador ante a proteção do direito de personalidade do trabalhador nos sistemas de videovigilância., Direito Constitucional: Estudo interdisciplinar Ibero-Americano., 1, 1, Multifoco Editora
          * 2019, Contextualização do Direito Concorrencial Brasileiro, Estudios de Derecho Iberoamericano. , 1, 1, Dykinson
          * 2018, Ponderações sobre a reestruturação de empresas no processo especial de revitalização e nos acordos extrajudiciais., Futurelaw, 1, 1, Universidade Católica Portuguesa Editora
          * 2018, La unión financiera y el sistema europeo de supervisión financiera: la cuarta libertad constitutiva del mercado comunitario., Derecho Transnacional Iberoamericano, 1, 1, Tirant Lo Blanch
          * 2018, La relación entre el aumento de la complejidad empresarial y el desarrollo económico sostenible (agenda 2030): el caso de la EMBRAPA y las nanotecnologías, Los nuevos desafíos del derecho iberoamericano, 1, 1, La Casa del Abogado
          * 2018, El deber de lealtad de los administradores y el conflicto de interés en los grupos de sociedades españoles. , Imágenes contemporáneas de la realización de los derechos en la cultura jurídica iberoamericana, 1, 1, Dykinson
          * 2017, Políticas Públicas como instrumento de efetivação da cidadania, desenvolvimento, transparência e solidariedade., Códigos de conduta: a "autorregulação" como proposta de efetivação da responsabilidade social corporativa. , 1, 1, Editora CRV
          * 2017, Paradigmas do Direito Constitucional Atual., 1, 1, IPCA
          * 2017, El comportamiento de los stakeholders como parámetro de control jurídico sobre los riesgos nanotecnológicos., Los desafíos Jurídicos a la gobernanza global: una perspectiva para los próximos siglos. , 1, 1, Advocacia-Geral da União
          * 2017, Considerações acerca do impacto ambiental, política de descarte de resíduos e a responsabilidade empresarial no pós-consumo., Paradigmas do Direito Constitucional Atual., 1, 1, Instituto Politécnico do Cávado e do Ave
          * 2017, A universalização dos Direitos Humanos na vertente Kantiana., O Direito Atual e as Novas Fronteiras Jurídicas., 1, 1, Instituto Politécnico do Cávado e do Ave
          * 2017, La relación de la responsabilidad societaria y la responsabilidad concursal de los administradores de sociedades en Portugal. , O direito actual e as novas fronteiras jurídicas no limiar de uma nova era., 1, 1, Universidade Católica Editora
          * 2016, A responsabilidade social das empresas., Dimensões dos Direitos Humanos., 1, 1, Universidade Portucalense
          * 2016, A União Financeira e o Sistema Europeu de Supervisão Financeira: a «quarta» liberdade constitutiva do Mercado Comunitário., O direito constitucional e o seu papel na construção do cenário jurídico global. , 1, 1, Instituto Politécnico do Cávado e do Ave
          * 2016, A livre iniciativa na ordem constitucional luso-brasileira. , Dimensões dos Direitos Humanos. , 1, 1, Universidade Portucalense
          * 2016, A integração participativa de jovens investigadores na lusofonia., Administración Pública, Juventud y Democracia Participativa., 1, 1, Xunta de Galicia
          * 2015, El gobierno de las sociedades y los derechos humanos de los stakeholders., Derechos Humanos y Juventud. , 1, 1, Xunda de Galicia

        Edição de livro

          * 2023, Instituto Iberoamericano de Estudos Jurídicos e Associação de Estudos Europeus de Coimbra (Faculdade de Direito da Universidade de Coimbra)
          * 2023, 2, 1, Instituto Iberoamericano de Estudos Jurídicos
          * 2023, 1, 1, Instituto Iberoamericano de Estudos Jurídicos
          * 2020, 1, 1, Dykinson

        Tradução

          * 2011, Publicidade jurídica do Gabinete de Advogados António Vilar & Associados - versão em espanhol.

        Documento de trabalho

          * 2022-12, Atas do I Seminário de Doutoramento em Direito da Universidade Lusófona
          * 2017, O Direito Lusófono – Atas do I Congresso Jurídico de Investigadores Lusófonos

        Artigo em conferência

          * 2021-12-10, O conceito de empresa na sociedade digitalizada: referência às fintech's., XI Congresso Internacional de Ciências Jurídico-Empresariais 'Economia digital, direito e as empresas'
          * 2019-12-05, Deberes de lealtad de los administradores en los grupos de sociedades: ¿lagunas o Conflictos normativos en los grupos de sociedades., Séptimas Jornadas de Jóvenes Investigadores de la Universidad de Alcalá
          * 2019-07-11, A empresa para o desenvolvimento no Brasil, 23º Annual Meeting of Nanterre Network
          * 2017, spectos recientes sobre los grupos de sociedades en el derecho de sociedades europeo., VI Jornadas de los Jóvenes Investigadores de la Universidad de Alcalá
          * 2017, Considerações acerca do impacto ambiental, política de descarte de resíduos e a responsabilidade empresarial no pós-consumo.
          * 2016, A União Financeira e o Sistema Europeu de Supervisão Financeira: a «quarta» liberdade constitutiva do Mercado Comunitário.
          * 2012, O interesse social: dos interesses dos shareholders aos interesses dos stakeholders., Jornada de Direito Empresarial Âmbito Jurídico
          * 2011, A responsabilidade tributária subsidiária por violação dos deveres de administração, III Congresso Internacional de Ciências Jurídico-Empresariais: Direito e Gestão Empresarial.

        Resumo em conferência

          * 2018, A lusofonia como fator de impacto na ciência jurídica iberoamericana: projeto IBEROJUR., 5.º Congresso Internacional de Direito na Lusofonia
          * 2016, The capital markets union and the european financial supervision system., I Congress of International Constitutional Law
          * 2016, Os jovens investigadores do direito na lusofonia: o que fazer para dinamizar a integração científica?., 3.º Congresso de Direito na Lusofonia
          * 2016, O interesse público tributário: os limites jurídico-constitucionais ao princípio do interesse público., I Congresso de Direito Constitucional Internacional
          * 2015, THE INFLUENCES OF PUBLIC LAW ON PRIVATE LAW AND THE CORRELATIONS OF THE CORPORATE SOCIAL RESPONSIBILITY VS. THE HUMAN RIGHTS. , 8TH MEETING OF YOUNG RESEARCHERS OF UNIVERSITY OF PORTO
          * 2015, OS DIREITOS LABORAIS NA PERSPECTIVA DOS DIREITOS HUMANOS: A COMPREENSÃO FILOSÓFICA E ÉTICA DOS DIREITOS HUMANOS., I Congresso Internacional Dimensões dos Direitos Humanos
          * 2015, O Confronto dos Direitos Humanos com a responsabilidade social das empresas., I Congresso Internacional Dimensões dos Direitos Humanos

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona