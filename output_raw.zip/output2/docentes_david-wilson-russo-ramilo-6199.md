# Response for https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
          PT: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199 EN: https://www.ulusofona.pt/en/teachers/david-wilson-russo-ramilo-6199
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
        fechar menu : https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/david-wilson-russo-ramilo-6199
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          David Wilson Russo Ramilo

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6199
              p61***@ulusofona.pt
              331D-CC48-62EB: https://www.cienciavitae.pt/331D-CC48-62EB
              0000-0003-4096-2581: https://orcid.org/0000-0003-4096-2581
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/17e49463-a44a-41ab-bf19-7f1a4465cb85
      : https://www.ulusofona.pt/

        Resume

        David Wilson Russo Ramilo. É Professor Auxiliar na Faculdade de Medicina Veterinária, Universidade Lusófona. Atua na(s) área(s) de Ciências Agrárias com ênfase em Ciências Veterinárias. No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural são: Culicoides; Vector borne; Zoonosis; Composed optical microscopy; Scanning electron microscopy; Aracno-entomology; Protozoology; Helminthology; Virology; Statistical analysis; One Health.

        Graus

            * Doutoramento
              Ciências Veterinárias
            * Mestrado integrado
              Medicina Veterinária
            * Pós-doutoramento
              Investigador de Pós-Doutoramento
            * Pós-Graduação
              Pedagogia no Ensino Superior

        Publicações

        Artigo em revista

          * 2023-05-17, Morphological and Molecular Identification of Physaloptera alata (Nematoda: Spirurida) in a Booted Eagle (Aquila pennata) from Portugal, Animals
          * 2023-05, The potential role of scavenging flies as mechanical vectors of Lagovirus europaeus/GI.2, Virology Journal
          * 2023-02-26, Microscopic detection of hemoparasite infection in grey parrots (Psittacus erithacus) in Portugal, Revista Lusófona de Ciência e Medicina Veterinária
          * 2023, A new definitive host for Moniliformis cestodiformis (Acanthocephala: Moniliformidae): first report of a naturally infected European hedgehog (Erinaceus europaeus), Revista Brasileira de Parasitologia Veterinária
          * 2022-08-03, Ácaros trombiculídeos: Revisão de uma parasitose negligenciada em animais de companhia, Revista Lusófona de Ciência e Medicina Veterinária
          * 2022-05, Spillover events of rabbit haemorrhagic disease virus 2 (recombinant GI.4P-GI.2) from Lagomorpha to Eurasian badger, Transboundary and Emerging Diseases
          * 2021-11-29, Morphological anomalies found in female Culicoides midges (Diptera: Ceratopogonidae), Biologia
          * 2021-10, Supplementary morphological data and molecular analyses of Eimeria labbeana (Labbé, 1896) Pinto, 1928 (Chromista: Miozoa: Eimeriidae) from columbiform birds in Portugal, Parasitology Research
          * 2021-01-07, Presence of one ecto- and two endoparasite species of the black stork (Ciconia nigra) in Portugal, BMC Veterinary Research
          * 2020-12, The tree that hides the forest: cryptic diversity and phylogenetic relationships in the Palaearctic vector Obsoletus/Scoticus Complex (Diptera: Ceratopogonidae) at the European level, Parasites & Vectors
          * 2020-09-16, VectorNet Data Series 3: Culicoides Abundance Distribution Models for Europe and Surrounding Regions, Open Health Data
          * 2020-07-15, First report of Ericotrombidium ibericense in domestic dogs., Acta parasitologica
          * 2020-02, Culicoides spp. found near Lusitano stud farms in mainland Portugal which may contribute for IBH studies, Veterinary Parasitology: Regional Studies and Reports
          * 2019-12-17, First report of one ecto- and two endoparasite species of the black stork (Ciconia nigra) in Portugal, BMC Veterinary Research
          * 2019-07-15, A new mite species of the genus Neottialges (Acariformes: Hypoderatidae) from the black stork Ciconia nigra (Ciconiiformes: Ciconiidae) in Portugal, Acarologia
          * 2019-02-22, An Overview of Zoonotic Disease Outbreaks and its Forensic Management Over Time., Journal of forensic sciences
          * 2019-01-30, First report of Neotrombicula inopinata infestation in domestic cats from Portugal., Veterinary parasitology
          * 2018, Os insetos do género Culicoides em Portugal e a sua relevância em medicina veterinária, Revista Portuguesa de Ciências Veterinárias
          * 2018, Os insetos do género Culicoides em Portugal e a sua relevância em medicina veterinária. RPCV (2018) 113 (605-606) 10-17, RPCV
          * 2017-06-24, Ovarian steroids, oxytocin, and tumor necrosis factor modulate equine oviduct function, Domestic Animal Endocrinology
          * 2017, Geographical distribution of Culicoides (DIPTERA: CERATOPOGONIDAE) in mainland Portugal: Presence/absence modelling of vector and potential vector species.
          * 2016, Range expansion of the Bluetongue vector, Culicoides imicola, in continental France likely due to rare wind-transport events.
          * 2015-10, Colonization of the Mediterranean Basin by the vector biting midge species Culicoides imicola: an old story.
          * 2015, Spatial and temporal distribution of Culicoides species in mainland Portugal (2005-2010). Results of the Portuguese Entomological Surveillance Programme.
          * 2014-04, Morphological aspects and expression of estrogen and progesterone receptors in the interdigital sinus in cyclic ewes.
          * 2013, Description of Culicoides paradoxalis sp. nov. from France and Portugal (Diptera: Ceratopogonidae).
          * 2012, First report of 13 species of Culicoides (Diptera: Ceratopogonidae) in mainland Portugal and Azores by morphological and molecular characterization.
          * 2010-12, Is FAS/Fas ligand system involved in equine corpus luteum functional regression?

        Tese / Dissertação

          * 2016-03-14, Doutoramento, Phenotypic and genetic characterization of Culicoides (Diptera: Ceratopogonidae) in Portugal and comparison of the effect of pyrethroid insecticides in their control
          * 2008-06-19, Mestrado, Subtipificação do Parvovírus canino e felino

        Capítulo de livro

          * 2020, Vectors and Vector Borne Diseases: Morphological and Molecular Diagnosis, Risk Assessment, Population Genetics and Control Strategies, Springer International Publishing
          * 2010, Investigating morphological structures of Culicoides from obsoletus complex by using Scanning Electron Microscopy and Composed Optical Microscopy, Microscopy: Science, Technology, Applications and Education, 2, Formatex Research Center

        Website

          * 2017-11, Identification key for female insects of Culicoides genus from Portugal, Chave politómica para identificação de insetos fêmea do género Culicoides de Portugal., http://www.fmv.ulisboa.pt/pt/noticias/faculdade/chave-de-identificacao-para-insectos-do-genero-culicoides-existentes-em-portugal
          * 2017, Guia de Parasitologia Vetetinária (Aracnoentomologia e Protozoologia), Atlas de Parasitologia - Uma ferramenta para as aulas práticas de Parasitologia I, http://atlasparasitologia.fmv.ulisboa.pt/

        Resumo em conferência

          * 2023, The effect on mortality of metaphylactic tulathromycin in a lamb feedlot, ISVC – 10th International Sheep Veterinary Congress 2023
          * 2022, Impact of the SARS-COV-2 pandemic on feline lower urinary tract signs, 2022 ISFM Feline Congress – Feline fine: How to create harmony between physical health and mental wellbeing in your treatment and management of feline cases
          * 2022, Impact of the SARS-COV-2 pandemic on feline lower urinary tract signs, 2022 ISFM Feline Congress – Feline fine: How to create harmony between physical health and mental wellbeing in your treatment and management of feline cases

        Poster em conferência

          * 2023-09, Lungworms and gastrointestinal parasites in domestic cats from the Lisbon metropolitan area, Portugal: Prevalence and risk factors, 48th World Small Animal Veterinary Association Congress and the 28th FECAVA Eurocongress
          * 2023-05-19, Infeção por helmintes pulmonares e gastrointestinais em gatos (Felis catus) da área metropolitana de Lisboa: Estudo preliminar, FMVet Research Meetings – II Encontro de Investigação
          * 2023-05-19, Hemoparasites ocurrence in healthy African Grey Parrots (Psittacus erithacus) in mainland Portugal, FMVet Research Meetings – II Encontro de Investigação
          * 2023-05-19, Caracterização molecular de ácaros da família Trombiculidae obtidos de um gato errante em Lisboa, FMVet Research Meeting - II Encontro de Investigação
          * 2023-05-19, Caracterização molecular de Hepatozoon canis em Portugal, FMVet Research Meetings – II Encontro de Investigação
          * 2023-04, Prevalência da infeção por parasitas gastrointestinais e pulmonares em gatos (Felis catus) da área metropolitana de Lisboa, 10.º Encontro de Formação da Ordem dos Médicos Veterinários
          * 2023-04, Caracterização molecular de ácaros da família Trombiculidae obtidos de um gato errante em Lisboa: Estudo preliminar, 10.º Encontro de Formação da Ordem dos Médicos Veterinários
          * 2023-04, Caracterização molecular de Hepatozoon canis em Portugal, 10.º Encontro de Formação da Ordem dos Médicos Veterinários
          * 2023-04, Caracterização Molecular de Hepatozoon Canis em Portugal.
          * 2023-03-19, Parasitological survey of the endangered Iberian lynx (Lynx pardinus) in Portugal, XI FAUNA International Conference
          * 2023-03-19, Hemoparasites occurrence in asymptomatic African Grey Parrots (Psittacus erithacus) in mainland Portugal, XI FAUNA International Conference
          * 2022-11-11, Presence of Phyllobothrium delphini (Cestoda: Phyllobothriidae) in a striped dolphin (Stenella coeruleoalba) stranded in the Tagus estuary (Alcochete, Portugal), CIISA Congress 2022 – Innovation in animal, veterinary and biomedical research
          * 2022-11-11, Helminths found in wild thrushes (Turdus spp.) from Portugal, CIISA Congress 2022 – Innovation in animal, veterinary and biomedical research
          * 2022-11-04, Deteção de ácaros trombiculídeos (Acari: Trombiculidae) em gatos errantes (in vivo) e no meio ambiente (ex vivo) em Lisboa e Santarém, XXIII Congresso Internacional Veterinário Montenegro
          * 2022-07-05, First report of Zachvatkinia larica in seagulls from the Iberian Peninsula, XXII Congreso de la Sociedad Española de Parasitología
          * 2022-06-30, Impact of the SARS-COV-2 pandemic on feline lower urinary tract signs, 2022 ISFM Feline Congress – Feline fine: How to create harmony between physical health and mental wellbeing in your treatment and management of feline cases
          * 2022-03-11, Resultados preliminares do inquérito a profissionais equestres sobre dermatofitose e biossegurança, 13.ª Edição das Jornadas do Hospital Veterinário Muralha de Évora
          * 2022-03-11, Deteção molecular de Anaplasma phagocytophilum em ovinos no Alentejo, 13.ª Edição das Jornadas do Hospital Veterinário Muralha de Évora
          * 2021-12-04, Analysis of the role of flies in the epidemiology of rabbit hemorrhagic disease virus Lagovirus europaeus/GI.2 in Portugal, XV Congreso SECEM
          * 2021-10-22, Identification of trombiculids (Acarina: Trombiculidae) in dogs and cats and therapeutic use of selamectin and sarolaner, XVII International Veterinary Congress Montenegro – Internal Medicine Without Secrets
          * 2020-06, Parasitism of native freshwater fish by Lernaea cyprinacea in Western Portugal, VIII Congresso Ibérico de Ictiología – SIBIC 2020
          * 2019-11, Pentasomides in Sea Gulls (Larus fuscus), VIII FAUNA International Conference
          * 2019-10, Parasites of a black stork (Ciconia nigra), The 8th Conference of the Scandinavian-Baltic Society for Parasitology (SBSP) and the Annual Meeting of the European Veterinary Parasitology College (EVPC)
          * 2018-11, Heavy infection by Halocercus delphini (Nematoda: Pseudaliidae) in a common dolphin (Delphinus delphis) stranded in the Sado estuary, VII FAUNA International Conference
          * 2018-11, First report of Neotrombicula inopinata infestation in domestic cats from Portugal, CIISA Congress 2018
          * 2018-05, Distribution of Culicoides spp. within Obsoletus group in mainland Portugal, Joint meeting of the Belgian Society for Parasitology and Protistology (BSPP), British Association for Veterinary Parasitology (BAVP), Irish Society for Parasitology (ISP) and the European Veterinary Parasitology College (EVPC)
          * 2017-10, “Morphological structures of Culicoides species revealed through Scanning Electron Microscopy, 7th International Congress of the Society for Vector Ecology (SOVE)
          * 2017-10, Which are the sensorial organs of Culicoides imicola and Obsoletus group species susceptible to permethrin and deltamethrin effect?, 7th International Congress of the Society for Vector Ecology (SOVE)
          * 2017-10, Pictoric identification key for Culicoides species reported in Portugal, 7th Society for Vector Ecology (SOVE) International Congress
          * 2017-10, Only one species? Cryptic diversity and spatial distribution of Culicoides obsoletus sensu lato (Diptera: Ceratopogonidae) in Europe, 7th International Congress of the Society for Vector Ecology (SOVE)
          * 2016-10, Morphological modifications on C. imicola palpus sensorial organs after exposure to pyrethroid molecules, 20th European Society for Vector Ecology (E-SOVE) conference
          * 2016-10, Culicoides found near horses in Portugal which could be related to Insect Bite Hypersensitivity (IBH), 20th European Society for Vector Ecology (E-SOVE) conference
          * 2016-10, Bluetongue occurrences in Portugal, their relationship with the entomological plan and measures established by the Portuguese Veterinary Official Services, 20th European Society for Vector Ecology (E-SOVE) conference
          * 2016-07, Autofluorescence and iridescence in Culicoides insects: hidden patterns to the human eye, Joint Conference EAVA & WAHVM
          * 2014-11, Preliminary study about wing interference pattern in 4 species of Culicoides genus (Diptera: Ceratopogonidae), XVII Congresso Português de Parasitologia (XVII CPP)
          * 2014-04, Preliminary study about morphological alterations observed in sensorial organs of Culicoides imicola insect species (Diptera: Ceratopogonidae) exposed to pyrethroid insecticides, VI Congresso da Sociedade Portuguesa de Ciências Veterinárias (SPCV): Ciências Veterinárias – Praxis e Futuro
          * 2012-11, Review of Culicoides (DIPTERA: CERATOPOGONIDAE) Genus in Portugal, XVI Portuguese Congress of Parasitology
          * 2012-11, Morphological Characterization of C. dendriticus, C. malevillei and C. riebi (DIPTERA: CERATOPOGONIDAE) species referred for the first time in Portugal, XVI Portuguese Congress of Parasitology
          * 2011-10, Identification of Culicoides (DIPTERA: CERATOPOGONIDAE) species reported for the first time in mainland Portugal and Azores archipelago by morphological characterization in the scope of National Entomological Program for Bluetongue, V Congresso da Sociedade Portuguesa das Ciências Veterinárias – As Ciências Veterinárias para uma só Saúde
          * 2011, Identificação de espécies de Culicoides (DIPTERA:CERATOPOGONIDAE) referidas pela primeira vez em Portugal Continental e no Arquipélago dos Açores por caracterização morfológica no âmbito do Programa Entomológico Nacional de Língua Azul. , V Congresso da Sociedade Portuguesa de Ciências Veterinárias
          * 2010-09, Preliminary Description of Culicoides (Diptera:Ceratopogonidae) Species Reported For The First Time In Mainland Portugal, 17th European Society for Vector Ecology Conference (ESOVE)
          * 2010-09, Cytokines And Their Receptors In The Equine Oviduct: A Preliminary Study, 14th Conference of European Society for Domestic Animal Reproduction
          * 2010-07, Detection of ERs Alpha and Beta and Progesterone Receptor (P4R) In The Interdigital Sinus Of Cyclic Ewes (Ovis aries) At Oestrus Stage, XXVIIIth EAVA-Congress
          * 2010-01-22, Cytokine mediated Angiogenesis In The Equine Corpus Luteum, 5th Leipzig Expertworkshop on Equine Reproductive Medicine - What's New in Equine Reproduction?
          * 2009-09, TNFa and IFN¿ Receptors Presence in the Equine Corpus Luteum and their Ligands Effect on Luteal Cells Viability, 13th Conference of the European Society of Domestic Animal Reproduction (ESDAR) and Annual Meeting of EU-Al-Vets
          * 2009-09, Expression Of Cytokines And Their Receptors In The Equine Endometrium During The Estrous Cycle, 13th Conference of the European Society of Domestic Animal Reproduction (ESDAR) and Annual Meeting of EU-Al-Vets
          * 2009-09, Cytokines on Equine Luteal Production of Nitric Oxide, Angiogenic Activity and Luteal Cells Viability, 13th Conference of the European Society of Domestic Animal Reproduction (ESDAR) and Annual Meeting of EU-Al-Vets
          * 2009-07, How Are Cytokines Involved In Equine Corpus Luteum Regression And Apoptotic Events?, 42nd Annual Meeting of the Society for the Study of Reproduction "Science for the Public Good"
          * 2008-11, Rastreio virológico e subtipificação do Parvovírus dos canídeos e felídeos, IV Congresso da SPCV & I Congresso Ibérico de Epidemiologia
          * 2007-03-11, Mercury in Tuna and Risks for Public Health, 2nd Iberian Journeys of Veterinarian Toxicology – Vetox II
          * 2004-04, A Genética e a Doença

        Conto de ficção

          * 2014-03-29, Em Silêncio, PoesiaFãClube
          * 2014-03-13, Pedaços, PoesiaFãClube

        Obra teatral

          * 2007-04, Liberdade!, Mauro, Grupo de Teatro "Zero", Ateneu Artístico Vilafranquense, Vila Franca de Xira, Portugal
          * 2007-03, Indicativo Zero, Mauro, Grupo de Teatro "Zero", Ateneu Artístico Vilafranquense, Vila Franca de Xira, Portugal

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona