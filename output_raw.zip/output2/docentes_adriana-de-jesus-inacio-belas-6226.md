# Response for https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
          PT: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226 EN: https://www.ulusofona.pt/en/teachers/adriana-de-jesus-inacio-belas-6226
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
        fechar menu : https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/adriana-de-jesus-inacio-belas-6226
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Adriana Belas

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6226
              adr***@ulusofona.pt
              4D1D-1718-6FFF: https://www.cienciavitae.pt/4D1D-1718-6FFF
              0000-0001-6564-6839: https://orcid.org/0000-0001-6564-6839
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/f4c8ff06-0ba8-45ec-8ab7-c50343a943b9
      : https://www.ulusofona.pt/

        Resume

        Professor and researcher at Faculty of Veterinary Medicine, Lusófona University - Lisbon and Head of Microbiology Laboratory of the Teaching Hospital - FMV. Integrated member at Veterinary and Animal Research Center (CECAV), Faculty of Veterinary Medicine, Lusófona University, Lisbon, Portugal. Ph.D in Veterinary Science/ Biological and Biomedical sciences (2016-2021) from Faculty of Veterinary Medicine - University of Lisbon, MSc in Food safety (2010-2012) from Faculty of Veterinary Medicine – Technical University of Lisbon and Graduated in Biotechnological Engennier (1997-2004) from Universidade Lusófona de Humanidades e Tecnologias. Her research interests focus on several aspects of antimicrobial resistance (AMR) in a One Health approach, namely the epidemiology of MDR pathogenic bacteria of clinical relevance in veterinary and human medicine, molecular epidemiology studies using metagenomic analysis and the pursuit of novel prophylactic and therapeutic alternatives to the use of antimicrobials.

        Graus

            * Licenciatura
              Engenharia Biotecnológica
            * Mestrado
              Mestrado em Segurança Alimentar
            * Doutoramento
              Doutoramento em Medicina Veterinária - Ciências Biológicas e Biomédicas
            * Outros
              Diagnosis of parasitic infections.
            * Outros
              Laboratory Animal Science course

        Publicações

        Magazine article

          * 2014, Resíduos de xenobióticos em mel nacional., Riscos e Alimentos nº 6, Autoridade de Segurança Alimentar e Económica (ASAE)

        Journal article

          * 2024, Effectiveness of two scrub methods with different chlorhexidine combinations for surgical field antisepsis in cats, Canadian Veterinary Journal
          * 2023-11-29, Influence of Particle Size and Extraction Methods on Phenolic Content and Biological Activities of Pear Pomace, Foods
          * 2023-07-08, Longitudinal study of ESBL/AmpC-producing Enterobacterales strains sharing between cohabiting healthy companion animals and humans in Portugal and in the United Kingdom, European Journal of Clinical Microbiology & Infectious Diseases
          * 2022-04-22, ESBL/pAmpC-Producing Escherichia coli Causing Urinary Tract Infections in Non-Related Companion Animals and Humans, Antibiotics
          * 2021-12-29, Human and Companion Animal Proteus mirabilis Sharing, Microbiology Research
          * 2021-11-24, ESBL/AmpC-Producing Enterobacteriaceae Fecal Colonization in Dogs after Elective Surgery, Microbiology Research
          * 2021-01-14, Epidemiological Study of Pesticide Poisoning in Domestic Animals and Wildlife in Portugal: 2014–2020, Frontiers in Veterinary Science
          * 2020-10-01, Sharing of Clinically Important Antimicrobial Resistance Genes by Companion Animals and Their Human Household Members, Microbial Drug Resistance
          * 2020-03-24, OXA-181-Producing Extraintestinal Pathogenic Escherichia coli Sequence Type 410 Isolated from a Dog in Portugal, Antimicrobial Agents and Chemotherapy
          * 2019-12-05, In vitro antimicrobial efficacy of two medical grade honey formulations against common high-risk meticillin-resistant staphylococci and Pseudomonas spp. pathogens, Veterinary Dermatology
          * 2019-09-16, Detection of multidrug resistance and extended-spectrum/plasmid-mediated AmpC beta-lactamase genes in Enterobacteriaceae isolates from diseased cats in Italy, Journal of Feline Medicine and Surgery
          * 2019-06, Evidence of Sharing of Klebsiella pneumoniae Strains between Healthy Companion Animals and Cohabiting Humans, Journal of Clinical Microbiology
          * 2019-01, Clonal relatedness of Proteus mirabilis strains causing urinary tract infections in companion animals and humans, Veterinary Microbiology
          * 2018-12-10, Klebsiella pneumoniae causing urinary tract infections in companion animals and humans: population structure, antimicrobial resistance and virulence genes, Journal of Antimicrobial Chemotherapy
          * 2018-10-05, Emergence of Escherichia coli ST131 H30/H30-Rx subclones in companion animals, Journal of Antimicrobial Chemotherapy
          * 2018-06, First report on antimicrobial resistance and molecular characterisation of Salmonella enterica serotype Typhi isolated from human specimens in Luanda, Angola, Journal of Global Antimicrobial Resistance
          * 2017-11-09, Increase in antimicrobial resistance and emergence of major international high-risk clonal lineages in dogs and cats with urinary tract infection: 16 year retrospective study, Journal of Antimicrobial Chemotherapy
          * 2017-09, Clonal spread of methicillin-resistant Staphylococcus aureus- t6065 - CC5-SCC mec V- agr II in a Libyan hospital, Journal of Global Antimicrobial Resistance
          * 2016-12, Acquisition of the fexA and cfr genes in Staphylococcus pseudintermedius during florfenicol treatment of canine pyoderma, Journal of Global Antimicrobial Resistance
          * 2016-09-22, European multicenter study on antimicrobial resistance in bacteria isolated from companion animal urinary tract infections, BMC Veterinary Research
          * 2016-03-03, Trends and molecular mechanisms of antimicrobial resistance in clinical staphylococci isolated from companion animals over a 16 year period, Journal of Antimicrobial Chemotherapy
          * 2016-03, Efficacy of medical grade honey in the management of canine otitis externa – a pilot study, Veterinary Dermatology
          * 2016-02, Comparative RNA-seq-Based Transcriptome Analysis of the Virulence Characteristics of Methicillin-Resistant and -Susceptible Staphylococcus pseudintermedius Strains Isolated from Small Animals, Antimicrobial Agents and Chemotherapy
          * 2015-09, Clonal diversity, virulence patterns and antimicrobial and biocide susceptibility among human, animal and environmental MRSA in Portugal, Journal of Antimicrobial Chemotherapy
          * 2014-08-25, Skin prick tests in dogs - Should we do them instead of the intradermal tests? (Poster Session Group III) , Allergy
          * 2014-08, Risk factors for faecal colonisation with Escherichia coli producing extended-spectrum and plasmid-mediated AmpC ß-lactamases in dogs.
          * 2014, First description of fexA-positive meticillin-resistant Staphylococcus aureus ST398 from calves in Portugal, Journal of Global Antimicrobial Resistance
          * 2014, Fatores de risco de colonização fecal com Escherichia coli produtores de ß-lactamases do tipo AmpC de largo espectro e mediadas por plasmídeos., Veterinary Record - Edição Portuguesa.
          * 2013-09, Within-lineage variability of ST131 Escherichia coli isolates from humans and companion animals in the south of Europe.
          * 2013-09, Biocide and antimicrobial susceptibility of methicillin-resistant staphylococcal isolates from horses.
          * 2013-07, Genetic Relatedness, Antimicrobial and Biocide Susceptibility Comparative Analysis of Methicillin-Resistant and -Susceptible Staphylococcus pseudintermedius from Portugal.
          * 2013-00, First report of swine-associated methicillin-resistant Staphylococcus aureus ST398 in Lithuania., Polish Journal of Veterinary Sciences
          * 2012-08-17, Immediate after birth transmission of epidemic Salmonella enterica Typhimurium monophasic strains in pigs is a likely event, Journal of Antimicrobial Chemotherapy
          * 2012, Screening of synthetic acaricides residues in honey
          * 2011, Distribution of animal poisoning in some Portuguese regions
          * 2010, Wildlife pesticide poisoning in Portugal: Retrospective analytical results, Toxicology letters
          * 2007, Hepatic drug metabolism under induced hepatic dysfunction by galactosamine, Toxicology letters
          * 2006, Drug pharmacokinetic in hepatodysfunction: A possible way to toxicity, Toxicology letters

        Thesis / Dissertation

          * 2024, Master, Pesquisa de Leptospira spp. em cavalos clinicamente saudáveis
          * 2024, Master, Monitoring and detection of Salmonella spp. from the oral and cloacal flora of reptiles in Portugal
          * 2024, Master, Deteção de Bactérias Gram-Negativas na Flora oral e fecal em geckos leopardo (eublepharis macularius)
          * 2024, Master, BACTÉRIAS ZOONÓTICAS EM DRAGÕES BARBUDOS (POGONA VITTICEPS) SAUDÁVEIS: UMA ABORDAGEM ONE-HEALTH
          * 2024, Master, "Estudo da frequência de FIV e FeLV em gatos (felis catus) na área metropolitana de Lisboa"
          * 2021, PhD, Extended–spectrum–beta-lactamases, cephalosporinases and carbapenemase-producing Escherichia coli in the human-dog interface
          * 2012, Master, Resíduos de medicamentos veterinários em mel

        Book chapter

          * 2020, The Public Health Risk of Companion Animal to Human Transmission of Antimicrobial Resistance During Different Types of Animal Infection, Advances in Animal Health, Medicine and Production, Springer International Publishing
          * 2020, The Gut Microbiome and Antimicrobial Resistance in Companion Animals, Advances in Animal Health, Medicine and Production, Springer International Publishing
          * 2020, Antimicrobial Resistance Trends in Dogs and Cats with Urinary Tract Infection, Advances in Animal Health, Medicine and Production, Springer International Publishing

        Conference abstract

          * 2023-12, ZOONOTIC SALMONELLA SPP. ISOLATED FROM HEALTHY LEOPARD GECKOS (EUBLEPHARIS MACULARIUS) – IN VIVO STUDY
          * 2023-12, ESBLs/pAMPC PRODUCING ENTEROBACTERALES IN FECAL SAMPLES OF COMPANION ANIMALS FROM A HOSPITAL SETTING – IN VIVO STUDY, MONTENEGRO INTERNATIONAL VETERINARY CONGRESS THE NEXT DECADE WITHOUT SECRETS XIX MEDICINE CONGRESS / XIII NURSE CONGRESS
          * 2023, PORTUGAL REMAINS AT THE TOP OF THE EUROPEAN PREVALENCE FOR FELINE LEUKEMIA VIRUS INFECTION? A 4-YEAR RETROSPECTIVE STUDY , 48th World Small Animal Veterinary Association Congress and the 28th FECAVA Eurocongress
          * 2023, DETEÇÃO DE MYCOBACTERIUM GENAVENSE EM ESFREGAÇO SANGUÍNEO DE UM FURÃO (MUSTELA PUTORIUS FURO)
          * 2023, Avaliação da microbiota bacteriana do útero em cadelas clinicamente saudáveis.
          * 2022-11, Opuntia ficus-indica as resilient and sustainable food and feed crop with a high potential for One Health, 1st International Congress on Food, Nutrition & Public Health Towards a sustainable future
          * 2022, Grupo de interesse em Biologia Molecular, I Encontro de Investigação da FMV da Universidade Lusófona
          * 2022, Faecal colonisation with Carbapenemase and ESBL/AmpC-producing Enterobacterales in Portugal and the United Kingdom: A One Health perspective on the Human-Companion animal relationship, 33rd ECCMID (European Congress of Clinical Microbiology and Infectious Diseases)
          * 2022, Compostos bioativos para a saúde e segurança alimentar, I Encontro de Investigação da FMV da Universidade Lusófona
          * 2020-10, Occurrence and Characterization of Carbapenemase and ESBL-producing Enterobacteriaceae isolates from companion animals with skin/soft tissue or urinary tract infections in Portugal and United Kingdom: a potential risk to public health., 2nd International Conference of the European College of Veterinary Microbiology
          * 2020-10, Identification of colistin-resistant Escherichia coli strains isolated from Portuguese dogs., 2nd International Conference of the European College of Veterinary Microbiology
          * 2020-09-06, Plasmid-mediated colistin resistance mcr-1 gene harbored on multidrug resistant isolates from companion animals in Portugal., 30th Congresso of the European College of Internal Medicine – Companion Animals-ISCAID
          * 2020-09-02, Gut microbiome evaluation in dogs with naturally-occurring hyperadrenocorticism., Congresso of the European College of Internal Medicine ¿ Companion Animals- European Society of Veterinary Endocrinology
          * 2020-09-02, Extended-spectrum-beta-lactamases- and carbapenemase-producing Enterobacteriaceae isolated from the gut of sick companion animals in Portugal., Congress of the European College of Internal Medicine – Companion Animals
          * 2019-09-27, ESBLs_pAmpC- producing Escherichia coli causing urinary tract infections in companion animals and humans in Portugal: antimicrobial resistance, pathogenicity and clonal diversity., 1stInternational Conference of the European College of Veterinary Microbiology
          * 2019-06-11, Human and companion animal interspecies sharing of Faecal Proteus, III IC2AR Congress
          * 2019-06-11, Gut microbiome of healthy dogs from households and shelters., III IC2AR Congress
          * 2018-11, Companion animals as reservoirs of Klebsiella pneumoniae, Exploring the boundaries of animal, veterinary and biomedical sciences, CIISA congresso.
          * 2018-09-14, Virulence and antimicrobial resistance of Escherichia coli Sequence Type 131 H30 and other human pandemic clones spreading in companion animals., 27th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2018-09, Dogs as reservoirs of uropathogenic Klebsiella pneumoniae to humans., 28th Congress of the European College of Internal Medicine – Companion Animals
          * 2018-06-14, Companion animals and humans with UTI share common uropathogenic Klebsiella pneumoniae., 27th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2018, Characterization of gut microbiome of healthy companion animals from households and shelters. , Exploring the boundaries of animal, veterinary and biomedical sciences, CIISA congresso.
          * 2017-09-08, Multidrug-resistant extended-spectrum-beta-lactamase and plasmid-mediated AmpC beta-lactamase-producing Enterobacteriaceae isolated from diseased cats in Southern Italy, 26th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2017-04-22, Risk factors for nasal colonization by methicillin- resistant staphylococci in healthy humans in professional contact with companion animals in Portugal., 27th European Congress of Clinical Microbiology and Infectious Diseases
          * 2017-04-17, Sharing of clinically important antimicrobial resistance genes by companion animals and their human household members., 27th European Congress of Clinical Microbiology and Infectious Diseases
          * 2016-09-10, Major international high-risk resistant human Klebsiella pneumoniae lineages are causing urinary tract infections in companion animals., 25th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2016, Emergence of human pathogenic Enterococcus faecalis CC2 lineages in companion animals., 25th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2015-04, Spread of highly successful human multidrug-resistant clones causing urinary tract infections in companion animals., 25th European Congress of Clinical Microbiology and Infectious Diseases
          * 2015, Risk factors for faecal colonization with Escherichia coli producing extended­spectrum and plasmid­mediated AmpC beta­lactamases in dogs without antimicrobial pressure., 24th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2015, Insights into the evolution of antimicrobial resistance in staphylococci isolated from companion animals: a 16-year study in Portugal., 25th European Congress of Clinical Microbiology and Infectious Diseases
          * 2015, Emergence of multidrug-resistant bacteria causing urinary tract infections in companion animals a 14-year retrospective study in Portugal., 24th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2014, Skin prick tests in dogs-should we do them instead of the intradermal tests?
          * 2013-11-20, Epidemic IncI1 and IncF plasmids allow the dissemination of blaCTX-M-1 and 32 genes in different Escherichia coli clones from pigs at slaughter, ESCMID Conference on Escherichia coli: An old friend with new things.
          * 2013-11-20, Detection and characterization of cmy2 plasmids from Escherichia coli in companion animals and humans., ESCMID Conference on Escherichia coli: An old friend with new things.
          * 2013-11-20, Are Animals a reservoir of pathogenic Escherichia coli in Humans ?, ESCMID Conference on Escherichia coli: An old friend with new things
          * 2013-11, Longitudinal characterization of commensal ESBL-producing Escherichia coli in fecal samples from pigs from three Portuguese herds., ESCMID Conference on Escherichia coli: An old friend with new things

        Conference poster

          * 2023-12-07, Characterization of Campylobacter spp. isolates from poultry slaughtered for human consumption in Portugal
          * 2023-12, Multidrug-resistant Escherichia coli and Salmonella spp. in pigs slaughtered for human consumption, a potential source for Humans?
          * 2023-07-05, Are Food-Producing Animals a Source of Multidrug-resistant E. coli and Salmonella spp.?
          * 2023-07, Potencial da salicórnia para a segurança alimentar e para a saúde humana., Ciência 2023, Encontro com a Ciência e a Tecnologia em Portugal.
          * 2023-07, ENDOMETRITE EM CADELAS CLINICAMENTE SAUDÁVEIS – IN VIVO, II Encontro de Investigação - FMV research meetings-Universidade Lusófona.
          * 2023-07, Cardoon in Cheese Rennet Presents Antibacterial and Anti-Inflammatory Potential, Ciência 2023, Encontro com a Ciência e a Tecnologia em Portugal.
          * 2023-05-19, Salmonella spp. serovars isolated from healthy Leopard geckos (Eublepharis macularius) in Lisbon, Portugal.
          * 2023-05-19, Potential health benefits of cardoon in cheese production., II Encontro de Investigação - FMV research meetings-Universidade Lusófona.
          * 2023-05-19, Non-Helicobacter pylori in feline gastrointestinal neoplasia
          * 2023-05-19, Frequência e caracterização fenotípica de estirpes de Campylobacter coli em suínos abatidos para consumo Humano em Portugal
          * 2023-05-19, Avaliação de multirresistências em estirpes de Campylobacter spp. isoladas de diferentes espécies de aves abatidas para consumo humano em Portugal
          * 2023-05-19, Aplicação de salicórnia como alternativa ao sal em produtos cárneos curados: Potencial para a segurança alimentar e para a saúde humana., II Encontro de Investigação - FMV research meetings-Universidade Lusófona.
          * 2023-05-18, Assessment of multidrug resistance in Campylobacter spp. isolated from different species of birds slaughtered for human consumption in Portugal, FMVet Research Meetings - II Encontro de Investigação da FMV da Universidade Lusófona
          * 2023-04, Faecal Klebsiella Pneumoniae carriage and sharing between companion animals and owners in Portugal.
          * 2023-04, Chlorhexidine effectiveness against Staphylococci - surgical field antisepsis.
          * 2023-04, Caracterização Molecular de Hepatozoon Canis em Portugal.
          * 2022-11, Effectiveness in antiseptic preparation of the surgical field.
          * 2020-04-04, qPCR to detect mecA in faecal samples: a tool for assessing resistance burden amongst pets and their owners in the microbiological ‘fast age’?. , 30th ECCMID (European congress of clinical microbiology and infectious diseases).
          * 2020-04-04, Screening and characterization of multidrug resistant Enterobacteriaceae in healthy companion animals in close contact with humans, 30th ECCMID (European congress of clinical microbiology and infectious diseases)
          * 2020-04-04, Public health impacto of ESBLs pAmpC – producing Escherichia coli causing urinary tract infections in non-related companion animal and humans.., 30th ECCMID (European congress of clinical microbiology and infectious diseases).
          * 2020-04-04, Molecular detection of the mcr-1 mobile colistin resistance gene in healthy humans and a dog with skin infection from Portugal., 30th ECCMID (European congress of clinical microbiology and infectious diseases)
          * 2020-02, Screening of vancomycin-resistant enterococci gut colonization in companion animal, XVI Congresso Internacional Veterinário Montenegro
          * 2019-12-12, Public health impact of ESBLs/pAmpC- producing Escherichia coli causing urinary tract infections in non-related companion animals and humans, Microbiotec 19
          * 2019-12-07, Companion animals with Skin and Soft Tissue Infection share multidrug resistant Escherichia coli strains gut colonization with their human household members, Microbiotec 19
          * 2019-12, Sharing of ESBLS/pAmpC-producing Escherichia coli in healthy companion animals and their household human member, Microbiotec 19
          * 2019-12, ESBL/Carbapenemase-producing Enterobacteriaceae in healthy companion animals in close contact with humans, Microbiotec 19
          * 2019-09-26, Survey of ESBL and Carbapenemase-Producing Enterobacteriaceae and MRSA in Companion Animals in close contact with humans, Portugal. , 1stInternational Conference of the European College of Veterinary Microbiology
          * 2019-07-01, Analysis of ESBLproducing Escherichia coli from pets and their owners , faecal carriage of different CTX-M producing E. coli in a dog and a human in Portugal.., 8th Symposium on Antimicrobial Resistance in Animals and the Environment.
          * 2019-04-13, Fecal microbiome of healthy dogs from households and shelters., 30th ECCMID (European congress of clinical microbiology and infectious diseases)
          * 2019-04, First report of an OXA-181-producing Escherichia coli from a dog in Portugal, 29th European Congress of Clinical Microbiology and Infectious Diseases
          * 2019, First report of a OXA-181 producing Escherichia coli from a dog in Portugal., 29th European Congress of Clinical Microbiology and Infectious Diseases
          * 2018-09-27, In vitro anti staphylococcal efficacy of medical grade honey formulation against methicillin-resistant Staphylococcus aureus ST22 and methicillin-resistant Staphylococcus pseudintermedius ST71 major high risk lineages., European Veterinary Dermatology Congress.
          * 2018-09-27, Emergence of carbapenemase resistant Pseudomonas aeruginosa isolates from otitis externa in companion animals, European Veterinary Dermatology Congress
          * 2018-08-23, Biocide susceptibility in Staphylococcus epidermidis causing infections in pets, 18th International Symposium of Staphylococci and Staphylococcal Infections (ISSSI), Copenhagen, Denmark
          * 2018-04-21, Human and companion animal faecal carriage of P mirabilis evidence of intra and interspecies sharing, 28th European Congress of Clinical Microbiology and Infectious Diseases (ECCMID)
          * 2018-04-21, Evidence of Klebsiella pneumoniae sharing between healthy companion animals and co habiting humans, 28th European Congress of Clinical Microbiology and Infectious Diseases (ECCMID)
          * 2018-04-21, Clonal relatedness of community and hospitalacquired Proteus mirabilis strains causing urinary tract infections in companion animals and humans, 28th European Congress of Clinical Microbiology and Infectious Diseases (ECCMID)
          * 2017-09-14, Evidence of sharing of MDR K pneumoniae between infected and non infected cats from same household., 27th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2017-07-03, Antimicrobial resistance and molecular characterization of Salmonella enterica serotype Typhi isolated in Luanda, Angola, in human specimens during 2013-2014, VIII Scientific Day of IHMT-NOVA. Lisbon, Portugal
          * 2017-07-03, Antimicrobial resistance and molecular characterization of Salmonella enterica serotype Typhi isolated in Luanda, Angola, in human specimens during 2013-2014, Encontro Ciência 2017. Lisbon, Portugal
          * 2017-06-29, Using the formula for rational antimicrobial therapy for prudent antimicrobial use in feline urinary tract Infection., International Society of Feline Medicine World Feline Congress 2017
          * 2017-06-29, Use of amoxicillin/clavulanate in the treatment of ESBLproducing Klebsiella pneumoniae feline UTI. , International Society of Feline Medicine World Feline Congress 2017
          * 2017-06-29, Cats with a urinary tract infection are reservoirs of antimicrobial resistant and virulent Escherichia coli isolates?, International Society of Feline Medicine World Feline Congress 2017
          * 2017-06-12, The gut of healthy dogs is a reservoir of antimicrobial resistant and pathogenic Escherichia coli. , II IC2AR Congress
          * 2017-04-22, Virulence and antimicrobial resistance mechanisms of uropathogenic proteus mirabilis from companion animals and humans. , 27th European Congress of Clinical Microbiology and Infectious Diseases
          * 2017, Multidrug-resistant CMY-2-producing Proteus mirabilis causing UTI in a dog: the therapeutic dilemma. , XIII Congresso Hospital Veterinário de Montenegro
          * 2016-09-08, Nosocomial faecal colonization by extended spectrum beta lactamase producer Gram negative bacteria in healthy dogs, 26th European Congress of Veterinary Internal Medicine - Companion Animals
          * 2016-06-20, Emergence of CMY2 producing proteus mirabilis in companion animals with UTI 16 years study. , ASM Microbe 2016
          * 2016-06-20, Companion animals are reservoirs of high risk human ESBL and AmpCproducing Escherichia coli Lineages., ASM Microbe 2016
          * 2016-06-20, CTX-M-15-producing multidrug resistant Klebsiella pneumoniae high risk lineages cause urinary tract infection in companion animals, ASM Microbe 2016
          * 2016-04-09, Spread of major human ESBL and AmpCproducing Escherichia coli lineages in companion animals with UTI over 17 years in Portugal., 26th European Congress of Clinical Microbiology and Infectious Diseases
          * 2016-04-09, Resistant CC17 E faecium causing urinary tract infections in companion animals. , 26th European Congress of Clinical Microbiology and Infectious Diseases
          * 2016-04-09, Expansion of ESBLproducing high-risk virulent ST15 Klebsiella pneumoniae lineage causing urinary tract infection in companion animals, 26th Congress of Clinical Microbiology and Infectious Diseases
          * 2016, Resistance to amoxicillin/clavulanate and third-generation cephalosporins in uropathogenic E. coli from companion animals., XII Congresso Hospital Veterinário Montenegro
          * 2016, Rational empirical antimicrobial therapy (FRAT) for UTI in companion animal , XII Congresso Hospital Veterinário Montenegro
          * 2016, Factores de risco para colonização nasal por staphylococci meticilina-resistente em portadores humanos saudáveis em contacto diário com animais em Portugal, 7º Encontro de Formação da Ordem dos Médicos Veterinários
          * 2015-12-10, Biocide susceptibility profiles of staphylococci colonizing humans in close contact with pets, National Congress of Microbiology and Biotechnology (MicroBiotec15). Évora, Portugal
          * 2015-07-01, Multidrug-resistant uropathogenic bacteria in cats a 13 Year retrospective snapshot, International Society of Feline Medicine Congress 2015
          * 2015-04-25, The transmission of blaCTX-M-1 and 32 throughout the pig production cycle is independent of E. coli clones or epidemic plasmids. , 25th European Congress of Clinical Microbiology and Infectious Diseases
          * 2015-04-25, Methicillin resistant Staphylococcus epidermidis and Staphylococcus haemolyticus in Portugal a comparison between companion animals and humans in close contact., 25th European Congress of Clinical Microbiology and Infectious Diseases
          * 2015, Are animals a reservoir of extraintestinal pathogenic Escherichia coli strains and blaCTX-M-1/32 epidemic plasmids for humans? , 25th European Congress of Clinical Microbiology and Infectious Diseases
          * 2014-05-10, CMY2 and CTX-M-15 beta-lactamase producing O25bH4B2ST131 Escherichia coli spread in urinary tract infection in the community in Portugal., 24th European Congress of Clinical Microbiology and Infectious Diseases
          * 2013-11-04, Virulence factors, agr groups (alleles), biofilm forming ability in methicillin resistance and methicillin susceptible Staphylococcus pseudintermedius., 3rd ASM-ESCMID Conference on Methicillin-resistant staphylococci in Animals: Veterinary and Public Health Implications
          * 2013-11-04, Trends in antimicrobial resistance in clinical staphylococci isolated from companion animals over a 8 year period. , 3rd ASM-ESCMID Conference on Methicillin-resistant staphylococci in Animals: Veterinary and Public Health Implications
          * 2013-11-04, Genetic relatedness, antimicrobial and biocide susceptibility patterns among human, animal and environmental methicillin resistant Staphylococcus aureus in Portugal., 3rd ASM-ESCMID Conference on Methicillin-resistant staphylococci in Animals: Veterinary and Public Health Implications
          * 2013-06, Glomerular filtration in dogs submitted to therapeutic protocols with antineoplastic drugs. Preliminary results, European Society of Veterinary Oncology – Annual Congress
          * 2013-04-27, Comparative study of ESBL producing and non producers ST131 Escherichia coli isolates from human and companion animals in the South of Europe., 23rd European Congress of Clinical Microbiology and Infectious Diseases 2013
          * 2013-02-15, Trends in the prevalence of methicillin resistance staphylococci isolated from companion animals., International Meeting on Emerging Diseases and Surveillance
          * 2013-02-15, Prevalence of commensal ESBL producing Escherichia coli strains isolated from piglets from birth to nursery on three Portuguese industrial pig farms, International Meeting on Emerging Diseases and Surveillance
          * 2013-02-15, Escherichia coli B2 and D virulent phylotypes carry extended spectrum and pAmpC beta-lactamases in healthy dogs with no antimicrobial pressure. , International Meeting on Emerging Diseases and Surveillance
          * 2013-02-15, Detection of monophasic Salmonella Typhimurium and its susceptibility throughout pigs life cycle from three industrial pig herds in Portugal, International Meeting on Emerging Diseases and Surveillance
          * 2013-02-15, Detection of bacteria resistant to critically important antimicrobials from lower urinary tract infections in cats and dogs from Portugal., International Meeting on Emerging Diseases and Surveillance
          * 2013-02-13, Relative activity overtime of chlorhexidine and benzalkonium chloride against methicillin resistant staphylococci isolates from horses, International Meeting on Emerging Diseases and Surveillance
          * 2012-08-26, Minimum bactericidal concentrations of four biocides and the presence of qac genes, 15th International Symposium of Staphylococci and Staphylococcal Infections (ISSSI). Lyon, France
          * 2012-08-26, Loss of the mecA gene during storage of a methicillin-resistant Staphylococcus cohnii subsp. cohnii strain, 15th International Symposium of Staphylococci and Staphylococcal Infections (ISSSI). Lyon, France
          * 2012-08-26, First report of livestock associated MRSA ST398 in Lithuania, 15th International Symposium on Staphylococci and Staphylococcal Infections 2012
          * 2012-08-26, Comparative analysis of antimicrobial biocide susceptibility data of methicillin-resistant and -susceptible S. pseudintermedius, 15th International Symposium of Staphylococci and Staphylococcal Infections (ISSSI). Lyon, France
          * 2012-08-26, Antimicrobial resistance among equine methicillin resistant staphylococci. , 15th International Symposium on Staphylococci and Staphylococcal Infections 2012
          * 2012-06-26, Vertical transmission of monophasic salmonella typhimurium in pigs., 3rd ASM Conference on Antimicrobial Resistance in Zoonotic Bacteria and Foodborne Pathogens in Animals, Humans, and the Environment.
          * 2012-06-26, Co resistance genes and phylogenetic groups of CTX-M, IRT and AmpC hyperproducers E. coli strains from diseased calves in Portugal. , 3rd ASM Conference on Antimicrobial Resistance in Zoonotic Bacteria and Foodborne Pathogens in Animals, Humans, and the Environment
          * 2012-06-22, Sow to piglets transmission of Escherichia coli blaCTX-M-1 and blaCTX-M-32 genes evidence of in vivo mutation?, 3rd ASM Conference on Antimicrobial Resistance in Zoonotic Bacteria and Foodborne Pathogens in Animals, Humans, and the Environment
          * 2012-03-31, Colonization with extended spectrum and plasmid mediated AmpC beta lactamases Escherichia coli producers in healthy dogs without antimicrobial pressure - a cross sectional study, 22nd European Congress of Clinical Microbiology and Infectious Diseases
          * 2012-03-31, Clonality of methicillin resistant Staphylococcus aureus and methicillin resistant Staphylococcus pseudintermedius isolated from healthy and sick companion animals and humans in Portugal, 22nd European Congress of Clinical Microbiology and Infectious Diseases

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona