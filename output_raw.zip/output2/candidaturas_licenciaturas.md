# Response for https://www.ulusofona.pt/candidaturas/licenciaturas

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/candidaturas/licenciaturas
          PT: https://www.ulusofona.pt/candidaturas/licenciaturas EN: https://www.ulusofona.pt/en/applications/bachelor
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/candidaturas/licenciaturas
        fechar menu : https://www.ulusofona.pt/candidaturas/licenciaturas

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/candidaturas/licenciaturas
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes
          Candidaturas
        https://www.ulusofona.pt/images/licenciaturas-header_600.jpg

            Licenciaturas

          Candidaturas
        : https://www.ulusofona.pt/candidaturas/licenciaturas
      ConteúdoNavegação

          Licenciaturas

            * Para quem terminou o 12º ano e realizou os exames nacionais: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Realizar Candidatura: https://secure.ensinolusofona.pt/candidaturas/page

                    + Os candidatos deverão ter concluído o ensino secundário ou habilitação legalmente equivalente.

                    + Os candidatos deverão ter realizado as provas de ingresso que constituem requisito de acesso para cada curso e que podem ser consultadas na página do curso a que o candidato se pretende candidatar.

                    + De acordo com as Deliberações nº 1043/2021 da CNAES, as provas de ingresso são válidas por 5 anos (o ano de realização e os 4 anos seguintes).

                    + Os candidatos serão seriados para os respetivos cursos através da atribuição de uma nota de candidatura, na escala de 0 a 200, calculada utilizando a seguinte ponderação:

                      65% para a nota final do Ensino Secundário

                      35% para a nota da prova de ingresso.

                    + Os candidatos serão ordenados por ordem decrescente das respetivas notas de candidatura, sendo a sua colocação feita nas vagas existentes.

                    + Os resultados de seriação serão disponibilizados no portal de candidaturas: https://secure.ensinolusofona.pt/candidaturas/page expressos da seguinte forma: a) Colocado b) Não colocado

                  Documentos a entregar

                    + FICHA ENES 2024
                      Original ou cópia autenticada

                    + DOCUMENTO DE IDENTIFICAÇÃO
                      Cartão de cidadão ou bilhete de identidade

            * Para Titulares de Ensino Secundário Estrangeiro: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Realizar Candidatura: https://secure.ensinolusofona.pt/candidaturas/page

                  (para alunos com ensino secundário estrangeiro que pretendam substituir as provas de ingresso por exames finais estrangeiros homólogos)

                  Uma das condições de candidatura à matrícula e inscrição no ensino superior é a titularidade das provas de ingresso que permitem avaliar a capacidade para a frequência do curso pretendido.

                  Para os estudantes titulares de um curso de ensino secundário português as provas de ingresso concretizam-se através da realização de exames finais nacionais do ensino secundário.

                  Para os estudantes titulares de cursos não portugueses legalmente equivalentes ao ensino secundário português, as provas de ingresso podem ser substituídas por exames finais de disciplinas daqueles cursos, nos termos do disposto no artigo 20.º-A do Decreto-Lei n.º 296-A/98, de 25 de setembro, na sua redação atual.

                  Candidatos que pretendem solicitar o Pedido de Substituição de Provas de Ingresso por Exames Estrangeiros

                  Os candidatos que, nos termos do artigo 20.º-A do Decreto-Lei n.º 296-A/98, de 25 de setembro, na sua redação atual, pretendam requerer a substituição das provas de ingresso por exames finais de cursos não portugueses legalmente equivalentes ao ensino secundário português, devem apresentar a sua candidatura no Portal de Candidaturas: https://secure.ensinolusofona.pt/candidaturas/page e submeter os seguintes documentos:

                    + a) Documento emitido pela entidade legalmente competente do sistema educativo estrangeiro a que respeita a habilitação do ensino secundário não português, indicando:
                        o A classificação final do curso;
                        o As classificações obtidas nos exames finais desse curso que pretendam que substituam as provas de ingresso, a data da sua realização e a escala de classificação, com indicação da classificação mínima positiva e máxima positiva, no caso de se tratar de uma escala numeral, ou com a indicação dos escalões positivos dispostos em ordem decrescente de valor, no caso de se tratar de uma escala apresentada por escalões alfabéticos;
                    + Documento comprovativo da equivalência do curso de ensino estrangeiro ao ensino secundário português, incluindo a classificação final do curso convertida para a escala portuguesa de 0 a 200.

                  Os documentos referidos na alínea a) do número anterior devem:

                    + Ser emitidos pelas autoridades de educação do país de origem;
                    + Ser autenticados pelos serviços oficiais de educação do respetivo país e reconhecidos pela autoridade diplomática ou consular portuguesa, ou trazer a apostilha da Convenção de Haia, devendo o mesmo acontecer relativamente às traduções de documentos cuja língua original não seja a espanhola, a francesa ou a inglesa.

                  Apenas serão avaliados os processos de candidatura apresentados ao abrigo do 20-A se se verificar a entrega da documentação referida bem como o pagamento do emolumento fixado.

                  Os serviços dispõem de 10 dias úteis para avaliação do pedido após verificação dos requisitos mencionados anteriormente.

                  Caso o candidato não apresente a totalidade dos documentos ou não efetue o pagamento nos 10 dias subsequentes à apresentação do pedido, o mesmo será invalidado pelo serviço competente.

            * Candidatos Maiores de 23 anos: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Inscrever-me na Prova e Realizar Candidatura: https://secure.ensinolusofona.pt/candidaturas/page

                  Candidatos que completem 23 anos até ao dia 31 de Dezembro do ano que antecede a realização do exame para maiores de 23 anos.

                  Requisitos Faculdade de Educação Física e Desporto / Universidade Lusófona - Centro Universitário de Lisboa: https://www.ulusofona.pt/candidaturas/calendarios-de-candidatura

                      Requisitos Faculdade de Educação Física e Desporto / Universidade Lusófona - Centro Universitário de Lisboa

                      Calendário de Provas: https://www.ulusofona.pt/media/calendarios-de-provas-fefd.pdf

                      Bibliografia

                        + Tema A: Fundamentos Bioenergéticos do Exercício

                            o Texto I: Biologia do 10º ano: Terra, Universo de Vida, 2ª parte, Amparo Dias da Silva, Fernanda Gramaxo, Maria Ermelinda Santos, Almira Fernandes Mesquita. Porto Editora

                                - Unidade II: O transporte nos animais

                                - Unidade III: Transformação e utilização de energia pelos seres vivos

                                - Unidade IV: Regulação nos seres vivos: termorregulação

                        + Tema B: Corpo, Educação Física e Desporto no Portugal do Séc. XX

                            o Texto II: Breton, D. (2006). A sociologia do corpo. Petrópolis: Editora Vozes Descarregar PDF: https://www.ulusofona.pt/media/breton-sociologia.pdf

                            o Texto III: Cunha, M. (2004). A imagem corporal. Azeitão: Autonomia 27 Descarregar PDF: https://www.ulusofona.pt/media/cunha-imagem-corporal.pdf


                    Candidatura através da Inscrição para a Prova

                    Documentos a Entregar

                      + CERTIFICADO DE HABILITAÇÕES

                      + CERTIFICADOS DE FORMAÇÃO COMPLEMENTAR
                        Opcional

                      + CURRICULUM VITAE
                        Datado e assinado, com a indicação do seu percurso escolar e profissional

                      + DOCUMENTO DE IDENTIFICAÇÃO
                        Cartão de cidadão ou bilhete de identidade


                    Candidatura com Prova Realizada noutra Instituição de Ensino Superior

                    Documentos a Entregar

                          o DOCUMENTO DE IDENTIFICAÇÃO
                            Cartão de cidadão ou bilhete de identidade.

                          o CERTIFICADO DE HABILITAÇÕES e Certificado(s) de Formação Complementar (opcional)

                          o CURRICULUM VITAE
                            Atualizado, datado e assinado, com a indicação do seu percurso escolar e profissional.

                          o DECLARAÇÃO DE HONRA
                            Se aplicável

                          o COMPROVATIVO DA REALIZAÇÃO da Prova para Maiores de 23 Anos
                            Com a identificação do curso a que se candidatou, descrição das provas realizadas, suas classificações e nota final.

                          o ENUNCIADO E CÓPIA DA PROVA ESCRITA
                            Realizada em outra instituição

                          o PORTFÓLIO
                            A entregar no dia da entrevista, aplicável ao 1º ciclo de Fotografia.

                          o DECLARAÇÃO MÉDICA
                            Comprovativa de que satisfaz o pré-requisito do Grupo E – Aptidão Funcional e Física, aplicável ao 1º ciclo de Educação Física e Desporto (obrigatória no ato de matrícula).

                  No cumprimento do disposto na lei (decreto-Lei 64/2006 - regulamenta o acesso dos maiores de 23 anos ao ensino superior), estas provas destinam-se a avaliar a capacidade dos maiores de 23 anos para a frequência de um curso de licenciatura num estabelecimento de ensino superior. A avaliação de todos os candidatos integra:

                    + Apreciação de currículo escolar e profissional;

                    + Realização de uma entrevista para efeitos de avaliação das motivações do candidato;

                    + Realização de uma prova teórica e/ou prática de avaliação de conhecimentos e competências indispensáveis para o ingresso no ensino superior.

                  NOTA: A PROVA TEM VALIDADE PARA O ANO LETIVO EM QUE É REALIZADA A CANDIDATURA.

                  Regulamentos Para Maiores de 23 Anos: https://www.ulusofona.pt/documentos?q=maiores+23

            * Titulares de Curso Superior: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Realizar Candidatura: https://secure.ensinolusofona.pt/candidaturas/page


                    Ex-Alunos do Ensino Lusófona devem escolher o tipo de candidatura "Titulares de Curso Superior - Ensino Lusófona" para usufruírem das condições de desconto aplicáveis.

                    Documentos a entregar

                      + CERTIFICADO DE HABILITAÇÕES do Ensino Superior
                        Com indicação das unidades curriculares em que obteve aprovação e média final de curso

                      + DOCUMENTO DE IDENTIFICAÇÃO
                        Cartão de cidadão ou bilhete de identidade

            * Titulares de CET/CTeSP: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Realizar Candidatura: https://secure.ensinolusofona.pt/candidaturas/page


                    Documentos a entregar

                      + CERTIFICADO DE HABILITAÇÕES do Curso de Especialização tecnológica ou Curso Técnico Superior Profissional

                      + DOCUMENTO DE IDENTIFICAÇÃO
                        Cartão de cidadão ou bilhete de identidade

                      + FICHA ENES 2024 (original ou cópia autenticada)
                        ou caso tenha completado 23 anos até ao dia 31 de dezembro consulte as condições de acesso para Maiores de 23 Anos.

            * Mudança de par Instituição/Curso ou Reingresso: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Realizar Candidatura: https://secure.ensinolusofona.pt/candidaturas/page


                    Mudança de par Instituição / Curso

                    Documentos a entregar

                      + Cópia do documento de identificação, válido em Portugal;

                      + Certidão de habilitações do ensino superior ou declaração de matrícula;

                      + Ficha ENES ou declaração comprovativa da forma de ingresso no Ensino Superior, com indicação dos exames de acesso realizados e respetivas classificações.

                      + Comprovativo de satisfação dos pré -requisitos, quando aplicável.


                    Reingresso

                    Documentos a entregar

                      + DOCUMENTO DE IDENTIFICAÇÃO
                        Cartão de cidadão ou bilhete de identidade

            * Estudante Internacional: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Realizar Candidatura: https://secure.ensinolusofona.pt/candidaturas/page

                  Curso Preparatório para Estudantes Internacionais: https://www.ulusofona.pt/curso-preparatorio-para-internacionais

                  Se é Titular de:

                    + Qualificação que dê acesso ao ensino superior em Portugal, entendida como qualquer diploma ou certificado emitido por uma autoridade competente que ateste a aprovação num programa de ensino e lhes confira direito de se candidatar e poder ingressar no ensino superior no país em que foi conferido;

                  Ou

                    + Diploma do ensino secundário português ou de habilitação legalmente equivalente;

                  E

                    + Pretende candidatar-se a um Curso de licenciatura / 1º ciclo...

                  Deverá consultar a página de apoio ao estudante internacional da instituição a que se quer candidatar em:

                  Estudantes Oriundos de Países da União Europeia (UE): https://www.ulusofona.pt/estudante-internacional/estudante-oriundo-de-paises-da-ue

                  Estudantes Oriundos de Países fora da União Europeia (UE): https://www.ulusofona.pt/estudante-internacional/estudantes-oriundos-de-paises-fora-da-eu

                  Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros

            * Inscrição em Unidades Curriculares Isoladas: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Inscreva-se: https://secure.ensinolusofona.pt/candidaturas/page

                  Programa Preparar - Programa de Preparação para os Exames Nacionais: https://www.ulusofona.pt/programa-preparar

                  NÃO PRECISA DE SER ALUNO DO ENSINO SUPERIOR PARA FREQUENTAR AS NOSSAS DISCIPLINAS!
                  Considerando a entrada em vigor de nova legislação, nomeadamente a alteração imposta pelo Decreto-Lei n.º 65/2018, de 16 de agosto, que altera o Decreto-Lei n.º 74/2006, de 24 de março, estabeleceu-se a possibilidade de inscrição em disciplinas isoladas, por parte de qualquer interessado, com a garantia, em caso de aprovação, de certificação e ainda de creditação, se e quando ingressar em curso que as integre. Segundo o artigo 46.º-A, referente à inscrição em unidades curriculares:

                   1. As instituições de ensino superior facultam a inscrição nas unidades curriculares que ministram.
                   2. A inscrição pode ser feita quer por estudantes inscritos num ciclo de estudos de ensino superior quer por outros interessados.
                   3. A inscrição pode ser feita em regime sujeito a avaliação ou não.
                   4. Quando a inscrição seja feita em regime sujeito a avaliação, cada estudante pode inscrever -se a um número máximo de 60 créditos acumulados ao longo do seu percurso académico.
                   5. As unidades curriculares em que o estudante se inscreva em regime sujeito a avaliação e em que obtenha aprovação:
                       1. São objeto de certificação;
                       2. São obrigatoriamente creditadas, com os limites fixados na alínea c) do n.º 1 do artigo 45.º, caso o seu titular tenha ou venha a adquirir o estatuto de estudante de um ciclo de estudos de ensino superior;
                       3. São incluídas em suplemento ao diploma que venha a ser emitido.
                   6. Pela inscrição nos termos deste artigo são devidos os montantes que forem fixados, de forma proporcionada, pelo órgão legal e estatutariamente competente da instituição de ensino superior.

                  Documentos a entregar

                    + DOCUMENTO DE IDENTIFICAÇÃO
                      Cartão de cidadão ou bilhete de identidade

            * Para Diplomados de Vias Profissionalizantes: https://www.ulusofona.pt/candidaturas/licenciaturas
                  Realizar Candidatura: https://secure.ensinolusofona.pt/candidaturas/page

                    + Os candidatos deverão ser titulares de cursos de dupla certificação e artísticos especializados que se insiram nas áreas de educação e formação (CNAEF) com correspondência às áreas dos 1º ciclos e Mestrados Integrados a que se candidatam previstas no elenco fixado pela CNAES.

                    + Os candidatos deverão realizar, na instituição a que se candidatam, provas teóricas ou práticas de avaliação de conhecimentos e competências consideradas indispensáveis ao ingresso e progressão no ciclo de estudos a que os estudantes se candidatam.

                    + O candidato terá de apresentar diploma/certificado final de conclusão do curso de habilitação anterior e documento comprovativo da classificação da prova final (aptidão ou avaliação) do curso de habilitação anterior.

                    + A avaliação da candidatura a um ciclo de estudos de licenciatura ou de mestrado integrado implica a avaliação da capacidade para a frequência dos mesmos, nos termos seguintes:

                      ponderação de 50% a classificação final do curso obtido pelo estudante;

                      ponderação de 20% as classificações obtidas nas provas de avaliação/aptidãoponderação de 30% nas classificações de provas teóricas ou práticas, realizadas na instituição a que se candidatam, de avaliação de conhecimentos e competências consideradas indispensáveis ao ingresso e progressão no ciclo de estudos a que os estudantes se candidatam.

                    + O acesso e ingresso ao abrigo do concurso especial a que se refere o presente artigo depende da obtenção pelo candidato de classificações iguais ou superiores a 95 pontos, na escala de 0 a 200 pontos, em cada um dos elementos de avaliação referidos no número anterior.

                    + Listas de colocação serão tornadas públicas e com os resultados expressos da seguinte forma: a) Colocado b) Não colocado

                  Documentos a entregar

                    + Documento de Identificação;

                    + Certificado de Habilitações (Curso profissional, artístico, aprendizagem nível 4) com a identificação da área do curso CNAEF

                    + Documento no qual conste classificação de prova final de curso nível 4 (PAP, PAF, PAA) caso o mesmo não conste no certificado de habilitações;

                    + Declaração Médica comprovativa de que satisfaz o pré-requisito do Grupo E – Aptidão Funcional e Física, aplicável ao 1º ciclo de Educação Física e Desporto (obrigatória no ato de matrícula).

                  Confirmar a minha área CNAEF: https://catalogo.anqep.gov.pt/qualificacoesPesquisa

                  Cursos de licenciatura com candidaturas abertas

                    + Universidade Lusófona - Centro Universitário de Lisboa CUL - Lisboa

                      Download (PDF) : https://www.ulusofona.pt/media/ulht-licenciatura-cand-abertas.pdf

                    + Universidade Lusófona - Centro Universitário do Porto CUP - Porto

                      Download (PDF) : https://www.ulusofona.pt/media/ulp-licenciatura-cand-abertas.pdf

                  Provas para Acesso ao Ensino Superior para Diplomados de Vias Profissionalizantes

                    + Universidade Lusófona - Centro Universitário de Lisboa CUL - Lisboa

                      Download (PDF) : https://www.ulusofona.pt/media/ulht-provas-acesso-ensino-superior.pdf

                    + Universidade Lusófona - Centro Universitário do Porto CUP - Porto

                      Download (PDF) : https://www.ulusofona.pt/media/ulp-provas-acesso-ensino-superior.pdf
                  Calendário e Datas de Provas para Diplomados de Vias Profissionalizantes: https://www.ulusofona.pt/candidaturas/calendarios-de-candidatura#provas

                  APÓS FORMALIZAÇÃO E CONFIRMAÇÃO DA CANDIDATURA SERÁ FORNECIDA A MATRIZ DAS PROVAS.



              Candidaturas: https://www.ulusofona.pt/candidaturas
                Calendário de Candidaturas e Provas: https://www.ulusofona.pt/candidaturas/calendarios-de-candidatura
                Emolumentos e Propinas 24/25: https://www.ulusofona.pt/documentos?cat=5&page=2
                Licenciaturas: https://www.ulusofona.pt/candidaturas/licenciaturas
                Mestrados: https://www.ulusofona.pt/candidaturas/mestrados
                Mestrados Integrados: https://www.ulusofona.pt/candidaturas/mestrados-integrados
                Doutoramentos: https://www.ulusofona.pt/candidaturas/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/candidaturas/posgraduacoes
                Programa Preparar (Estudantes Nacionais): https://www.ulusofona.pt/candidaturas/programa-preparar
                Curso Preparatório (Estudantes Internacionais): https://www.ulusofona.pt/lisboa/formacao/curso-preparatorio
                Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                Vantagens Ensino Lusófona: https://www.ensinolusofona.pt/pt/vantagens
        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona