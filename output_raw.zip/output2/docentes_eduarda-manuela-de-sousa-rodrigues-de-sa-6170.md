# Response for https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
          PT: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170 EN: https://www.ulusofona.pt/en/teachers/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
        fechar menu : https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/eduarda-manuela-de-sousa-rodrigues-de-sa-6170
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Eduarda Sousa-sá

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6170
              p61***@ulusofona.pt
              9E1E-C022-87B0: https://www.cienciavitae.pt/9E1E-C022-87B0
              0000-0001-8753-6817: https://orcid.org/0000-0001-8753-6817
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/167224c4-113b-4d0f-918c-4a00e2016fc9
      : https://www.ulusofona.pt/

        Resume

        Eduarda Manuela de Sousa Rodrigues de Sá. Completed a Licenciatura (bachelor with honours) in Sports Science (specialization in Exercise and Health) in 2009 at University of Porto, a Master in Teaching Physical Education in Primary and Secondary Education in 2014 at University of Minho, and a PhD in Physical Activity and Public Health in 2019 at University of Wollongong, Australia. She is an Assistant Professor at Lusófona University, Lisbon, Portugal. She is a Researcher at CIDEFES (Lusófona University) and CIAFEL-ITR (Faculty of Sports and Public Health Institute, University of Porto); moreover, she is an Invited Researcher at University of Wollongong. So far, Eduarda has published 36 articles in peer-reviewed scientific journals; 1 magazine article; 3 book chapters and 1 scientific journal editorial. She has received 6 awards and/or honours. Eduarda participates and/or participated in 12 internationally funded research projects; PhD Student Fellow in 1 project and Post-doc Fellow in 1 project. She works in the area of Medical and Health Sciences with emphasis on Health Sciences and on Sport and Fitness Sciences. In her professional activities, Eduarda interacted with +200 collaborators, mostly in co-authorship of scientific papers. In her Ciência Vitae curriculum, the most frequent terms in the context of scientific, technological and artistic-cultural outputs are: preschool years; children; adolescents; youth; public health; guidelines; surveillance; movement behaviours; physical activity; exercise; sedentary behaviour; sedentary time; screen time; childcare; systematic review; scoping review; national survey; cardiovascular health; hypertension; executive function; obesity; motor density; fine motor skills; environment; motor development; motor coordination; fundamental movement skills; motor proficiency.

        Graus

            * Doctor of Philosophy
              Physical Activity and Public Health
            * Outros
              International English Language Testing System
            * Licenciatura
              Sports Science (specialization: Exercise and Health)
            * Mestrado
              Teaching Physical Education in Primary and Secondary Education

        Publicações

        Magazine article

          * 2022, O Conceito dos Comportamentos 24h Movimento e as suas Recomendações, Portugal Activo

        Journal article

          * 2023-12-07, Sleep duration and cardiorespiratory fitness in adolescents: Longitudinal analysis from the LabMed study, Journal of Adolescence
          * 2023-08-07, Editorial: Movement behaviors (sleep, sedentary behavior and physical activity) and physical and mental/cognitive health, Frontiers in Psychiatry
          * 2023-07-05, COVID-19 Social Restrictions’ Impact on the Health-Related Physical Fitness of the Police Cadets, Healthcare
          * 2023-06, Discrepancies Between Self-reported and Objectively Measured Smartphone Screen Time: Before and During Lockdown, Journal of Prevention
          * 2023-01-01, Questionnaires Measuring 24-Hour Movement Behaviors in Childhood and Adolescence: Content Description and Measurement Properties—A Systematic Review, Journal of Physical Activity and Health
          * 2023, Physical Education Teachers’ Perceptions of a Motor Competence Assessment Digital App, Journal of Teaching in Physical Education
          * 2022-08, Associations of sleep characteristics with cognitive and gross motor development in toddlers, Sleep Health
          * 2022, Questionnaires measuring movement behaviours in adults and older adults: content description and measurement properties. A systematic review
          * 2021-12-17, Longitudinal differences in levels and bouts of sedentary time by different day types among Australian toddlers and pre-schoolers, Journal of Sports Sciences
          * 2021-08, Systematic Review of the Relationships between 24-Hour Movement Behaviours and Health Indicators in School-Aged Children from Arab-Speaking Countries, International Journal of Environmental Research and Public Health
          * 2021-07, Prevalence, patterns and socio-demographic correlates of sleep duration in adolescents: results from the LabMed study, Sleep Medicine
          * 2021-03, Objectively Measured Sedentary Levels and Bouts by Day Type in Australian Young Children, Journal of Physical Activity & Health
          * 2020-12, A Narrative Review of Motor Competence in Children and Adolescents: What We Know and What We Need to Find Out, International Journal of Environmental Research and Public Health
          * 2020-09-08, Sedentary time and blood pressure in Australian toddlers: The get-up study longitudinal results, Journal of Sports Sciences
          * 2020-07, The Get-Up! study: adiposity and blood pressure in Australian toddlers, Porto Biomedical Journal
          * 2020-06-04, Correlates of Sleep Duration in Early Childhood: A Systematic Review, Behavioral Sleep Medicine
          * 2020-04-06, Correlates of sedentary time in young children: A systematic review, European Journal of Sport Science
          * 2020-03-10, Systematic review on retinal microvasculature, physical activity, sedentary behaviour and adiposity in children and adolescents, Acta Paediatrica
          * 2020-02-26, Systematic Review on the Associations between Objectively Measured Breaks in Sitting Time and Cardiovascular Health in Youth, International Journal of Physical Education, Fitness and Sports
          * 2020, Concurrent validity of the ActiGraph GT3X+ and activPAL for assessing sedentary behaviour in 2–3-year-old children under free-living conditions, Journal of Science and Medicine in Sport
          * 2019-12, Childcare Physical Activity Interventions: A Discussion of Similarities and Differences and Trends, Issues, and Recommendations, International Journal of Environmental Research and Public Health
          * 2019-09-21, Association of Dairy Product Consumption with Metabolic and Inflammatory Biomarkers in Adolescents: A Cross-Sectional Analysis from the LabMed Study, Nutrients
          * 2019-07-03, The cross-sectional and prospective associations between sleep characteristics and adiposity in toddlers: Results from the GET UP! Study, Pediatric Obesity
          * 2019, The associations between environmental characteristics of early childhood education and care centers and 1-year change in toddlers’ physical activity and sedentary behavior, Journal of Physical Activity and Health
          * 2019, Correlates of nocturnal sleep duration, nocturnal sleep variability, and nocturnal sleep problems in toddlers: results from the GET UP! Study, Sleep Medicine
          * 2019, Associations between gross motor skills and cognitive development in toddlers, Early Human Development
          * 2018-12-18, Prevalence of objectively measured sedentary behavior in early years: Systematic review and meta-analysis, Scandinavian Journal of Medicine & Science in Sports
          * 2018-11-14, Association between breaks in sitting time and adiposity in Australian toddlers: Results from the GET-UP! study, Scandinavian Journal of Medicine & Science in Sports
          * 2018, Gross motor skills in toddlers: Prevalence and socio-demographic differences, Journal of Science and Medicine in Sport
          * 2018, Associations between gross motor skills and physical activity in Australian toddlers, Journal of Science and Medicine in Sport
          * 2017-11, Compliance with the Australian 24-hour movement guidelines for the early years: associations with weight status, BMC Public Health
          * 2016-11-09, “GET-UP” study rationale and protocol: a cluster randomised controlled trial to evaluate the effects of reduced sitting on toddlers’ cognitive development, BMC Pediatrics

        Thesis / Dissertation

          * 2019, PhD, Sitting Time and Cardiovascular Health in Children and Adolescents
          * 2014, Master, The influence of music on motor density of physical education lessons
          * 2009, Degree, Strength training in children and adolescents with obesity

        Book chapter

          * 2022, Mitos sobre o Sono: Será que o que sabemos sobre o sono não passa de ficção? , Mitos vs. Factos no Desporto, Educação Física, Exercício e Saúde, CIDEFES, ULHT
          * 2022, Dias da semana vs. fim-de-semana: sou mais ativo quando tenho mais tempo “livre”? O impacto da escola e da família, Mitos vs. Factos no Desporto, Educação Física, Exercício e Saúde, CIDEFES, ULHT
          * 2020, Preschool and Childcare Center Physical Activity Interventions, The Routledge Handbook of Youth Physical Activity, 1st, Routledge

        Conference paper

          * Relação entre a perceção da imagem corporal e a obesidade em adolescentes

        Conference abstract

          * 2023-06, Get-Up study: a cluster RCT on the effects of reduced sitting on toddlers’ cognitive development, ISBNPA
          * 2022-03, Prevalence, Patterns and Socio-Demographic Correlates of Sleep Duration in Adolescents: Results from the Labmed Study, World Sleep Conference
          * 2019-11, The effectiveness of a healthy lifestyle program on childhood self-regulation, creative thinking and problem solving: a protocol for childcare centers, 5th European Conference on Health Promoting Schools
          * 2019-11, Protocol for developing Portuguese 24h Movement Guidelines for children and adolescents, 5th European Conference on Health Promoting Schools
          * 2019-06, The associations between environmental characteristics of early childhood education and care centres and one-year change in toddlers’ physical activity and sedentary behaviour: a multilevel analysis from the GET UP! Study, ISBNPA
          * 2017-10, Prevalence of Objectively Measured Sedentary Behaviour in Toddlers and Pre-schoolers: A Systematic Review, PWP - Pediatric Work Physiology meeting XXX
          * 2017-10, Association between physical activity, sedentary behaviour and adiposity and retinal microvasculature in children and adolescents: a systematic review, PWP - Pediatric Work Physiology meeting XXX
          * 2017-09, Proportion of toddlers meeting physical activity, screen time and sleep and association with weight status, Early Start Conference 2017
          * 2017-07, Breaks in Sedentary Time and Adiposity in Australian Toddlers: The GET UP! Study, International Conference on Childhood Obesity (COSI) 2017
          * 2017-01, Gross motor skills and Physical Activity in Toddlers, CIAPSE 2 - Children's Physical Activity and Sport
          * 2017-01, Cognitive Development and Physical Activity in Toddlers, CIAPSE 2 - Children's Physical Activity and Sport
          * 2017-01, Blood pressure and physical activity in Australian toddlers, CIAPSE 2 - Children's Physical Activity and Sport

        Conference poster

          * 2022-03, Prevalence, Patterns and Socio-Demographic Correlates of Sleep Duration in Adolescents: Results from the Labmed Study, World Sleep Conference
          * 2019-11, Prevalence of sleep duration in Portuguese adolescents: a school-based study, 5th European Conference on Health Promoting Schools
          * 2019-09, Sitting Time and Blood Pressure in Australian Toddlers: longitudinal results from the Get-Up! Study, I-MDRC and CIAPSE - Healthy and active children: lifespan motor development science & applications
          * 2018-07, Patterns and geographic distribution of objectively measured Sedentary Behaviour in Early Years: Systematic Review and Meta-analysis, ECSS ¿ 23rd annual Congress of the European College of Sport Science
          * 2018-05, The Get-Up! Study: Adiposity and Blood Pressure in Australian Toddlers, 25th ECO ¿ European Congress on Obesity
          * 2017-10, The association of meeting physical activity, screen time and sleep guidelines with cognitive development among toddlers, PWP - Pediatric Work Physiology meeting XXX
          * 2017-10, Compliance with the Australian 24-hour movement guidelines for the early years: associations with weight status, PWP - Pediatric Work Physiology meeting XXX
          * 2017-07, Environmental characteristics of early childhood education and care centres and young children’s weight status: A systematic review, International Conference on Childhood Obesity (COSI) 2017
          * 2017-01, Blood Pressure, waist circumference and physical activity in Australian toddlers, CIAPSE 2 - Children's Physical Activity and Sport
          * 2017, Association between body mass index and gross motor development in toddlers, CIAPSE 2 - Children's Physical Activity and Sport

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona