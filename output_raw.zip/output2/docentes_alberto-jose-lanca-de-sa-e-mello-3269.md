# Response for https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
          PT: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269 EN: https://www.ulusofona.pt/en/teachers/alberto-jose-lanca-de-sa-e-mello-3269
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
        fechar menu : https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/alberto-jose-lanca-de-sa-e-mello-3269
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Alberto De Sá E Mello

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3269
              alb***@netcabo.pt
              AC12-9F25-8B6B: https://www.cienciavitae.pt/AC12-9F25-8B6B
              0000-0001-9468-7496: https://orcid.org/0000-0001-9468-7496
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/94366283-ccef-411e-a04f-a8bfb94203ab
      : https://www.ulusofona.pt/

        Resume

        Alberto José Lança de Sá e Melo. É licenciado em Direito pela Faculdade de Direito da Universidade de Lisboa (1981). É Mestre em Direito pela Faculdade de Direito da Universidade e Lisboa (1989). É Doutorado em Direito pela Universidade Lusíada de Lisboa (2007). É Professor Catedrático convidado na Faculdade e Direito da Universidade Lusófona. É Professor Associado no Instituto Superior de Gestão. Leccionou 73 Cursos de Pós-graduação e de Mestrado. Publicou 55 artigos em revistas especializadas, possui 25 capítulos de livros e 24 livros publicados. Possui 33 itens de produção técnica. Participou em 105 eventos em Portugal e no estrangeiro (todos como keynote speaker). É Consultor jurídico de Empresas, de Associações Empresariais e da Confederação do Comércio e Serviços de Portugal (desde 1984). É Advogado. Actua especialmente na área do Direito Civil, Direito do Trabalho, Direito Empresarial e Direito e Autor. Nas suas actividades profissionais interagiu com 23 colaboradores em co-autorias de trabalhos científicos. No seu curriculum Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural são: Direito, Empresas, Direito do Trabalho, Trabalhadores, Direito Civil, Direito de Autor, Direito da Empresa, Autores, Contratação Colectiva de Trabalho e Internet._______ Alberto José Lança de Sá e Melo. He has a degree in Law from the Faculty of Law of the University of Lisbon (1981). He holds a Master's degree in Law from the Faculty of Law of the University of Lisbon (1989). He has a PhD in Law from the Lusíada University of Lisbon (2007). He is a guest Professor at the Faculty and Law of the Lusófona University. He is an Associate Professor at the Instituto Superior de Gestão. Taught 73 Postgraduate and Master's Courses. He has published 55 articles in specialized journals, has 25 book chapters and 24 books published. It has 33 technical production items. Participated in 105 events in Portugal and abroad (all as keynote speaker). He is a legal consultant for Companies, Business Associations and the Confederation of Commerce and Services of Portugal (since 1984). He's a lawyer. He works especially in the areas of Civil Law, Labor Law, Business Law and Copyright Law. In his professional activities, he interacted with 23 collaborators in co-authoring scientific works. In your Science Vitae curriculum, the most frequent terms in the context of scientific, technological and artistic-cultural production are: Law, Companies, Labor Law, Workers, Civil Law, Copyright, Company Law, Authors, Collective Labor Agreement and Internet.

        Graus

            * Licenciatura
              Direito
            * Mestrado
              Mestrado em Direito
            * Doutoramento
              Direito

        Publicações

        Artigo em revista (magazine)

          * 2015-06-20, Questões sobre Direito de Autor, Vida Judiciária

        Artigo em revista

          * 2024-06-01, La transposición de la Directiva de la UE 2019/790, sobre derechos de autor y derechos afines en el mercado único digital, al derecho portugués , Anuario de Propiedad Intelectual 2023
          * 2023-07-25, Inteligência artificial e Direito de autor, Revista de Direito Intelectual
          * 2023-07-18, Crónica de Actualidad Latinoamericana (Portugal), Anuario de Propiedad Intelectual 2022
          * 2022-11-30, Aspectos constitucionais do regime do casamento em Direito português, JURISMAT - Revista jurídica
          * 2022-09-05, Derechos de Autor y Libertad de Expresión, de Religión y de Culto, Anuario de Propiedad Intelectula
          * 2022-09-05, Cronica de Actualidad Latino Americana (Portugal), Anuario de Propiedad Intelectual
          * 2021-12-07, A transposição em Portugal da Directiva 2019/790 (UE), relativa aos direitos de autor e direitos conexos no mercado único digital - subsídios em nova reflexão sobre o tema, Revista de Direito Intelectual
          * 2021-10-15, Responsabilidade do produtor e do vendedor por produtos defeituosos no direito português, Revista IBERC
          * 2021-09-09, O direito exclusivo dos autores e as excepções a favor de bibliotecas, museus, arquivos e demais instituições culturais – Estudo de direito comparado dos regimes português e espanhol – Uma proposta para a transposição dos artigos 6º a 8º da directiva 2019/790 (UE), Anuario de Propiedad Intelectual
          * 2021-09-09, Cronica de Iberoamerica - Portugal 2020, Anuario de Propiedad Intelectual
          * 2021-06-30, De los Animales en el Derecho portugués, Revista General de Legislación y Jurisprudencia
          * 2021-05-28, O direito exclusivo dos autores e as excepções a favor de bibliotecas, museus, arquivos e demais instituições culturais – Estudo de Direito comparado dos regimes português e espanhol - Uma proposta para a transposição dos artigos 6º a 8º da Directiva 2019/790 (UE), JURISMAT - Revista jurídica
          * 2020-11-27, Modificação ou resolução de contratos por alteração das circunstâncias, no contexto da pandemia COVID-19 (breve nota ao regime da lei civil), JURISMAT - Revista jurídica
          * 2020-11-16, O Direito de Autor e a Impressão 3D, Revista de Direito Intelectual
          * 2020-08-21, Plágio e Direito de Autor (Brasil), Revista Fórum de Direito Civil
          * 2020-06-20, Plágio e Direito de Autor, Revista de Direito Intelectual
          * 2020-01-05, Plagio y Derecho de autor, Anuario de Propiedad Intelectual
          * 2019-12-02, A Directiva (UE) 2019/790, relativa aos direitos de autor e direitos conexos no mercado único digital e os termos para a sua transposição em Portugal, Revista de Direito Intelectual
          * 2019-10-01, Direito de autor e Arquitectura, Revista De Legibus
          * 2019-08-30, O regime dos bens industriais criados em execução de contrato de trabalho no novo Código da Propriedade Industrial de Portugal e nos ordenamentos jurídicos de Espanha e dos Países e territórios lusófonos, Anuario de Propiedad Intelectual 2018
          * 2018-12-31, A colocação em rede electrónica digital (www) de obras intelectuais e de outros conteúdos protegidos alheios, Galileu - Revista de Direito e Economia
          * 2018-12-02, As invenções e outros bens industriais criados em execução de contrato - regime em direito comparado lusófono , Revista Vida Judiciária
          * 2018, Os limites à liberdade de expressão e de criação cultural : a protecção da vida privada, Revista de Direito Intelectual
          * 2018, Os animais no ordenamento jurídico português - algumas notas, Revista da Ordem dos Advogados
          * 2018, Le contrat de réalisation et de production audiovisuelle en droit portugais et en droit marocain, Journal d'Économie, de Management, d'Environement et de Droit (JEMED)
          * 2018, Direitos conexos dos editores. Desenvolvimentos recentes , Revista de Direito Intelectual
          * 2018, A colocação em rede electrónica digital (www) de obras intelectuais e de outros conteúdos protegidos alheios, Revista Fórum de Direito Civil
          * 2018, A "reserva de convenção colectiva" e a Constituição Portuguesa, Revista de Direito e de Estudos Sociais
          * 2017, Principais aspectos e alguns problemas da gestão colectiva de direitos de autor e de direitos conexos, Revista da Ordem dos advogados
          * 2017, O direito pessoal (dito "moral") de autor nos ordenamentos jurídicos português e espanhol, Revista de Direito Intelectual
          * 2017, Direito Exclusivo dos Autores e as Excepções a Favor de Bibliotecas, Arquivos e Museus - Estudo de direito comparadao dos regimes português, brasileiro e espanhol, Revista Fórum de Direito Civil
          * 2017, Derecho personal (dicho "moral") del autor - en derecho portugués y español, Anuario de Propiedad Intelectual 2016
          * 2016, Principais aspectos e alguns problemas da gestão colectiva de direitos e de autor e de direitos conexos no ambiente digital - O regime em Portugal e em Espanha e no direito Comunitário, Revista da Ordem dos Advogados
          * 2016, Principais Aspectos e Alguns Problemas da Gestão Colectiva de Direitos de autor e Direitos Conexos em Portugal e em Espanha, Anuario de Propiedad Intelectual
          * 2016, Cronica de Actualidad Latinoamericana, Anuario de Propiedad Intelectual
          * 2016, Contratos relativos a bens industriais: algumas notas, Revista de Direito Intelectual
          * 2015, Trabalho criativo subordinado: a criação de obras intelectuais em execução de contrato de trabalho: com uma perspectiva de Direito comparado), JURISMAT - revista jurídica
          * 2015, Trabalho criativo subordinado: A criação de obras intelectuais em execução de contrato de trabalho (com uma perspectiva de Direito comparado), Revista Fórum de Direito Civil
          * 2015, Trabalho criativo subordinado - a criação de obras intelectuais em execução de contrato de trabalho, Anuario de Propiedad Intelectual
          * 2015, O registo de obras literárias e artísticas - o Novo Regime em 2015, Revista de Direito Intelectual
          * 2015, Cronica de Actualidad LatinoAmericana, Anuario de Propiedad Intelectual
          * 2014, O Direito das Sucessões em Portugal, JURISMAT - Revista jurídica
          * 2014, Direito pessoal de autor - Uma perspectiva Lusófona, Revista Fórum de Direito Civil
          * 2014, Crónica de Actualidad LatinoAmericana (Portugal), Anuario de Propiedad Intelectual 2013
          * 2013, A Causa do Negócio Jurídico, De Legibus - Revista jurídica da Faculdade de Direito da Universidade Lusófona
          * 2012, Situação Jurídica Laboral - notas para a definição de um paradigma (revisto), International Business and Economics Review
          * 2012, Filmagem de espectaculos desportivos e "direito de arena", JURISMAT - Revista Jurídica
          * 2005, A Telecomunicação Electrónica em Rede de Obras Intelectuais na Sociedade da Informação - a Directriz 2001/29/CE e a sua Transposição em Portugal pela Lei n.º 50/2004, Anuario de Propiedad Intelectual
          * 2001, Situação Jurídica Laboral - notas para a definição de um paradigma, Trabalho e Relações Laborais - Cadernos Sociedade e Trabalho
          * 2000, Cronica de Iberamerica - Portugal, Revista General de Legislación y Jurisprudencia
          * 1998, Tutela Jurídica das Bases de Dados, Revista de la Facultad de Derecho de la Universidad Complutense de Madrid
          * 1997, Extinção de Contratos de Trabalho por Dissolução da Pessoa Colectiva >Empregadora, Revista de Direito e de Estudos Sociais
          * 1989, Critérios de Apreciação da Culpa na Responsabilidade Civil, Revista da Ordem dos Advogados
          * 1982, O Objecto do Processo Penal - sua determinação, Revista da Ordem dos Advogados

        Livro

          * 2023, Manual de Direito de Autor e Direitos Conexos, 5, Mello, Alberto José Lança de Sá e, Edições Almedina
          * 2023, Direito do Trabalho para Empresas, 5, Mello, Alberto José Lança de Sá e, Edições Almedina
          * 2022, Direito do Trabalho para Empresas, 4, Mello, Alberto José Lança de Sá e, Edições Almedina
          * 2021, Estudos de Direito Lusófono Comparado - Vol. II, 1, Mello, Alberto José Lança de Sá e, Edições Universitárias Lusófonas
          * 2020, Manual de Direito de Autor e Direitos Conexos , 4, Eugenia Caldas Barros, Carla, Edições Almedina
          * 2019, Manual de Direito de Autor e Direitos Conexos, 3, Mello, Alberto José Lança de Sá e, Almedina
          * 2019, Direito do Trabalho para Empresas, 3, Mello, Alberto José Lança de Sá e, Almedina
          * 2019, Direito do Trabalho para Empresas, 2, Mello, Alberto José Lança de Sá e, Almedina
          * 2019, Casos práticos de Direito das Sucessões, 1, Mello, Alberto José Lança de Sá e, Almedina
          * 2019, Casos Práticos de Direito das Sucessões - (120 casos, incluindo 50 casos resolvidos), Mello, Alberto José Lança de Sá e; Mamedes, Vanessa, Almedina
          * 2018, Casos Práticos de Direito das Obrigações - (incluindo casos resolvidos), Mello, Alberto José Lança de Sá e; Mamedes, Vanessa, Almedina
          * 2018, Casos Práticos - Direito das Obrigações, 1, Mello, Alberto José Lança de Sá e; Vanessa Isabel Mamedes, Edições Almedina
          * 2017, O Direito em Portugal, 1, Mello, Alberto José Lança de Sá e; Carlos Blanco de Morais; Jorge Miranda; Luiz Cabral de Moncada; Manuel Nogueira Serens; Mário Ferreira Monte; Maria do Rosário Ramalho; Maria dos Prazeres Beleza; Miriam Afonso Brigas, Editorial Reus
          * 2016, Manual de Direito de Autor e Direitos Conexos, 2, Mello, Alberto José Lança de Sá e, Almedina
          * 2016, Direito do Trabalho para Empresas, 1, Mello, Alberto José Lança de Sá e, Almedina
          * 2015, Manual para a Renovação da Contratação Colectiva no Comércio e Serviços - orientações para a contratação colectiva de trabalho, 1, Mello, Alberto José Lança de Sá e; Alexandra Afonso; Ana Cristina Figueiredo; Ana Jacinto; Ana Monteiro Souta; Ana Rita Relógio; Catarina Correia; et al, CCP
          * 2014, Manual de Direito de Autor, 1, Mello, Alberto José Lança de Sá e, Editora Almedina
          * 2011, Código do Trabalho e Renovação da Contratação Colectiva - Orientações para a Contratação Colectiva de Trabalho no Comércio e Serviços, 2, Melo, Alberto José Lança de Sá e; Luísa Silva Carvalho; Sílvia Valente; Isabel Figueira; Nuno Cerejeira Namora, CCP
          * 2008, Contrato de Direito de Autor - a autonomia contratual na formação do direito de autor, 1, Melo, Alberto José Lança de Sá e, Alnedina
          * 2006, Elementos de Direito do Trabalho para Empresas, 1, Melo, Alberto José Lança de Sá e, Almedina
          * 2004, Código do Trabalho e Renovação da Contratação Colectiva - Orientações para a Contratação Colectiva do Trabalho no Sector do Comércio e Serviços, 1, Melo, Alberto José Lança de Sá e; Sílvia Valente; Luísa Silva Carvalho; Nuno Cerejeira Namora; Isabel Figueira, CCP
          * 2002, Revisão da Legislação Laboral - Nova Lei Geral do Trabalho, 1, Melo, Alberto José Lança de Sá e; António Monteiro Fernandes; Pedro Furtado Martins; Américo Thomati; Luís Brito Correia, Ministério do Trabalho
          * 1998, Manual de Princípos Fundamentais de Direito do Trabalho para Empresas, 1, Melo, Alberto José Lança de Sá e, Instituto do Emprego e Formação Profissional
          * 1990, O Direito Pessoal de Autor no Ordenamento Jurídico Podtuguês, 1, Melo, Alberto José Lança de Sá e, SPA
          * 1990, Casos Práticos de Direito das Obrigações, 2, Mello, Alberto José Lança de Sá e; Manuel Januário da Costa Gomes; Carlos Lacerda Barata; Maria Paula Gouveia Andrade; Luís Mello, AAFDL
          * 1989, Casos Práticos de Direito das Obrigações, 1, Mello, Alberto José Lança de Sá e; Manuel Januário da Costa Gomes; Carlos Lacerda Barata; Maria Paula Gouveia Andrade; Luís Mello, AAFDL

        Capítulo de livro

          * 2024, Les effets personnels du divorce en droit portugais, Actas de Coneferência internacional, 1, 1, xxx
          * 2023, O impacto da impressão 3D no Direito do Consumo, Estudos de Direito do Consumo, III, 1, Edições Almedina
          * 2023, A situação da regulação legal do direito de autor em Portugal e as exigências da sua adaptação à Directiva (UE) 2019/790, Economia Colaborativa, 1, 1, UMinho Editora/JusGov
          * 2022, Desenhos e modelos industriais – relações do direito de autor com o direito de propriedade industrial – anotação ao artigo 194º do Código da Propriedade Industrial e ao artigo 2º/1-i) do Código do Direito de Autor e dos Direitos Conexos, Propriedade Intelectual, Contratação e Sociedade da Informação – Estudos jurídicos em Homenagem a Manuel Oehen Mendes , 1, 1, Almedina
          * 2021, O direito pessoal de autor - uma perspectiva lusófona, Estudos de Direito Lusófono Comparado - Vol. II, 1, 1, Edições Universitárias Lusófonas
          * 2019, O regime dos bens industriais criados em execução de contrato de trabalho ou de prestação de serviços no novo Código da Propriedade Industrial de portugal e nos ordenamentos jurídicos de países e territórios lusófonos, Estudos de Direito Lusófono Comparado, 1, 1, Edições Universitárias Lusófonas
          * 2019, La Directiva sobre los Derechos de Autor en el Mercado Único Digital y su Transposición al Derecho Portugués. Algunos ejemplos de perspectivas, Bases para una Reforma de la Ley de Propiedad Intelectual, 1, 1, Reus Editorial
          * 2019, Apadrinhamento civil - uma perspectiva luso-brasileira, Estudos de Direito Lusófono Comparado, 1, 1, Edições Universitárias Lusófonas
          * 2018, Propuesta de nueva redacción del artículo 37.1 TRLPI. Límite al derecho de reproducción, Propiedad Intelectual y Bibliotecas: una revisión crítica, 1, 1, Reus Editorial
          * 2017, O Direito Pessoal (dito "Moral") de Autor nas Obrsa criadas em Execução de Contrato de Trabalho ou de Prestação de Serviços - em Portugal e no Brasil, Danos Extrapatrimoniais no Direito do trabalho, 1, 1, Editora LTDA
          * 2017, Derecho exclusivo de los autores y las excepciones en favor de las bibliotecas, archivos y demás instituiciones culturales. Estudio de Derecho Comparado de los Regímenes Portugués, Español y Comunitario, Estudio de los Límites a los Derechos de Autor desde una Perspectiva de Derecho Comparado, 1, 1, Reus
          * 2016, Uma Perspectiva Lusófona sobre o Direito Pessoal de Autor, Direito Na Lusofonia - Cultura, direitos humanos e globalização, 1, 1, Universidade do Minho - Escola de Direito
          * 2015, Trabalho criativo subordinado: a criação de obras intelectuais em execução de contrato de trabalho, Estudos dedicados ao Professor Doutor Bernardo da Gama Lobo Xavier, 1, 1, Universidade Católica Editora
          * 2015, A eficácia das autorizações (licenças) contratuais de utilização patrimonial de obra intelectual literária ou artística, Estudos de Direito Intelectual em homenagem ao Prof. Doutor José de Oliveira Ascensão, 1, 1, Almedina
          * 2008, A Telecomunicação Electrónica em Rede de Obras Intelectuais na Sociedade da Informação - A Directriz 2001/29/CE e a sua Transposição em Portugal pela Lei 50/2004, Direito da Sociedade da Informação - vol. VII, 7, Coimbra Editora
          * 2001, Os Multimedia - regime jurídico, Direito da Sociedade da Informação, Coimbra Editora
          * 2001, Novos Modelos de Organização do Tempo de Trabalho, Estudos do Instituto de Direito do Trabalho, 1, Almedina
          * 2001, Filmagem de Espectáculos Desportivos e «Direito de Arena», Creaciones Audiovisuales y Propiedad Intelectual, 1, Reus
          * 2000, O Costume como Fonte de Direito em Espanha e em Portugal, O Costume, o Direito Consuetudinário e as Tradições Populares na Extremadura e no Alentejo, Junta de Extremadura
          * 1999, Tutela Jurídica das Bases de Dados (A Transposição da Directriz 96/9/CE), Direito da Sociedade da Informação, Coimbra Editora
          * 1999, Trabalho a Tempo Parcial, Manual Prático de Processamento Laboral, 1, xxx
          * 1999, Tempo de Trabalho - Período de Trabalho, Manual Prático de Processamento Laboral, 1, xxx
          * 1999, Bases de Dados. A Tutela Jurídica Europeia, Nuevas Tecnologias y Propiedad Intelectual, 1, Reus

        Revisão de livro

          * Recensão de obra Manual de Derecho de Autor

        Manual

          * 2019, Manual para a Renovação da Contratação Colectiva de Trabalho no Comércio e Serviços - Orientações para a Contratação Colectiva de Trabalho, Confederação do Comércio e Serviços de Portugal - CCP

        Outra produção

          * 2012, JURISMAT - Revista jurídica

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona