# Response for https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
          PT: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113 EN: https://www.ulusofona.pt/en/teachers/catarina-isabel-santos-patricio-leitao-4113
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
        fechar menu : https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/catarina-isabel-santos-patricio-leitao-4113
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Catarina Patrício

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4113
              p41***@ulht.pt
              2318-6DDC-9A92: https://www.cienciavitae.pt/2318-6DDC-9A92
              0000-0002-1904-2775: https://orcid.org/0000-0002-1904-2775
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/535e439e-d435-4181-8692-b5e4642a0cad
      : https://www.ulusofona.pt/

        Resume

        Catarina Patrício (b. 1980) is a Visual Artist and Assistant Professor at ECATI, Lusófona University. She holds a Ph.D in Communication Sciences from FCSH-NOVA (2014), a MA in Anthropology of Social Movements from FCSH-NOVA (2008) and has an undergraduate degree in Painting from the Faculty of Fine Arts University of Lisbon (2003). The Portuguese Foundation for Science and Technology (FCT) funded both her doctoral and post-doctoral research. Integrated researcher at CICANT – Center for Research in Applied Communication, Culture and New Technologies (DOI 10.54499/UIDB/05260/2020), she publishes essays and exhibits artwork regularly.

        Graus

            * Licenciatura
              Fine Arts - Painting
            * Mestrado
              MSc Anthropology of Social Movements
            * Pós-doutoramento
              Post-Doc in Communication Sciences - Contemporary Culture and Technologies
            * Doutoramento
              PhD Communication Sciences-Contemporary Culture and New Technologies

        Publicações

        Artigo em revista (magazine)

          * 2023-11, O Movimento da Passagem - Ensaio sobre a Exposição "Ciclóptico" de Paulo Lisboa, no MAAT, Arte Capital
          * 2018, On Geoaesthetics in Film Form: from the paleolithic Rock Art of the Côa Valley Archaeological Park to Les Amours de la Pieuvre by Jean Painlevé, Cine Qua Non, Bilingual Arts Magazine, issue 10
          * 2014-05, A Landscape / Uma Paisagem de Acontecimentos, Cine Qua Non, Bilingual Arts Magazine, issue 8
          * 2010-09-21, "Mapeamento de uma arte político-social: Untitled, de Paula Rego" , Le Monde Diplomatique

        Edição de número de revista

          * Movimento
          * Cidades do Futuro / Cities of the Future

        Artigo em revista

          * 2023-06-30, Smart City as Participatory Environment, Interações: Sociedade e as novas modernidades
          * 2022-04-17, vestir como impulso criativo das mudanças políticas:, Latitude
          * 2018-04, Cities of the Future: Editor’s Introduction, Journal of Languages and Communication / Revista de Comunicação e Linguagens
          * 2018-04, Cidades do Futuro: Introdução do Editor, Revista de Comunicação e Linguagens
          * 2017, The Paralyzed Legislator: Crisis Of The Nomos Of The Earth / O Legislador Paralisado: Crise do nomos da Terra, Revista de Comunicação e Linguagens, 45
          * 2015-05-01, The First World War and Total Mobilization: The Inevitability of Planetary Recruitment / A Primeira Grande Guerra e a Inevitabilidade do Recrutamento Planetário, Revista de Ciências Militares
          * 2014-07, Fiction and Method: A science fiction tale and object-oriented ontology / A Ficção como Método: , INTERACT, Revista On-line de Arte, Cultura e Tecnologia
          * 2013, On Simondon Mechanology / Notas sobre a Mecanologia de Gilbert Simondon, Interact: Revista On-line de Arte, Cultura e Tecnologia
          * 2012, Industrialização da Percepção Artificial, Revista Lusófona de Arquitectura e Educação
          * 2012, Feedback de Cablegate para o Jardim de Éden: A individuação do vírus de mutação tecnológica, Revista de Comunicação e Linguagens

        Tese / Dissertação

          * 2014-10-20, Doutoramento, Dissuasão Visual: Arte, Cinema, Cronopolítica e Guerra em Directo
          * 2007, Mestrado, Untitled : antropologia, arte e abjeção no aborto clandestino em Portugal

        Livro

          * 2021, "Crítica das Mediações Totais - Perspectivas expandidas dos media", Bogalheiro, Manuel; RIBEIRO, LUÍS CLÁUDIO; Gomes Pinto, Jose; Leitão, Catarina Patrício; Castro, Aida Estela; Natálio, Carlos; Bragança de Miranda, José, Documenta
          * 2014, O Resto e o Gesto / The Rest and the Gesture (The Catalogue), Patrício, Catarina

        Capítulo de livro

          * 2022, Simondon no Antropoceno, A Máquina Aberta: A Mentalidade Técnica de Gilbert Simondon. Thiago Novaes, Lucas Vilalta e Evandro Smarieri (Org.), Dialética
          * 2020, The production of public open spaces and the deliberate exclusion of undesirables, Co-Creation of Public Open Places. Practice - Reflection - Learning, Edições Universitárias Lusófonas
          * 2020, A atualidade na História do Futuro de Padre António Vieira, Imprensa da Universidade de Coimbra
          * 2019, Heterotopic Landscapes: From GreenParks to Hybrid Territories, CyberParks – The Interface Between People, Places and Technology, Springer International Publishing
          * 2019, A Gentrificação como Procedimento Global ; Gentrification as global procedure
          * 2017, Smart-City: Cinema, Utopicidade e Governamentalidade na Cidade Pós-Industrial?, netativismo, Edições Universitários Lusófona
          * 2015, Genealogia da Percepção e a Fabricação do Sogennante Mensch, Tecnologias Culturais e Artes dos Media, Maria Teresa Cruz, Maria Augusta Babo e José Gomes Pinto (Org.) , 1, Unyleya
          * 2014, Expect the unexpected: Paul Virilio’s «Museum of Accidents». , La vitesse des signes., Collection Riflessi
          * 2014, Da Contingência
          * 2008, "Reciprocidade e Reprodutibilidade na Gravura e na Abjecção" in , "Ensayos sobre Reprodutibilidade; Ensaios sobre Reprodutibilidade", Editorial Universidad de Granada

        Tradução

          * 2019, (translation to portuguese:) So-called Nature: Friedrich Kittler and Ecological Media Materialism by Jussi Parika / A Assim chamada Natureza: Friedrich Kittler e o Materialismo dos Media Ecológicos) de Jussi Parika, Orfeu Negro

        Recurso online

          * 2021-03, DEPOIMENTOS DE ARTISTAS. Testemunho da artista Catarina Patrício, para o MNAC, sobre o seu processo criativo., https://www.youtube.com/watch?v=yuL6UwG-1ns&t=35s
          * 2014-12, Entrevista a Giuliana Bruno, https://www.ulusofona.pt/lessons/giuliana-bruno
          * 2013, Entrevista a Pascal Chabot, por Catarina Patrício para a Interact , http://interact.com.pt/20/entrevista-a-pascal-chabot/

        Artigo em conferência

          * “Étant donnés: 1º la chute d’eau. 2º le gaz d’éclairage vs. L’Origine du monde”, 3º ciclo de conferências de Ciências de Arte: Arte e Eros
          * Visual Deterrence: On Paul Virilio and the Information War, “Communication and Citizenship: Rethinking Crisis and Change”, International Association for Media and Communication Research (IAMCR),
          * Post-industrial landscapes: smart cities as rhetorical territory / Paisagens pós-industriais: a cidade inteligente como território retórico, 1º Congresso Ibérico de semiótica
          * Genealogia da percepção e a fabricação do sogenannte Mensh., Colóquio Tecnologias Culturais e Artes dos Media, In Memoriam Friedrich Kittler
          * Da Guerra: desafios de uma investigação em cultura contemporânea e novas tecnologias, I Jornada de Doutorandos em Ciências da Comunicação e Estudos Culturais
          * Carl Schmitt e Filoficções Cosmopolíticas, X Congresso Lusocom
          * A abjecção e o informe em Francis Bacon, 2º Ciclo de Conferências de Ciências de Arte: Arte e Abstracção, Faculdade de Belas-Artes da Universidade de Lisboa.
          * A Técnica como Libertação Originária: ou da ferramenta enquanto invenção do humano, Colóquio Movimento e Mobilização Técnica
          * 2019, Paisagens pós-industriais ; a cidade inteligente como território retórico
          * 2018-04-26, Cities and Screens: Architecture and information in the age of transductive reproduction, 5th International Academic Conference on Places and Technologies
          * 2015, Does the human brain really like ICT tools and being outdoors? A brief overview of the cognitive neuroscience perspective of the cyberparks concept (TU 1306)
          * 2015, Cyberparks and Geoaesthetics: Reading Modern Technology after Nietzsche, ICiTy: Enhancing places through technology.

        Prefácio / Posfácio

          * 2023, Casas Regionais em Lisboa: Lugares de Cultura Popular Tradicional Portuguesa

        Exposição artística

          * 2023-11-16, Balada do Condado Laranja / Orange County Ballad - Exposição Individual no Museu Nacional de Arte Contemporânea, http://www.museuartecontemporanea.gov.pt/pt/programacao/2090
          * 2023-04-01, Descuradas, obras da coleção Norlinda e José Lima, curadoria Sara e André
          * 2022-09-15, exposição individual "Out of the Blast"
          * 2021-01-12, Promenade. A virtual walk through the realm of drawing, https://drawingroom.store/on-show/
          * 2020-10-14, Drawing Room 2020 https://drawingroom.pt/
          * 2020, Exposição colectiva 12º Prémio Amadeo de Souza-Cardoso,, Museu Municipal Amadeo de Souza-Cardoso
          * 2018-05-17, Para além do zero e do um
          * 2015, Two days before the day after tomorrow
          * 2015, Caught in the Act: the (literary) imagiconography of Paula Rego, Curadoria Emília Ferreira
          * 2013, 9º Prémio Amadeo de Souza Cardoso
          * 2012, Uma Paisagem de Acontecimentos, Livraria Sá da Costa(Lisboa)
          * 2012, A Ciência do Desenho, Casa da Cerca(Almada)
          * 2010, Cabinet d’amateur, Sala do Veado, Museu de História Natural(Lisboa)
          * 2009, Pavilhão de Portugal, HangART-7, Salzburg, HangART-7(Salzburg)
          * 2008, all work and no play, Plataforma Revólver(Lisboa)
          * 2008, V éme Biennale Méditerranéenne
          * 2008, UP COMING SHOW
          * 2008, Ouvertures d’ateliers d’artistes, 11e édition
          * 2008, DROMOPOLIS, Largo do Camões(Lisboa)
          * 2008, “Gravura Contemporânea FBAUL 1999-07”, , Sala do Veado, Museu de História Natural, 2008;(Lisboa)
          * 2006, DruckArt, Kulturhus De Bijenkorf(Borne)
          * 2006, DruckArt, Galeria Kaire Desine, Vilnius, 2006;(Vilnius)
          * 2005, DruckArt
          * 2004, Exposição do prémio Celpa/Vieira da Silva, Museu Arpad Szenes Vieira da Silva(Lisboa)
          * 2002, Mostra Nacional Jovens Criadores 01
          * 2001, Mostra Nacional Jovens Criadores 00

        Arte visual

          * uma paisagem de acontecimentos
          * The night I killed Tommy
          * Selotemachinas
          * DROMOPOLIS

        Outra produção

          * 2019-02, Co-directora da INTERACT – Revista Online de Arte, Cultura e Tecnologia entre fevereiro 2019 e Dezembro de 2020., A Interact é uma publicação digital editada pelo Centro de Estudos de Comunicação e Linguagens (CECL), atualmente integrado no pólo FCSH do ICNOVA: Centro de Investigação em Comunicação, Informação e Cultura Digital.

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona