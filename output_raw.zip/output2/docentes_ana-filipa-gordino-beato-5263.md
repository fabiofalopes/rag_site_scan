# Response for https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
          PT: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263 EN: https://www.ulusofona.pt/en/teachers/ana-filipa-gordino-beato-5263
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
        fechar menu : https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-filipa-gordino-beato-5263
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ana Beato

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5263
              ana***@ulusofona.pt
              C518-5DEE-0166: https://www.cienciavitae.pt/C518-5DEE-0166
              0000-0003-3177-3578: https://orcid.org/0000-0003-3177-3578
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/7d930921-0d9c-4523-9bee-87019cc213f8
      : https://www.ulusofona.pt/

        Resume

        Ana Beato has concluded her PhD in Clinical Psychology at the Faculty of Psychology, University of Lisbon, with a thesis entitled "Parenting Styles, beliefs and Strategies in Parents of Children with Anxiety Disorders". She completed her master's degree in psychology in Stress and Well-being at the same institution. She concluded her graduation in Clinical Psychology, cognitive-behavioral approach in 2004 (Faculty of Psychology and Educational Sciences, University of Coimbra). She is an Assistant Professor at the School of Psychology and Life Sciences at Universidade Lusófona. She is also a member of the coordination of the master in sexology and a researcher at the HEI-Lab - Digital Human-Environment Interaction Lab and her main research interests are related to anxiety, parenting, sexuality, neurodevelopment, third-wave CBT therapies, and new technologies and applications adapted to psychology.

        Graus

            * Pós-Graduação
              Clinical sexology
            * Licenciatura
              Psychology
            * Mestrado
              Psychology
            * Doutoramento
              Psychology
            * Diploma de especialização
              Especialidade avançada em sexologia clínica / Advanced speciality in clinical sexology
            * Diploma de especialização
              Especialista em psicologia clínica e da saúde / Certificated specialist in clinical psychology and health
            * Outros
              Mindful Self-Compassion
            * Outros
              Third-wave therapies with children and adolescents / Curso de Terapias de 3ª Geração com Crianças e Adolescentes
            * Outros
              Focused CBT for Obsessional Problems
            * Outros
              Treating Trauma with ACT. Revitalizing Interrupted Lives
            * Outros
              The Compassion Focused Therapy approach to deal with shame-based difficulties in sexual minorities
            * Outros
              Dialetical Behavior Therapy (DBT): Assessment and intervention
            * Outros
              Pedagogical Innovation in Higher Education: Practices, challenges and evidence (Inovação Pedagógica no Ensino Superior: Práticas, desafios e evidências)
            * Outros
              Pedagogical Innovation in Higher Education - Contributions of Applied Research to Distance Learning
            * Outros
              Introduction to portable psychophysiological recording in a laboratory context (Introdução ao registo psicofisiológico portátil em contexto laboratorial)
            * Outros
              Conceção de Unidades Curriculares focada nos objetivos de aprendizagem/ Design of Curricular Units focused on learning objectives
            * Outros
              Metacognitive Interpersonal Therapy
            * Outros
              Autism on the line!
            * Outros
              Output Data Management
            * Outros
              Designing and Conducting a Meta-analysis (8h)
            * Outros
              Teams | EPCV | DOCENTES
            * Outros
              ERC grants: from a Starting Grant (TREND) to a Proof-of-Concept Grant (FLETRAD)
            * Outros
              O caminho para uma bolsa ERC: a pergunta de um milhão (e meio) de euros
            * Outros
              Boas práticas em Ciência
            * Outros
              DATA MANAGEMENT PLANS & ARGOS SYSTEM

        Publicações

        Journal article

          * 2024-03-25, Experiencing Intimate Relationships and Sexuality: A Qualitative Study with Autistic Adolescents and Adults, Sexuality and Disability
          * 2024-03-14, The impact of digital media on sexuality: a descriptive and qualitative study, International Journal of Impotence Research
          * 2024-03, Profiling parent's responses to children's anxiety: A qualitative study combined with multiple correspondence and cluster analyses, Journal of child and family studies
          * 2024, Protecting mothers against posttraumatic stress symptoms related to childbirth: Whats the role of formal and informal support?
          * 2023-10-24, Psychometric properties of the European Portuguese version of the modified perinatal PTSD questionnaire (PPQ-II), Current Psychology
          * 2022-12-30, Revista Portuguesa de Educação, 35(2), 378-401. http://doi.org/10.21814/rpe.25008Implementação do RESCUR com crianças e adolescentes surdos: Perceção de professores, pais e alunos sobre o impacto ao nível do bem-estar e das aprendizagens, Revista Portuguesa de Educação
          * 2022-05-26, Do Maternal Self-Criticism and Symptoms of Postpartum Depression and Anxiety Mediate the Effect of History of Depression and Anxiety Symptoms on Mother-Infant Bonding? Parallel–Serial Mediation Models, Frontiers in Psychology
          * 2021-02-19, “Everything Is Gonna Be Alright with Me”: The Role of Self-Compassion, Affect, and Coping in Negative Emotional Symptoms during Coronavirus Quarantine, International Journal of Environmental Research and Public Health
          * 2021-02, The Impact of COVID-19 on Sexual Health: A Preliminary Framework Based on a Qualitative Study With Clinical Sexologists, Sexual Medicine
          * 2021, The Impact of COVID-19 on Sexual Health: A Preliminary Framework Based on a Qualitative Study With Clinical Sexologists
          * 2018-09, Father's and mother's beliefs about children's anxiety, Child: Care, Health and Development
          * 2018, Father's and mother's beliefs about children's anxiety
          * 2017-05, The Sexology Clinic at the faculty of Psychology of the University of Lisbon, The Journal of Sexual Medicine
          * 2017, Parenting Strategies to Deal with Children’s Anxiety: Do Parents Do What They Say They Do?, Child Psychiatry and Human Development
          * 2016, Parenting Strategies to Deal with Children’s Anxiety: Do Parents Do What They Say They Do?
          * 2015-12-18, Sexology in Portugal: Narratives by Portuguese Sexologists, The Journal of Sex Research
          * 2015-11-28, The Relationship Between Different Parenting Typologies in Fathers and Mothers and Children’s Anxiety, Journal of Child and Family Studies
          * 2015, The relationship between different parenting typologies in fathers and mothers and children’s anxiety
          * 2015, Sexology in Portugal : narratives by portuguese sexologists
          * 2013, Parental anxiety and overprotection scale: A psychometric study with a sample of parents of school age-children,Escala de avaliação da ansiedade e superprotecção parentais: estudo psicométrico numa amostra de pais e mães de crianças em idade escolar, Revista Iberoamericana de Diagnostico y Evaluacion Psicologica
          * 2013, Parental anxiety and overprotection scale: A psychometric study with a sample of parents of school age-children, Revista Iberoamericana de Diagnóstico Y Evaluación - E Avaliação Psicológica
          * 2013, Escala de avaliação da ansiedade e superprotecção parentais: estudo psicométrico numa amostra de pais e mães de crianças em idade escolar.
          * 2013, Escala de avaliação da ansiedade e superprotecção parentais: estudo psicométrico numa amostra de pais e mães de crianças em idade escolar
          * 2007-01, PP-06General Issues in Sexual Medicine, The Journal of Sexual Medicine

        Thesis / Dissertation

          * 2022, Master, Relações amorosas e íntimas em adolescentes e adultos com perturbação do espetro do autismo
          * 2021, Master, The blame game : exploring portuguese gamers’ perceptions and experiences regarding sexism in video games
          * 2018, Master, Respostas emocionais e comportamentais do pai à ansiedade dos filhos
          * 2018, Master, Respostas emocionais e comportamentais do pai à ansiedade dos filhos
          * 2018, Master, Respostas cognitivas e emocionais dos pais face à ansiedade dos filhos
          * 2018, Master, Respostas cognitivas e emocionais dos pais face à ansiedade dos filhos
          * 2018, Master, Preocupações parentais e preocupações de crianças com perturbação de ansiedade generalizada
          * 2018, Master, Preocupações parentais e preocupações de crianças com perturbação de ansiedade generalizada
          * 2018, Master, Preocupações parentais e preocupações de crianças com perturbação de ansiedade generalizada
          * 2018, Master, Preocupações parentais e preocupações de crianças com perturbação de ansiedade generalizada
          * 2018, Master, Perceção parental das vulnerabilidades e potencialidades das crianças com perturbação de ansiedade
          * 2018, Master, Perceção parental das vulnerabilidades e potencialidades das crianças com perturbação de ansiedade
          * 2018, Master, Cognições e emoções parentais a partir de um cenário ambíguo em pais de crianças com ansiedade social
          * 2016, PhD, Estilos, estratégias e crenças de pais e mães e ansiedade infantil : o pai é importante?
          * 2009, Master, Características morfo-anatómicas de cultivares tintas de videira (Vitis vinifera)
          * 2008, Master, "Adolescer" entre relações : parentalidade, amizade e amorosidade : que contributos na transição para a idade adulta?
          * 2008, Master, "Adolescer" entre relações : parentalidade, amizade e amorosidade : que contributos na transição para a idade adulta?

        Book chapter

          * 2023, Desenvolvimento Psicossexual (Psychossexual Development), Intervenção Psicológica em Sexologia Clínica, 1, 1, PACTOR
          * 2022, USING ACCEPTANCE AND COMMITMENT THERAPY WITH A PATIENT WITH PANIC DISORDER AND PHYSICAL HEALTH CONDITIONS, Advances in Clinical Psychology, 2, 1, Dykinson
          * 2021, Caring for Myself - Self-Compassion, Coping and Emotional Symptoms during the 1st wave of COVID-19 in Portugal, Prime Archives in Public Health, Vide Leaf

        Conference paper

          * Understanding male (con)tradi(c)tions through an in-depth interview study
          * The Sexology Clinic at the Faculty of Psychology of the University of Lisbon
          * Sexual sensation-seeking, hypersexuality, and risky sexual behaviors between adults with and without ADHD symptoms
          * Relational and sexual satisfaction during military deployment: a comparative study
          * Relational and sexual satisfaction during military deployment : a comparative study
          * Is it a man´s world? Exploring Portuguese female gamer's perception's and experience regarding sexism in the gaming
          * Busca de sensações sexuais, hipersexualidade e comportamentos de risco sexuais em adultos com e sem sintomas de PHDA

        Conference poster

          * 2023-11-11, Improve social skills in children with autism spectrum disorder, Cypsy : 26th Annual Cyberpsychology, Cybertherapy and Social Networking Conference
          * 2023-09-23, O que são direitos sexuais? Análise temática das definições e perceções de adultos Portugueses (What are sexual rights? Thematic analysis of the definitions and perceptions of Portuguese adults), Encontro Nacional da Sociedade Portuguesa de Sexologia Clínica
          * 2023-03-30, Medical support during pregnancy and mother-infant bonding: A serial multiple mediation model of satisfaction with childbirth and postpartum posttraumatic stress symptoms , IV International Congress of CINEICC
          * 2022-10, The mediating role of perinatal trauma in the association between negative perception of childbirth and maternal stress during COVID-19 pandemic, VIII Encontro Ser Bebé
          * 2018-04-13, Respostas cognitivas e emocionais dos pais à ansiedade dos filhos
          * 2018-04-13, Que crenças têm os pais sobre as crianças com Fobia Específica, I Simpósio de Ansiedade do PIN
          * 2018-04-13, Preocupações parentais e preocupações em crianças com PAG, I Simpósio de Ansiedade do PIN
          * 2017-11-16, Perceção parental de vulnerabilidade em crianças com perturbação de ansiedade, X Congreso Internacional e XV Nacional de Psicologia Clínica
          * 2017-11-16, Consistência interparental em relação às estratégias dos pais para lidar com a ansiedade de crianças ansiosas, X Congreso Internacional e XV Nacional de Psicologia Clínica
          * 2017-11-16, Caracterização dos principais receios de crianças com perturbação de ansiedade social, X Congreso Internacional e XV Nacional de Psicologia Clínica
          * 2017-04-03, É uma criança sensível: Crenças parentais acerca das crianças com perturbação de ansiedade generalizada, Jornadas de Psicologia Clínica e da Saúde da ULHT
          * 2017-04-03, Perceção parental das estratégias usadas pela criança para lidar com a ansiedade social, Jornadas de Psicologia Clínica do CHPL: Psicologia e suas Convergências na Saúde Mental
          * 2017-04-03, Acordo interparental relativamente às estratégias usadas para lidar com a ansiedade de crianças com perturbações de ansiedade, Jornadas de Psicologia Clínica e da Saúde da ULHT
          * 2017-03, Estratégias parentais para lidar com a ansiedade de crianças ansiosas: perspectiva do/a parceiro/a, Jornadas de Psicologia Clínica do CHPL: Psicologia e suas Convergências na Saúde Mental
          * 2015-03, Contingent relations between parental behavior and child’s anxiety in interactions of anxious and non-anxious children with their parents, International Convention of Psychological Science
          * 2014-09, A sequential analysis of parent-child interactions: Differences between anxious and non-anxious children, 44th Annual Congress of European Association for Behavioural and Cognitive Therapies
          * 2013-09, Anxiety runs in families? Exploring parental typologies in families of children with anxiety symptoms, 43rd Annual Congress of European Behavioural and Cognitive Therapies
          * 2012-09, Exploring gender and class inequalities in the bedroom: women’s perceptions of their sexuality through an in-depth interview study, 11th Congress of European Federation of Sexology (EFS)
          * 2012-09, Dialogues about sexual (dys)Function: Exploring sexual (con)tradi(c)tions in the primary health care setting through an in-depth interview study, 11th Congress of European Federation of Sexology (EFS)
          * 2012-07, Towards defining sexologists as a professional group: The MAPS study – Mapping sexology as a profession in Portugal, 38 Annual Meeting of International Academy of Sex Research (IASR)
          * 2012-07, Exploring Sexual (Con)Tradi(c)tions in the Primary Healthcare Setting through an In-depth Interview Study, Annual Meeting of the International Academy of Sex Research.
          * 2007-12, Body image and Sexuality in Individuals self-presented with and without Sexual Difficulties, 9º Congresso da Sociedade Europeia de Medicina Sexual
          * 2007-05, Insatisfação corporal em sujeitos de ambos os sexos: estudo comparativo, I Jornadas de Psicologia Clínica da UTAD
          * 2007-03, Imagem corporal e distracção cognitiva durante a actividade sexual, II Jornadas de Psicologia Clínica e Saúde Mental do Hospital Júlio de Matos
          * 2006-12, Body image and sexuality: comparative study, 9º Congresso da Sociedade Europeia de Medicina Sexual

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona