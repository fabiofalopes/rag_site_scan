# Response for https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
          PT: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477 EN: https://www.ulusofona.pt/en/teachers/elisabete-cristina-nogueira-magalhaes-5477
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
        fechar menu : https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/elisabete-cristina-nogueira-magalhaes-5477
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Elisabete Cristina Nogueira Magalhães

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5477
              eli***@gmail.com
              3710-35F9-C9A1: https://www.cienciavitae.pt/3710-35F9-C9A1
      : https://www.ulusofona.pt/

        Graus

            * Ensino secundário
              Escola profissional de dança e teatro
            * Licenciatura
              Cinema e Audiovisual
            * Mestrado
              Mestrado em Artes Cénicas
            * Pós-Graduação
              Pós-Graduação em Dança Contemporânea
            * Outros
              Curso de Programação Neurolinguística
            * Licenciatura
              Dança

        Publicações

        Tese / Dissertação

          * 2018, Mestrado, Grau zero, um corpo que espera

        Obra teatral

          * 2021-05-20, Espetros , Teatro Nacional São João. Encenação: Nuno Cardoso, Teatro Carlos Alberto (TECA), Porto
          * 2020-11-17, O Balcão, Teatro Nacional São João, Encenação: Nuno Cardoso, Teatro Nacional são João, Porto
          * 2020-03-05, Castro, Teatro Nacional São João, Encenação: Nuno Cardoso, Teatro Aveirense, Aveiro, Portugal
          * 2019-09-18, A Morte de Danton, Teatro Nacional São João, Porto, Portugal, encenação: Nuno Cardoso, Teatro Nacional São João, Porto, Portugal

        Gravação vídeo

          * 2012-06-12, So Far, Co-produção TNSJ, Festival da Fábrica MAP
          * 2010-10-13, Olhos caídos, Elisabete Magalhães e Tãnia Carvalho
          * 2010-06-10, Dança e Arte Digital, Elisabete Magalhães
          * 2009-09-10, Imago, Companhia Instável, Porto (Portugal)
          * 2008-05-04, Passagens, Elisabete Magalhães, Festival frame

        Coreografia

          * 2022-06-27, A Imprevisibilidade das Coisas, Elisabete Magalhães , Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2021-06-19, Sopro, Elisabete Magalhães , Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2020-09-28, Quando se Dança Diz-se a Verdade, Elisabete Magalhães , Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2020-03-07, Flores de Inverno, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2019-09-25, Variações sobre um corpo, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2018-09-27, A simplicidade de um gesto, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2018-06-27, Exaustão, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2018-06-01, Grau zero, um corpo que espera, Elisabete Magalhães, Magalhães, Elisabete (3710-35F9-C9A1) / Teatro Nacional São João, Porto Portugal
          * 2018-03-10, Com sequência, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2017-12-18, Silence is sexy, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2016-06-27, Beautiful ones, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2016-06-04, Coletivo, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2015-09-26, Contos, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2013-05-05, As palavras dançam?, Elisabete Magalhães, Produção do Teatro Campo Alegre, Serviço Educativo, Porto
          * 2013, Aquilo que vês, não é aquilo que sinto, Elisabete Magalhães, Magalhães, Elisabete (3710-35F9-C9A1)
          * 2009-07-13, Living Dead Girl, Elisabete Magalhães, Magalhães, Elisabete (3710-35F9-C9A1) / Quintas de Leitura - Teatro Campo Alegre, Porto Portugal
          * 2007-07-20, Metamorfose, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Serviço Educativo
          * 2007-07-05, Encontros Reperages, Danse à Lille, Elisabete Magalhães, Danse à Lille
          * 2006-09-08, Auto retrato, Elisabete Magalhães, Festival de Artes Performativas de Vila de Conde, Vila do Conde (Portugal)
          * 2006-06-18, Girls, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Serviço eduvativo
          * 2004-07-21, Meu nome é ninguém, Elisabete Magalhães, Festival da Fábrica, Porto, Portugal
          * 2002-06-27, ADN, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Serviço Educativo
          * 2002-03-03, Encontros reparage, Elisabete Magalhães, Danse à Lille
          * 2001-09-17, Fachada, Elisabete Magalhães, Balleteatro Contemporâneo do Porto- Escola Profissional
          * 2001-05-10, Idade Interdita, Elisabete Magalhães, Teatro Nacional são João
          * 1999-09-12, Pintura animada, Elisabete Magalhães, Núcleo de Experimentação coreográfiaca (NEC), Porto, Portugal

        Interpretação artística

          * 2022-11-20, Pó de Isabel Barros, Teatro Nacional São João, Porto, Portugal
          * 2018-11-16, Revoluções, Né barros., Rivoli, Porto, Portugal/ Convento São Francisco, Coimbra, Portugal
          * 2017-04-27, Muros, Né Barros., Teatro Nacional São João, Porto, Portugal/ CCB, Lisboa, Portugal
          * 2016-09-30, Uníssono, Victor Hugo Pontes, Teatro São Luís, Lisboa, Portugal/ Teatro Rivoli, Porto, Portugal/ Teatro Aveirense, Aveiro,Portugal
          * 2015-10-29, Lastro, Né Barros., Rivoli, Porto, Portugal/ Culturgest, Lisboa, Portugal
          * 2014-04-29, Million, Né Barros., Teatro Municipal do Porto, Rivoli, Portugal
          * 2012-02-09, Ballet Story, Victor Hugo Pontes., Centro Cultural Vila Flor, Guimarães, Portugal/ Culturgest, Lisboa, Portugal...
          * 2009-01-24, Manual de instruções, Victor Hugo Pontes, Centro Cultural Vila Flor, Guimarães, Portugal
          * 2009, Well Done, Patricia Milheiro, Balleteatro Auditório, Porto, Portugal
          * 2008-10-15, Blanche-Neige, de Catherine Baÿ, Intervenções performativas e site-specific na cidade Porto, Portugal
          * 2007-06-06, Alugo-me para sonhar, Isabel Barros, CCB, Lisboa, Portugal
          * 2006-07-15, Orquestica, Tânia Carvalho, Culturgest, Lisboa, Portugal
          * 2005-10-25, Dia Maior, Né Barros, Teatro Carlos Alberto, Porto, Portugal
          * 2005-10-24, Solistas, Né Barros, Teatro rivoli, Porto, Portugal
          * 2005-09-10, 100 palavras, Victor Hugo Pontes, Teatro rivoli, Porto, Portugal
          * 2005-06-03, Sursauts de Mathilde Monnier, Auditório de Serralves, Porto, Portugal
          * 2004-10-12, 40 Espontâneos de La Ribot, Teatro Carlos Albert, Porto, Portugal
          * 2003-06-06, Wade in the water, Javier de Frutos, Companhia Instável, Teatro Municipal do Porto, Rivoli, Portugal/ CCB , Lisboa, Portugal/ teatro Viriato, Viseu, Portugal
          * 2002-10-24, Lá ou je dors, Isabel Barros, Teatro rivoli, Porto, Portugal
          * 2002-03-09, Nº 5, Né Barros, CCB, Lisboa, Portugal
          * 2001-12-16, Quarto Escuro, Isabel barros, Teatro Helena Sá e Costa, Porto, Portugal
          * 2001-04-29, Delete, Isabel barros, Balleteatro Auditório, Porto, Portugal
          * 2001-03-05, EXO, Né Barros, Auditório Fundação Calouste Gulbenkian, Lisboa, Portugal
          * 2000-10-20, No Fly Zone, Né Barros, Teatro Nacional São João, Porto, Portugal
          * 2000-07-18, Ballet Neoconcreto, , Auditório de Serralves, Porto, Portugal
          * 1999-10-25, Vooum, Né barros, Teatro Nacional São João, Porto, Portugal
          * 1998-06-22, Acidente de Automóvel Cor de Laranja 10X, Isabel Barros, Expo 98 - Festival do mergulho, Lisboa, Portugal / Balleteatro Auditório, Porto, Portugal
          * 1998-05-03, As lições, encenação : Ricardo Pais, Teatro Nacional São João, Porto, Portugal/ CCB, Lisboa, Portugal
          * 1997-10-22, In Limine, Né Barros, CCB, Lisboa, Portugal / Balleteatro Auditório, Porto, Portugal
          * 1997-03-27, Screen 24 Fracturas Expostas, Isabel Barros, Balleteatro Auditório, Porto, Portugal
          * 1996-07-24, L.M.(Lady Macbeth), Né Barros, Teatro Nacional São João, Porto, Portugal
          * 1995-04-29, Perigo de Explosão, Isabel Barros, Balleteatro Auditório, Porto, Portugal
          * 1993-06-25, Os vestidos que eu lhe emprestei já não são meus, Isabel Barros, Mosteiro São bento da Vitória, Porto, Portugal
          * 1993-06-23, Do Princípio Ao Fim, Né Barros, Mosteiro São bento da Vitória, Porto, Portugal
          * 1992-10-25, Sobressaltos In- De -Gestos, Isabel Barros, Teatro rivoli, Porto, Portugal
          * 1992-02-25, See How The Wind Blows, Né Barros, Teatro rivoli, Porto, Portugal

        Registo de direitos de autor

          * So far, Elisabete Magalhães

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona