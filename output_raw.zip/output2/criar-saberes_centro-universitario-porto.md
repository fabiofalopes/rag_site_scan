# Response for https://www.ulusofona.pt/criar-saberes/centro-universitario-porto

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
          PT: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto EN: https://www.ulusofona.pt/en/building-knowledge/porto-university-center
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
        fechar menu : https://www.ulusofona.pt/criar-saberes/centro-universitario-porto

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes
          Criar Saberes
        https://www.ulusofona.pt/images/criar-saberes_600.jpg

            Criar Saberes (Porto)

          Criar Saberes
        : https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
      ConteúdoNavegação

          O projeto “Criar Saberes” iniciou há mais de 20 anos e a sua evolução e reconhecimento resulta da integração de diferentes áreas científicas do ensino secundário e da sua constante adequação aos programas curriculares e à inovação das atividades a realizar.

          Está direcionado para os alunos do 10º, 11º e 12º anos, em diferentes áreas científicas do ensino secundário e coloca ao dispor dos alunos uma série de atividades práticas nas áreas da Química, Biotecnologia, Ambiente, Genética, Medicina e Gestão.

          O projeto conta com a colaboração da Faculdade de Engenharia e da Escola de Psicologia e Ciências da Vida da Universidade Lusófona e ainda com a colaboração da Escola Superior de Saúde Ribeiro Sanches, que organizam atividades de cariz laboratorial, em diferentes áreas do saber.

          As sessões têm a duração de duas horas por cada grupo de 15 alunos, totalizando quatro horas para uma turma com um máximo de 30 alunos.

          Qualidade do ar interior - Risco Biológico para os humanos

          Professora Responsáveis - Professoras Doutoras Cândida Manuel e Kalina Samardjieva

          Descrição: Sabias que a principal fonte poluente do ar interior são os humanos? Esta aƟvidade é deveras importante para os estudantes uma vez que passam a maior parte do seu tempo na escola ou em casa, sendo por isso muito importante conhecerem os parâmetros da qualidade do ar interior, os principais poluentes e quais as boas práƟcas a adotar

            * Atividades: Será feita uma breve apresentação sobre a qualidade do ar interior, seguida da recolha de amostras de ar para determinação das bactérias, fungos numa sala e no ambiente exterior. Também serão medidas as partículas inaláveis, temperatura, humidade relativa e concentração de CO2.

          Desenvolvimento Embrionário do Ouriço-do-Mar: A Fertilização e os Primeiros Ciclos Celulares

          Professora Responsável: Professora Doutora Kalina Samardjieva

          Descrição: Os alunos poderão observar e praticar eles próprios o método de recolha de ovos e espermatozoides no ouriço-do-mar e observar depois as suas colheitas ao microscópio, numa simples gota de água, com o material vivo. Seguidamente, irão ver diretamente ao microscópio o fenómeno da fertilização, em que se seguirão os seguintes passos:

            * a. Reconhecimento de óvulos não fertizados;
            * b. Adição de uma goticula de sémen à água do mar contendo esses ovos;
            * c. Observação da chegada dos espermatozoides à área da gota onde se encontram os ovos;
            * d. Reconhecimento da ligação do espermatozoide à membrana plasmática do ovo;
            * e. Observação da formação da membrana de fertilização em torno do ovo fertilizado e estimativa do tempo decorrido entre o passo anterior e este.

          Os alunos irão também observar diversos estádios de desenvolvimento embrionário resultantes de previamente ovos fertilizados que ilustraram os seguintes passos:

            * a. Formação da mórula;
            * b. Cavitação da mórula;
            * c. Formação da blástula;
            * d. Início da invaginação do arquêntero;
            * e. Formação da gástrula;
            * f. Início do movimento independente da blástula;
            * g. Finalização da formação do arquêntero;
            * h. Formação da larva pluteus.

          Desenvolvimento Embrionário no Pinto: A Organização Básica dos Vertebrados

          Professora Responsável: Professora Doutora Kalina Samardjieva

          Descrição: Os alunos assistirão à abertura de ovos fertilizados de galinha em diferentes fases de desenvolvimento, observando o método de isolamento do embrião a partir da gema do ovo. As imagens destes embriões vivos, depois de dispostos em caixas de Petri para melhor visualização, serão projetadas num monitor de alta resolução, de forma a todos os presentes poderem distinguir os seguintes fenómenos:

            * a. Diferenciação do coração;
            * b. Início do batimento cardíaco;
            * c. Sistema de circulação do sangue através das membranas circundantes;
            * d. Início do desenvolvimento cerebral;
            * e. Diferenciação e crescimento dos três compartimentos do encéfalo embrionário;
            * f. Início e desenvolvimento da segmentação da mesoderme em somitos.

          Campos eletromagnéticos

          Professora Responsável: Professora Doutora Cândida Manuel

          Descrição: Os campos eletromagnéticos são utilizados praticamente a cada instante pela humanidade e sem eles as condições de vida seriam bem diferentes. As forças magnéticas geradas nos campos eletromagnéticos estão presentes no modo de funcionamento de variadíssimos equipamentos utilizados como, nos micro-ondas, discos dos computadores, cartões bancários, telecomunicações, comboios super-rápidos, entre muitos outros. Aliás, sem o seu conhecimento e utilização, não seria possível a produção de energia elétrica longe das cidades, pois o seu transporte não seria exequível. Na área da Saúde, as técnicas de aquisição de imagem atuais como os aparelhos de raios X, de ressonância magnética e densitometria óssea funcionam com a aplicação dos campos eletromagnéticos. Esta atividade de demonstração experimental dos campos eletromagnéticos e as suas aplicações pode ser enquadrada nos diversos programas de ensino secundário da Física.

            * Atividades: A atividade proposta é composta por uma apresentação teórica em sistema multimédia seguida de uma demonstração experimental. A apresentação teórica inicial pretende ensinar/recordar os princípios teóricos necessários à compreensão desta atividade, na qual se focam os seguintes tópicos:
        * a. forças e linhas de fluxo em campos elétricos e campos magnéticos;
        * b. ação dos campos eletromagnéticos sobre partículas carregadas em movimento;
        * c. indução magnética, lei de Faraday e de Lenz;
        * d. circuitos magnéticos;
        * e. aplicações dos campos eletromagnéticos;
        * f. explicação do modo de funcionamento: comboios super-rápidos (Maglev), fornos de indução e transformadores elétricos.

          Após esta apresentação, será realizada uma demonstração experimental com a participação ativa dos alunos sobre a força magnética, as linhas de fluxo magnético, os circuitos magnéticos e as leis de indução de Faraday e de Lenz.

          Lançamento de projéteis e de foguetões

          Professora Responsável: Professora Doutora Cândida Manuel

          Descrição: Os alunos poderão aplicar na prática o que estudaram sobre os lançamentos horizontais e oblíquos na disciplina de Físico-Química. Também vão aprender porque voam os aviões e construir foguetões sustentáveis. Será que vai ser o teu o que voará mais longe?

          Atrito dinâmico e atrito estático

          Professora Responsável: Professora Doutora Cândida Manuel

          Descrição: Os alunos poderão aplicar na prática o que estudaram sobre o atrito dinâmico e estático na disciplina de Físico-Química. O atrito é a força de resistência ao movimento quando dois objetos em contacto se estão a movimentar um em relação ao outro. O atrito estático (ou atrito aderente) ocorre entre 2 objetos que não se movem um em relação ao outro ou que têm o mesmo movimento. É devido à força de atrito estático que um objeto não desliza num plano inclinado até uma dada inclinação. Quando se aplica uma força sobre um objeto e este não se desloca é porque esta força é inferior à força de atrito estático. À medida que se aumenta a força aplicada, a força de atrito estático vai aumentar contrabalançando o efeito da força e o objeto mantém-se imóvel. Atingindo-se a força de atrito estático máxima, se a força aplicada aumentar, o objeto inicia o movimento e o atrito será dinâmico.

          Fotossíntese – vamos criar submarinos vegetais!

          Professora Responsável: Professora Doutora Kalina Samardjieva

          Descrição: Nesta atividade os estudantes irão poder aplicar conceitos adquiridos nas aulas sobre o processo de fotossíntese. Os estudantes irão realizar um trabalho experimental em que vão avaliar a importância da disponibilidade de dióxido de carbono e luz para o processo de fotossíntese e para a produção de oxigénio molecular.

          Microbiologia do Ambiente – os microrganismos estão em toda a parte!

          Professora Responsável: Professora Doutora Kalina Samardjieva

          Descrição: Os microrganismos encontram-se no solo, na água, no ar e constituem o microbiota de animais e plantas. Os microrganismos têm papel essencial nos diferentes ecossistemas que habitam, como por exemplo, pela produção de oxigénio, a decomposição de matéria orgânica, as associações simbióticas com animais e plantas, entre outros. Nesta atividade os alunos terão a possibilidade de investigar sobre o mundo microbiano em que habitam. Esta atividade será iniciada com uma breve introdução aos conceitos teóricos que são necessários para a compreensão do trabalho prático, seguida da realização do mesmo. Serão fornecidas aos alunos placas de Petri contendo meio de cultura sólido e zaragatoas estéreis. Os alunos irão formar grupos de trabalho e determinar quais os compartimentos do ambiente que os rodeia pretendem amostrar. Irão preparar as placas e proceder à amostragem com o auxílio das zaragatoas. As placas serão incubadas e observadas numa segunda sessão na qual também serão observados microrganismos ao microscópio.

          Controlo do crescimento microbiano – quem lavou as mãos? Os antibióticos e muito mais!

          Professora Responsável: Professora Doutora Kalina Samardjieva

          Descrição: A presença e crescimento de microrganismos pode ser controlado por agentes químicos e Físicos como, por exemplo, os antisséticos, antibióticos, temperatura, radiação ultravioleta, entre muitos outros. Nesta atividade, que decorre ao longo de duas sessões, serão demonstrados os efeitos de vários métodos para o controlo do crescimento dos microrganismos, desde o uso do sabão para lavar as mãos, aos antibióticos e à radiação ultravioleta.

          Calendário

            * outubro a maio – Segundas, Quartas e Sextas-feiras.

          Horário:

          2 sessões diárias

            * 1.ª Sessão - 09h30 às 11h30
            * 2.ª Sessão - 11h30 às 13h30
              Criar Saberes: https://www.ulusofona.pt/criar-saberes
                Centro Universitário de Lisboa (CUL): https://www.ulusofona.pt/criar-saberes/centro-universitario-lisboa
                Centro Universitário do Porto (CUP): https://www.ulusofona.pt/criar-saberes/centro-universitario-porto
        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona