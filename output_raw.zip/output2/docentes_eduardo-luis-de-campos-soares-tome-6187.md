# Response for https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
          PT: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187 EN: https://www.ulusofona.pt/en/teachers/eduardo-luis-de-campos-soares-tome-6187
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
        fechar menu : https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/eduardo-luis-de-campos-soares-tome-6187
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Eduardo Luís De Campos Soares Tomé

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6187
              p61***@ulusofona.pt
              7910-9C6B-91CE: https://www.cienciavitae.pt/7910-9C6B-91CE
              0000-0001-6335-5501: https://orcid.org/0000-0001-6335-5501
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/1ff9e671-77a6-4e41-9670-7b989026467f
      : https://www.ulusofona.pt/

        Resume

        Eduardo Tome B Econ, M Econ, PhD is an active researcher and teacher in the domain of the economics of human resources. He also plays an important role in the network of research active European academics in his field of study. To date he has had 64 papers published in peer-reviewed journals which he has authored or co-authored and 115 papers in peer-reviewed conference proceedings. He has also authored 15 book chapters. He is a member of the Editorial Board of several peer-reviewed Journals. He has received several Honours, among two Prizes for Scientific Achievement. Eduardo Tome teaches a variety of subjects on both undergraduate and post graduate programmes. He is also active as a supervisor where he works with undergraduates, master students and PhD students. He is noted for his success with both masters and doctoral students. He also lectures on a PhD programme. He is equally comfortable teaching in both Portuguese and English. He can also speak, read and write in French and Spanish. Long before Covid-19 he used online platforms (emails, Moodle, Blackboard, Skype, etc) as a complementary form of communication with students and colleagues, a situation that has been made essential after the pandemic. Eduardo Tome has a significant presence among the academic community in general and especially those interested in intangibles. Since 2009, he has organized well-attended international conferences for his university on themes such as knowledge management, human resource development, and intellectual capital. With friends he created the TAKE Conference, which has been held every year since 2016., with the exception of 2020. The conferences enlarged the external focus and international relationships of his activities. All conferences resulted in spin-offs such as special issues of journals. These event have brought both prestige and financial rewards to the university . Currently he is a member of GOVCOPP of UnIversidade de Aveiro, Intrepid of UTAD and teaches at Univerisidade Lusofona.

        Graus

            * Doutoramento
              Economia
            * Mestrado
              Economia e Política Social
            * Licenciatura
              Economia

        Publicações

        Journal issue

          * Tomé E (2022) Special Issue "Sustainable Development and Knowledge Economy" Sustainability
          * Special Issues - Journal of European Industrial Training Volume 35 Issue 6. Pp 524-622
          * Special Issue on ECKM 2019
          * Special Issue - Sustainable Development and Knowledge Economy
          * Special Issue - Electronic Journal of Knowledge Management Volume 9 Issue 1 ECKM
          * Special Issue "Socio-Economic Burden of Disease: The COVID-19
          * Tomé E. (2014) International Journal of Knowledge Based Development, volume 5, number 1. pgs 5-115.

        Journal article

          * 2023, "Integrative model of the leader competences",, European Journal of Training and Development,
          * 2022, Knowledge Management and COVID-19: Technology, People and Processes" Special Issue Covid-19 - , Knowledge and Process Management
          * 2022, "Knowledge Management Practices and Benefits, Agile Economy and the use of foreing languages - A theoretical analysis illustrated with the cases of Russia and Portugal –, Knowledge and Processs Management Volume29, Issue2 April/June 2022 Pages 176-184
          * 2022, Agile Manufacturing, Collaboration and Knowledge Creation: ¿ pilot study from Russia, - Academy of Strategic Management Journal (Print ISSN: 1544-1458; Online ISSN: 1939-6104)
          * 2021-03, Development of Emergent Knowledge Strategies and New Dynamic Capabilities for Business Education
          * 2021, Types of labour contract and its importance on commitment and engagement: A case study., , Journal of Knowledge Management Application and Practice
          * 2020, Editorial for EJKM volume 18 issue 2, Electronic Journal of Knowledge Management
          * 2020, Did the Bubble Burst? The Portuguese Economy during COVID-19, Management and Marketing
          * 2020, Current and historical application of knowledge management in economy, Emerging Science Journal
          * 2020, Actors in the Knowledge Economy, Managing Dynamics in the Knowledge Economy
          * 2019, Will robots have the capacity to replace Mankind? Survey from Portugal
          * 2019, Why Knowledge Management Fails , Journal of Knowledge Management Application and Practice
          * 2019, The European social fund in the Visegrad countries in the 2007-2013 programming phase, European Journal of Training and Development
          * 2019, Perspective paper: Intellectual capital, knowledge management, politics and billionaires, International Journal of Knowledge-Based Development
          * 2019, India and Portugal on Human Resources Development – A Fruitful Comparison Related to Context, Operations and Outcomes, Business Insight, Journal of the Department of Commerce, The University of Burdwan, India
          * 2019, Human Resource Development in SMEs. within the European Social Fund in Poland, Research findings and international perspective. Management Sciences / Nauki o Zarzadzaniu
          * 2018-09, Special Issue on TAKE 2016 Conference, Aveiro – Theory and Applications in the Knowledge Economy, International Journal of Knowledge Based Development
          * 2018, Knowledge Management in the BRICS , Management Dynamics in the Knowledge Economy
          * 2018, Introduction – Special Issue on Theory and Applications on the Knowledge Economy, International Journal of Knowledge Based Development
          * 2017, The role of billionaires in the economic paradigm of the 21st century. Managing Dynamics in the Knowledge Economy , MDKE
          * 2017, KNOWLEDGE MANAGEMENT AND LEADERSHIP – THE CARBON EMISSIONS SCANDAL IN THE AUTOMOBILE INDUSTRY , Challenges for international business in Central and Eastern Europe Przedsiebiorczosc Miedzynarodowa
          * 2015-10, Thomas Piketty’s Capital in the 21st century – an Intellectual Capital Perspective, EJKM
          * 2015, The Bologna Process in Portugal and Poland: A comparative study , Gestão e Sociedade
          * 2015, Look for people, not for alpha: mutual funds success and managers intellectual capital, Measuring Business Excellence
          * 2015, Knowledge Management and Politics at the Highest Level: An Exploratory Analysis , Management Dynamics in the Knowledge Economy
          * 2015, Human capital, HRD and VET: the case of India, European Journal of Training and Development
          * 2014, The role of HRD and VET in the emerging economy of India , ‘Business Insight’, Departmental Journal of The Department of Commerce, The University of Burdwan
          * 2014, The Potential for Regional Intellectual Capital Formation: Towards a Computational Approach, EJKM
          * 2014, The Intangible Cube: a Co-Word Analysis for Mapping the Faces, EJKM
          * 2014, The Impact of Continuous Education on Intellectual Capital and Market Value of Companies: A conceptual study, International Journal of Management and Applied Research
          * 2014, Taking a different view: the case of the Eurozone Macroeconomic policies as a case of incompetence , EJKM
          * 2014, Special Issues -International Journal of Knowledge Based Development, International Journal of Knowledge Based Development
          * 2014, Personnel Welfare and Intellectual Capital, an Empirical Study, Journal of Intellectual Capital
          * 2014, Personal welfare and intellectual capital: The case of football coaches, Journal of Intellectual Capital
          * 2014, Introduction in E. Tomé, International Journal of Knowledge Based Development
          * 2014, Intellectual capital formation in Eu cross border regions: Theory and application, International Journal of Intelligent Enterprise
          * 2014, Editorial, International Journal of Knowledge-Based Development
          * 2013, World Atlas of Intellectual Capital: A Sketcky Version, Managing Dynamics in the Knowledge Economy
          * 2013, The European Union HRD Policies: A very specific case of HRD European , Journal of European Industrial Training
          * 2013, The European Social Fund: a very specific case instrument of HRD policy, European Journal of Training and Development
          * 2013, HRD, Sects and Culture – Theoretical basis for a comparative study , HRD, Sects and Culture – Theoretical basis for a comparative study
          * 2012, European Social Fund in Portugal: A complex question for human resource development, European Journal of Training and Development
          * 2012, Building the Intangible Cube: Assessment of the Relevant Organizational Dimensions of Intangible Assets, Poslovna Izvrsnost (Business Excellence)
          * 2011, The Changing Role of Knowledge in Companies: How to Improve Business Performance Through Knowledge, Electronic Journal of Knowledge Management
          * 2011, Intellectual capital reporting: A conceptual study with application in the Portuguese case, International Journal of Learning and Intellectual Capital
          * 2011, Human resource development in the knowledge based and services driven economy: An introduction, Journal of European Industrial Training
          * 2011, HRD in the 21st century Knowledge based and Services driven economy: An Introduction, Journal of European Industrial Training
          * 2010, Unlocking the development potential of knowledge: A methodological framework to support knowledge-based development, International Journal of Knowledge-Based Development
          * 2010, Functional concept for a web-based knowledge impact and IC reporting portal, Electronic Journal of Knowledge Management – ECKM Special Issue
          * 2010, European policies to foster knowledge: The case of the European Social Fund – an introductory study, Journal of Modern Accounting and Auditing
          * 2010, A methodological framework for unlocking developmental potential of knowledge, International Journal of Knowledge Based Development
          * 2009, The evaluation of HRD: A critical study with applications, Journal of European Industrial Training
          * 2009, HRD in a Multipolar World: An Introductory Study Chinese, Business Review
          * 2009, Empirical impact study on the role of knowledge management in logistics, International Journal of Electronic Customer Relationship Management
          * 2008, The hidden face of intellectual capital: Social policies, Journal of Intellectual Capital
          * 2008, The Portuguese youth labour market: A critical approach, Journal of European Industrial Training
          * 2008, IC and KM in a macroeconomic perspective: The Portuguese case, International Journal of Learning and Intellectual Capital
          * 2007, Employability, skills, and training in Portugal (1988-2001): evidence from official data, Journal of European Industrial Training
          * 2006, Knowledge Management and Logistics: Where we are and where we might go to, ” LogForum - Electronic Scientific Journal of Logistics
          * 2005-09, Evaluation Methods in Social Policy, Boletín Informativo de Trabajo Social (Bits), Revista Digital – Escola Universitaria de Trabajo Social de Cuenca – Universidade de Castilla la Mancha
          * 2005, Social aspects in knowledge management and intellectual capital, International Journal of Management Concepts and Philosophy
          * 2005, Human resources policies compared: what can the US and the EU learn with each other?, Journal of European Industrial Training
          * 2005, Human resources policies compared: What can the EU and the USA learn from each other?, Journal of European Industrial Training
          * 2004, Intellectual capital, social policy, economic development and the world evolution, Journal of Intellectual Capital
          * 2003, Bad management and its consequences in a problematic European union member (Portugal), Journal of Universal Computer Science
          * 2001, The evaluation of vocational training: A comparative analysis, Journal of European Industrial Training

        Thesis / Dissertation

          * 2023, Master, Investimento no Mercado de Ações: Uma visão pós pandemia, novas tendências e tecnologias do mercado Mestrado Neves, Vanessa Co-orientador Economia Universidade Lusofona – 4 de Setembro de 2023
          * 2022, PhD, Gestão do Conhecimento, e Confiança no Processo de Sucessão nas Empresas Familiares da Região Autonoma da Madeira ¿ Defendida em Dezembro de 2022.
          * 2022, PhD, A eficiência do sector bancário em Cabo Verde .- Tiago Santos – Gestão – Lusófona de Lisboa – Maio de 2022 – 18 valores.
          * 2022, Master, Endomarketing e Gestão de Recursos Humanos: estudo teórico com aplicação
          * 2021, Master, O Impacto da Conciliação entre o Trabalho e a Vida Pessoal na Satisfação no Trabalho
          * 2021, Master, A Teoria dos Jogos aplicada a situações do Comportamento Organizacional
          * 2019, PhD, Processo de Modernização Administrativa em Angola: Estudo de Caso Guiché Único da Empresa
          * 2019, PhD, On-Site vs. Off-Site practices of MSD intervention and its impact on Organizational - Productivity, Absenteeism and Costs.Theoretical analysis with application
          * 2019, Master, Terão os robôs capacidade para substituir o ser humanos?
          * 2018, Master, Employer Branding e Talent Management: o caso da EDP
          * 2018, Master, Diferentes tipos de contrato de trabalho e o impacto na organização ao nível do commitment e do work engagement
          * 2013, Master, Mercado de trabalho : estudo comparativo : protecção social e integração no mercado de trabalho
          * 2013, Master, Fatores explicativos do desemprego na Zona Euro
          * 2013, Master, Capital humano : estudo aplicado às empresas da região Norte
          * 2012, Master, A importância do desenvolvimento tecnológico para o crescimento económico português
          * 2012, Master, A competência dos empresarios como vantagem competitiva das empresas : estudo empírico
          * 2011, Master, Os sistemas de informação na dinâmica da construção do conhecimento : estudo teórico com aplicação
          * 2001, PhD, A experiência portuguesa (1986-99) de uma instituição europeia : o Fundo Social Europeu. Estudo numa perspectiva metodológica de avaliação
          * 1994, Master, Contributos para a análise sócio-económica da formação profissional

        Book

          * 2023, Proceedings TAKE2023 , Tomé E
          * 2023, Developing Diversity, Equity, and Inclusion Policies for Promoting Employee Sustainability and Well-Being , Gonçalves S. ;Figueiredo P.;, Tomé E, Baptista J,, IGI
          * 2022, Proceedings of TAKE 2022 Conference , E4 Conferences
          * 2022, Handbook of Research on Challenges for Human Resource Management in the COVID-19 Era, Tomé, Eduardo; Figueiredo, P; Rouco, C
          * 2021, Proceedings of TAKE 2021 Conference , Tomé E Lobo C (, E4 Conferences
          * 2019, Proceedings of TAKE 2019 - Theory and Applications in the Knowledge Economy Conference , Tomé, Eduardo; Kragulj F.
          * 2019, Proceedings of ECKM 2019, Tomé, Eduardo; Cesário F. ; Soares R.
          * 2018, Proceedings of TAKE 2018 - Theory and Applications in the Knowledge Economy Conference], Tomé, Eduardo; Neumann, G.; Majewska J; Truskolasky Szymon
          * 2017, Proceedings of the 18th International Conference on Human Resource Development Research and Practice across Europe, Tomé, Eduardo; Sousa M; J. Costa S
          * 2017, Proceedings of TAKE 2017 – Faculty of Economics of Zagreb, Tomé, Eduardo; Neumann, G.; Knezevic B.
          * 2016, Proceedings da Conferência TAKE 2016, Tomé, Eduardo
          * 2016, Human resource development in Southern Europe, Tomé, E.
          * 2014, The interesting case of Portugal in the Economy of Sport, Tomé, E.
          * 2012, Proceedings da 13th International Conference on Human Resource Development Research and Practice Across Europe: The future of HRD - 2020 and beyond: challenges and opportunities, Tomé, Eduardo; Silva R
          * 2011, Proceedings da International Conference on Managing Services in the Knowledge Economy, Tomé, Eduardo; Silva R
          * 2010, Proceedings of the 11th European Conference on Knowledge Management, Tomé, Eduardo
          * 2010, Proceedings of the 11th European Conference on Knowledge Management, Tomé, Eduardo
          * 2009, Proceedings of the 1st International Conference on Managing Services in the Knowledge Economy, Tomé, Eduardo; Silva R.

        Book chapter

          * 2023, Chess as a way of inclusion of prisoners – a Portuguese Experience , - Developing Diversity, Equity, and Inclusion Policies for Promoting Employee Sustainability and Well-Being, IGI
          * 2020, Will Robots Have the Capacity to Replace Humankind? Empirical Analysis from Portugal "Building Future Competences - Challenges and Opportunities for Skilled Crafts and Trades in the Knowledge Economy, Editors: Heidrun Bichler-Ripfel & Florian Kragulj, IAGF - Institute for Applied Research on Skilled Crafts and Trades, Vienna, Austria (Paulus Stuller & Reinhard Kainz) Vienna
          * 2020, KM and the Post COVID-19 new normal - Theoretical analysis with application to Universities – The Future of Universities, Edited by Dan Remenyi. Academic Conferences Publishing International
          * 2020, Evaluation of HRD and UFHRD Conferences: Analysing at the last 20 years and looking at the next 20 in The Future of HRD, 2, Editors: Loon, Mark, Stewart, Jim, Nachmias, Stefanos (Eds.) Palgrave
          * 2020, ) KM and the Post COVID-19 new normal - Theoretical analysis with application to Universities ¿ , The Future of Universities , Edited by Dan Remenyi. Academic Conferences Publishing International.
          * 2019, Leadership in a Portuguese Company Evidence-Based Initiatives for Organizational Change and Development , Edited by Robert Hamlin. Andrea Ellinger e Jenni Jones IGI.
          * 2016, HRD in Southern Europe in Garavan, Morley and McCharty (Eds) Global Human Resource Development
          * 2015, The influence of pre-departure training on expatriate adjustment: an empirical investigation with portuguese international assignees, Springer International Publishing
          * 2014, The Specific Case of Portugal in the Economy of Sport, P. Pardalos, Zamaev V. Social Networks and Economics in Sports Edited by Springer.
          * 2014, Knowledge management in logistics industry organizations
          * 2014, Knowledge Management and Logistcs , chapter 19, Ortenbald. A. (Editor) Handbook of Research on Knowledge Management: Edward Elgar,
          * 2012, “Knowledge Management” in International Human Resource Development: Learning, Education and Training for Individuals and Organizations 3rd Edition, 3, Edited by JP Wilson. Kogan Page Editors
          * 2012, Trust in Encyclopaedia of Corporate Social Responsibility PART Ethics/Environment, editor Samuel Idowu, published by Springer
          * 2009, Labor Market Training Programs” International Encyclopedia of Public Policy., International Encyclopedia of Public Policy. Philip Anthony Ohara, Editor., 2

        Conference paper

          * World Atlas of Intellectual Capital: An Introduction, Intellectual Capital Congress
          * Welfare State: Performance and Design: Foreseeing the Future in a Macroeconomic Dimension, Welfare State Performance and Design Conference Institute of Public Finance
          * Técnicos Oficiais de Contas: um estudo de caso sobre formação contínua , V Congresso da OTOC
          * Types of labor contract and its importance on commitment and engagement: A case study from Portugal. Proceedings, UFHRD 2019
          * Training Subsidies for US labor market in comparison with the ESF assistance, AHRD Conference, February, Richmond
          * Tourism in Portugal – between the bubble and the miracle , INVTUR. Maio 2021.
          * Thomas Piketty's Capital in the 21st Century: An Analysis Based on Intellectual Capital, ECIC 2015
          * Thirty years of programing in the European HRD policy – 1988-2020, UFHRD Conference, 2016 Manchester
          * The touristic routes in Portugal as a case of Social Policy.
          * The role of billionaires in the economic paradigm of the 21st century , 11th International Management Conference - The role of management in the economic paradigm of the 21st century
          * The role of Intangible Capital in Economic Growth: Organizational, Regional and Personal Dimensions., MENA AHRD Conference
          * The role of HRD and VET and the HR market in one of the emerging BRICS: the case of India, UFHRD 2014
          * The present comes from the past – HRD in 2023 as predicted by the UFHRD Conference
          * The future of the world economy: an hypothesis, Conferênce “Economics for the Future”, Cambridge Journal of Economics
          * The future of labour mobility in Europe: the importance of social security, 7th Congress International Industrial Relations Association
          * The cube of Intangibles – first empirical evidence, ECKM Conference. Belfast.
          * The certified accountant’s influence in creating a tax education system, system ICICKM 2017 Hong Kong
          * The Potential for Regional Intellectual Capital Formation: Towards a Computational Approach, ECIC 2014
          * The Portuguese Experience of the European Social Fund: A curious case for HRD, 12th International Conference on HRD Research and Practice Across Europe
          * The Portuguese Case of Covid-19 as a case of Knowledge Management , ECKM 2021
          * The Periodic Table of HRD, Proceedings of UFHRD 2017 Conference
          * The NAFTA Region case of Human Resource Development: A very actual question, UFHRD 2019
          * The Intangible Cube: a Co-Word Analysis for Mapping the Faces, ECIC 2014
          * The Impact of Universities in the Development of Local Communities - A Portuguese Experience, Conference Internationale Education, Economie e Société
          * The Heisenberg Principle and other ideas from the scientific world and HRD., UFHRD 2016 Conference Manchester
          * The European Union support to human resources: a management case with several problems, 7th International Human Resources Management Conference
          * The European Union HRD Policies: A very specific case of HRD, UFHRD 2012
          * The European Social Fund in the Visegrad Countries in the 2007-13 Programming Phase, UFHRD 2018 Newcastle Proceedings
          * The European Social Fund in Portugal – A singular case of Social Policy Stream 5 – European Social Policies , ESPANET Conference – ISCSP Lisbon
          * The Coin and the Cube in IC analysis, MSKE 2011, Universidade Lusíada
          * The Challenges faced by Banco Crédito Agrícola in Portugal to the changes in the European Commission's Sustainable Finance Action Plan
          * The Bologna Process in Portugal and Poland: A comparative study, UFHRD 2015 Conference
          * The Bologna Process in Portugal and Poland – a Comparative study -Poster session, UFHRD 2014
          * Social issues in knowledge management and intellectual capital, 5th European Conference on Organizational Knowledge, Learning and Capabilities
          * Should I accept this job or not – Over qualification an emergent dilemma , Proceedings of TAKE 2017. Zagreb.
          * Secondary Vocational Education In South Africa: Can We Learn From Portugal?, ICTR 2019 Proceedings
          * SCIENTIFIC CONFERENCES: TAKING PART OR MAKING THEM - A theoretical study with application, UFHRD 2018, Newcastle
          * ROBOTICS AND ARTIFICIAL INTELLIGENCE (R&AI) PERCEPTIONS OF CONSUMERS AND PRODUCERS – AN INTERNATIONAL COMPARISON AMONG PORTUGAL AND SPAIN, ECIAIR Conference, ISCTE Lisbon
          * Public Policies to Foster the Investment in Knowledge: The case of the ESF in Portugal, International Conference on Managing Services in the Knowledge Economy
          * Portugal 1974-2014: de um império a uma região numa união monetária, Congresso – Portugal 40 anos de Democracia
          * Perceived Effective and Ineffective Managerial Behaviors within Private Sector Organizations in Hungary, Portugal and the Netherlands, UFHRD 2016 Conference, Manchester.
          * On the way towards an European Atlas on KM and IC, 9th European Conference on Knowledge Management
          * Millionaires and Intellectual Capital, na Empirical Study, 5th ECIC Conference
          * May Robots Replace Humans ? , ICAIR 2019 Oxford
          * Managing Experts in the Knowledge Economy by Enneagram, ECIC 2015
          * MSKs Overlooked Opportumity for Health Cost Savings and Productivity Loss Prevention, Proceedings of TAKE 2017
          * Looking at the Black Box , IC ICGML Conference
          * Limits of Rationality on IC an KM, European Conference on Intellectual Capital
          * Knowledge management and logistics: an empirical evaluation, 5th International Conference on Knowledge Management
          * Knowledge Management in the BRICS GSOM, Emerging Markets Conference in St Petersburgh
          * Knowledge Management in Portugal, ECKM 2019 Proceedings
          * Knowledge Management and Logistics: Results from an Empirical Impact Study, 6th International Conference on Knowledge Management
          * Knowledge Management and Logistics: An European Perspective, 8th European Conference of Knowledge Management
          * Knowledge Clinic: Methods and Models to apply Knowledge in Organizations, 12th ECKM 2011
          * Knowledge Cities: A portuguese case, 3rd ECIC 2011, University of Nicosia Cyprus
          * KNOWLEDGE MANAGEMENT PRACTICES AND BENEFITS, AGILE ECONOMY AND THE USE OF FOREIGN LANGUAGES - A theoretical analysis illustrated with the cases of Russia and Portugal, ECKM Conference
          * Intellectual capital: two Sciences, two worlds, 4th European Conference of Knowledge Management
          * Intellectual Capital and the Very Rich, 4th ECIC 2012
          * Informal Education in Portugal: a Study in an International Comparative Perspective, Network 8, Economics of Education, European Conference on Educational Research
          * Indicators to guide the EU’s social policy, World Congress of Social Economics
          * In Support of an Emergent European Taxonomy of Perceived Managerial and Leadership Effectiveness, Proceedings of UFHRD 2017 Conference,
          * INTEGRATIVE COMPETENCE MANAGEMENT MODEL: A REVIEW , TAKE 2021 Conference
          * Human resources policies compared: what can Europe learn with the USA and vice versa, 5th International Conference on HRD Research Across Europe
          * Human Resources, Globalization and Glocalization: The Portuguese Case, 8th International Conference on Human Resource Development Research & Practice across Europe
          * Human Resource, Social Responsibility and Sustainability: the Economic Perspective, 12th International Conference on HRD Research and Practice Across Europe
          * HRD: The case of Laureate International Universities. Proceedings , UFHRD 2015 Conference
          * HRD, Sects and Culture – Theoretical basis for a comparative study, UFHRD 2013
          * HRD in times of turbulence: the case of Southern Europe – A study on low cost HRD economies, UFHRD 2013
          * HRD in the Global Players , UFHRD 2016 Conference
          * HRD in a Global Persepective: An Introductory Study, 10th International Conference on HRD Research and Practice Across Europe
          * HRD in Visegrad Countries and Covid-19, K. , UFHRD 2022, Sheffield,
          * HRD in Portugal and South Korea – A Comparative Study, AHRD Conference
          * HRD and the Olympic Games: Tools, People, Practices, Returns and Consequences., AHRD Conference, San Antonio
          * Global disruptions as a part of change and a call for global leadership , ECMLG Conference
          * Exploring Workplace Word Phobias a comparative study between the USA and Portugal , UFHRD 2016 Conference, Manchester
          * Exploring Meaningful Career through “The Alchemist”: Cognitive, Social and Emotional Approaches to Management Learning Proceedings, UFHRD 2019
          * Explaining the Economic Crisis Through Human Resources Development Policy: A comparison between the USA and the European Union , Academy of HRD Conference
          * Evaluation of HRD and Training: a critical study with applications, 9th International Conference on HRD Research and Practice Across Europe
          * Economics for the new millenium: the European Union case, International Conference: Economic Policies for the New Millenium
          * ESF in Portugal 2009-2020 – a reassessment s.
          * Do minimal or inconsequent organizational changes matter ?, Proceedings of TAKE 2017. Zagreb
          * Critical Knowledge Management – A state of the art analysis , ECKM 2018 Proceedings
          * Covid-19, Safety and Knowledge Management,
          * Conflict Management Styles and Knowledge Management – Theoretical Analysis with Application in Portugal , ECKM Conference
          * Conditions for Emplyoee Development in SMEs within the European Social Fund in Poland, UFHRD 2018 Newcastle
          * Atlas of Intellectual Capital: A sketchy draft, 3rd ECIC 2011, University of Nicosia Cyprus
          * Atlas of Intellectual Capital, OLKC 2011 Making Waves, Hull Uiversity
          * Assessing Regional Intellectual Capital: The Portuguese case, International Forum for Knowledge Assets Dynamics
          * Agile Manufacturing a new field for HRD.
          * A specific problem of time use: schooling summer holidays in Portugal, International Association of Time Use Research Conference
          * A NEW AGE OF DISCOVERIES IN HRD: VASCO da GAMA’S 1498 JOURNEY REVISITED , AHRD India Conference, Ahmedabad
          * A Macroeconomic Social Policy Issue: How does the EU compare with other socio-economic spaces of equal dimension, 12th World Congress in Social Economics
          * 2019, Preface Proceedings of the European Conference on Knowledge Management, ECKM
          * 2019, Knowledge management in practice: Context, interventions and outcomes
          * 2019, Back pain: Lost productivity, associated costs and a solution
          * 2018, Why knowledge management fails
          * 2018, Critical knowledge management: An insight into the literature
          * 2017, What could be in a black box of the economy?
          * 2017, To take part in a Conference or to Make a Conference – Intellectual Capital in Practice, ECIC Conference, Lisbon.
          * 2017, Intellectual capital and billionaires – an empirical study
          * 2017, Actors in the knowledge economy: Creators, owners performers, and costumers
          * 2017, Actors in smart cities
          * 2017, 10 years after – an update on the role of knowledge management in logistics companies., Proceedings of ECKM 2017, Barcelona
          * 2016, The intangibles cube: First description with data
          * 2016, Knowledge Management in the "Casino Economy"
          * 2015, The relationship between knowledge acquisition on international assignments and career development: An exploratory study with portuguese repatriates
          * 2015, Queen Elizabeth II and Knowledge Management, ECKM 2015 Conference
          * 2014, Knowledge management in multinational companies: The repatriates' role in the competitive advantage in subsidiaries
          * 2014, KM and politics at the highest level: an exploratory analysis
          * 2013, Innovation, knowledge and incompetence: The case of the eurozone macroeconomic policies
          * 2012, Building the intangible cube: Assessment of the relevant organisational dimensions of intangible assets
          * 2011, The knowledge clinic: Concepts, methods and tools to support productive knowledge management in companies
          * 2010, Preface Proceedings of the European Conference on Knowledge Management
          * 2010, How to Initiate Knowledge-Based Change Processes in Companies, 11th European Conference on Knowledge Management
          * 2009, Methods and tools of a web-Based knowledge impact and IC reporting portal
          * 2008, On the way towards a european atlas on knowledge and intellectual capital
          * 2007, Knowledge management and logistics: A European perspective
          * 2006, The hidden face of intellectual capital: Social policies
          * SMEs a field of disconnections. .
          * Quality of Education in 2022
          * Knowledge Management and Cryptocurrencies: Review and Reflection ,, ECKM, 2023, 2, pp. 1353–1357
          * Ethics and the University of the Future,

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona