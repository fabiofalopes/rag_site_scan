# Response for https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
          PT: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333 EN: https://www.ulusofona.pt/en/teachers/fernando-rui-de-sousa-campos-333
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
        fechar menu : https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/fernando-rui-de-sousa-campos-333
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Fernando Rui De Sousa Campos

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p333
              fer***@ulusofona.pt
              FB1D-CD8E-C9AA: https://www.cienciavitae.pt/FB1D-CD8E-C9AA
              0000-0001-7778-8930: https://orcid.org/0000-0001-7778-8930
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/b1fbf8d6-b009-4af3-81cb-7cd83365f775
      : https://www.ulusofona.pt/

        Resume

        Fernando Rui de Sousa Campos. Concluiu o(a) Doutoramento em Ciência Política em 2010 pelo(a) Universidade Lusófona de Humanidades e Tecnologias, Mestrado em Estudos Africanos Especialização em Desenvolvimento Social e Económico em África em 2001 pelo(a) ISCTE-Instituto Universitário de Lisboa e Licenciatura em Ciência Política em 1996 pelo(a) Universidade Lusófona de Humanidades e Tecnologias. É Professor Associado no(a) Universidade Lusófona de Humanidades e Tecnologias e Coordenador do Mestrado em Ciência Política - Cidadania e Governação no(a) Universidade Lusófona - Centro Universitário de Lisboa. Publicou 13 artigos em revistas especializadas. Possui 9 capítulo(s) de livros e 4 livro(s). Organizou 13 evento(s). Participou em 67 evento(s). Orientou 1 tese(s) de doutoramento. Orientou 12 dissertação(ões) de mestrado. Recebeu 1 prémio(s) e/ou homenagens. Participa e/ou participou como Investigador em 2 projeto(s) e Outra em 1 projeto(s). Atua na(s) área(s) de Ciências Sociais com ênfase em Outras Ciências Sociais e Ciências Sociais com ênfase em Ciências Políticas. Nas suas atividades profissionais interagiu com 15 colaborador(es) em coautorias de trabalhos científicos. No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural são: São Tomé e Príncipe; Democracia; Desenvolvimento; Partido Único; Igreja Católica; Brasil; Multipartidarismo; Partidos Políticos; Património; Portugal; Estudos Lusófonos; Direitos Humanos; Direito Humanitário; Migrações; Mulher; Lusofonia; Pertença; Política; Independência; Educação; Religião e Movimentos Religiosos; Angola; Cooperação Internacional; Estudos Africanos; África; Descolonização; Identidade; América Latina. Abstract: Fernando Rui de Sousa Campos. She completed her PhD in Political Science in 2010 from the Lusófona University of Humanities and Technologies, a Master's degree in African Studies specializing in Social and Economic Development in Africa in 2001 from ISCTE-Instituto Universitário de Lisboa and a degree in Political Science in 1996 from the Lusófona University of Humanities and Technologies.He is an Associate Professor at the Lusófona University of Humanities and Technologies and Coordinator of the Master's Degree in Political Science - Citizenship and Governance at the Lusófona University - University Center of Lisbon. He has published 13 articles in specialized journals. It has 9 book chapter(s) and 4 book(s). Organized 13 event(s). He has participated in 67 event(s). He supervised 1 PhD thesis(s). He supervised 12 master's dissertation(s). He has received 1 award(s) and/or honors. Participates and/or participated as a Researcher in 2 project(s) and Another in 1 project(s). She works in the area(s) of Social Sciences with an emphasis on Other Social Sciences and Social Sciences with an emphasis on Political Sciences. In his professional activities, he interacted with 15 collaborator(s) in co-authorship of scientific papers. In his Ciência Vitae curriculum, the most frequent terms in the contextualization of scientific, technological and artistic-cultural production are: São Tomé and Príncipe; Democracy; Development; Single Party; Catholic Church; Brazil; Multipartyism; Political Parties; Heritage; Portugal; Lusophone Studies; Human Rights; Humanitarian Law Migrations; Woman; Lusophony; Belonging; Politics; Independence; Education; Religion and Religious Movements; Angola; International cooperation; African Studies; Africa; Decolonization; Identity; Latin America.

        Graus

            * Mestrado
              Estudos Africanos Especializ.Desenvolvimento Social e Económico em África
            * Doutoramento
              Ciência Política
            * Licenciatura
              Ciência Política

        Publicações

        Artigo em revista (magazine)

          * 2004-04-25, Drenar os pântanos é PRECISO, África Hoje

        Artigo em revista

          * 2023-06, Guerra na Ucrânia: O Direito Fundamental à Saúde e os desafios políticos do Direito Internacional Humanitário, Revista População e Sociedade
          * 2023-01-09, Muçulmanos em Odivelas. Dinâmicas e Comunidade, EHQUIDAD. Revista Internacional de Polítcas de Bienestat Y Trabajo
          * 2023-01, Muslims in Odivelas. Dynamics and Community, Ehquidad International Welfare Policies and Social Work Journal
          * 2022-10, A relevância da Gaudium et Spes nos 60 anos do início do Concílio Ecuménico Vaticano II, Revista Caminhos
          * 2020-12, A CPLP e a Dignidade Humana, em tempo de Direitos Humanos, População e Sociedade
          * 2014, Os desafios para uma mulher migrante na procura de uma vida com dignidade na América Latina num contexto multicultural, Série Diálogos en Red - Nuestra América
          * 2014, Democracia e a prática da reciprocidade nos Direitos Humanos, IHU - Revista do Instituto Humanitas Unisinos
          * 2014, A Mulher Migrante na América Latina, Serie Dialogos en Red - Nuestra América
          * 2014, A Investigação e as Redes, Série Diálogos en Red - Nuestra América
          * 2013, Maquiavel entre a violência e a religião, ResPublica - Revista de Ciência Política, Segurança e Relações Internacionais
          * 2009, O Século XXI - África aposta no futuro?, Africanologia - Revista Lusófona de Estudos Africanos
          * 2008, O lugar e o papel da Cooperação Internacional no Desenvolvimento de São Tomé e Príncipe, Revista Lusófona de Humanidades e Tecnologias
          * 2008, Família e Migrações, Africanologia – Revista Lusófona de Estudos Africanos

        Livro

          * 2022, Dicionário de Ciência Política e Relações Internacionais, Fernando Campos et al, Almedina
          * 2019, Na Senda dos Direitos Humanos. Breves passos., 1ª, Campos, Fernando , Edições Universitárias Lusófonas
          * 2017, Reflexos da América Latina e Caribe, 1, Campos, Fernando Rui de Sousa, Edições Universitárias Lusófonas
          * 2011, As relações entre Portugal e São Tomé e Príncipe: Do passado colonial à Lusofonia, 1, Campos, Fernando Rui de Sousa, Edições Colibri

        Capítulo de livro

          * 2023, Justiça e Direitos Humanos: Um Caminho para o Desenvolvimento
          * 2023, Dos direitos das crianças, ao direito a ser criança, em tempo de incertezas, VI Congresso Ibero-Americano de Intervenção Social - Infância e Juventude, Lema d'Origem - Editora, Lda.
          * 2022, O Direito Fundamental à Saúde em tempo de incertezas, V Congresso Ibero-americano de Intervenção Social: Desenvolvimento Sustentável, Direitos Humanos e Igualdade de Género, Lema d'Origem
          * 2020, A pena de morte num contexto político, Pena de morte e morte sem pena: 150 anos de abolição da pena de morte em Portugal (1867-2017), 2ª Revista, Edições Universitárias Lusófonas
          * 2019, Los derechos humanos y la pobreza en la sociedad global, Desarollo rural en el contexto del posconflicto. In Muñoz, T.; Albarracín, N. y Rojas,S. (Ed.)., 1, Universidad Central
          * 2019, A pena de morte num contexto político, Pena de Morte e morte sem pena, 1ª, Edições Universitárias Lusófonas
          * 2017, América Latina, Direitos Humanos e os Novos Desafios, Reflexos da América Latina e Caribe, Edições Universitárias Lusófonas
          * 2012, O Exercício do Poder Político e os Novos Movimentos Religiosos na América Latina - o caso do Brasil, Religião, Política, Poder e Cultura na América Latina, 1, Escola Superior de Teologia
          * 2012, Novos movimentos religiosos em Portugal e no Brasil. Semelhanças e diferenças, Religião, modernidade e pós-modernidade, Ideias & Letras
          * 2012, Ciência Política, uma área que se afirma no século XXI - teorias e metodologias, II Fórum Internacional de Conhecimento & Ciência, 2, 1, Conhecimento & Ciência

        Artigo em jornal

          * 2015-04-03, Manifestantes pedem Impeachment de Dilma, aFolha.eu - o jornal da comunidade brasileira na Europa

        Artigo em conferência

          * Os desafios para uma mulher migrante na procura de uma vida com dignidade na América Latina, num contexto multicultural, II Encuentro Internacional del Conocimiento /II Encuentro de las Ciencias Humanas y Tecnológicas para la Integración en el Conosur
          * O insucesso e abandono escolar num contexto de pobreza, II Congresso Ibero-americano de Intervenção Social: Direitos Sociais e Exclusão
          * O Século XXI - África aposta no futuro?, VI CONGRESO DE ESTUDIOS AFRICANOS EN EL MUNDO IBÉRICO
          * LA MUJER MIGRANTE FRONTERAS Y CONSTRANGIMIENTOS, II Congreso Internacional “África – Occidente” : corresponsabilidad en el desarrollo
          * Educação e religião: Património, Pertença e Identidade, XIII Simpósio Nacional da Associação Brasileira de História das Religiões
          * A mulher imigrante na América Latina, I Encuentro Internacional del Conocimiento: diálogos en nuestra América / I Encuentro de las Ciencias de las Ciencias Humanas y Tecnológicas
          * A Investigação e as Redes - a impossível separação, Dialogos en Mercosur - Rede Académica
          * 2022-03-07, 60 Anos do Concílio Vaticano II: da Gaudium et Spes, aos "Sinais dos Tempos"
          * 2021-09-21, A vivência da Ecologia nos Sacramentos
          * 2019-10-21, A violência doméstica em contexto de pobreza, III Congresso Ibero-Americano de Intervenção Social. Direitos Humanos e Mediação

        Resumo em conferência

          * 2024-01, Educar para a tolerância e para o perdão, como alicerces para a construção da paz, V Congresso Internacional de Pedagogia: Educação e Cultura de Paz
          * 2022-03-07, 60 anos do Concílio Vaticano II: da Gaudium et Spes aos "Sinais dos Tempos", II Simpósio Internacional Estudos do Catolicismo: O Concílio Vaticano II: O Catolicismo de João XXIII a Francisco

        Outra produção

          * 2010, As relações entre Portugal e São Tomé e Príncipe: do passado colonial à lusofonia.
          * 2001, A Cooperação Internacional face às estratégias políticas e de desenvolvimento em São Tomé e Príncipe

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona