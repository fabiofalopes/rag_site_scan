# Response for https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
          PT: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258 EN: https://www.ulusofona.pt/en/teachers/francisco-alberto-arruda-carreiro-da-costa-4258
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
        fechar menu : https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/francisco-alberto-arruda-carreiro-da-costa-4258
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Francisco Carreiro Da Costa

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4258
              fca***@ulusofona.pt
              B413-E2DA-90D0: https://www.cienciavitae.pt/B413-E2DA-90D0
              0000-0002-4874-2957: https://orcid.org/0000-0002-4874-2957
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/510d7d85-d6de-420f-941a-7df84a1aa66b
      : https://www.ulusofona.pt/

        Graus

            * Doutoramento
              Motricidade Humana
            * Licenciatura
              Educação Física
            * Especialização pós-licenciatura
              Provas de Aptidão Pedagógica e Capacidade Científica
            * Título de Agregado
              Ciências da Educação

        Publicações

        Artigo em revista

          * 2024-03-15, Análise do processo de pensamento e intervenção pedagógica de treinadores de ténis: Desenho e va-lidação do protocolo de uma entrevista, Retos
          * 2023-01-22, The Impact of Non-Physical Education Teachers’ Perceptions on the Promotion of Active and Healthy Lifestyles: A Cross-Sectional Qualitative Study, International Journal of Environmental Research and Public Health
          * 2023-01-02, Physical activity levels of Portuguese adolescents in the first period of confinement due to the COVID-19 pandemic and the first activities of teachers and coaches: a cross-sectional study, Retos
          * 2021-07-03, Adolescents’ Experiences and Perspectives on Physical Activity and Friend Influences Over Time, Research Quarterly for Exercise and Sport
          * 2019-12-20, Educación física como proyecto de innovación y transformación cultural, RECIE. Revista Caribeña de Investigación Educativa
          * 2019, Trends and age-related changes of physical activity among portuguese adolescent girls from 2002-2014 : highlights from the health behavior in school-aged children study
          * 2017, Valoración de la escuela y la Educación Física y su relación con la práctica de actividad física de los escolares, Retos
          * 2017, The performing of a secondary physical education department committed to the Portuguese physical education national curriculum, Motricidade
          * 2017, Relación entre la actividad física de los adolescentes y la de madres/padres, Revista de Psicologia del Deporte
          * 2017, Correlates of physical activity in young people
          * 2017, As orientações educacionais dos professores portugueses de educação Física, Retos
          * 2016-12-20, Innovación en la formación del profesorado de educación física (Innovation in teacher training on physical education), Retos
          * 2016-09-15, Exploring the perspectives of physically active and inactive adolescents: how does physical education influence their lifestyles?, Sport, Education and Society
          * 2016, Students thought processes in physical education: a multi-dimensional analysis, Gymnasium, Scientific Journal of Education, Sport, and Health
          * 2016, Socioeconomic, personal and behavioral correlates of active commuting among adolescents, Montenegrin Journal of Sports Science and Medicine
          * 2016, Identificação de padrões de atividade física e comportamentos sedentários em adolescentes, com recurso à avaliação momentânea ecológica
          * 2016, Effects of obesity on perception of ability and perception of body image in portuguese children and adolescents, Journal of Human Sport & Exercise
          * 2016, Atividade física na adolescência: qual a importância do apoio e dos níveis de atividade física dos pais? , Gymnasium,·Revista da Rede Euroamericana de Actividade Física, Educação e Saúde
          * 2015-08, Adolescents’ perspectives on the barriers and facilitators of physical activity: a systematic review of qualitative studies, Health Education Research
          * 2015-05, Socio-demographic correlates of leisure time physical activity among Portuguese adults, Cadernos de Saúde Pública
          * 2015-02, Do Students Know the Physical Activity Recommendations for Health Promotion?, Journal of Physical Activity and Health
          * 2015, Narratives of adolescents with an active and sedentary lifestyle, REVISTA INTERNACIONAL DE MEDICINA Y CIENCIAS DE LA ACTIVIDAD FISICA Y DEL DEPORTE
          * 2015, DO BOYS AND GIRLS SHARE THE SAME CHARACTERISTICS WHEN THEY ARE EQUALLY CLASSIFIED AS ACTIVE OR INACTIVE?, Revista Iberoamericana de Psicología del Ejercicio y el Deporte
          * 2015, Correlatos da atividade física nos tempos de lazer dos alunos do 12.º ano de duas escolas públicas de Lisboa, Boletim SPEF
          * 2014-03-04, Correlates of urban children's leisure-time physical activity and sedentary behaviors during school days, American Journal of Human Biology
          * 2013-09-17, Perception and reality – Portuguese adults' awareness of active lifestyle, European Journal of Sport Science
          * 2013, Levels of Physical Activity of Urban Adolescents, International Journal of Sports Science
          * 2013, Correlates of school sport participation: A cross-sectional study in urban Portuguese students, Science and Sports
          * 2012-08, The correlates of meeting physical activity recommendations: A population-based cross-sectional study.
          * 2010-04, Sex equity and physical activity levels in coeducational physical education: exploring the potential of modified game forms, Physical Education & Sport Pedagogy
          * 2009-08-02, El pensamiento del profesorado en el proceso enseñanza-aprendizaje en educación física, Educación Física y Deporte
          * 2009, La Gestión del Currículo a través de Competencias, Tándem. Didáctica de la Educación Física
          * 2009, A influência socializadora da formação inicial em educação física. percepções dos protagonistas e unidade conceptual inter-pares, Boletim da Sociedade Portuguesa de Educação Física
          * 2007, El proceso de entrenamiento en gimnasia rítmica, Red: revista de entrenamiento deportivo
          * 2004, del Profesorado en el Proceso Enseñanza-Aprendizaje en Educación Física, Educación Física y Deporte. Universidad de Antioquia
          * 2003, A organização de tarefas motoras e aprendizagem. Estudo do nível inicial de habilidade motora e da estrutura da tarefa numa unidade de ensino, Cinergis
          * 1999, Estilo de vida de jóvenes europeos: Un estudio comparativo (Lifestyle young Europeans: A comparative study), Revista de Educación Física: Renovar la teoría y practica
          * 1997, Teaching the curriculum: Policy and practice in Portugal and Belgium, The Curriculum Journal
          * 1996, Seeking expert teachers in physical education and sport, European Journal of Physical Education
          * 1996, Feedback pedagogique: Analyse de l'information evoquee par l'eleve wrs de seances d'education physique, Revue de l'Education Physique
          * 1994, Expectativas de Exercício Profissional em Estudantes de Educação Física
          * 1992, As representações de sucesso e insucesso profissional em professores de Educação Física
          * 1979, A observação de professores: Algumas considerações em torno do processo de observação utilizado no estágio de profissionalização de bachareis em educação física - 1978/79, Ludens

        Tese / Dissertação

          * 1988, Doutoramento, O sucesso pedagógico em educação física : estudo das condições e factores de ensino-aprendizagem associados ao êxito numa unidade de ensino.
          * 1972, Licenciatura, Para uma atitude científica em educação física.

        Livro

          * 2005, The Art and Science of Teaching in Physical Education and Sport, Carreiro da Costa, F., Edições FMH
          * 2001, Educação e expressão físico-motora na região autónoma dos Açores, José Alves Diniz; Marcos Onofre; Jorge Mira; Luís Carvalho; Carreiro da Costa, F., Direção Regional de Educação Física e Desporto
          * 2001, A Educação Física no 1º Ciclo do Ensino Básico na Região Autónoma dos Açores, Diniz, José Alves; Onofre, Marcos; Carvalho, Luís Miguel; Mira, Jorge Trigo; Costa, Francisco Carreiro da, Direcção Regional de Educação Física e Desporto
          * 1998, Avaliação externa do projecto "Viva a Escola", Luis Carvalho; Carreiro da Costa, F., Ministério da Educação
          * 1996, O universo das actividades físicas. Manual de educação física para os 5º e 6º anos, 2º ciclo do ensino básico, João Jacinto; Sebastião Cruz; Graça Santos; Carreiro da Costa, F., Lisboa Editora
          * 1996, Formação de professores em educação física. Concepções, investigação, prática, Carreiro da Costa, F.; Luis Carvalho; Onofre, Marcos; José Alves Diniz; Pestana, Catalina, Edições FMH
          * 1983, A selecção de estratégias de ensino, Carreiro da Costa, F., CDI-ISEF

        Capítulo de livro

          * 2023, A promoção da literacia física, uma responsabilidade de todos os profissionais de Educação Física e Desporto, A Educação Física para além do óbvio , Universidade da Madeira
          * 2017, A promoção da saúde em contexto escolar. O contributo da disciplina de educação física, Conhecimentos do professor de educação física escolar , EdUECE
          * 1998, School Physical Education Views: Parents' and Students' Connections, Verlag Hofmann
          * 1996, School physical education purposes: the parents view, Wingate Institute
          * 1996, As Expectativas de Exercício Profissional dos Alunos de um Curso que Habilita para a Docência: A Formação (Não) Passa por Aqui?, Edições FMH
          * 1995, Physical education and sport first and fifth years students' expectations of future work activities, Université du Québec à Trois-Rivières

        Edição de livro

          * 2006, Edições FMH
          * 2000, Edições FMH

        Relatório

          * 1998, Avaliação do projecto Viva a Escola, http://hdl.handle.net/10451/7359

        Artigo em conferência

          * 1998, Educacao_Fisica na escola primária: Como pensam os professores, VI Congreso Galego de Educación Física

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona