# Response for https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
          PT: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning EN: https://www.ulusofona.pt/en/click/outras-ferramentas-para-e-learning
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
        fechar menu : https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes
          Click - Portal de e-Learning
        https://www.ulusofona.pt/images/click_600.jpg

            Outras ferramentas para e-Learning

          Click - Portal de e-Learning
        : https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
      ConteúdoNavegação

          Outras ferramentas para e-Learning

          Poderá também usar para as suas aulas a distância outras aplicações que podem complementar as suas atividades lectivas. Entre as disponíveis sugerimos as seguintes:

              Kahoot: https://kahoot.com/schools-u/
              É uma ferramenta que permite realizar jogos e quizzes online com os alunos. Os Quizzes são muito apreciados pelos alunos e podem ser realizados via telemóvel em qualquer local;

              Kialo: https://www.kialo.com/
              É uma ferramenta que permite a criação de listas de discussão de argumentos. Muito útil para o desenvolvimento de discussões e de argumentos de forma estruturada;

              WhatsApp: https://web.whatsapp.com/
              É uma ferramenta que todos conhecem, mas que ainda é pouco utilizada no contexto de educação. Poderá criar grupos com os seus alunos de forma a esclarecer todas as dúvidas e questões. Caso recorra ao WhatsApp recomendamos que defina muito bem o que pode ser colocado no grupo, por cada participante, de modo a que se respeite o objetivo que levou à criação do mesmo;

              Google Hangouts: https://hangouts.google.com/
              É uma ferramenta gratuita da Google que permite a realização de chamadas vídeo até 25 participantes;

              Cisco Webex: https://www.webex.com/go-covid19.html
              A ferramenta Cisco Webex é uma das mais poderosas e completas soluções para reuniões online. Como resposta ao COVID-19 a Cisco disponibiliza uma versão gratuita até ao final de julho.

              Google Classroom: https://classroom.google.com/
              O Google Classroom é um sistema de gestão de conteúdo académico, que permite facilitar a criação, distribuição e a avaliação de trabalhos.

              Edmodo: https://www.edmodo.com/
              Plataforma de ensino à distância que facilita de comunicação e colaboração entre os docentes e os estudantes.

              Coursera: https://www.coursera.org/
              Plataforma de ensino online que conta com uma variadade de MOOC's - Massive Open Online Courses. O aluno pode optar por pagar uma taxa para obter um certificado autenticado.

              Atelier Digital: https://learndigital.withgoogle.com/atelierdigitalportugal/course/digital-marketing
              Curso dedicado a bordar temas relacionados com o marketing digital contribuindo para o desenvolvimento da sua empresa ou carreira.

              edX: https://www.edx.org/
              Plataforma online orientada para a oferta de MOOC's - Massive Open Online Courses.



              Categorias

              * Ferramentas Digitais Úteis: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/small-pdf.png : https://smallpdf.com/
                          + Small PDF: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                É uma solução gratuita para todos os seus problemas com ficheiros PDF.

                          https://www.ulusofona.pt/media/diagrams-net.png : https://www.diagrams.net/
                          + Diagrams: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Tudo o que precisa para a criação de um diagrama profissional.

                          https://www.ulusofona.pt/media/infopedia.png : https://www.infopedia.pt/
                          + Infopédia: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Conjunto de dicionários da Porto Editora, gratuitos e disponíveis online.

                          https://www.ulusofona.pt/media/zoomit.png : https://docs.microsoft.com/en-us/sysinternals/downloads/zoomit
                          + ZoomIt: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Ferramenta de anotações para apresentações técnicas que envolvem demonstração de aplicações.

                          https://www.ulusofona.pt/media/word-to-html.png : https://wordtohtml.net/
                          + Word to HTML: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Carregue o seu texto em Word, PDF, ou outro e converta-o em HTML.

                          https://www.ulusofona.pt/media/lightshot.png : https://app.prntscr.com/
                          + LightShot: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                A forma mais rápida de fazer uma captura de ecrã (screenshot) personalizável.

                          https://www.ulusofona.pt/media/canvas.png : https://www.canva.com/
                          + Canva: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Crie imagens e posters de comunicação de forma prática, acessível e gratuita.

                          https://www.ulusofona.pt/media/miro.png : https://miro.com/
                          + Miro: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Quadro branco de colaboração em equipa escalável, seguro, entre dispositivos.

              * Ferramentas úteis para a interação do aluno: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/google-classroom.png : https://classroom.google.com/
                          + Google Classroom: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Google Classroom é o seu lugar central onde o ensino e a aprendizagem se unem. Essa ferramenta segura e fácil de usar ajuda os educadores a gerenciar, medir e enriquecer as experiências de aprendizado.

                          https://www.ulusofona.pt/media/edmodo.png : https://new.edmodo.com/
                          + Edmodo: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Edmodo é uma rede global de educação que ajuda a conectar todos os alunos com as pessoas e os recursos necessários para atingir seu pleno potencial.

                          https://www.ulusofona.pt/media/mentimeter.png : https://www.mentimeter.com/pt-BR
                          + Mentimeter: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Crie apresentações interativas com o editor online fácil de usar. Adicione perguntas, enquetes, questionários, slides, imagens, gifs e muito mais à sua apresentação para criar apresentações divertidas e envolventes.

                          https://www.ulusofona.pt/media/padlet.png : https://padlet.com/
                          + Padlet: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Padlet fornece um software como serviço baseado em nuvem, hospedando uma plataforma web colaborativa em tempo real na qual os usuários podem carregar, organizar e compartilhar conteúdo em quadros de avisos virtuais chamados "padlets".

                          https://www.ulusofona.pt/media/edpuzzle.png : https://edpuzzle.com/
                          + Edpuzzle: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O EDpuzzle é um aplicativo de eLearning baseado na web que permite aos usuários selecionar um vídeo e personalizá-lo editando, cortando, gravando seu próprio áudio e adicionando perguntas do quiz diretamente ao fluxo de vídeo.

                          https://www.ulusofona.pt/media/wooclap.png : https://www.wooclap.com/
                          + Wooclap: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Wooclap é uma plataforma eletrônica interativa usada para criar enquetes e questionários. Os usuários respondem a perguntas anonimamente por meio de dispositivos de tecnologia, como smartphones ou laptops.

              * Para Avaliação: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/kahoot.png : https://kahoot.com/
                          + Kahoot!: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Kahoot! é uma plataforma de aprendizagem baseada em jogos, usada como tecnologia educacional em escolas e outras instituições de ensino. Seus jogos de aprendizagem, "kahoots", são questionários de múltipla escolha gerados pelo usuário que podem ser acessados por meio de um navegador da web ou do aplicativo Kahoot. Kahoot! pode ser usado para revisar o conhecimento dos alunos, para avaliação formativa ou como uma pausa nas atividades tradicionais de sala de aula.

                          https://www.ulusofona.pt/media/quizizz.png : https://quizizz.com/
                          + Quizizz: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                A Quizizz é uma empresa indiana de software de criatividade com sede em Bengaluru, na Índia, que cria e vende uma plataforma gamificada de engajamento estudantil. O software é usado em aula, trabalhos em grupo, revisão pré-teste, avaliações formativas e questionários pop.

                          https://www.ulusofona.pt/media/socrative.png : https://www.socrative.com/
                          + Socrative: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O feedback imediato é uma parte vital do processo de aprendizagem. O Socrative oferece exatamente isso para a sala de aula ou escritório - uma maneira eficiente de monitorar e avaliar o aprendizado que economiza tempo para os educadores enquanto oferece interações divertidas e envolventes para os alunos.

                          https://www.ulusofona.pt/media/quizlet.png : https://quizlet.com/pt-br
                          + Quizlet: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Quizlet cria ferramentas de aprendizado simples que permitem que você estude qualquer coisa. Comece a aprender hoje com flashcards, jogos e ferramentas de aprendizagem — tudo de graça.

                          https://www.ulusofona.pt/media/poll-everywhere.png : https://www.polleverywhere.com/
                          + Poll Everywhere: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O produto da Poll Everywhere permite que o público e as salas de aula em mais de 100 países usem telefones celulares, "tratando assim a obsolescência" de dispositivos de resposta de hardware proprietários, também conhecidos como clickers.

                          https://www.ulusofona.pt/media/quizalize.png : https://www.quizalize.com/
                          + Quizalize: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                A melhor plataforma de quiz para salas de aula remotas ou presenciais. Envolva sua turma com questionários divertidos e padronizados. Obtenha dados instantâneos sobre o domínio do aluno. Atribua automaticamente atividades de acompanhamento diferenciadas.

              * Aplicativos de compartilhamento de arquivos: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/google-drive.png : https://drive.google.com/
                          + Google Drive: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Google Drive é um serviço de armazenamento e sincronização de arquivos desenvolvido pelo Google. Permite que os usuários armazenem arquivos na nuvem, sincronizem arquivos entre dispositivos e compartilhem arquivos. O Google Drive engloba o Google Docs, o Google Sheets e o Google Slides, que fazem parte do pacote de escritório do Google Docs Editors que permite a edição colaborativa de documentos, planilhas, apresentações, desenhos, formulários e muito mais. Os arquivos criados e editados por meio do pacote Google Docs são salvos no Google Drive.

                          https://www.ulusofona.pt/media/dropbox.png : https://www.dropbox.com
                          + Dropbox: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Dropbox é um serviço de hospedagem de arquivos operado pela empresa americana Dropbox, Inc., com sede em San Francisco, Califórnia, EUA, que oferece armazenamento em nuvem, sincronização de arquivos, nuvem pessoal e software cliente.

                          https://www.ulusofona.pt/media/one-drive.png : https://www.microsoft.com/pt-br/microsoft-365/onedrive/online-cloud-storage
                          + OneDrive: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Microsoft OneDrive é um serviço de hospedagem de arquivos que a Microsoft opera. Permite que usuários registrados compartilhem e sincronizem seus arquivos. O OneDrive também funciona como back-end de armazenamento da versão web do Microsoft Office. O OneDrive oferece 5 GB de espaço de armazenamento gratuito, com opções de armazenamento de 100 GB, 1 TB e 6 TB disponíveis separadamente ou com assinaturas do Office 365.

                          https://www.ulusofona.pt/media/we-transfer.png : https://wetransfer.com/
                          + WeTransfer: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                WeTransfer é a maneira mais simples de enviar seus arquivos ao redor do mundo. Compartilhe arquivos e fotos grandes. Transfira até 2 GB grátis. Compartilhamento de arquivos facilitado!

                          https://www.ulusofona.pt/media/mega.png : https://mega.io/
                          + Mega: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O MEGA fornece armazenamento em nuvem criptografado controlado pelo usuário que pode ser acessado por meio de navegadores padrão e aplicativos móveis. Ao contrário de outros provedores de armazenamento em nuvem, seus dados são codificados e descriptografados apenas por seus dispositivos, nunca por nós.

              * Ferramentas de Preparação de Apresentação: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/prezi.png : https://prezi.com/
                          + Prezi: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Ferramenta baseada na Web para criar apresentações (chamadas prezis). É semelhante a outros softwares de apresentação como o Microsoft PowerPoint, mas oferece alguns recursos exclusivos que o tornam uma boa alternativa. Se você deseja criar uma apresentação um pouco mais atraente e envolvente, o Prezi pode ser para você.

                          https://www.ulusofona.pt/media/powtoon.png : https://www.powtoon.com/
                          + Powtoon: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Powtoon é uma plataforma de comunicação visual projetada para ajudar as empresas a criar vídeos animados e apresentações para marketing, RH, TI, treinamento e muito mais. Com uma grande variedade de modelos pré-criados e um editor de arrastar e soltar, o Powtoon permite que empresas e equipes criem apresentações totalmente personalizadas.

                          https://www.ulusofona.pt/media/canva2.png/ : https://www.canva.com/pt_br/
                          + Canva: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Canva é usado para criar gráficos de mídia social, apresentações, pôsteres, documentos e outros conteúdos visuais. O aplicativo inclui modelos para os usuários usarem. A plataforma é gratuita e oferece assinaturas pagas, como Canva Pro e Canva for Enterprise, para funcionalidades adicionais.

                          https://www.ulusofona.pt/media/visme.png : https://www.visme.co/
                          + Visme: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Crie apresentações profissionais, infográficos interativos, design bonito e vídeos envolventes, tudo em um só lugar. O Visme oferece outros recursos, incluindo uma ampla variedade de fontes, imagens e ícones gratuitos para personalizar o conteúdo.

                          https://www.ulusofona.pt/media/genially.png : https://genial.ly/pt-br/
                          + Genially: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Use Genially, a ferramenta online mais poderosa para criar conteúdo interativo e animado. Surpreenda com suas criações.

              * Aplicativos de quadro interativo: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/jamboard.png : https://jamboard.google.com/
                          + Google Jamboard: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Jamboard é um quadro interativo digital desenvolvido pelo Google para funcionar com o Google Workspace, anteriormente conhecido como G Suite. Ele tem uma tela sensível ao toque 4K de 55" e pode ser usado para colaboração on-line usando o Google Workspace. O monitor também pode ser montado em uma parede ou configurado em um suporte.

                          https://www.ulusofona.pt/media/microsoft-whiteboard.png : https://www.microsoft.com/en-us/microsoft-365/microsoft-whiteboard/digital-whiteboard-app
                          + Microsoft Whiteboard: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Microsoft Whiteboard é uma tela infinita e colaborativa para reuniões eficazes e aprendizado envolvente. Você pode usar o Whiteboard para colaborar com outras pessoas e realizar muitas atividades, desde brainstorming e planejamento até aprendizado e workshops.

                          https://www.ulusofona.pt/media/miro2.png : https://miro.com/
                          + Miro: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Miro é a plataforma de quadro branco colaborativo on-line que permite que equipes distribuídas trabalhem juntas de maneira eficaz, desde brainstorming com notas adesivas digitais até planejamento e gerenciamento de fluxos de trabalho ágeis.

                          https://www.ulusofona.pt/media/explain-everything.png : https://explaineverything.com/
                          + Explain Everything: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O aplicativo de quadro interativo online onde as pessoas compartilham e aprendem sem limites. Junte-se a partir de qualquer dispositivo e colabore em tempo real visualmente e audivelmente. Transforme ideias em compreensão com Explique Tudo.

                          https://www.ulusofona.pt/media/stormboard.png : https://stormboard.com/
                          + Stormboard: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Use o espaço de trabalho compartilhado do Stormboard para gerar mais ideias e, em seguida, priorize, organize e refine essas ideias para tornar suas reuniões, brainstorms e projetos mais produtivos e eficazes.

              * Atividades a serem realizadas na Introdução e Ferramentas da Web Apropriadas: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/poster-my-wall.png : https://www.postermywall.com/
                          + PosterMyWall: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Apresentação Visual
                                O PosterMyWall é uma solução de design gráfico baseada em nuvem que ajuda as empresas a criar conteúdo, cabeçalhos e pôsteres personalizados para várias plataformas de mídia social e campanhas de marketing. Ele permite que os usuários importem fontes personalizadas para o sistema e baixem modelos de imagem e vídeo da biblioteca integrada.

                          https://www.ulusofona.pt/media/powtoon.png : https://www.powtoon.com/
                          + Powtoon: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Powtoon é uma plataforma de comunicação visual projetada para ajudar as empresas a criar vídeos animados e apresentações para marketing, RH, TI, treinamento e muito mais. Com uma grande variedade de modelos pré-criados e um editor de arrastar e soltar, o Powtoon permite que empresas e equipes criem apresentações totalmente personalizadas.

                          https://www.ulusofona.pt/media/phet.png : https://phet.colorado.edu/
                          + PhET: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Utilizando Simulação
                                Phet é uma simulação interativa baseada na web para ciências e matemática. Os professores têm acesso a dicas específicas de simulação e cartilhas em vídeo, recursos para ensino com simulações e atividades compartilhadas pela comunidade.

                          https://www.ulusofona.pt/media/voki.png : https://www.voki.com/
                          + Voki: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Voki é uma ferramenta educacional para professores e alunos, que pode ser usada para melhorar a instrução, o envolvimento e a compreensão das aulas. O Voki pode ser usado em sala de aula (para trabalhos dos alunos), como uma ferramenta de apresentação animada, para tarefas dos alunos e como um fórum de discussão virtual supervisionado (Voki Hangouts).

                          https://www.ulusofona.pt/media/cram.png : https://www.cram.com/
                          + Cram: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Flashcards é uma plataforma baseada no Leitner System, que ajuda os alunos a memorizar quase qualquer tipo de informação. Tabelas de multiplicação, listas de vocabulário, um novo idioma ou apenas definições antigas simples, os flashcards ajudarão a organizar as informações de uma maneira que ajude os alunos a aprender com mais eficiência.

              * Atividades a serem realizadas na Seção de Desenvolvimento e Ferramentas Web Apropriadas: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/prezi.png : https://prezi.com/
                          + Prezi: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Preparação da apresentação
                                Ferramenta baseada na Web para criar apresentações (chamadas prezis). É semelhante a outros softwares de apresentação como o Microsoft PowerPoint, mas oferece alguns recursos exclusivos que o tornam uma boa alternativa. Se você deseja criar uma apresentação um pouco mais atraente e envolvente, o Prezi pode ser para você.

                          https://www.ulusofona.pt/media/google-classroom.png : https://classroom.google.com/
                          + Google Classroom: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Interação na sala de aula virtual
                                O Google Classroom é o seu lugar central onde o ensino e a aprendizagem se unem. Essa ferramenta segura e fácil de usar ajuda os educadores a gerenciar, medir e enriquecer as experiências de aprendizado.

                          https://www.ulusofona.pt/media/moovly.png : https://www.moovly.com/
                          + Moovly: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Exibindo vídeo/animação
                                Moovly é uma solução de criação de vídeo projetada para ajudar empresas de todos os tamanhos e instituições de ensino a criar tutoriais ou vídeos promocionais usando uma combinação de imagens, vídeos, texto e voz enviados, modelos personalizáveis, bem como uma biblioteca de imagens, recursos visuais e áudios usando uma interface de arrastar e soltar. O sistema permite que os editores de vídeo baixem e publiquem os vídeos selecionados em várias plataformas, incluindo YouTube, Vimeo e Moovly's Gallery.

                          https://www.ulusofona.pt/media/piktochart.png : https://piktochart.com/
                          + Piktochart: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Utilizando infográficos
                                O Piktochart é uma ferramenta de design gráfico e criador de infográficos baseada na Web que permite que usuários sem experiência intensiva como designers gráficos criem facilmente recursos visuais, incluindo infográficos, relatórios, apresentações, pôsteres, folhetos e gráficos de mídia social, usando modelos personalizáveis.

                          https://www.ulusofona.pt/media/zoom.png : https://zoom.us/
                          + Zoom: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Vídeo conferência
                                Destaca-se por sua interface simples e usabilidade, independentemente do conhecimento tecnológico. Os recursos incluem reuniões individuais, videoconferências em grupo, compartilhamento de tela, plug-ins, extensões de navegador e a capacidade de gravar reuniões e transcrevê-las automaticamente. Em alguns computadores e sistemas operacionais, os usuários podem selecionar um plano de fundo virtual, que pode ser baixado de diferentes sites, para usar como pano de fundo atrás de si.

                          https://www.ulusofona.pt/media/mindmeister.png : https://www.mindmeister.com/
                          + Mindmeister: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Usando mapas mentais
                                O MindMeister é um aplicativo de mapeamento mental online que permite que seus usuários visualizem, compartilhem e apresentem seus pensamentos através da nuvem. Fornece uma maneira de visualizar informações em mapas mentais utilizando modelagem de usuário, além de fornecer ferramentas para facilitar a colaboração em tempo real, coordenar o gerenciamento de tarefas e criar apresentações.

                          https://www.ulusofona.pt/media/discord.png : https://discord.com/
                          + Discord: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Discord é um aplicativo gratuito de bate-papo por voz, vídeo e texto usado por dezenas de milhões de pessoas com mais de 13 anos para conversar e sair com suas comunidades e amigos
                                As pessoas usam o Discord diariamente para falar sobre muitas coisas, desde projetos de arte e viagens em família até trabalhos de casa e apoio à saúde mental. É um lar para comunidades de qualquer tamanho, mas é mais amplamente usado por grupos pequenos e ativos de pessoas que conversam regularmente.

                          https://www.ulusofona.pt/media/slack.png : https://slack.com/
                          + Slack: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                O Slack é um aplicativo de mensagens para empresas que conecta as pessoas às informações de que precisam. Ao reunir as pessoas para trabalhar como uma equipe unificada, o Slack transforma a forma como as organizações se comunicam.

                          https://www.ulusofona.pt/media/howspace.png : https://www.howspace.com/
                          + Howspace: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Howspace é uma plataforma de colaboração digital alimentada por IA que traz o aprendizado social para a vanguarda dos processos e iniciativas de desenvolvimento das organizações.

              * Atividades e Ferramentas Web Apropriadas na Seção de Resultados e Avaliação: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                          https://www.ulusofona.pt/media/tricider.png : https://www.tricider.com/
                          + Tricider: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Discutindo sobre um problema
                                Tricider é um site que oferece uma plataforma gratuita de brainstorming e votação para ajudar as pessoas a tomar decisões. Anunciado como uma "ferramenta de votação social", o site é voltado para equipes de negócios, turmas ou qualquer pessoa que queira avaliar a resposta de um grupo a uma ideia.

                          https://www.ulusofona.pt/media/live-work-sheets.png : https://www.liveworksheets.com/
                          + LiveWorkSheets: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Planilhas interativas
                                O Liveworksheets é uma ferramenta que permite aos professores criar planilhas interativas para seus alunos. Os professores carregam planilhas impressas tradicionais em PDF ou como documentos do Word e podem transformá-las em exercícios interativos usando diferentes formatos, como múltipla escolha, arrastar e soltar ou juntar as setas, que podem incluir áudios ou vídeos, se necessário. Também é possível criar exercícios de fala onde os alunos tenham que se gravar usando o microfone da ferramenta. Uma variedade de planilhas já criadas por outros usuários também podem ser acessadas.

                          https://www.ulusofona.pt/media/mentimeter.png : https://www.mentimeter.com/pt-BR
                          + Mentimeter: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Perguntas e respostas - Perguntas e respostas
                                Crie apresentações interativas com o editor online fácil de usar. Adicione perguntas, enquetes, questionários, slides, imagens, gifs e muito mais à sua apresentação para criar apresentações divertidas e envolventes.

                          https://www.ulusofona.pt/media/padlet.png : https://padlet.com/
                          + Padlet: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Colaborações
                                Padlet fornece um software como serviço baseado em nuvem, hospedando uma plataforma web colaborativa em tempo real na qual os usuários podem carregar, organizar e compartilhar conteúdo em quadros de avisos virtuais chamados "padlets".

                          https://www.ulusofona.pt/media/survey-monkey.png : https://www.surveymonkey.com/
                          + SurveyMonkey: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Realização de pesquisas
                                O SurveyMonkey é um software de pesquisa online que ajuda você a criar e executar pesquisas online profissionais. É muito poderoso e um aplicativo online bem conhecido.

                          https://www.ulusofona.pt/media/socrative.png : https://www.socrative.com/
                          + Socrative: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Criação de teste on-line
                                O feedback imediato é uma parte vital do processo de aprendizagem. O Socrative oferece exatamente isso para a sala de aula ou escritório - uma maneira eficiente de monitorar e avaliar o aprendizado que economiza tempo para os educadores enquanto oferece interações divertidas e envolventes para os alunos.

                          https://www.ulusofona.pt/media/word-wall.png : https://wordwall.net/
                          + Wordwall: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning

                                Gamificação
                                Uma parede de palavras é uma ferramenta de alfabetização composta por uma coleção organizada (normalmente em ordem alfabética) de palavras que são exibidas em grandes letras visíveis em uma parede, quadro de avisos ou outra superfície de exibição em uma sala de aula. A parede de palavras foi projetada para ser uma ferramenta interativa para alunos ou outras pessoas usarem e contém uma série de palavras que podem ser usadas durante a escrita e/ou leitura.


              Click - Portal de e-Learning: https://www.ulusofona.pt/click
                Aulas Síncronas: https://www.ulusofona.pt/click/aulas-sincronas
                Aulas Assíncronas: https://www.ulusofona.pt/click/aulas-assincronas
                Outras Ferramentas para e-Learning: https://www.ulusofona.pt/click/outras-ferramentas-para-e-learning
                Formações Online: https://www.ulusofona.pt/click/formacoes-online
        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona