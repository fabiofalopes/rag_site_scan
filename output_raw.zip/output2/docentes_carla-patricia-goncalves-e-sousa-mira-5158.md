# Response for https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
          PT: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158 EN: https://www.ulusofona.pt/en/teachers/carla-patricia-goncalves-e-sousa-mira-5158
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
        fechar menu : https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carla-patricia-goncalves-e-sousa-mira-5158
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carla Sousa

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5158
              car***@ulusofona.pt
              1A13-60F1-0B45: https://www.cienciavitae.pt/1A13-60F1-0B45
              0000-0003-1036-963X: https://orcid.org/0000-0003-1036-963X
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/34eda968-2247-4048-b774-2b0766368e78
      : https://www.ulusofona.pt/

        Resume

        Carla Sousa is a PhD in Communication Sciences from Lusófona University, where she also took her Bachelors Degree in Psychology, her Master's Degree in Clinical and Health Psychology, and a Postgraduate degree in Applied Neuropsychology. Her PhD thesis approached game accessibility as a path to empower and promote well-being in individuals with intellectual disability, which illustrates her main research targets - the different intersections between media, with a particular focus on games, inclusion, behavior, and human diversity. Also in Lusófona University, Carla is part of the Centre for Research in Applied Communication, Culture, and New Technologies (CICANT; https://doi.org/10.54499/UIDB/05260/2020) and is an assistant professor in the Bachelor's Degrees in Psychology and Videogames. She published several papers as an author and co-author in peer-reviewed journals, and has done communications at national and international conferences in the fields of media studies, media psychology, games, accessibility, disability, social inclusion, learning, and education. Carla has been part of several national and internationally funded projects, both in research and management roles, including: GameIN (2022.07939.PTDC); TEGA (2020-1-UK01-KA203-079248); ID-Games (2019-1-EL01-KA204-062517); Youth for Youth (2020-2-HU01-KA205-079126); ASDigital (2020-1-PT01-KA226-SCH-094961); or GamiLearning (UTAP-ICDT/IVC-ESCT/0020/2014). Carla has also been involved in the organization of scientific events and scientific networks, being the chair of Working Group 2 in COST Action (CA 19104) - advancing Social inclusion through Technology and EmPowerment (a-Step), which aims to map the best practices and define a research agenda for the future of assistive technologies for individuals with intellectual disability and autism. Since 2022, Carla has been an individual ambassador for the non-profit Women in Games and, since 2023, a member of the advisory board of the European Communication Research and Education Association (ECREA). She is also the editor of the International Journal of Games and Social Impact (ISSN 2975-8386).

        Graus

            * Licenciatura
              Psicologia [Psychology]
            * Mestrado
              Psicologia Clínica e da Saúde [Clinical and Health Psychology]
            * Pós-Graduação
              Neuropsicologia Aplicada [Applied Neuropsychology]
            * Doutoramento
              Ciências da Comunicação [Communication Sciences]

        Publicações

        Magazine article

          * 2023-05-17, Archaeologists discover ancient Mayan game - here is what it can teach modern educators, The Conversation UK
          * 2021, The Inclusion of People with Intellectual Disability in Media and Communication Research: Insights and Contributions from Haraway, Media Ethics - The Magazine Serving Mass Communication Ethics

        Physical object

          * 
          * 
          * 
          * 
          * 

        Journal issue

          * Special Issue 2022: Media Literacy and Civic Cultures
          * Media Literacy and Civic Cultures
          * International Journal of Games and Social Impact, 1(1), 1
          * Interaction, Challenge, and Learning: Innovations in Gaming for Serious Purposes, 8

        Journal article

          * 2024-02, Ética na Investigação com Pessoas com Deficiência Intelectual: Linhas Orientadoras e Materiais Acessíveis Para a Inclusão Plena, HUMANITAS - Nada do que é humano nos é alheio
          * 2024-01-15, Developing and Validating a Qualitative Tool for Playtesting Service Learning-Based Accessible Games: A Comprehensive Approach, EAI Endorsed Transactions on Creative Technologies
          * 2023-10-12, Investigating Inclusivity in Game-Based Learning: Current Practices and Multistakeholder Perspectives, European Conference on Games Based Learning
          * 2023-09-29, The Novelty of Collaboration: High School Students Learning and Enjoyment Perceptions When Playing Cooperative Modern Board Games, European Conference on Games Based Learning
          * 2023-09-29, The Dark Side of Fun: Understanding Dark Patterns and Literacy Needs in Early Childhood Mobile Gaming, European Conference on Games Based Learning
          * 2023-09-29, Mathematics and Sign Language Learning with a Tangible Game: An Inclusive Approach for DHH and Hearing Children, European Conference on Games Based Learning
          * 2023-09-29, Barriers and Hindrances to the Effective Use of Games in Education: Systematic Literature Review and Intervention Strategies, European Conference on Games Based Learning
          * 2023-09-01, [Roundtable] Analogue Co-Design: Opportunities, Challenges and Other Nuances, International Journal of Games and Social Impact
          * 2023-06-15, Game-Based Learning in Higher Education Using Analogue Games, International Journal of Film and Media Arts
          * 2023-06-15, Editorial - Games and Learning: Consolidating and Expanding the Potential of Analogue and Digital Games, International Journal of Film and Media Arts
          * 2023-06-02, Playing at the school table: Systematic literature review of board, tabletop, and other analog game-based learning approaches, Frontiers in Psychology
          * 2023-01-01, Editorial, International Journal of Games and Social Impact
          * 2022-10-31, Mapping the Inclusion of Children and Youth With Disabilities in Media Literacy Research, Media and Communication
          * 2022-07-01, Intellectual disability through gaming: Operationalizing accessibility, participation and inclusion, Journal of Gaming & Virtual Worlds
          * 2022-04-26, Empowerment and Well-Being Through Participatory Action Research and Accessible Gaming: A Case Study With Adults With Intellectual Disability, Frontiers in Education
          * 2022-01-25, The Pedagogical Value of Creating Accessible Games: A Case Study with Higher Education Students, Multimodal Technologies and Interaction
          * 2022-01-06, Exploring the Feasibility of Game-Based Tangible Resources in the Teaching of Deaf Preschoolers and their Hearing Peers, Journal of Educational Studies and Multidisciplinary Approaches
          * 2020, Empowerment and ownership in intellectual disability gaming: review and reflections towards an able gaming perspective (2010-2020), International Journal of Film and Media Arts
          * 2019-12-01, Game creation to promote media and information literacy (MIL) skills in basic education teachers, Revista Lusófona de Educação
          * 2019-10-01, Game Review: EVERYTHING, DAVID OREILLY (2017), Journal of Gaming & Virtual Worlds
          * 2018-09-01, Videogames as a learning tool: is game-based learning more effective?, Revista Lusófona de Educação
          * 2018-09-01, Desenvolvimento e Validação da Escala de Literacia Mediática e Informacional para Alunos dos 2º e 3º Ciclos do Ensino Básico em Portugal, Revista LUsófona de Educação
          * 2018-04, Game Creation in Youth Media and Information Literacy Education, International Journal of Game-Based Learning
          * 2017, Playing digital security: Youth voices on their digital rights, International Journal of Game-Based Learning
          * 2016, A review of research questions, theories and methodologies for game- based learning, Journal of Content, Community and Communication

        Book

          * 2023, Do Tokenismo à Autodeterminação: Considerações Éticas na Investigação com Pessoas com Deficiência Intelectual, 1, Casimiro, Cátia; Sousa, Carla; Luz, Filipe Soares Branco da Costa; Oliveira, Jorge; Loureiro, Ana, Edições Universitárias Lusófonas
          * 2023, Book: Media Literacy and Assistive Technologies for Empowerment in Autism, Sousa, Carla; Tkaczyk, Alan H., Edições Universitárias Lusófonas

        Book chapter

          * 2024, Videogame Students in Portuguese Higher Education: Perceptions, Motivations, and Playing Habits – A Case Study, Communications in Computer and Information Science, Springer Nature Switzerland
          * 2023, The Potential Role of TEACCH and PECS for Secondary Education Students With a Focus on Literacy, Media Literacy and Assistive Technologies for Empowerment in Autism, Edições Universitárias Lusófonas
          * 2023, The Dark Side Of Early Childhood Mobile Gaming, The Children’s Media Yearbook 2023, 1, 1, The Children's Media Foundation
          * 2023, PART I: Autism, Diversity, and Media Literacy – Introduction, Media Literacy and Assistive Technologies for Empowerment in Autism, Edições Universitárias Lusófonas
          * 2023, Gaming, Assistive Technologies, and Neurodiversity, Media Literacy and Assistive Technologies for Empowerment in Autism, Edições Universitárias Lusófonas
          * 2023, Developing Playful and Tangible Approaches to the Gap Between Academia and Civil Society: Inclusion, and Access Through Participatory Action-Research, ArtsIT 2022: ArtsIT, Interactivity and Game Creation - Lecture Notes of the Institute for Computer Sciences, Social Informatics and Telecommunications Engineering, Springer
          * 2023, Decoding the Digital Landscape: Media Literacy for Autism Spectrum Disorder, Media Literacy and Assistive Technologies for Empowerment in Autism, Edições Universitárias Lusófonas
          * 2020, Media and Information Literacy (MIL) for social integration of Portuguese youth, Media and information literacy in critical times: Re-imagining learning and information environments, UNESCO Chair on Media and Information Literacy for Quality Journalism Faculty of Communication Sciences, Autonomous University of Barcelona (UAB)
          * 2020, Evaluation of the Effectiveness of Game Creation by Youth for Media and Information Literacy, Global Perspectives on Gameful and Playful Teaching and Learning, IGI Global
          * 2019, Media and ICT as Promoters of School Readiness: Beliefs from Parents and Young Children, Crianças, famílias e tecnologias. Que desafios? Que caminhos?, Escola Superior de Educação do Instituto Politécnico de Lisboa

        Edited book

          * 2021, Universidade Lusófona

        Report

          * 2023-12, YouNDigital: Relatório Survey - Task 3, https://drive.google.com/file/u/2/d/14_ec1kPXWhFyWCa1uN4MrIYIBgdj2_Zc/view?usp=sharing
          * 2023, YouNDigital - Relatório Revisão de Literatura PRISMA (fase 2), https://drive.google.com/file/d/1JodRcmcZXUm99Kj3rF6Mxg0lOELPq3NF/view
          * 2021-09-30, Media Technology and Educational Innovation, http://dx.doi.org/10.13140/RG.2.2.11321.29287
          * 2019-11, People with Intellectual Disability in Portugal - Report, http://recil.grupolusofona.pt/handle/10437/10170
          * 2017-12-26, State of Art in Web Forms (2012-2017) - A literature Review in HCI field , https://lightweightform.io/wp-content/uploads/2018/07/State-of-Art-in-Web-Forms-HCI-Field.pdf

        Online resource

          * 2021-11-01, OPERAT - laboratory for research and production on tangible accessible resources, https://operat.ulusofona.pt

        Conference paper

          * Towards Cognitive Accessibility in Digital Game Design: Evidence-Based Guidelines for Adults with Intellectual Disability, 2023 IEEE Conference on Games (CoG)
          * Níveis de Literacia Mediática em estudantes do 2º e 3º ciclos do ensino básico em Portuga, 5º Congresso Literacia, Media e Cidadania
          * 2024-04-22, Perceptions of Inclusion Professionals on Employability of Individuals With Intellectual and Developmental Disabilities: a Transnational Study, International Psychological Applications Conference and Trends (InPACT) 2024
          * 2023-07-09, GameIN: Proposing Methodological Disruptions in the Study of Inclusive Games, IAMCR 2023 Lyon - Inhabiting the planet: Challenges for media, communication and beyond
          * 2022-11-07, An Accessible and Inclusive Future for Tabletop Games and Learning: Paradigms and Approaches, 15th annual International Conference of Education, Research and Innovation - ICERI 2023
          * 2022-10-06, Inclusive AR-games for Education of Deaf Children: Challenges and Opportunities, 16th European Conference on Games Based Learning - ECGBL 2022
          * 2021-10-23, GBL for Psychological Intervention Related Skills: What Challenges? What Paths?, 15th European Conference on Game-Based Learning (ECGBL 2021)
          * 2020-12-11, Formação online e capacitação para a utilização, criação e co-criação de jogos como estratégia de inclusão de pessoas com deficiência intelectual: Experiências de um projeto europeu, V Encontro do Obervatório da Deficiência e Direitos Humanos (ODDH) - A deficiência face à crise pandémica: Desafios e respostas
          * 2020-09-09, Research in serious games for people with intellectual disability: a meta-analysis study, 13th International Conference on Disability, Virtual Reality & Associated Technologies - ICDVRAT 2020
          * 2020-08-24, Developing a participatory game creation e-course in the field of Intellectual Disability, IEEE Conference of Games 2020
          * 2020-05-15, Conceção de um e-course sobre processos participativos na criação de jogos como estratégia de capacitação na área da Deficiência Intelectual, 5º Encontro sobre Jogos e Mobile Learning 2020
          * 2019-10-03, Games for Education of Deaf Students: A Systematic Literature Review, 12th European Conference on Game Based Learning - ECGBL2019
          * 2019-10-03, Developing Pedagogical Videogames to Support Math Learning in Deaf Children: A Work in Progress (Phases 1-3)., 13th European Conference on Games Based Learning - ECGBL 2019
          * 2019-07-01, Cognitive Foundations of Mathematics Learning in Deaf Students: a Systematic Literature Review, 11th International Conference on Education and New Learning Technologies - EDULEARN 2019
          * 2018-10-04, Making games, making literacy: A case-study in formal educational contexts, 12th European Conference on Games Based Learning - ECGBL 2018
          * 2018-04-19, A Case Study of Production and Application of Video Games for Teaching Mathematics to Deaf People, Play2Learn - The GamiLearning Conference
          * 2017-07-03, Games for Media and Information Literacy - Developing Media and Information Literacy skills in children through digital games creation, 9th International Conference on Education and New Learning Technologies - EDULEARN2017
          * 2017-07-03, Are Videogames a waste of time? - A multi-stakeholder approach, 9th International Conference on Education and New Learning Technologies - EDULEARN 2017
          * 2017-07, Digital game creation for media and information literacy development in children, ECGBL 2017
          * 2017-03-06, Drivers and Motivations to Game-Based Learning approaches - A perspective from parents and teachers, 11th International Technology, Education and Development Conference - INTED2017
          * 2016-10-13, The effect of virtual reality-based serious games in cognitive interventions: A meta-analysis study, 4th Workshop on ICTs for improving patients rehabilitation research tecniques - REHAB '16

        Conference poster

          * 2019-12-13, A eficácia das intervenções baseadas em videojogos na promoção de competências em pessoas com deficiência intelectual, IV Encontro ODDH - Deficiência, Políticas Públicas e Direitos Humanos
          * 2019-07-02, Development and Validation of the Media and Information Literacy Scale (MILS) for the 2nd and 3rd Cycle of Basic Education in Portugal, XVI European Congress of Psychology, Moscow, Russia
          * 2019-03, Rastreio Neuropsicológico e Estudo das Associações entre Metacognição e Sintomatologia em Indivíduos com Perturbação de Consumo de Substâncias: Estudo Exploratório Preliminar, V Congresso Nacional da Sociedade Portuguesa da Psicossomática: Re-Pensar a Psicossomática
          * 2018-10-31, Measuring media and information literacy (MIL) among students aged 9 to 14 years old from Portugal and Austin, 7th European Communication Conference - ECREA 2018
          * 2016-10-13, Reabilitação Neuropsicológica na Esquizofrenia: um estudo de revisão, I Encontro de Psiquiatria da Casa de Saúde da Idanha
          * 2016-05-23, Games for Media and Information Literacy Learning: Objectives, Research Design and recent Outcomes, UT-Austin I Portugal Conference
          * 2015-11-19, Recovery em utentes da Casa de Saúde da Idanha integrados num programa de reabilitação na comunidade, XI Congresso Nacional de Psiquiatria

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona