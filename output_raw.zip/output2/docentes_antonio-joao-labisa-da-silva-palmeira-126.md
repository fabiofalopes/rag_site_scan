# Response for https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
          PT: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126 EN: https://www.ulusofona.pt/en/teachers/antonio-joao-labisa-da-silva-palmeira-126
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
        fechar menu : https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/antonio-joao-labisa-da-silva-palmeira-126
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          António João Labisa Da Silva Palmeira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p126
              ant***@ulusofona.pt
              EC1F-4BD0-B070: https://www.cienciavitae.pt/EC1F-4BD0-B070
              0000-0001-6508-0599: https://orcid.org/0000-0001-6508-0599
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/6bf3d387-62a2-4576-97f0-6e3f63aeb756
      : https://www.ulusofona.pt/

        Resume

        António João Labisa da Silva Palmeira. Concluiu o(a) Título de Agregado em Educação Física e Desporto em 2021/07/06 pelo(a) Universidade Lusófona de Humanidades e Tecnologias, Doutoramento em Saúde e Condição Física em 2009 pelo(a) Universidade de Lisboa, Mestrado em Psicologia do Desporto em 1999 pelo(a) Universidade de Lisboa e Licenciatura em Educação Física e Desporto em 1993 pelo(a) Universidade de Lisboa. É Professor Associado com Agregação no(a) Universidade Lusófona de Humanidades e Tecnologias, Director Executivo no(a) International Society for Behavioral Nutrition and Physical Activity, Coordenador do CIDEFES no(a) Coordenação Científico-Pedagógica do Mestrado em Exercício e Bem-Estar e do Doutoramento em Educação Física e Desporto, área de Actividade Física e Saúde na Universidade Lusófona. Publicou 116 artigos em revistas especializadas. Publicou 4 capítulo(s) de livros e 4 livro(s). Organizou diversos eventos internacionais evento(s). Orientou 5 tese(s) de doutoramento. Orientou meia-centena de dissertação(ões) de mestrado . Recebeu 6 prémio(s) e/ou homenagens. Participa e/ou participou como Investigador em 7 projeto(s) e Investigador responsável em 1 projeto(s). Atua na(s) área(s) de Ciências Médicas e da Saúde com ênfase em Ciências da Saúde. Nas suas atividades profissionais interagiu com 417 colaborador(es) em coautorias de trabalhos científicos. No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural são: Physical Activity; Imagem Corporal; Quality of Life; Cirurgia Bariátrica; Exercise; Weight Maintenance; Eating Behaviors; Subjective Well-Being; Distúrbios alimentares; Cross-Cultural; Adolescentes; Exercise Motivation; Video-Games; Peso; Prediction; Sleep; Body Composition; Qualidade de Vida; Ansiedade Competitiva; Metabolism; Weight Management; Body Image; Obesity; Controlo do peso; Actividade Física; Obesidade; Aptidão Cardiorespiratória; Children; Women; Exercise Dependence; Mulheres; Nutrition; Ginastas; Psychometric Validation; Psychosocial Variables; Adolescents; Obesidade Adolescente ; Tratamento ; E-terapia; Família; Exercício Físico; Obesidade e Nutrição; Auto-Regulação Comportamental; Avaliação; Obesidade Adolescente; Tratamento; Pares; Actividade física; Estilo de vida; Escola; Saúde; Fiscalidade; Nutrição; Comportamento Sedentário; Psicologia; Motivation; University Students; Comportamentos de movimento; Saúde pública; .

        Graus

            * Mestrado
              Psicologia do Desporto
            * Doutoramento
              Doutoramento em Saúde e Condição Física
            * Licenciatura
              Educação Física e Desporto
            * Título de Agregado
              Educação Física e Desporto

        Publicações

        Artigo em revista

          * 2023-10-27, Are motivational and self-regulation factors associated with 12 months’ weight regain prevention in the NoHoW study? An analysis of European adults, International Journal of Behavioral Nutrition and Physical Activity
          * 2023-10, Comparing self-reported energy intake using an online dietary tool with energy expenditure by an activity tracker, Nutrition
          * 2023-08-02, The bioelectrical impedance analysis (BIA) international database: aims, scope, and call for data, European Journal of Clinical Nutrition
          * 2023-07, Exploring the impact of individualized pleasure-oriented exercise sessions in a health club setting: Protocol for a randomized controlled trial, Psychology of Sport and Exercise
          * 2023-06, Discrepancies Between Self-reported and Objectively Measured Smartphone Screen Time: Before and During Lockdown, Journal of Prevention
          * 2023-01-02, Intervention and mediation effects of a community-based singing group on older adults’ perceived physical and mental health: the Sing4Health randomized controlled trial, Psychology & Health
          * 2023-01-02, Experiência profissional e formação académica dos profissionais de exercício físico: relação das pressões no trabalho com as necessidades psicológicas básicas no contexto laboral, Retos
          * 2022-12-12, Employee perceptions of non-communicable diseases health risks, absenteeism and the role of organisational support in a South African pharmaceutical manufacturing company, PLOS ONE
          * 2022-11-20, Motivational and self-efficacy reciprocal effects during a 12-month' weight regain prevention program, British Journal of Health Psychology
          * 2022-11-06, What goes on in digital behaviour change interventions for weight loss maintenance targeting physical activity: A scoping review, Digital Health
          * 2022-07-07, The Long-Term Association between Physical Activity and Weight Regain, Metabolic Risk Factors, Quality of Life and Sleep after Bariatric Surgery, International Journal of Environmental Research and Public Health
          * 2022-05-03, A Coach Development Program: A Guided Online Reflective Practice Intervention Study, Journal of Sports Sciences
          * 2022-04-14, Evaluation of the Immediate Effects of Web-Based Intervention Modules for Goals, Planning, and Coping Planning on Physical Activity: Secondary Analysis of a Randomized Controlled Trial on Weight Loss Maintenance, Journal of Medical Internet Research
          * 2021-12-03, A Theory- and Evidence-Based Digital Intervention Tool for Weight Loss Maintenance (NoHoW Toolkit): Systematic Development and Refinement Study, Journal of Medical Internet Research
          * 2021-08-27, Actividad física en tiempo libre en estudiantes universitarios y transición escolar a la universidad desde las teorías de comportamiento: una revisión sistemática (Leisure-time in physical activity in university students and school transition to universi, Retos
          * 2021-05-19, Procesos motivacionales hacia la actividad física en el contexto escolar en estudiantes universitarios colombianos: un estudio desde la teoría de la autodeterminación, Educación Física y Deporte
          * 2021-03-04, The H2020 "NoHoW Project": A Position Statement on Behavioural Approaches to Longer-Term Weight Management. , Obesity facts
          * 2021-03-01, Development and cross-cultural validation of the Goal Content for Weight Maintenance Scale (GCWMS)., Eating and weight disorders : EWD
          * 2021-01-22, Running prevalence in Portugal: Socio-demographic, behavioral and psychosocial characteristics., PloS one
          * 2021, Keep on running – a randomized controlled trial to test a digital evidence-based intervention for sustained adoption of recreational running: rationale, design and pilot feasibility study, Health Psychology and Behavioral Medicine
          * 2020-12, Sing4Health: protocol of a randomized controlled trial of the effects of a singing group intervention on the well-being, cognitive function and health of older adults, BMC Geriatrics
          * 2020-12, A systematic review of intrapersonal coach development programs: Examining the development and evaluation of programs to elicit coach reflection, International Journal of Sports Science & Coaching
          * 2020-12, A Narrative Review of Motor Competence in Children and Adolescents: What We Know and What We Need to Find Out, International Journal of Environmental Research and Public Health
          * 2020-11-26, Everything counts in sending the right message: science-based messaging implications from the 2020 WHO guidelines on physical activity and sedentary behaviour, International Journal of Behavioral Nutrition and Physical Activity
          * 2020-11-03, The impact of early body-weight variability on long-term weight maintenance: exploratory results from the NoHoW weight-loss maintenance intervention, International Journal of Obesity
          * 2020-09, Body weight variability is not associated with changes in risk factors for cardiometabolic disease, International Journal of Cardiology Hypertension
          * 2020-07-26, The Dark Side of Motivational Practices in Exercise Professionals: Mediators of Controlling Strategies, International Journal of Environmental Research and Public Health
          * 2020-07-16, Consistent sleep onset and maintenance of body weight after weight loss: An analysis of data from the NoHoW trial, PLOS Medicine
          * 2020-05, Neck circumference is associated with adipose tissue content in thigh skeletal muscle in overweight and obese premenopausal women., Scientific reports
          * 2020-04, Weekly, seasonal and holiday body weight fluctuation patterns among individuals engaged in a European multi-centre behavioural weight loss maintenance intervention., PloS one
          * 2020-01-27, Data imputation and body weight variability calculation using linear and non-linear methods in data collected from digital smart scales: a simulation and validation study (Preprint), JMIR mHealth and uHealth
          * 2020-01-16, OBEDIS Core Variables Project: European Expert Guidelines on a Minimal Core Set of Variables to Include in Randomized, Controlled Clinical Trials of Obesity Interventions, Obesity Facts
          * 2020-01-14, Association between objectively measured sleep duration, adiposity and weight loss history, International Journal of Obesity
          * 2020-01-08, Motivation: key to a healthy lifestyle in people with diabetes? Current and emerging knowledge and applications, Diabetic Medicine
          * 2020, A novel scaling methodology to reduce the biases associated with missing data from commercial activity monitors (vol 15, e0235144, 2020), Plos One
          * 2019-12-03, The validity of two widely used commercial and research-grade activity monitors, during resting, household and activity behaviours, Health and Technology
          * 2019-09, The NoHoW protocol: a multicentre 2×2 factorial randomised controlled trial investigating an evidence-based digital toolkit for weight loss maintenance in European adults, BMJ Open
          * 2019-06-18, Development and preliminary validation of the Coach Interpersonal Style Observational System, International Journal of Sports Science & Coaching
          * 2019, Perceived Environmental Supportiveness Scale: Portuguese Translation, Validation and Adaptation to the Physical Education Domain, Motriz: Revista de Educação Física
          * 2018-10-11, The Behavioral Regulation in Exercise Questionnaire (BREQ-3) Portuguese-Version: Evidence of Reliability, Validity and Invariance Across Gender, Frontiers in Psychology
          * 2018, Prevalence of recreational running and behavioral characteristics of Portuguese runners: The Keep on Running national survey, Journal of Physical Activity and Health
          * 2018, Preliminary development of the Portuguese Coach Motivation Questionnaire, International Journal of Sports Science & Coaching
          * 2018, Preliminary development of the Portuguese Coach Motivation Questionnaire (CMQ-P), International Journal of Sports Science & Coaching
          * 2018, How does frustration make you feel? A motivational analysis in exercise context, Motivation and Emotion
          * 2018, Effectiveness of High-Intensity Interval Training on cardiorespiratory fitness and body composition in preadolescents: A systematic review, European Journal of Human Movement
          * 2017, “What Goes Around Comes Around¿?: Antecedents, Mediators, and Consequences of Controlling vs. Need-Supportive Motivational Strategies Used by Exercise Professionals, Annals of Behavioral Medicine
          * 2017, Understanding the Motivational Strategies Used by Exercise Professionals: A Latent Profile Analysis Approach, Medicine & Science in Sports & Exercise
          * 2017, Project PANK: Rationale, study protocol and baseline results of a multidisciplinary school based intervention in children with cardiovascular and metabolic risk factors, Motriz: Revista de Educação Física
          * 2017, Associations between affect, basic psychological needs and motivation in physical activity contexts: Systematic review and meta-analysis, Revista Iberoamericana de Psicología del Ejercicio y el Deporte
          * 2017, A bifactor exploratory structural equation modeling representation of the structure of the basic psychological needs at work scale, Journal of Vocational Behavior
          * 2016, Needs satisfaction effect on exercise emotional response: A serial mediation analysis with motivational regulations and exercise intensity, Motriz. Revista de Educacao Fisica
          * 2016, Longitudinal Relationship between Cardiorespiratory Fitness and Academic Achievement, Medicine & Science in Sports & Exercise
          * 2016, Is Participatory Design Associated with the Effectiveness of Serious Digital Games for Healthy Lifestyle Promotion? A Meta-Analysis, J Med Internet Res
          * 2016, Expectation and beliefs: Influence on health based on physical exercise | Expectativas e crenças: Influência na saúde tendo por base o exercício físico, Revista Iberoamericana de Psicologia del Ejercicio y el Deporte
          * 2015-10, Physical activity and cardiorespiratory fitness, but not sedentary behavior, are associated with carotid intima-media thickness in obese adolescents., European Journal of Pediatrics
          * 2015, Weight management program based on self-determination theory: comparing parents-child data, Psicologia, Saúde e Doenças
          * 2015, The Yin and Yang of Formative Research in Designing Serious (Exer-)games, Games for Health Journal
          * 2015, The TOP Program: Treatment of Pediatric Obesity, Journal of Adolescent Health
          * 2015, The Impact of Moderate Weight Loss on the Metabolic Profile and Inflammatory Condition of Overweight Adolescents, Journal of Adolescent Health
          * 2015, Social support influences on eating awareness in children and adolescents: the mediating effect of self-regulatory strategies, Global Public Health
          * 2015, Project PANK: prediction of nutritional status and cardiorespiratory fitness evolution in a multidisciplinary school-based intervention with children with cardiovascular and metabolic risk factors, European Journal of Clinical Nutrition
          * 2015, Programa De Gestão Do Peso Baseado Na Teoria Da Autodeterminação: Comparação De Dados De Pais-Filhos, Psicologia, Saúde & Doença
          * 2015, Cross-sectional and prospective associations between moderate to vigorous physical activity and sedentary time with adiposity in children, International Journal of Obesity
          * 2015, Competitive anxiety, competitiveness and vulnerability to sports injury: Risk profiles | Ansiedad competitiva, competitividad y vulnerabilidad a la lesión deportiva: Perfiles de riesgo, Revista Iberoamericana de Psicologia del Ejercicio y el Deporte
          * 2015, COMPETITIVE ANXIETY, COMPETITIVENESS AND VULNERABILITY TO SPORTS INJURY: RISK PROFILES, Revista Iberoamericana de Psicologia del Ejercicio Y el Deporte
          * 2015, Ansiedad competitiva, competitividad y vulnerabilidad a la lesión deportiva: perfiles de riesgo, Revista Iberoamericana de Psicologia del Ejercicio y del Deporte
          * 2015, Analysis of the indirect effects of the quality of motivation on the relation between need satisfaction and emotional response to exercise, International Journal of Sport Psychology
          * 2014, Racional e principais resultados de um programa de tratamento da obesidade pediátrica: o TOP (Tratamento da Obesidade Pediátrica), Factores de Risco
          * 2014, Managing paediatric obesity: a multidisciplinary intervention including peers in the therapeutic process, BMC Pediatrics
          * 2014, Lesiones deportivas y personalidad: una revisión sistemática, Apunts. Medicina de l'Esport
          * 2014, Fitness, fatness, and academic performance in seventh-grade elementary school students, BMC Pediatrics
          * 2014, Effect of a school-based intervention on physical activity and quality of life through serial mediation of social support and exercise motivation: the PESSOA program, Health Education Research
          * 2013, Priming, mindfulness e efeito placebo. Associação com a saúde, exercício físico e actividade física não programada. Uma revisão sistemática da literatura, Revista Andaluza de Medicina del Deporte
          * 2013, Priming, mindfulness and placebo effect. Association with health, physical exercise and non-structured physical activity. A systematic review of the literature | Priming, mindfulness e efeito placebo. Associação com a saúde, exercício físico e actividade física não programada. Uma revisão sistemática da literatura, Revista Andaluza de Medicina del Deporte
          * 2013, Active Video Games – An Opportunity for Enhanced Learning and Positive Health Effects?, The International Journal of cognitive technology
          * 2012-07, ESTUDO DA BASIC NEED SATISFACTION IN GENERAL SCALE PARA A LÍNGUA PORTUGUESA, Psic., Saúde & Doenças
          * 2012, Usefulness of Standard BMI Cut-Offs for Quality of Life and Psychological Well-Being in Women, Obesity Facts
          * 2012, The Role of Self-Determination Theory and Motivational Interviewing in Behavioral Nutrition, Physical Activity, and Health: An Introduction to the IJBNPA Special Series, International Journal of Behavioral Nutrition and Physical Activity
          * 2012, The Influence of Physical Activity on Obesity and Health, Journal of Obesity
          * 2012, Short- and medium-term impact of a residential weight-loss camp for overweight adolescents, International Journal of Adolescent Medicine and Health
          * 2012, Motivation, self-determination, and long-term weight control, International Journal of Behavioral Nutrition and Physical Activity
          * 2011, The Importance of Importance in the Physical Self: Support for the Theoretically Appealing but Empirically Elusive Model of James, Journal of Personality
          * 2011, LONGITUDINAL OUTCOMES OF A SCHOOL-BASED LIFESTYLE PROMOTION PROGRAM: PRELIMINARY RESULTS, Journal of Adolescent Health
          * 2011, Autonomy support in strength and conditioning, Sport Scientific And Practical Aspects
          * 2010, INFLUENCE OF CARDIORESPIRATORY FITNESS AND BODY SIZE DISSATISFACTION ON THE RELATION BETWEEN BMI AND QUALITY OF LIFE IN ADOLESCENTS, Journal of Adolescent Health
          * 2010, Helping overweight women become more active: Need support and motivational regulations for different forms of physical activity¿, Psychology of Sport and Exercise
          * 2010, Efeitos Agudos da Sequência de Exercício Aeróbio e de Resistência Muscular no Metabolismo Energético: Um Estudo com Adolescentes Obesos , Gymnasium
          * 2010, Change in body image and psychological well-being during behavioral obesity treatment: Associations with weight loss and maintenance, Body Image
          * 2010, Associações entre auto-conceito físico e motivação para o exercício em adolescentes: interacções com o nível de prática e o género, Revista de Educação Física do Exército
          * 2010, Análise do poder preditivo da Teoria do Comportamento Planeado na Adesão ao exercício, Gymnasium
          * 2010, ADOLESCENT RESIDENTIAL SUMMER WEIGHT-LOSS CAMPS CAN WORK: SHORT-TERM OUTCOMES, Journal of Adolescent Health
          * 2009-07-01, Fitness versus fatness and quality of life: analysis of the influence of the cardiorespiratory fitness on the weight related quality of life of adolescents, Fit Per J
          * 2009, UMA ANÁLISE DO PARADIGMA FITNESS VS FATNESS NA QUALIDADE DE VIDA: INFLUÊNCIA DA APTIDÃO CARDIORESPIRATÓRIA NO IMPACTO DO PESO NA QUALIDADE DE VIDA DE ADOLESCENTES, Fitness e Performance
          * 2009, The Role of Personality Causality Orientations in Overweight Women Seeking Behavioral Weight Loss Treatment, Obesity
          * 2009, Reciprocal effects among changes in weight, body image, and other psychological factors during behavioral obesity treatment: A mediation analysis, IJBNPA
          * 2009, Mediators of weight loss and weight loss maintenance in middle-aged women, Obesity
          * 2009, Mediators of Different Types of Physical Activity During Behavioral Obesity Treatment, Obesity
          * 2008, Factorial validity and invariance testing of the exercise dependence scale- revised in swedish and portuguese regular exercisers., Measurement in Physical Education and Sport Sciences.
          * 2008, Exercício Físico num programa de controlo de peso: Associação com a qualidade de vida, bem-estar subjectivo e peso corporal. , Endocrinologia, diabetes e obesidade
          * 2008, Exercise Behavioral Regulations Mediation of the Relationship between Exercise and Subjective Well-Being, Journal of the Coimbra Network in Sport Science
          * 2007, Usefulness of different techniques for measuring body composition changes during weight loss in overweight and obese women., British Journal of Nutrition
          * 2007, Predicting short-term weight loss using four leading health behavior change theories, International Journal of Behavioral Nutrition and Physical Activity
          * 2007, Decreases in insulin sensitivity are associated with liver fat independent of abdominal and thigh adipose tissue in overweight and obese women, International Journal of Obesity
          * 2007, Anthropometric predictors of total body fat mass, trunk, and abdominal fat mass changes in overweight and obese women in a short-term weight loss program, International Journal of Obesity
          * 2006, Weight loss and physical activity impact on bone mineral density in overweight pre-menopausal women., Journal of Bone and Mineral Research
          * 2005, Psychometric and cross-national evaluation of a Portuguese version of the Impact of Weight on Quality of Life-Lite (IWQOL-Lite) questionnaire, European Eating Disorders Review
          * 2005, Prospective predictors of physical activity, motivational stage of change, and weight loss in overweight women, Obesity Research
          * 2005, Impact of behavioral obesity treatment on quality of life and psychological well-being: Analyzing the relative role of maintenance program and weight loss, Obesity Research
          * 2005, Effects of a 16-month weight management program on abdominal and thigh body composition compartments in overweight and obese women, Obesity Research
          * 2005, Body composition changes in a weight management program: A randomized controlled trial with overweight and obese women, Obesity Research
          * 2004, Who will lose weight? A reexamination of predictors of weight loss in women, International Journal of Behavioral Nutrition and Physical Activity
          * 2004, Predicting changes in weight and physical activity level during short-term lifestyle obesity treatment, Obesity Research
          * 2004, Meal patterns and weight reduction during behavioral obesity treatment in women, International Journal of Obesity
          * 2004, Does weekend exercise enhance weight management? Six-month results from a randomized controlled trial in women, Obesity Research
          * 2004, Body composition and muscle mass quality in premenopausal overweight and obese women, Obesity Research
          * 2004, Associations between objectively measured physical activity and abdominal and thigh adipose tissue in overweight and obese women, Obesity Research
          * 2004, Are individuals volunteering for university-based weight control programs different than the general overweight population?, Obesity Research
          * 2003, Quality of life in women participating or not participating in weight reduction, Obesity Research
          * 2000-06, [Predictability and rehabilitation of athletic injuries: effects of life style, coping ability, and personality]
          * 2000, Predictability and rehabilitation of athletic injuries: effects of life style, coping ability, and personality | Vorhersagbarkeit und Rehabilitation von Sportverletzungen: Welchen Einfluss haben Lebenssituation, die Fähigkeit zur Bewältigung und die Persönlichkeit?, Sportverletzung Sportschaden : Organ der Gesellschaft fur Orthopadisch-Traumatologische Sportmedizin

        Livro

          * 2012, Manual de Saúde e Fitness, 1, Palmeira, AL; Martins, SS; Raposo, F.; Cerca, L.; Barreto, R, AGAP
          * 2012, Manual PESSOA III - Racional / Intuitivo, 1, Palmeira, AL; Martins, SS; Minderico, CM; Sardinha, LB, FMH; DGIDC
          * 2010, Manual Pessoa - II - Trabalhos Teórico-Práticos, 1, Palmeira, AL; Martins, SS; Minderico, CM; Sardinha, LB, DGDIC
          * 2009, Manual do Programa Pessoa - Volume I - Fundamentação, 1, Palmeira, AL; Martins, SS; Minderico, CM; Sardinha, LB, DGDIC

        Capítulo de livro

          * 2016, Treino de forc¸a, motivac¸a~o e bem-estar psicolo´gico, Manual do Treino da Força, 2, 2, Edições FMH
          * 2016, Treino da Força e Obesidade, Manual do Treino da Força, 2, Edições FMH
          * 2009, Manual de Aconselhamento da Actividade Física, Manual de Combate à Obesidade, 1, Plataforma de Combate à Obesidade: Direcção Geral da Saúde

        Relatório

          * 2023-10-23, Effects of swimming exercise on early adolescents’ physical conditioning and health: a systematic review, https://doi.org/10.37766/inplasy2023.10.0078

        Artigo em conferência

          * Um Programa de Controlo de Peso para Adolescentes no Contexto de uma Colónia de Férias: Análise do Impacto no IMC e Sintomas Depressivos, 12º Congresso Português de Obesidade
          * Symposium: Using consumer activity and weight devices in the design of a theory-based mHealth tools for weight loss maintenance: the NoHoW toolkit, ISBNPA 2017
          * Symposium: Evidence-based behaviour change in a weight loss maintenance e-Health program: The H2020 NoHoW intervention toolkit, European Congress of Obesity 2017
          * Relação entre os hábitos pessoais e a prática de aconselhamento sobre nutrição e actividade física: um estudo com Profissionais de Saúde, 12º Congresso Português de Obesidade
          * OBJECTIVELY MEASURED PHYSICAL ACTIVITY IN BARIATRIC SURGERY PATIENTS: A CROSS-SECTIONAL STUDY, NAASO 2007
          * O Exercício Físico na Obesidade, NEDO 2008
          * Motivar a Nível Individual, Curso de Obesidade Pediátrica
          * Modificação Comportamental Para A Actividade Física: Intervenção Em Crianças E Adolescentes , 12º Congresso Português de Obesidade.
          * Keynote: Mitos e factos na obesidade. Os diferentes papéis da actividade física: para além das calorias , 14 Congresso da Sociedade Brasileira de Alimentação e Nutrição
          * Influência Da Aptidão Cardiorespiratória No Impacto Do Peso Na Qualidade De Vida: Estudo Das Diferenças Entre Género E Escalões Etários Em Adolescentes , 12º Congresso Português de Obesidade
          * Influence Of Cardiorespiratory Fitness And Body Dissatisfaction On The Relation Between Bmi And Quality Of Life In Adolescents, 2009 Annual Conference of the ISBNPA
          * Impacto de vídeo-jogos com a tecnologia matching motion na actividade física de adolescentes obesos., 11º Congresso da SPEO
          * Impacto Do Programa Jovens Em Exercício Para A Perda De Peso: Necessidades Psicológicas Básicas E Influência Parental, 12º Congresso Português de Obesidade
          * Impact of a weight loss camp for obese adolescents: Analysis of BMI and psychosocial changes during the camp and after 6 months, 2009 Annual Conference of the ISBNPA
          * IMPACTO A CURTO-PRAZO DO PROGRAMA JOVENS EM EXERCÍCIO PARA A PERDA DE PESO: ANÁLISE PRELIMINAR DAS VARIÁVEIS PSICOSSOCIAIS, 11º Congresso da SPEO
          * Experiência de grupo: O Programa Exercício na Cirurgia para a Obesidade (ECO), Jornadas "A Endocrinologia e o Clínico geral"
          * Confirmatory factor analysis of the portuguese version of the Impact of Weight on Quality of Life – Kids, Obesity 2008
          * Confirmatory Factor Analysis of the Behavioural Regulation in Exercise Questionnaire - Portuguese Version, FEPSAC 2007
          * Comparação da Actividade Física Habitual e do Número de Horas de Sono entre Géneros: Associação com Indicadores Antropométricos, 12º Congresso Português de Obesidade.
          * Colónia de Férias para adolescentes obesos: impacto no peso e na composição corporal, 12º Congresso Português de Obesidade
          * Changes in BMI and behavioral regulations for exercise in obese adolescents participating in a multidisciplinary hospital treatment, 2009 Annual Conference of the ISBNPA
          * Benefícios Psicológicos do Exercício, Curso de Medicina Adolescente
          * Análise da evolução da Ingestão Alimentar e IMC em programas multidisciplinares de tratamento da Obesidade Adolescente , 12º Congresso Português de Obesidade
          * 2013-05, Active video games in schools to enhance children's physical activity
          * 2013-05, Active Video Games and Physical Activity in overweight children and adolescents
          * 2013, Active video games in schools to enhance children's physical activity
          * 2013, Active video games and physical activity in overweight children and adolescents: Systematic review
          * 2008, Motivação e modificação comportamental

        Resumo em conferência

          * 2023-11-25, Is it more tiring to carry out chest compressions procedures with the patient's bed at a height of 80 cm or 49 cm? , CIDEFES-MANZ - Exercise and Health Congress and Portugal Fit Meeting
          * 2013, Physical activity, quality of life and prosthesis adaptation in transtibial amputees, ISBNPA 2013
          * 2013, Physical activity and quality of life in youngsters: A mediation analysis of the role of physical activity motivation and peer support, 5th International conference on self-determination theory
          * 2013, Physical activity and quality of life association in youngsters: does motivation matters?, ISBNPA 2013
          * 2013, Parental and peer support on physical activity of children and adolescents: results from the PESSOA study, ISBNPA 2013
          * 2013, More is sometimes less: the role of quantitative and qualitative motivation for physical activity, eating behavior, and well-­-being, ISBNPA 2013
          * 2013, Exercise motivation, adherence and well-­-being: a comparative study between Freestyle and Les Mills fitness classes, ISBNPA 2013
          * 2013, Associations between changes on the level of physical activity and changes on psychological need satisfactions, exercise behaviour regulations and well-being: An analysis of a two year school-based study, 5th International conference on self-determination theory
          * 2013, Association between exercise dependence and burnout among fitness class instructors, ISBNPA 2013
          * 2013, A program for the treatment of adolescent obesity (TOP): 6 month results on cardiorespiratory fitness, body mass index and weight related quality of life, ISBNPA 2013
          * 2008, Validação do questionário de dependência do bodybuilding., Congresso da Sociedade Portuguesa de Psicologia da Saúde, 2008
          * 2008, Self-Determination and Exercise Intrinsic Motivation as Mediators of Physical Activity During a Weight Loss Program: One-Year Results from a Randomized Controlled Trial. , ECO - European Congress of Obesity
          * 2008, SHORT-TERM PSYCHOSOCIAL CHANGES IN AN EXERCISE BASED WEIGHT MANAGEMENT PROGRAM: A STUDY WITH OBESE OUTPATIENTS ADOLESCENTS., 13th Annual Congress of the European College of Sport Science
          * 2008, Reported Use of Anabolic Steroids and Ergogenic Substances in Gym/Health Club Settings: Associations with Psychosocial and Exercise Behavior Factors., 13th Annual Congress of the European College of Sport Science: Sport Science by the Sea
          * 2008, Preliminary Validation of the Portuguese Version of the Eating Inventory for Athletes, 13th Annual Congress of the European College of Sport Science
          * 2008, Physical Activity Compliance in Severely Obese Women. , 13th Annual Congress of the European College of Sports Science: Sport Sciences by the Sea
          * 2008, Overweight adolescents: impact of motion matching video-games on physical activity levels, ISBNPA 2008
          * 2008, Multiple mediation of long-term treatment-related weight loss: An analysis of the predictive power of the Theory of Planned Behavior, Obesity 2008
          * 2008, Factores comportamentais e psicológicos da dependência do exercício: uma possível causa da utilização de substâncias dopantes em ginásios, Sociedade Portuguesa de Psicologia da Saúde, 2008
          * 2008, Exercício e bem-estar: análise da mediação múltipla dos tipos de motivação para o exercício. , Sociedade Portuguesa de Psicologia da Saúde, 2008
          * 2008, Exercise Intrinsic Motivation, Autonomous Self-Regulation, and Psychological Motives as Mediators of Physical Activity During Weight Management. , ISBNPA 2008
          * 2008, Associations between BMI and Physical Activity in Outpatients Obese Adolescents, 18th Annual Meeting of the European Chilhood Obesity (ECOG)
          * 2008, Analysis of reciprocal effects between changes in weight and body image in a behavioral weight loss treatment., ISBNPA 2008
          * 2008, Analysis of mediation and reciprocal effects of changes in weight, self-esteem, and exercise in a behavioral weight loss treatment., European Congress of Obesity - ECO 2008
          * 2008, Adolescent obesity: what we know and what we do. , Society for Adolescent Medicine Annual Meeting 2008
          * 2007, Predictors of Successful Weight Control: Cross-cultural Moderators of Treatment Outcomes, 54th American College of Sports Medicine
          * 2007, IMPACTO DAS ÉPOCAS FESTIVAS DO NATAL E FIM DE ANO NO PESO CORPORAL E MASSA GORDA EM UTENTES DE HEALTH CLUB., 11º Congresso da SPEO.
          * 2007, Exercise Motivation and Subjective Well-Being: A Study with the Self-Determination Theory , FEPSAC 2007
          * 2007, EFEITOS AGUDOS DA SEQUÊNCIA DE EXERCÍCIO AERÓBIO E DE RESISTÊNCIA MUSCULAR NO METABOLISMO ENERGÉTICO: Um estudo com adolescentes obesos. , 11º Congresso da SPEO.
          * 2007, ASSOCIAÇÃO ENTRE VINCULAÇÃO E AUTO-EFICÁCIA PARA O CONTROLO DO PESO E MOTIVAÇÃO PARA O EXERCÍCIO EM ADOLESCENTES OBESOS: NOVOS CAMINHOS PARA O DESENHO DE INTERVENÇÕES. , 11º Congresso da SPEO
          * 2007, ARE BMI OBESITY LEVELS RELEVANT FOR DIMINISHED QUALITY OF LIFE AND PSYCHOLOGICAL WELL-BEING IN WOMEN? , NAASO 2007
          * 2007, ASSOCIAÇÃO ENTRE O TEOR CALÓRICO DAS REFEIÇÕES LIGEIRAS E A COMPOSIÇÃO CORPORAL DE CRIANÇAS DA 1ª E 2ª CLASSE., 11º Congresso da SPEO

        Poster em conferência

          * 2019-09-13, An oncologist¿s perspective on exercise promotion practices in clinical setting and on how to improve them: A qualitative analysis, Exercise and Cancer Symposium - Oncofit
          * 2019-09-13, A physical activity behavior change intervention for breast cancer survivors on aromatase inhibitors (PAC-WOMAN): Protocol description, Exercise and Cancer Symposium - Oncofit
          * 2019-02-01, Association between physical activity and quality of life in hematologic cancer survivors - Systematic Review of Literature, International Congress CIDESD

        Prefácio / Posfácio

          * 2015

        Conjunto de dados

          * Symposium 5: Psychology of pain and sport injuries: Psychological aspects of athletic injury: A cross-cultural study, (547922012-281)
          * Motivation for physical education classes and its relations with physical self-perceptions, (547922012-280)
          * Individual zone of optimal functioning, (547922012-277)
          * Does being fit influence our physical-self and mood states?, (547922012-278)
          * Being in first place. A study of the psychological state associated with first position, (547922012-279)

        Outra produção

          * 2009, Quando Faço Exercício Sinto-Me Bem… Então Porque Não Faço Mais?
          * 2009, Aconselhamento da Actividade Física. Lisboa: Formação de Formadores em Alimentação Saudável, Actividade Física e Obesidade

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona