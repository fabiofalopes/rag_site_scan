# Response for https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
          PT: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228 EN: https://www.ulusofona.pt/en/teachers/alexandra-isabel-cruchinho-barreiros-nogueira-6228
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
        fechar menu : https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/alexandra-isabel-cruchinho-barreiros-nogueira-6228
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Alexandra Isabel Cruchinho Barreiros Nogueira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6228
              ale***@ulusofona.pt
              D914-B9B5-46BC: https://www.cienciavitae.pt/D914-B9B5-46BC
              0000-0002-2728-6024: https://orcid.org/0000-0002-2728-6024
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/53ff7980-0c2a-4893-945e-d1fbe3630009
      : https://www.ulusofona.pt/

        Resume

        Alexandra Cruchinho is a Full Professor and Researcher at the School of Communication, Architecture, Art and Information Technologies of the Lusófona University o- Centro Universitário de Lisboa, since January 2021. She is an integrated researcher at the Centre for Research in Applied Communication, Culture and New Technologies (CICANT) DOI 10.54499/UIDB/05260/2020 (https://doi.org/10.54499/UIDB/05260/2020). She completed her PhD in Textile Engineering - Design Management, at the University of Minho, with a dissertation on "Design - The continuous construction of competences", in December 2009. She completed a Master's degree in Art Theory at the Faculty of Fine Arts of the University of Lisbon and a degree in Visual and Technological Education, Primary School Teachers, at the School of Education of the Castelo Branco Polytechnic Institute, in 1999. She undertook international training in Art Direction for Fashion at Central Saint Martin's - University of the Arts London. She has been teaching in higher education in the area of Design, Fashion Design and Photography since 1999. Since 2000, she has been coordinating different 1st and 2nd Cycle Studies, namely in the areas of Design, more specifically in the area of Fashion Design. She is currently the director of the BA and MA in Fashion Design and Production at Universidade Lusófona - Centro Tecnológico de Lisboa and the BA in Fashion Design and Production at Universidade Lusófona - Centro Universitário do Porto. Since 2000, she has coordinated several initiatives in the area of Fashion, namely the organisation of Fashion Shows, both at the academic level and at the professional level with several national designers in the main fashion weeks. Her photography work, both fashion and artistic, has also been a constant feature of her professional career. Her line of research is directed towards Fashion Design - Production, Fashion Photography and Editorial, Contemporary Fashion Design, Cultural heritage and sustainability in fashion. In the areas of intervention and research, she has been invited to take part in thematic panels, round tables, moderations and is a member of the Scientific Committee of various national and international conferences.

        Graus

            * Doutoramento
              Engenharia Têxtil
            * Mestrado
              Teorias da Arte
            * Licenciatura
              Professores do Ensino Básico, variante de Educação Visual
            * Licenciatura
              Professores do Ensino Básico, variante de Educação Visual

        Publicações

        Artigo em revista

          * 2022, Fashion and new technologies. From fashion film to expanded reality - Castelo Branco moda, International Journal of Film and Media Arts
          * 2021-12-01, Fashion brand campaigns: Carlos Gil SS21 case study, Clothing Cultures
          * 2018, Fashion shows: the potential of multidisciplinary activities, IPCB CAMPUS, Revista do Instituto Politécnico de Castelo Branco
          * 2013, Pedagogical changes towards the implementation of the Bologna Process: indicators structure of measurement, Journal of Further and Higher Education
          * 2013, Implementing new pedagogical practices in Higher Education, Revista Portuguesa da Educação
          * 2013, Are students and teachers ready for Bologna? A pedagogical project in a tourism course, Tourismos

        Tese / Dissertação

          * 2009-12-22, Doutoramento, Design - the continuous construction of competences

        Livro

          * 2012, A Concretização do Processo de Bolonha em Portugal: Encontro Nacional, 1, Ramos, Ana F.; Cruchinho, Alexandra; Delgado, Fernanda; Almeida Ramos, George Manuel; Pereira, Paula; Sapeta, Ana Paula; Afonso, Paulo, Edições IPCB

        Capítulo de livro

          * 2024, Moda e Cinema, Reflexões sobre Moda e Media, 1, Universidade Lusófona
          * 2023, New Ways of Ageless Fashion: Project Development in Class Context, Advances in Fashion and Design Research II. CIMODE 2023., Springer Nature
          * 2023, Lérias Lace: Tradition and Innovation in Fashion, Património, Educação e Cultura - Convergências e novas Perspetivas., IPCB, Instituto Politécnico de Castelo Branco
          * 2023, Knowledge of Traditional Techniques in the University Education of Fashion Design, Advances in Fashion and Design Research II. CIMODE 2023., Springer Nature
          * 2023, #1st_Composition# - The Artistic Performance as an Integral Part of a Fashion Show, Advances in Fashion and Design Research II. CIMODE 2023., Springer Nature
          * 2022, The Paradigm of Patternmaking Teaching - Draping as a Starting Point, Advances in Fashion and Design Research. CIMODE 2022, Springer Nature
          * 2022, The Cultural Identity of a Country as a Competitive Factor in Fashion Design: The Impact of Academic Education on the Construction of National Brands, Advances in Design, Music and Arts II. EIMAD 2022. Springer Series in Design and Innovation, 25, Springer International Publishing
          * 2022, Fashion Design - Sustainability and Technologies - The Carlos Gil Case, Advances in Fashion and Design Research. CIMODE 2022, Springer Nature
          * 2022, Castelo Branco Embroidery - Tradition and Innovation, Developments in Design Research and Practice. Senses 2019., 17, Springer International Publishing
          * 2022, Art and fashion in costume design for cinema, AVANCA | CINEMA 2022, 13, Edições Cine-Clube de Avanca
          * 2018, The fashion design as a contribution to the preservation of Nazaré culture and costumes: 7 project, Reverse Design: A Current Scientific Vision From the International Fashion and Design Congress, 1st Editio, CRC Press
          * 2018, Circular and Collaborative Economies as a Propulsion of Environmental Sustainability in the New Fashion Business Models, Innovation, Engineering and Entrepreneurship. HELIX 2018. Lecture Notes in Electrical Engineering, 505, Springer
          * 2013, Design : the continuous construction of competences, Design Learning for Tomorrow – Design Education from Kindergarten to PHD, Proceedings from the 2nd International Conference for Design Education Researchers, 3, ABM-media as

        Edição de livro

          * 2022, Lusófona University
          * 2022, Lusófona University

        Artigo em conferência

          * Lérias Lace: sustainability products design, Senses & Sensibility'19: Lost in (G)Localization.
          * A Definição de um Sistema de Qualidade para Avaliar o Percurso Formativo nas IES, FECIES 2012
          * 2022-11-04, SANTA CLARA TRAPOLOGY A CASE OF A TRADITIONAL TEXTILE TECHNOLOGY, FL Conference - Fashion&Sustainability
          * 2022-11-04, Environmental and Social Sustainability: Unite Textile and Fashion Design Education with a Social Cause, Fashion & Sustainability - FL International Conference
          * 2012-03-28, A concretização do Processo de Bolonha no IPCB
          * 2012, The Bologna Process Principles Applied to Design Teaching, 1st International Fashion and Design Congress CIMODE

        Resumo em conferência

          * 2024-02-29, Simpósio da Moda e a ITV, Simpósio do Ensino da Moda e a ITV
          * 2022-11, Reconstruction and upcycling to create a fashion installation, FL Conference | Fashion & Sustainability
          * 2022-11, Inclusiveness in fashion design and social sustainability: Finally Fashion Project, Fashion & Sustainability - FL International Conference
          * 2022-06-03, Simpósio do Ensino da Moda e a ITV #01 - Formação de Talentos para a Fileira da Moda, Simpósio do Ensino da Moda e a ITV

        Poster em conferência

          * 2012-06-12, O processo de Bolonha no IPCB : dos princípios à sua aplicação

        Prefácio / Posfácio

          * 2022, FL Conference | Fashion & Sustainability - Upcycling Expo Catalog
          * 2022, : FL Conference | Fashion & Sustainability — Book of Abstracts

        Outra produção

          * 2023-07-21, Over&Out - Desfile com os trabalhos dos estudantes de Design e Produção de Moda, Over&Out - Desfile com os trabalhos dos estudantes de Design e Produção de Moda
          * 2023-07-08, Lérias: A Arte das Linhas, Mostra de trabalhos desenvolvidos pelos estudantes do Curso de Design e Produção de Moda

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona