# Response for https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
          PT: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275 EN: https://www.ulusofona.pt/en/teachers/ana-rita-boino-godinho-alves-farias-6275
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
        fechar menu : https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-rita-boino-godinho-alves-farias-6275
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ana Rita Boino Godinho Alves Farias

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6275
              ana***@ulusofona.pt
              5718-46AC-401B: https://www.cienciavitae.pt/5718-46AC-401B
              0000-0002-7686-4046: https://orcid.org/0000-0002-7686-4046
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/933f3e3c-2dd3-4794-b8e6-18d7fa66ebdf
      : https://www.ulusofona.pt/

        Resume

        I earned my Ph.D. in Psychology in December 2013 from ISCTE-Instituto Universitário de Lisboa, thanks to an FCT grant. Currently, I hold a position as an Auxiliary Researcher and Assistant Professor at Lusófona University's HEI-Lab: Digital Human-Environment Interaction Labs. During my career I held research positions and visited as a guest researcher both in psychology and in business and economics departments, including Utrecht University in the Netherlands, the University of Wisconsin in the USA, Católica Lisbon - Research Unit in Business and Economics (CUBE), and the Center for Economics and Finance at the University of Porto (cefUP). My work has been published in leading international peer-reviewed journals such as Social Psychology, Scientific Reports-UK, Emotion, Acta Psychologica, Science Advances, and PLoS ONE. In addition to several book chapters, conference proceedings, abstracts, and technical reports, my articles have garnered recognition within the academic community and have been covered by the media. I have also presented my research at over 70 national and international scientific conferences and have served as a peer reviewer for esteemed journals, including Current Psychology, The International Journal of Consumer Studies, and Scientific Reports. Currently, I am overseeing the work of two postdoctoral researchers and two research assistant. My previous experience includes mentoring 15 Master's students, overseeing 5 internships, and coaching 8 trainees, while also teaching 10 courses that bridge the fields of business/economics and psychology. My involvement in research has been extensive, with projects funded by both national (FCT) and international agencies (NIMH, EC, FCT-EC, La Caixa). Notably, I have been the principal investigator for three projects sponsored by the La Caixa Foundation and the European Commission. Since 2019, I have had the privilege of serving as an external expert in social sciences for the European Commission's Research Executive Agency, aiding in the evaluation of the Marie Sklodowska-Curie Actions - Individual Fellowships among other Horizon calls, and as a consultant for the Project Peer Review of the Science Fund of the Republic of Serbia. My contributions to the field have been recognized with seven awards and honors, including those for Best Teacher and Best Paper.

        Graus

            * Licenciatura
              Psicologia Aplicada
            * Pós-Graduação
              Pós-Graduação em Análise de Dados com SPSS
            * Doutoramento
              Psicologia
            * Pós-doutoramento
              Psychology
            * Pós-doutoramento
              Psychology/Business
            * Pós-doutoramento
              Economics
            * Título de especialista
              Advanced course in cognitive neuroscience methods for the social sciences EEG, ERP, fMRI, GSR and eye movement recording
            * Título de especialista
              Advanced course in MATLAB
            * Título de especialista
              Trainee in functional magnetic resonance imaging (fMRI)

        Publicações

        Preprint

          * 
          * 
          * 

        Journal issue

          * Behavioral Economics and Sustainable Public Policies

        Journal article

          * 2024-02-09, Addressing climate change with behavioral science: A global intervention tournament in 63 countries, Science Advances
          * 2024, BlindGame: The online gambling activities of Portuguese young people, Lacaixa Foundation - The Social Observatory
          * 2023-12-19, Exploring the Interplay of Pro-Environmental Attitudes, Dietary Choices, and Packaging Preferences: A Virtual Reality Restaurant Scenario Study, Challenges
          * 2022-02-16, Why we’re wrong about nearly everything: a theory of human misunderstanding, The Social Science Journal
          * 2022-02-13, The spatial grounding of politics, Psychological Research
          * 2022, Why We are Wrong about Nearly Everything: A theory of human misunderstanding, by Bobby Duffy. New York, Basic Books, 2019. 296 pp. $28.00 paperback. ISBN: 978-1-5416-1808-4., The Social Science Journal
          * 2021, The Effects of Temporal Discounting on Perceived Seriousness of Environmental Behavior: Exploring the Moderator Role of Consumer Attitudes Regarding Green Purchasing, Sustanability
          * 2021, Grit and Productivity: work related barriers during COVID-19 lockdown., European Journal of Work and Organizational Psychology
          * 2020, Drivers of willingness to adopt and pay for a home cooking app., The International Food and Agribusiness Management Review
          * 2019-09-26, Messaging, monetary incentives, and participation in wellness programs, International Journal of Workplace Health Management
          * 2019-05, Observing Synchrony in Dyads, Social Psychology
          * 2019-04, Forecasting the duration of emotions: A motivational account and self-other differences., Emotion
          * 2019, Observing synchrony in dyads effects on observers' expectations and intentions
          * 2019, Grounding politics in space: Evidence from nonlinguistic tasks., Social Cognition
          * 2018, Human chemosignals of disgust facilitate food judgment, Scientific Reports
          * 2017-11-07, Consumer Based Market Intelligence: Behavioral Foundations of An Energy Control Platform—End User Profile for Behavioral Change, Proceedings
          * 2016-05, Embodiment of abstract categories in space… grounding or mere compatibility effects? The case of politics, Acta Psychologica
          * 2015, The scent of a handshake, eLife
          * 2015, Chemical and physical warning signals: Common and distinct effects., Chemical Senses
          * 2015, Brucella spp. Lumazine Synthase Induces a TLR4-Mediated Protective Response against B16 Melanoma in Mice, Plos One
          * 2013-04-10, Converging Modalities Ground Abstract Categories: The Case of Politics, PLoS ONE
          * 2010, “O espaço da política”: Avaliação da conotação política e da valência de uma lista de palavras, Laboratório de Psicologia

        Thesis / Dissertation

          * 2021, Master, Riscos psicossociais e indignidade no trabalho : um estudo com advogados
          * 2021, Master, Remote work and wellbeing : the role of grit during Covid19 outbreak
          * 2021, Master, Filling the gaps : prosociality and temporal discounting in the extended theory of planned behavior to predict green purchase intention
          * 2021, Master, Comunicação organizacional : relação com o clima organizacional e a satisfação no trabalho em corpos de bombeiros portugueses
          * 2020, Master, How purchase type influences customers´ engagement on brands´ social media platforms
          * 2020, Master, Engagement on Instagram : emotions and content of picture posts in the luxury market
          * 2020, Master, Do experiential posts increase consumer engagement on instagram? : exploring the effect of vividness and emotional appeal on experiential posts’ consumer engagement

        Book

          * 2023, Como comemos o que comemos. [How we eat what we eat]., Costa, A.I.A., Simão, C., Farias, A.R., Rodrigues, S., Lopes, C., Torres, D. & Rei, M., Fundação Francisco Manuel dos Santos
          * 2022, Behavioural Economics and the Environment, Bucciol, Alessandro; Tavoni, Alessandro; Veronesi, Marcella, Routledge
          * 2019, Psicologia – Economia & Negócios, A.R., Farias; Simão, C.; Gaspar, R., EDIÇÕES SÍLABO

        Book chapter

          * 2022, A shock doctrine for the climate: Pro-environmental behavior following natural disasters., Behavioural Economics and the Environment: A Research Companion., Routledge
          * 2021, Study on Behavioral Change Interventions and New Digital Technologies: An Energy-Saving Related Behaviors Survey, Current Approaches in Science and Technology Research Vol. 9, Book Publisher International (a part of SCIENCEDOMAIN International)
          * 2021, Behavioral foundations of an energy control platform - end user profile for behavioral change., New Ideas Concerning Science and Technology.
          * 2014, How many processes does it take to ground a concept?, Dual process theories of the social mind., Guilford Press
          * 2011, Politicians in space: spatial grounding of politics., Percursos de investigação em psicologia social e organizacional, Edições Colibri

        Newsletter article

          * 2021, SCORAI - Sustainable Consumption Research and Action Initiative: February newletter.
          * 2017, me2 - Customer Survey, First me2 project newsletter

        Report

          * 2023-05-19, Exploring supply-side barriers for commercialization of new biopolymer production technologies: A systematic review, https://doi.org/10.37766/inplasy2023.5.0076
          * 2023-01-17, Systematic Review on Digital Literacy Predictors, https://doi.org/10.37766/inplasy2023.1.0053
          * 2017, Pre-pilot Report - Deliverable Fundo de Apoio à Inovação (FAI)
          * 2017, Me2 Whitebook requirements - System specifications used in the first pilot phase, http://www.me2-project.eu/wa_files/Deliverable_20D1_1_me2.pdf
          * 2017, me² INTEGRATED SMART CITY MOBILITY AND ENERGY PLATFORM Final Report, http://www.me2-project.eu/wa_files/Me2-publication_LR.pdf
          * 2016-11-18, 2nd Consortium Meeting Lisbon - Minutes
          * 2016-09, GAMIFICATION - SUMMARY, goo.gl/jeGwng
          * 2016-08-15, Workshop/Meeting Lisbon - Minutes
          * 2013-11, Travel grant report , https://www.easp.eu/getmedia.php/_media/easp/201510/76v0-orig.pdf

        Working paper

          * 2020, The cat is out of the bag: Using Mouselab to expose HIV discrimination.
          * 2020, Just Do It: A Prescription for Lowering Stress Related to Planning a Business.
          * 2020, Entrepreneurial Perceptions and Transition from Mere Planning to New Business Startup.
          * 2020, Body Mass Index and Health Related Quality of Life Among Urban Adults in South Africa.
          * 2020, An Apple (or Carrot) a Day Keeps the Stress Away.

        Online resource

          * 2020, A systematic review of the effects of digitally-mediated cooking interventions on millennials’ meal preparation behavior, diet quality and weight status., https://www.crd.york.ac.uk/prospero/display_record.php?RecordID=143146
          * 2015-03, People use handshakes to sniff each other out, https://www.eurekalert.org/pub_releases/2015-03/e-puh030215.php
          * 2015-03, Handshakes May Engage Our Sense Of Smell, https://steamregister.com/handshakes-may-engage-our-sense-of-smell/

        Website

          * 2011, SMALL GROUP MEETING: Socially Situated Cognition ISCTE-Lisbon University Institute, graphic design and website of SMALL GROUP MEETING: Socially Situated Cognition 2011, http://smallgroupmeetingssc.wix.com/smallgroupmeetingssc2011

        Conference abstract

          * 2015-07-10, Association for Chemoreception Sciences (AChemS), 37th Annual Meeting, Bonita Springs, Florida, 22–25 April 2015:

        Conference poster

          * 2021, Linking Prosocial Values and Temporal Discounting with the Extended Theory of Planned Behavior to Predict Green Purchase Intention , SPSP
          * 2019-10-07, Understanding the motivational antecedents for adopting a cooking app. , Cook and Health Conference
          * 2019-08-05, Evaluation of extreme events as challenges or threats to cope with: Social media as a data source for stress measurement., Second Annual Meeting of the Society of Risk Analysis
          * 2017-03, Integrated Smart GRID Cross-Functional Solutions for Optimized Synergetic Energy Distribution, Utilization Storage Technologies (inteGRIDy), Green Business Week
          * 2017, Me2: Integrated smart city mobility and energy platform., Green Business Week
          * 2016, In the eye of the beholder: Synchrony and shared goal attainment in dyads., Interdisciplinary Network for Group Research
          * 2013-01-17, Multimodal grounding of social concepts., 14th Annual Meeting Society for Personality and Social Psychology
          * 2012-01, "Spatial Grounding of Politics"., 14th Annual meeting of The Society of Personality and Social Psychology
          * 2010-09-09, "Political wings": Crossmodal grounding of abstract concepts., Lisbon Workshop on Social Relations
          * 2010-03-26, Dar Espaço à Política [Give space to politics]., V Encontro da Associação Portuguesa de Psicologia Experimental

        Invention

          * 2020, Mobile application 'PRIMEMEAL' A research-based behavioral change technique app to promote healthier food intake
          * 2016, Behavioral Insight Concept (B..I.C.) Integrated behavioral insight concept model to behavioral change interventions. (Direct Link: goo.gl/8rxynK)

        Dataset

          * PLoS 2016 Garrido et al.
          * Emotion duration forecasting, Simão, C., & Farias, A. R. (2021, February 25). Emotion duration forecasting. https://doi.org/10.17605/OSF.IO/M4C72
          * Appreciation predicts business online reputation, Description: Online reviews are critical for business thriving, but their management is not often effective. Using data from one Social Media platform, with more than 600 observations of public online interactions between business owners and customers, we showed that a strategic management of online reviews predicts a positive increment of online reputation. Publicly expressing gratitude (Study 1)

        Other output

          * 2014, Graphic Design
          * 2013, Graphic Design – Cover book layout , C. Andrade, D. Garcia, S. Fernandes, T. Palma, V. Silva, M. B. Monteiro, & P. Castro (2013). Percursos de investigação em psicologia social e organizacional. Vol.5. (pp. 148) Lisboa: Colibri.

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona