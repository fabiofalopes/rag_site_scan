# Response for https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
          PT: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111 EN: https://www.ulusofona.pt/en/teachers/antonio-augusto-teixeira-da-costa-111
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
        fechar menu : https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/antonio-augusto-teixeira-da-costa-111
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          António Augusto Teixeira Da Costa

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p111
              aau***@ulusofona.pt
              B518-9F39-FDA8: https://www.cienciavitae.pt/B518-9F39-FDA8
              0000-0003-0719-6897: https://orcid.org/0000-0003-0719-6897
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/4ef8ab1b-50c1-436c-9e03-6c08f3177d1d
      : https://www.ulusofona.pt/

        Resume

        António Augusto Teixeira da Costa. Concluiu o(a) Mestrado em Economia em 1995 pelo(a) Universidade de Lisboa Instituto Superior de Economia e Gestão, Licenciatura em Economia em 1989 pelo(a) Universidade Lusíada de Lisboa, Bacharelato em Engenharia Electrotécnica em 1979 pelo(a) Instituto Politécnico de Lisboa Instituto Superior de Engenharia de Lisboa e Doctorat em Economie em 2005 pelo(a) Université Lumière Lyon 2. Publicou 5 artigos em revistas especializadas. Possui 1 capítulo(s) de livros. Organizou 3 evento(s). Participou em 1 evento(s). No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural são: MESTRADO EM GESTÃO DE EMPRESAS; GESTÃO; GESTÃO DE EMPRESAS; GESTÃO DA SAÚDE; DOENTES; GESTÃO DE DOENTES; MANAGEMENT; BUSINESS MANAGEMENT; HEALTH MANAGEMENT; PATIENTS; PATIENT CARE MANAGEMENT; BRASIL; BRAZIL; FARMACÊUTICOS; GESTÃO FARMACÊUTICA; POLÍTICA DE SAÚDE; MEDICAMENTOS; SISTEMAS INFORMÁTICOS; PHARMACISTS; PHARMACEUTICAL MANAGEMENT; HEALTH POLICY; DRUGS; COMPUTER SYSTEMS; GESTÃO DE RECURSOS HUMANOS; COMPORTAMENTO HUMANO; CLIMA ORGANIZACIONAL; ESTUDOS DE CASO; FLORIANÓPOLIS; HUMAN RESOURCES MANAGEMENT; WORK ENVIRONMENT; CASE STUDIES; MESTRADO EM CIÊNCIA POLÍTICA - CIDADANIA E GOVERNAÇÃO; CIÊNCIA POLÍTICA; ESTADO; PODER POLÍTICO; PARTICIPAÇÃO POLÍTICA; ÉTICA; EMPREGO; EMPREENDEDORISMO; POLITICAL SCIENCE; STATE; POLITICAL POWER; POLITICAL PARTICIPATION; ETHICS; EMPLOYMENT; ENTREPRENEURSHIP; GESTÃO PÚBLICA; ADMINISTRAÇÃO LOCAL; DESENVOLVIMENTO LOCAL; DESENVOLVIMENTO ECONÓMICO; ANGOLA; HUAMBO; PUBLIC MANAGEMENT; LOCAL ADMINISTRATION; LOCAL DEVELOPMENT; ECONOMIC DEVELOPMENT; QUALIDADE DE VIDA; AMBIENTE DE TRABALHO; CONDIÇÕES DE TRABALHO; INSTITUIÇÕES BANCÁRIAS; LUANDA; QUALITY OF LIFE; LABOUR CONDITIONS; BANKS; COMÉRCIO ELETRÓNICO; E-MARKETING; INTERNET; E-COMMERCE; ADMINISTRAÇÃO PÚBLICA; DISTRIBUIÇÃO DE RENDIMENTOS; PUBLIC ADMINISTRATION; INCOME DISTRIBUTION; UNIÃO EUROPEIA; POLÍTICA PÚBLICA; CIDADANIA; ENVELHECIMENTO; GOVERNAÇÃO; ITÁLIA; EUROPEAN UNION; PUBLIC POLICY; CITIZENSHIP; AGEING; GOVERNANCE; ITALY; SATISFAÇÃO PROFISSIONAL; MOTIVAÇÃO PROFISSIONAL; TRABALHADORES; TRANSPORTES; PROFESSIONAL SATISFACTION; PROFESSIONAL MOTIVATION; WORKERS; TRANSPORT; CONDUÇÃO DE VEÍCULOS; DRIVING; GESTÃO ORGANIZACIONAL; MEDICINA; HOSPITAIS; LIDERANÇA; GESTÃO DE SERVIÇOS DE SAÚDE; ORGANIZATIONAL MANAGEMENT; MEDICINE; HOSPITALS; LEADERSHIP; HEALTH SERVICES ADMINISTRATION; GESTÃO HOSPITALAR; HOSPITAL MANAGEMENT; CAPITAL HUMANO; INOVAÇÃO; CRESCIMENTO ECONÓMICO; ESTUDOS EMPÍRICOS; EQUAÇÕES ESTRUTURAIS; HUMAN CAPITAL; INNOVATION; ECONOMIC GROWTH; EMPIRICAL STUDIES; STRUCTURAL EQUATIONS; PORTUGAL; ABSENTISMO; PROFISSIONAIS DE SAÚDE; ALAGOAS; ABSENTEEISM; HEALTH CARE PROFESSIONALS; MACAPÁ; GESTÃO DA QUALIDADE; ACREDITAÇÃO HOSPITALAR; QUALITY MANAGEMENT; HOSPITAL ACCREDITATION; QUALIDADE DE SERVIÇO; QUALITY SERVICE; COMÉRCIO MUNDIAL; GESTÃO INTERNACIONAL; COMÉRCIO INTERNACIONAL; OMC; REGRAS DA CONCORRÊNCIA; CONCORRÊNCIA DESLEAL; WORLD TRADE; INTERNATIONAL MANAGEMENT; INTERNATIONAL TRADE; CONCURRENCY REGULATIONS; UNFAIR COMPETITION; TECNOLOGIAS DA INFORMAÇÃO E COMUNICAÇÃO; DESENVOLVIMENTO SUSTENTÁVEL; SUSTENTABILIDADE; PRÁTICAS ADMINISTRATIVAS; MARANHÃO; SÃO LUÍS; INFORMATION AND COMMUNICATION TECHNOLOGIES; SUSTAINABLE DEVELOPMENT; SUSTAINABILITY; ADMINISTRATIVE PRACTICES; ORÇAMENTOS; PLANEAMENTO; INVESTIMENTOS FINANCEIROS; CAPITAL; INDÚSTRIA MINEIRA; BUDGETS; PLANNING; FINANCIAL INVESTMENTS; MINING INDUSTRY; INVESTIMENTOS ECONÓMICOS; INVESTIMENTOS EXTERNOS; GUINÉ-BISSAU; ECONOMIC INVESTMENTS; EXTERNAL INVESTMENTS; UEMOA; GUINEA-BISSAU; PEREIRA, FIRMO DE ARAÚJO; GESTÃO DE PROJETOS; OPM3; PMBOK; PARÁ; PROJECT MANAGEMENT; MARKETING; ARTES MARCIAIS; MARTIAL ARTS; ENFERMEIROS; PRÁTICAS PROFISSIONAIS; LEGISLAÇÃO; GESTÃO DE UNIDADES DE SAÚDE; SERVIÇOS DE SAÚDE; HEMODIÁLISE; NURSES; PROFESSIONAL PRACTICES; LEGISLATION; HEALTH CARE FACILITIES MANAGEMENT; HEALTH CARE SERVICES; HEMO

        Graus

            * Bacharelato
              Engenharia Electrotécnica
            * Licenciatura
              Economia
            * Mestrado
              Economia
            * Doctorat
              Economie
            * Curso de mestrado (conclusão do curso de especialização)
              Mestrado em Política Internacional e Direito Comum
            * Curso de mestrado (conclusão do curso de especialização)
              Mestrado em Economia e Gestão de Ciência e Tecnologia
            * Outros
              Concurso de Projetos em todos os Domínios Científicos

        Publicações

        Artigo em revista

          * 2019-09-30, ATITUDE, PRÁTICAS E TECNOLOGIAS: INICIATIVAS DOS GESTORES NAS ORGANIZAÇÕES PÚBLICAS E PRIVADAS PARA UM DESENVOLVIMENTO SUSTENTÁVEL, Revista Fluxos & Riscos
          * 2018, Inovação e Crescimento Económico : Portugal (2000-2013), Revista Lusófona de Economia e Gestão das Organizações (R-LEGO)
          * 2017, Integração Regional da Guiné-Bissau na CEDEAO e Adesão à UEMOA, Revista Fluxos & Riscos
          * 2005-04-01, Système d`innovation au Portugal : comparaison avec quelques pays de l`Europe Centrale et Orientale, Economia e Empresas
          * 2000, Exportações e Inovação- Uma aplicação ao caso português, Lusíada- Revista de Ciência e Cultura
          * 1998, Incidência das novas tecnologias no setor laboral- Algumas reflexões, Lusíada- Revista de Ciência e Cultura

        Tese / Dissertação

          * 2019, Mestrado, Satisfação e motivação no trabalho no setor de transporte de pessoas em veículos ligeiros
          * 2018, Mestrado, O exercício do poder político em rede. Uma aposta no emprego e no empreendedorismo. O caso do Fórum Nacional de Aprendizagem Profissional (FNP)
          * 2018, Mestrado, A atuação dos poderes públicos na distribuição de renda no Brasil: análise do Programa Bolsa Família no período de 2003 a 2010
          * 2017, Mestrado, Impacto do capital humano e da inovação no crescimento económico de Portugal : estudo empírico através de modelos de equações estruturais
          * 2017, Mestrado, Gestão de E-commerce
          * 2017, Mestrado, Ferramentas de gestão em saúde : uma avaliação da implantação do sistema nacional de gestão da assistência farmacêutica no estado de Alagoas
          * 2017, Mestrado, As políticas de recursos humanos e práticas de qualidade de vida no trabalho : estudo sobre a perceção dos colaboradores do banco de poupança e crédito em Luanda
          * 2017, Mestrado, A influência das políticas públicas na União Europeia em prol da cidadania : a atuação dos poderes públicos na Itália em relação ao envelhecimento
          * 2017, Mestrado, A gestão do atendimento aos pacientes em tratamento de tuberculose pulmonar : a situação em duas unidades hospitalares de Maceió/AL
          * 2016, Mestrado, Gestão pública para o desenvolvimento local endógeno - região do Huambo - Angola
          * 2016, Mestrado, Gestão de pessoas: o caso da empresa Yes Contact Center no Município de Florianópolis/SC - Brasil
          * 2016, Mestrado, A influência do médico-gestor na gestão hospitalar : estudo de caso em um hospital universitário
          * 2015, Mestrado, O conhecimento do enfermeiro gestor sobre sua responsabilidade técnica em serviços de hemodiálise
          * 2015, Mestrado, Marketing como ferramenta na gestão nas artes marciais : o caso da empresa ADFAM de Belém do Pará
          * 2015, Mestrado, Liderança política individual na construção da cidadania de uma população: o caso do Coronel Firmo de Araújo Pereira
          * 2015, Mestrado, Investigação de origem como instrumento paralelo de defesa comercial: impactos e desafios para a gestão das empresas brasileiras
          * 2015, Mestrado, Gestão de pessoas: absenteísmo nas unidades de estratégia saúde da família no município de Marechal Deodoro/AL - Brasil
          * 2015, Mestrado, A política económica no contexto da UEMOA: investimento direto estrangeiro na economia da Guiné-Bissau: uma abordagem
          * 2014, Mestrado, Gestão verde de tecnologia da informação e comunicação nas organizações públicas e privadas na Região Metropolitana de São Luis, Estado do Maranhão: boas práticas de iniciativas para um desenvolvimento sustentável
          * 2014, Mestrado, Gestão do orçamento empresarial em projetos de investimento de capital no setor de minéração no Brasil: análise da empresa vale s.a em São Luis do Maranhão
          * 2014, Mestrado, Gestão de inovação nas pequenas e médias empresas portuguesas: o caso das PME de excelência
          * 2014, Mestrado, Avaliação de maturidade em gerenciamento de projetos: estudo de caso no programa de extensão mídias eletrônicas da Ufopa, Santarém-Pará
          * 2013, Mestrado, Razões e dificuldades para se implantar setor de recursos humanos nas médias empresas de material de construção em Macapá
          * 2013, Mestrado, O processo de gestão da qualidade com foco em resultado em um hospital privado da cidade de Macapá:estudo de caso
          * 2013, Mestrado, O processo de acreditação hospitalar na perspectiva de profissionais de saúde de um hospital privado em Macapá - Estudo de caso
          * 2013, Mestrado, Motivação no trabalho: um estudo de caso na gestão administrativa do Hospital Divina Providência
          * 2013, Mestrado, Gestão da qualidade: avaliação do processo de acreditação do Hospital Divina Providência
          * 2013, Mestrado, A gestão de políticas públicas em saúde da divisão de vigilância em saúde da secretaria de estado de saúde pública - SESPA no combate do HIV/AIDS no estado do Pará - um estudo de caso
          * 2012, Mestrado, Política de educação em cidadania e relações internacionais : aplicação de um modelo indiano no Brasil
          * 2012, Mestrado, A implementação do regime de competência na qualidade das informações contábeis : uma análise de suas características na tomada de decisão dos gestores públicos da grande Belém
          * 2009, Mestrado, Os custos de desempenho ocultos no dia-a-dia de um restaurante
          * 2009, Mestrado, A restauração nos transportes turísticos : o catering no comboio TGV europeu : projecto de empresa para explorar o catering do TGV em Portugal
          * 1995, Mestrado, O impacto da tecnologia no comércio. Uma aproximação ao caso português

        Capítulo de livro

          * 2023, A IMPORTÂNCIA DO COMBATE AO INSUCESSO ESCOLAR PRECOCE
          * 2020, IMPACT OF TOURISM ON PORTUGAL’S REGIONAL DEVELOPMENT
          * 2019, Analyses of the Determinants and Outputs of Innovation in the Nordic Countries, Data Analyses and applications 2, 3, John Wiley & Sons, Inc

        Artigo em conferência

          * 2021, Financial Literacy and Risk Aversion of University Students: Study Applied to Lusófona University Students
          * 2020, IMPACT OF TOURISM ON PORTUGAL’S REGIONAL DEVELOPMENT, 5th International Thematic Monograph - Modern Management Tools and Economy of Tourism Sector in Present Era
          * 2019-07-25, Gender and Entrepreneurship: in wich areas of higher education are woman and man more entrepreneurial ?, International Scientific Conference on Economic and Social Development
          * 2019-04-30, Comparing models of IT and economic growth: An empirical investigation, International Scientific Conference on Economic and Social Development
          * 2017-07-25, Analysis of the determinants and outputs of innovation in the Nordic countries, Applied Stochastic Models and Data Analysis International Society and Demographics Workshop
          * 2017-07-07, Analysis of the human capital and innovation impact in the portuguese economy through stuctural equation models, ASEPELT

        Poster em conferência

          * 2018-04-06, Análise da Relação entre Inputs e Outputs da Inovação : Países da Europa do Norte vs Países da Europa do Sul, XXV Jornadas de Classificação e Análise de Dados - JOCLAD 2018

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona