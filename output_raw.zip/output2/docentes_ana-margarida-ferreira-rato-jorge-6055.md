# Response for https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
          PT: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055 EN: https://www.ulusofona.pt/en/teachers/ana-margarida-ferreira-rato-jorge-6055
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
        fechar menu : https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-margarida-ferreira-rato-jorge-6055
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ana Jorge

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6055
              ana***@ulusofona.pt
              F21A-1BFE-4C26: https://www.cienciavitae.pt/F21A-1BFE-4C26
              0000-0002-4069-6212: https://orcid.org/0000-0002-4069-6212
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/54588957-99df-460d-a638-e79d79568f80
      : https://www.ulusofona.pt/

        Resume

        Ana Jorge is Associate Professor at Lusófona University and Senior Researcher at CICANT. She holds a Communication Sciences PhD from NOVA University of Lisbon (2012), where she also conducted postdoctoral research on Media Education (2015), both with individual grants from FCT. Ana researches on audiences, digital culture, children, youth and media, celebrity and influencer culture. She has acted as PI in funded projects Dis/Connect (2021-22) and On&Off (2023- ). Her scholarship appears in journals such as European Journal of Cultural Studies, Popular Communication, Social Media + Society, Journal of Children and Media, Celebrity Studies, and collections such as Celebrity and Youth (Peter Lang, 2019), The Future of Audiences (Palgrave, 2018) and Childhood and Celebrity (Routledge, 2017). She has co-edited Digital Parenting (Nordicom, 2018), Reckoning with Social Media (Rowman & Littlefield, 2021) and Audience Interactions in Contemporary Celebrity Culture: Approaches from across Disciplines (Lexington, forthcoming/2024).

        Graus

            * Licenciatura
              Ciências da Comunicação
            * Mestrado integrado
              Comunicação, Cultura e Tecnologias da Informação
            * Doutoramento
              Ciências da Comunicação

        Publicações

        Artigo em revista (magazine)

          * 2011-07-01, Jornalismo e segurança das crianças na internet, Jornalismo e Jornalistas
          * 2009-03-01, Os estudos europeus da comunicação em congresso, Jornalismo e Jornalistas
          * 1906-09-09, Revistas com estilo, Jornalismo e Jornalistas

        Edição de número de revista

          * Vulnerabilidades digitales, 10
          * The co-option of audiences in the attention economy, 12
          * Educação para os Media na Era Digital, 15

        Artigo em revista

          * 2023-07-20, Digital Disconnection and Portuguese Youth: Motivations, Strategies, and Well-Being Outcomes, Comunicação e Sociedade
          * 2023-06-14, Parents’ social networks, transitional moments and the shaping role of digital communications: an exploratory study in Austria, Denmark, England and Portugal, Families, Relationships and Societies
          * 2023-03-17, Growing out of overconnection: The process of dis/connecting among Norwegian and Portuguese teenagers, New Media & Society
          * 2023-03, Coping Comes with the Job An Exploratory Study into the Selection and Use of Coping Strategies for Online Aggression among Social Media Influencers, Telematics and Informatics Reports
          * 2023-01-13, Parenting on Celebrities’ and Influencers’ Social Media: Revamping Traditional Gender Portrayals, Journalism and Media
          * 2023-01-13, Parenting on Celebrities’ and Influencers’ Social Media: Revamping Traditional Gender Portrayals, Journalism and Media
          * 2023-01-12, Pilgrimage to Fátima and Santiago after COVID: Dis/connection in the post-digital age, Mobile Media & Communication
          * 2022-09-01, Sharenting of Portuguese Male and Female Celebrities on Instagram, Journalism and Media
          * 2022-01-24, ‘When you realise your dad is Cristiano Ronaldo’: celebrity sharenting and children’s digital identities, Information, Communication & Society
          * 2022-01, Digital Nomads and the Covid-19 Pandemic: Narratives About Relocation in a Time of Lockdowns and Reduced Mobility, Social Media + Society
          * 2022, "Time well spent": the ideology of dis/connection as a means for digital wellbeing, International Journal of Communication
          * 2021-08-12, In the mood for disconnection, Convergence: The International Journal of Research into New Media Technologies
          * 2021-07-03, Offshoring & leaking: Cristiano Ronaldo’s tax evasion, and celebrity in neoliberal times, Popular Communication
          * 2021-06-30, Plataformas de Financiamento Coletivo na Economia Política dos Média Alternativos, Comunicação e Sociedade
          * 2021-04-03, Mummy influencers and professional sharenting, European Journal of Cultural Studies
          * 2020-10-27, Children’s cancer narratives on YouTube: Agency and entrepreneurship in Brazilian CarecaTV, Global Studies of Childhood
          * 2020-01-02, “I felt like I was really talking to you!”: intimacy and trust among teen vloggers and followers in Portugal and Brazil, Journal of Children and Media
          * 2019-10, Social Media, Interrupted: Users Recounting Temporary Disconnection on Instagram, Social Media + Society
          * 2018, RadioActive101-Learning through radio, learning for life: an international approach to the inclusion and non-formal learning of socially excluded young people, International Journal of Inclusive Education
          * 2018, 'I am not being sponsored to say this': A teen youtuber and her audience negotiate branded content, Observatorio
          * 2017-12, Are victims to blame?, Catalan Journal of Communication & Cultural Studies
          * 2017-03-31, Ferramentas jornalísticas na educação: uma rádio online para jovens, Sociologia, Problemas e Práticas
          * 2017, Meios digitais e direitos: Perspetivas de jovens com cancro, Comunicação Pública
          * 2017, Media education competitions: An efficient strategy for digital literacies?, Italian Journal of Sociology of Education
          * 2016, Comparative audience research: A review of cross-national and cross-media audience studies, Participations: Journal of Audience & Reception Studies
          * 2016, Audience experiencing of emotions in the contemporary media landscape, Participations: Journal of Audience & Reception Studies
          * 2015, ‘Cristiano Ronaldo is cheap chic, Twilight actors are special’: young audiences of celebrities, class and locality, Celebrity Studies
          * 2015, Learning for life: A case study on the development of online community radio, Cuadernos.info
          * 2014, Problematizar para intervir: rádio online e educação para os media como estratégia de inclusão de jovens, Observatorio (OBS*)
          * 2014, Media representations and children's discourses on online risks: Findings from qualitative research in nine European countries, Cyberpsychology
          * 2014, At the Heart of Celebrity: Celebrities’ children and their rights in the media, Communication & Society / Comunicación y Sociedad
          * 2013, Online experiences of socially disadvantaged children and young people in Portugal, Communications - The European Journal of Communication Research
          * 2013, Do questions matter on children’s answers about internet risk and safety?, Cyberpsychology: Journal of Psychosocial Research on Cyberspace
          * 2013, Descobrindo a Comunidade Otaku Portuguesa: os Fãs Online, Vozes e Diálogo
          * 2013, Audiências e fãs juvenis de celebridades: Potencialidades e limitações para uma cidadania cultural, Ciberlegenda
          * 2012, Young consumers and celebrities, Revista Portuguesa de Marketing
          * 2011, Young audiences and fans of celebrities in Portugal, Comunicação & Cultura
          * 2011, Nascer para ser famoso? Os filhos de celebridades e seus direitos na mídia, Comunicação Midiática
          * 2011, Contactar, entreter, informar: Um retrato da inclusão digital de jovens e seus familiares em Portugal, Observatorio
          * 2010, Media Education in Portugal: a building site, Journal of Media Literacy
          * 2009, Os direitos (de comunicação) de crianças e jovens na esfera pública europeia: O papel da sociedade civil numa sociedade em rede, Media & Jornalismo
          * 2009, Celebridades no Feminino: mulheres célebres em revistas femininas de estilo de vida portuguesas, Estudos de Comunicação

        Tese / Dissertação

          * 2012-11-26, Doutoramento, Cultura das celebridades e jovens: do consumo à participação
          * 2008-04-24, Mestrado, Publicidade e Media: da produção à recepção de revistas femininas e masculinas de estilo de vida

        Livro

          * 2021, Reckoning with Social Media, Jorge, Ana, Rowman & Littlefield
          * 2014, 'O Que é Que os Famosos Têm de Especial?' - A cultura das celebridades e os jovens, 1, Jorge, Ana, Texto

        Capítulo de livro

          * 2021, ‘Hey! I’m back after a 24h #DigitalDetox!’: Influencers posing disconnection, Reckoning with Social Media: Disconnection in the Age of the Techlash, Rowman & Littlefield
          * 2020, Social media and sick children, The Routledge Companion to Digital Media and Children, Routledge
          * 2020, Family mediating practices and ideologies: Spanish and Portuguese parents of children under 3 and digital media in homes, Mediating practices and ideologies: Spanish and Portuguese parents of children under 3 and digital media in the home, Springer
          * 2019, WTF: Digital ambassadors for the young generation?, Celebrity and Youth: Mediated Audiences, Fame Aspirations, and Identity Formation, Peter Lang
          * 2019, The Industry of Smart Toys: Cultural Implications from the Political Economy, The Internet of Toys: Practices, Affordances and the Political Economy of Children’s Play, Palgrave Macmillan
          * 2018, The co-option of audience data and user-generated content: the empowerment and exploitation of audiences through algorithms, produsage and crowdsourcing, The Future of Audiences: a foresight analysis of interfaces and engagement, Palgrave Macmillan
          * 2018, Educando entre ecrãs, Boom Digital? Crianças (3-8 anos) e ecrãs, Entidade Reguladora para a Comunicação Social
          * 2018, Algorithms and intrusions: emergent stakeholder discourses on the co-option of audiences' creativity and data, The Future of Audiences, Palgrave Macmillan
          * 2017, ONG e Meios para a Comunicação: as conquistas e os desafios da APSI, Comunicação no Terceiro Sector - Desafios contemporâneos, Labcom
          * 2017, Born to be famous? Children of celebrities and their rights in the media, Childhood and Celebrity, Routledge
          * 2016, Descobrindo o som, a palavra e a comunidade: implementação de uma WebRádio educativa, Educar com Podcasts, CirKula
          * 2016, Culturas juvenis e desfavorecimento digital: o projeto RadioActive, Cultura e Digital em Portugal, Afrontamento
          * 2016, 'Cristiano Ronaldo is cheap chic, Twilight actors are special': young audiences of celebrities, class and locality, Celebrity Audiences, Routledge
          * 2015, RadioActive. A European Online Radio Project, Agents and Voices: A Panorama of Media Education in Brazil, Portugal and Spain, Nordicom Clearinghouse
          * 2015, Media Education Practices in Portugal. A Panoramic View, Agents and Voices: A Panorama of Media Education in Brazil, Portugal and Spain, Nordicom Clearinghouse
          * 2015, Grey Zones: Audience research, moral evaluations and online risk negotiation, Revitalising Audiences: Innovations in European Audience Research, Routledge
          * 2015, A semi-periferia conta: notas sobre o papel de Portugal nos estudos internacionais a partir dos estudos das audiências de celebridades, Comunicação e Linguagens: novas convergências, Colibri
          * 2015, A educação para a cultura de consumo e media, Interfaces das Relações Públicas com a Cultura, LabCom Books
          * 2015, A comunicação comercial de alimentos e bebidas para crianças em Portugal: entre a regulação e a auto-regulação, Infância, Juventude E Mídia: Olhares Luso-Brasileiros, 1, Ed. UECE
          * 2014, RadioActive. Um projeto europeu de rádio online, Agentes e Vozes: Um Panorama da Mídia-Educação no Brasil, Portugal e Espanha, Nordicom
          * 2014, Práticas de educação para os media em Portugal. Uma visão panorâmica, Agentes e Vozes: Um Panorama da Mídia-Educação no Brasil, Portugal e Espanha, Nordicom
          * 2012, Em risco na internet? Resultados nacionais do inquérito EU Kids Online, Crianças e internet em Portugal: Acessos, usos, riscos, mediações – Resultados do inquérito europeu EU Kids Online, MinervaCoimbra
          * 2011, Celebrity Culture and postcolonial relations within the Portuguese media landscape: The case of Catarina Furtado, Transnational Celebrity Activism in Global Politics – Changing the World?, Intellect
          * 2011, Celebridades e Jovens em Portugal: da Televisão aos Novos Media , A Vida Como Um Filme: Celebridade e Fama no século XXI, Texto
          * 2009, Representation of the "Feminine" in the Portuguese Popular Newspapers Correio da Manhã and 24Horas, Media Agoras: Democracy, Diversity, and Communication, Cambridge Scholars Publishing

        Edição de livro

          * 2018, 1, Nordicom
          * 2015, 1, LabCom Books
          * 2012, 1, Minerva Coimbra

        Entrada de enciclopédia

          * Celebrity bloggers and vloggers, The International Encyclopedia of Gender, Media, and Communication

        Relatório

          * 2018, A Day in the Digital Lives of Children aged 0-3. Summary report by DigiLitEY ISCH COST Action IS1410 Working Group 1 “Digital literacy in homes and communities.”
          * 2017, The Internet of Toys: A report on media and social discourses around young children and IoToys, http://digilitey.eu/wp-content/uploads/2017/01/IoToys-June-2017-reduced.pdf
          * 2017, Crescendo entre ecrãs: Usos de meios eletrónicos por crianças (3-8 Anos), http://www.erc.pt/documentos/Crescendoentreecras/files/downloads/crescendo-entre-ecras.pdf
          * 2017, Audiences, towards 2030 Priorities for audience analysis , http://epubs.surrey.ac.uk/842403/
          * 2016, Projecto #ON_SEX: Direitos sexuais e jovens vulneráveis

        Manual

          * 2016, Fazer rádio online com crianças e jovens: Manual de Sugestões, Centro de Investigação Media e Jornalismo
          * 2014, A Facilitator’s Guide to RadioActive 101

        Artigo em conferência

          * Um dia na vida de crianças com menos de 3 anos: os meios digitais no quotidiano das famílias, XV Congresso IBERCOM
          * RadioActive Europe: jovens, o digital e as suas comunidades, 2.º Congresso Literacia, Media e Cidadania
          * Public sphere of the reception of women’s and men’s lifestyle magazines: Sex sells (for men) and products are bought (by women), ECREA - 2nd European Communication Conference
          * O sexo vende, e os produtos compram-se’: a publicidade nos discursos de produção e recepção nas revistas femininas e masculinas de estilo de vida, VI Congresso SOPCOM, "Sociedade dos Media: Comunicação, Política e Tecnologia"
          * Female Celebrity in Portuguese women's lifestyle magazines, 9th Conference of the European Sociological Association
          * Crescendo entre ecrãs: competências digitais de crianças de 3 a 8 anos, Literacia, Media e Cidadania
          * Consumir ou Participar: Análise dos Produtos Mediáticos para Jovens 12-18, IV Jornadas Internacionais de Jornalismo - Os Jovens e a Renovação do Jornalismo
          * Celebrities' young fans online: identities, practices and communities, 4e Colloque International Enjeux et Usages des Technologies de l'Information et de la Communication
          * Celebridades e jovens: de recursos para a literacia mediática à literacia para o consumo, Congresso Nacional "Literacia, Media e Cidadania"
          * Between access and use: a case-study on technology mediation in a school environment, V International Conference on Multimedia and ICT in Education (m-ICTE)
          * Acessos e Usos: estudo de caso sobre a mediação das tecnologias em contexto escolar, VI Congresso SOPCOM, "Sociedade dos Media: Comunicação, Política e Tecnologia"
          * A repercussão dos média alternativos no ciberespaço: estudo comparativo das páginas “Outras Palavras” e “O Corvo”, Cibercultura: Circum-navegações em redes transculturais de conhecimento, arquivos e pensamento
          * A Maternidade dos Discursos de Celebridade em Catarina Furtado, Género e Culturas Mediáticas

        Resumo em conferência

          * 2018, On and Off: Digital practices of connecting and disconnecting across the life course, AoIR 2017: The 18th Annual Conference of the Association of Internet Researchers
          * 2011, Online risks and opportunities amongst socially disadvantaged children and young people: findings from the Digital Inclusion and Participation Project, EU Kids Online II: final conference

        Outra produção

          * 2017, Under the limelight: Celebrity parents sharenting
          * 2016, RadioActive Portugal: Relatório Final à Rede TIC e Sociedade
          * 2014, RadioActive101 Practices
          * 2014, Media and Information Literacy Policies in Portugal (2013)
          * 2014, Book review: Helena Bilandzic, Geoffroy Patriarche & Paul J. Traudt (Eds.): The Social Use of Media: Cultural and social scientific perspectives on audience research.
          * 2014, Awareness of online problematic situations, in The meaning of online problematic situations for children (Smahel, David, and Wright, Michelle F., eds.)
          * 2013, A cultura das celebridades e os jovens: do consumo à participação
          * 2012, Portugal in EU Kids Online: National Perspectives
          * 2011, Book review: Graeme Turner, Ordinary People and the Media: The Demotic Turn, in European Journal of Communication
          * 2010, “Youth and Celebrity Culture – Between Consumption and Participation. A study of 12-17 year-olds in Portugal”
          * 2010, Recensão de Children, Media and Consumption. On the Front Edge, in The Journal of International Communication, 16, 1,
          * 2010, Portuguese audiences research in Communication Studies: an overview of the last decade (1999-2010) with a focus on age and generations
          * 2010, EU Kids Online - Stakeholders’ Forum General report, Comissão Europeia

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona