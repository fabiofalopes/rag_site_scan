# Response for https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
          PT: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227 EN: https://www.ulusofona.pt/en/teachers/carlos-pedro-pinto-lopes-de-almeida-roque-227
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
        fechar menu : https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carlos-pedro-pinto-lopes-de-almeida-roque-227
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carlos Pedro Pinto Lopes De Almeida Roque

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p227
              car***@gmail.com
              4B15-DC0B-C7CF: https://www.cienciavitae.pt/4B15-DC0B-C7CF
              0000-0003-3612-7807: https://orcid.org/0000-0003-3612-7807
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/2c954526-b22f-4b77-81af-ac454f53707e
      : https://www.ulusofona.pt/

        Resume

        Carlos Roque is an assistant researcher at the Planning, Traffic and Safety Division of the Department of Transportation, in LNEC - National Laboratory for Civil Engineering. He holds an M.Sc. and Ph.D. degrees in Transportation Systems from Instituto Superior Técnico of the University of Lisboa. His research interests are in applying machine learning, statistical and econometric methods to road safety, traffic engineering, and transportation economics. He has participated in several research projects, developing an extensive set of road safety models, including crash prediction models, crash severity models (discrete outcome and ordered probability models), hazard-based duration models, and topic models. He is the author or co-author of over 40 journal and conference papers in his scope of expertise. Carlos is the author of a framework for assisting in cost-effective decisions regarding roadside safety interventions based on crash prediction models and safety performance functions. He was also involved in developing infrastructure and operating system requirements for automatic bus guidance on a dedicated mountainous route. Carlos participated in the Portuguese Science and Technology Foundation financed research project SAFESIDE - Roadside Safety, developing an extensive set of roadside accident prediction models and their application in a method for benefit-cost analysis of alternative roadside safety interventions. He was co-author of Portuguese guidelines on safe roadside design and the selection of EN1317 compliant safety barriers. He was also co-author of the background document for the new Portuguese Interurban Road Design Standards and is currently participating in developing the Portuguese design standards for roads and streets in built-up areas. He collaborated in LNEC¿s participation in two research projects co-financed by the European Union: SAFERAFRICA - Innovating dialogue and problems appraisal for a safer Africa (EC, 2016-2019), and PROGREsS - Provision of Guidelines for Road Side Safety (CEDR, 2016-2019). Currently, Carlos is also an Assistant Professor in the Bachelor of Civil Engineering at the Universidade Lusófona de Humanidades e Tecnologias and guest lecturer for Road Safety modelling in one of the courses of the Doctoral Program in Transport Systems at the Instituto Superior Técnico of the University of Lisboa.

        Graus

            * Licenciatura
              Engenharia Civil
            * Outros
              Ac��ão de Formação em Estatística
            * Curso médio
              Aplicação de Semáforos no Controle de Tráfego Urbano
            * Outros
              Haciendo frente a la inseguridad en la Circulación Viaria
            * Outros
              Acção de Formação em Estatística
            * Mestrado
              Mestrado em Transportes
            * Doutoramento
              Sistemas de Transportes
            * Especialização pós-licenciatura
              Iniciação aos sistemas de informação geográfica com software open source
            * Especialização pós-licenciatura
              Introdução à programação em Python para ciência e engenharia

        Publicações

        Artigo em revista

          * 2021-03, Investigation of injury severities in single-vehicle crashes in North Carolina using mixed logit models, Journal of Safety Research
          * 2020-06-12, Shifting from Private to Public Transport using Duration-Based Modeling of a School-Based Intervention, Transportation Research Record: Journal of the Transportation Research Board
          * 2019-10, Topic analysis of Road safety inspections using latent dirichlet allocation: A case study of roadside safety in Irish main roads, Accident Analysis & Prevention
          * 2018-11, Improving roadside design policies for safety enhancement using hazard-based duration modeling, Accident Analysis & Prevention
          * 2015, SAFESIDE: A computer-aided procedure for integrating benefits and costs in roadside safety intervention decision making, Safety Science
          * 2015, Detecting unforgiving roadside contributors through the severity analysis of ran-off-road crashes, Accident Analysis & Prevention
          * 2014, Investigating the relationship between run-off-the-road crash frequency and traffic flow through different functional forms, Accident Analysis & Prevention
          * 2013-07, Observations on the relationship between European standards for safety barrier impact severity and the degree of injury sustained, IATSS Research

        Tese / Dissertação

          * 2013-12, Doutoramento, Critérios de segurança para a área adjacente à faixa de rodagem na Rede Rodoviária Nacional
          * 2001, Mestrado, Influência das características da área adjacente à faixa de rodagem na sinistralidade rodoviária

        Livro

          * 2011, Área Adjacente à Faixa de Rodagem - Manual sobre Aspectos de Segurança, 1, ROQUE, CARLOS PEDRO PINTO LOPES DE ALMEIDA; Cardoso, João Lourenço, InIR, Instituto de Infra-Estruturas Rodoviárias, I.P.
          * 2010, Sistemas de Retenção Rodoviários - Manual de Aplicação, 1, ROQUE, CARLOS PEDRO PINTO LOPES DE ALMEIDA; Cardoso, João Lourenço, InIR, Instituto de Infra-Estruturas Rodoviárias, I.P.
          * 2009, Destinos Principais e Pólos Não Classificados, 1, ROQUE, CARLOS PEDRO PINTO LOPES DE ALMEIDA, InIR, Instituto de Infra-Estruturas Rodoviárias, I.P.

        Capítulo de livro

          * 2012, The Role of Roadside Safety Criteria in Accident Reduction and Injury Severity Mitigation., Accidents: Risk Factors, Health Outcomes and Safety Measures., Nova Science Publishers

        Relatório

          * 2020, Programa Nacional de Investimentos 2030 Mobilidade e Transportes | Rodovia. Recomendações para a definição de critérios a aplicar na seleção e priorização dos projetos a contemplar no PNI 2030.
          * 2020, Norma Técnica para Traçado e Ordenamento da Envolvente de Redes Viárias Urbanas. FASCÍCULO IV - Medidas de acalmia e outros dispositivos de tráfego.
          * 2020, Norma Técnica para Traçado e Ordenamento da Envolvente de Redes Viárias Urbanas. FASCÍCULO III - Características geométricas para vias de tráfego não motorizado.
          * 2020, Norma Técnica para Traçado e Ordenamento da Envolvente de Redes Viárias Urbanas. FASCÍCULO II - Características geométricas para rodovias com tráfego motorizado.
          * 2019, Provision of Guidelines for Road Side Safety (PROGReSS) – Quality Management and final report. Deliverable 5.1.
          * 2019, Norma Técnica para Traçado e Ordenamento da Envolvente de Redes Viárias Urbanas. FASCÍCULO I - Fundamentos sobre utentes e rede rodoviária
          * 2019, Avaliação Comparativa do Serviço de Transporte Ferroviário Suburbano de Passageiros da Fertagus no Eixo Ferroviário Norte-Sul. Último Relatório.
          * 2019, Assessment of Standards for Road design and vehicle safety in Burkina Faso: Proposed amendments and enabling project plans. WP5 – Road safety and traffic management capacity reviews.
          * 2018, Sistema de Mobilidade Do Mondego. Análise de viabilidade da implementação de guiamento automático óptico.
          * 2018, Provision of Guidelines for Road Side Safety (PROGReSS) – Road side safety elements, state of the art report. WP1 Tech Review. Deliverable 1.1.
          * 2018, Programa de ID&I 2013-2020 do Departamento de Transportes do LNEC. Revisão Intercalar (2013-2017).
          * 2018, Parecer técnico sobre o anteprojeto do Aeroporto Internacional do Montijo.
          * 2018, Avaliação Comparativa do Serviço de Transporte Ferroviário Suburbano de Passageiros da Fertagus no Eixo Ferroviário Norte-Sul. Levantamento de práticas de avaliação da qualidade de serviço de transporte público ferroviário suburbano de passageiros.
          * 2017, Sistema de Mobilidade do Mondego. Análise de viabilidade de implementação de guiamento magnético. Laboratório Nacional de Engenharia Civil.
          * 2017, Análise comparada de soluções tecnológicas de transportes para um sistema de mobilidade do mondego custo-eficiente. Avaliação qualitativa dos cenários rodoviários retidos.
          * 2017, Análise comparada de soluções tecnológicas de transportes para um sistema de mobilidade do Mondego custo-eficiente. Sistemas rodoviários eficazes aplicáveis.
          * 2017, Análise comparada de soluções tecnológicas de transportes para um sistema de mobilidade do Mondego custo-eficiente. Relatório Final.
          * 2017, Análise comparada de soluções tecnológicas de transportes para um sistema de mobilidade do Mondego custo-eficiente. Acompanhamento da atualização do estudo de procura na solução base.
          * 2017, Análise comparada de soluções tecnológicas de transportes para um sistema de mobilidade do Mondego custo-eficiente. Acompanhamento da atualização do estudo de procura Fase 2.
          * 2015, Análise comparada de soluções tecnológicas de transportes para um sistema de mobilidade do mondego custo-eficiente. Relatório de progresso.
          * 2015, Análise comparada de soluções tecnológicas de transportes para um sistema de mobilidade do mondego custo-eficiente. Diagnóstico da situação de referência e requisitos para a viabilidade tecnológica e económico-financeira.
          * 2013, Relatório Final – Conclusões. 6º Relatório Safeside
          * 2013, Procedimento de avaliação de alternativas de intervenção. 5º Relatório Safeside
          * 2013, Definição de cenários tipo para acidentes envolvendo a área adjacente à faixa de rodagem. 4º Relatório Safeside
          * 2011, Estimativa do Custo dos Acidentes por Saída da Faixa de Rodagem. 3º Relatório Safeside
          * 2011, Estado-da-Arte. 1º Relatório Safeside
          * 2011, Apoio à revisão da norma de traçado. Elaboração de Documento Base para normas de projecto rodoviário.
          * 2011, Análise de Dados de Sinistralidade e Modelação de Despistes. 2º Relatório Safeside
          * 2001, Área adjacente à faixa de rodagem de estradas interurbanas e sinistralidade

        Artigo em conferência

          * The influence of urban network characteristics in pedestrian injury severity. A case study from Lisbon, TRA2020 - Transport Research Arena. Conference canceled
          * The development of roadside safety criteria for portuguese roads, Young Researchers Seminar 2011
          * SAFESIDE: avaliação custo-benefício de alternativas de intervenção na área adjacente à faixa de rodagem, 8º Congresso Rodoviário Português
          * Recomendações para selecção e colocação de sistemas de retenção rodoviários de veículos., 7º Congresso Rodoviário Português
          * Pressupostos para uma reformulação das Normas de Traçado Rodoviário, 7º Congresso Rodoviário Português
          * Mudança para a mobilidade sustentável na infância: uma avaliação dos impactos das campanhas A serpente papa-léguas nas escolas primárias portuguesas, 9º Congresso Rodoviário Português
          * Modelos explicativos da gravidade dos atropelamentos em Lisboa, 9º Congresso Rodoviário Português
          * Modelos explicativos da gravidade dos acidentes rodoviários: o caso particular dos despistes em auto-estradas, 8º Congresso Rodoviário Português
          * Mobilidade sustentável. A vertente do sistema seguro como elemento a integrar para abordagem holística dos problemas dos utentes vulneráveis., 9º Congresso Rodoviário Português
          * Investigação em segurança rodoviária em Portugal: a utilização de bases de dados hospitalares e sua ligação a outras bases, 9º Congresso Rodoviário Português
          * Investigação de novas formas funcionais para melhoria da aplicabilidade dos modelos de estimativa de frequência de acidentes, 8º Congresso Rodoviário Português
          * Integrating Encroachment Angles from Google Street View in a Roadside Safety Assessment Framework. , 5th International Symposium on Highway Geometric Design
          * Influência das características da área adjacente à faixa de rodagem na sinistralidade , 1º Congresso Rodoviário Português – Estrada 2000
          * Guiamento automático de autocarros. Impactes nos requisitos aplicáveis à infraestrutura, 9º Congresso Rodoviário Português
          * Gravidade das consequências associadas à colisão com barreiras de segurança. Aspetos relevantes para as respetivas normas de desempenho, 9º Congresso Rodoviário Português
          * Definição de uma rede de recenseamento de tráfego para a Rede Fundamental de Estradas de Angola, 8º Congresso Rodoviário Português
          * Critérios de segurança para a área adjacente à faixa de rodagem, 7º Congresso Rodoviário Português
          * Avaliação do impacte potencial do programa U-bike nos padrões de mobilidade da comunidade do Instituto Superior Técnico, 9º Congresso Rodoviário Português
          * As condições de fundação dos prumos e o desempenho das guardas de segurança , 3º Congresso Rodoviário Português – Estrada 2004
          * Aplicação de modelos de duração à segurança rodoviária: o caso particular dos despistes, 9º Congresso Rodoviário Português
          * Análise comparativa da sinistralidade rodoviária e de outros indicadores sócio-económicos em países da CPLP, 8º Congresso Rodoviário Português
          * A hybrid approach for prioritising road safety interventions in urban areas, XXIV International Conference Living and Walking in Cities 2019
          * A Road Safety Approach for a New Revision of the Portuguese Design Guidelines., Road Safety on Four Continents. 16th International Conference
          * 2018, The severity of pedestrian crashes in Lisbon. , 31st ICTCT Conference On the track of future urban mobility: safety, human factors and technology.
          * 2017, Integrating crash severity in roadside safety quantitative analysis: Assessing partial proportional odds models., First International Roadside Safety Conference: Safer Roads, Saving Lives, Saving Money. Transportation Research Board.
          * 2017, Challenges and opportunities for improving the SAFESIDE procedure for cost-benefit assessment of roadside safety intervention alternatives. , First International Roadside Safety Conference: Safer Roads, Saving Lives, Saving Money. Transportation Research Board.

        Poster em conferência

          * 2018, Identification of potential relationships between road safety and design and operation of roadside elements., 31st ICTCT Conference On the track of future urban mobility: safety, human factors and technology.
          * 2018, Analysing the relationship between freeway flow parameters and safety, through the functional form of a crash prediction model. The case of run-off-road crashes. , 31st ICTCT Conference On the track of future urban mobility: safety, human factors and technology.

        Outra produção

          * 2013, SAFESIDE, Software
          * 2011, SAFEGARD, Software

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona