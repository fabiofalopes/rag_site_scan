# Response for https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
          PT: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471 EN: https://www.ulusofona.pt/en/teachers/antonio-manuel-lopes-tavares-4471
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
        fechar menu : https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/antonio-manuel-lopes-tavares-4471
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          António Tavares

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4471
              ant***@ulusofona.pt
              BE13-B649-E249: https://www.cienciavitae.pt/BE13-B649-E249
              0000-0002-3536-7035: https://orcid.org/0000-0002-3536-7035
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/9f22d28c-d49a-4c22-a0e3-a7a49a117565
      : https://www.ulusofona.pt/

        Resume

        António Manuel Lopes Tavares has a degree in Law and a PhD in Political Science, Citizenship and International Relations from the Universidade Lusófona do Porto. He is Director of the 1st cycle of Political Science and Electoral Studies and 2nd cycle of International Relations at Lusófona University - Oporto University Center. Between 1985 and 1991 he was a Member of Portuguese Parliament where he was a member of several parliamentary committees, and also represented Portuguese State at the Parliamentary Assembly of the Western European Union. He has held several positions of responsibility as member of the High Authority for Social Communication, President of TecParques - Portuguese Association of Science and Technology Parks, President of the Board of the General Assembly of the Association of National Defence Auditors, President of the Via Norte Club, President of the Board of the General Assembly of Montepio and member of the Fiscal Council of Real Companhia. He has been Provedor at Santa Casa da Misericórdia in Porto since 2010. In 1982, he won the Adelino Amaro da Costa Prize with the theme "Political Parties and Local Administration". Of his published work, he is the author of the following publications: "A Coabitação Política em Portugal na Vigência da Constituição de 1976" (Edições Almedina, Coimbra, 2016), and "Estado, Sociedade Civil e Misericórdias" (Editora d'Ideias, Coimbra, 2023). He is one of the coordinators of the "Dicionário de Ciência Política e Relações Internacionais" (Edições Almedina, Coimbra, 2022). (Last update: 21 January 2024)

        Graus

            * Doutoramento
              Doutoramento em Ciência Política, Cidadania e Relações Internacionais
            * Outros
              Auditor de Defesa Nacional
            * Mestrado
              Mestrado em Direito
            * Licenciatura
              Licenciatura em Direito
            * Título de especialista
              Especialista em economia social

        Publicações

        Artigo em revista (magazine)

          * 2024-04, Bernardo Reis - O compromisso entre a tradição e a modernidade, Revista da Santa Casa da Misericórdia de Braga

        Artigo em revista

          * 2024-04-15, Exploring the dynamics between artificial intelligence and cybersecurity in Healthcare, ARIS2 - Advanced Research on Information Systems Security
          * 2023-12, Recensão Crítica do livro de Fareed Zakaria "O mundo pós-americano", Revista de Ciência Política 1820
          * 2023-09, USE OF THE ARMED FORCES OF THE REPUBLIC OF POLAND ON THE EXAMPLE OF THE IRAQ MISSION, Security Forum Journal
          * 2022-12-23, O MUNDO NO TEMPO DA PÓS-PANDEMIA: IMPLICAÇÕES GEOPOLÍTICAS E GEOESTRATÉGICAS, HUMAN REVIEW. International Humanities Review / Revista Internacional de Humanidades
          * 2022, The phenomenon of migration in context of threats to internal security of Portugal and Poland, Internal Security
          * 2022, Mais um episódio da Guerra Fria? A intervenção externa na invasão indonésia do território timorense, Revista de Ciência Política 1820
          * 2021-09-27, Human and Civil Rights and Freedomsin a State of Natural Disaster and Epidemic Emergency, Internal Security
          * 2021, The role of Poland in ensuring european security, Internal Security
          * 2021, A ideia de crise política na construção e sentido de um Poder Moderador, Revista de Ciência Política 1820
          * 2019, O poder moderador ou a forma de iniciativa invisível do Presidente, Revista de Ciência Política 1820

        Livro

          * 2023, Parque - Conjunto Habitacional Luso-Lima 1958-2023, 1, Pinto Nunes, Luís; Marques, Susana Lourenço; Luís Albuquerque Pinho; Moura, Sónia; Rocha, Luciana; Bernardo Pinto de Almeida; Loureiro, Luis; Tavares, António, Pierrot Le Fou
          * 2023, Estado, Sociedade Civil e Misericórdias, Tavares, António, Editora d'Ideias
          * 2020, Na Balança do Tempo na Política, Tavares, António, Âncora Editora
          * 2018, Coletânea de Legislação Florestal, Tavares, António, Forrestis e AEDRL | Associação de Estudos de Direito Regional e Local
          * 2016, A coabitação política na vigência da constituição de 1976, Tavares, António, Edições Almedina
          * 2013, Segurança e Defesa Nacional - Um Conceito Estratégico, Tavares, António, Edições Almedina
          * 2012, NATO. Desafios no quadro atual internacional, Tavares, António, Edição própria
          * 1982, Partidos Políticos e Administração Autárquica, Tavares, António, Instituto Fontes Pereira de Melo

        Capítulo de livro

          * 2024, O Presidente da República e o poder de dissolver o parlamento, Peter Lang
          * 2023, The Pillars of Portuguese Foreign Policy: From the First Globalisation to the Twenty-First Century
          * 2023, José Vieira de Carvalho (1938-2002), AMPORTO 1992-2022, AMP
          * 2023, As políticas públicas de habitação, ambiente e sustentabilidade na cidade do século XXI: o exemplo da intervenção social, Políticas Locais de Habitação, Vida Económica
          * 2023, A concessão dos aliados de facilidades nos Açores - o episódio da demissão de um embaixador, 650.º aniversário da Aliança Luso-Britânica: balanço do passado e perspetivas de futuro, Gestlegal
          * 2023, A INOVAÇÃO NA INVESTIGAÇÃO E DOCÊNCIA: O CASO DA HISTÓRIA E DA CIÊNCIA POLÍTICA NO ESTUDO DO DIREITO, Sembrando el futuro: la revolucion en la formacion y desarrollo de competencias, Dykinson
          * 2022, Solidariedade e Ação Social, Ambição: duplicar o PIB em 20 Anos, Edições Almedina
          * 2022, Impulsionar a economia e a qualidade das instituições, Manual de Boas Práticas no Envelhecimento - intervenção em tempos de pandemia, APTSES
          * 2022, Direitos humanos e saúde mental: novos desafios para o século XXI, Compêndio de Direitos Humanos, Comissão de Direitos Humanos da Ordem dos Advogados
          * 2018, Um gesto de Mãe, Cadeia de Tires - mãos de esperança - Fotografias de Rosa Reis, Ministério da Justiça e INCM
          * 2018, Ação Social vista de fora, Serviços de Ação Social do Politécnico do Porto: 20 anos - Factos e Pessoas, Instituto Politécnico do Porto
          * 2013, Um conceito estratégico, Segurança e Defesa Nacional - Um Conceito Estratégico, Edições Almedina
          * 2012, Parques de Ciência e Tecnologia como fator de competitividade no apoio às empresas para atrair e fixar os melhores talentos: o caso do TECMAIA, XIX Congresso Internacional de Formação para o Trabalho Norte de Portugal/Galiza, IEFP
          * 2005, Uma questão jurídica, Obra coletiva "Uma demanda escusada", Edição da Santa Casa da Misericórdia de Matosinhos

        Edição de livro

          * 2023, Springer Nature Singapore
          * 2022, Edições Almedina
          * 2022, Editora d'Ideias
          * 2013, Misericórdia do Porto e União das Misericórdias Portuguesas

        Entrada de dicionário

          * 2022, Coimbra, Notáveis, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Método D’Hondt, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Ministros, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Líder de Opinião, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Governo de gestão, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Governamentabilidade
          * 2022, Coimbra, Gabinete sombra, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Gabinete ministerial, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Coligação, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Aliança eleitoral, Dicionário de Ciência Política e Relações Internacionais
          * 2022, Coimbra, Agenda política, Dicionário de Ciência Política e Relações Internacionais

        Artigo em conferência

          * 2024-03-01, China-EU Relations In the Ongoing International Security Environment, 9th International Conference on Social sciences, Humanities and Education
          * 2023-10, O PRESIDENTE DA REPÚBLICA E O PODER DE DISSOLVER O PARLAMENTO , Congreso Universitario Internacional de Innovación, Investigación y Docencia 2023
          * 2023-06-08, A INOVAÇÃO NA INVESTIGAÇÃO E DOCÊNCIA: O CASO DA HISTÓRIA E DA CIÊNCIA POLÍTICA NO ESTUDO DO DIREITO, III Congreso internacional de innovación en la docencia e investigación de las Ciencias Sociales y Jurídicas
          * 2023-04-01, O mandato do Presidente da República: condicionante ou livre-arbítrio
          * 2022-10, O MUNDO NO TEMPO DA PÓS-PANDEMIA: IMPLICAÇÕES GEOPOLÍTICAS E GEOESTRATÉGICAS, Congreso Universitario Internacional de Innovación, Investigación y Docencia 2022
          * 2009-06-13, A missão das Misericórdias perante a comunidade e o Estado, IX Congresso Nacional das Misericórdias
          * 2006-05, Sustentabilidade atual das Misericórdias na Conjuntura Atual, II Congresso das Misericórdias do Norte

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona