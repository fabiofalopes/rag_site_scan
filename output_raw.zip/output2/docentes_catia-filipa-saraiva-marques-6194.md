# Response for https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
          PT: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194 EN: https://www.ulusofona.pt/en/teachers/catia-filipa-saraiva-marques-6194
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
        fechar menu : https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/catia-filipa-saraiva-marques-6194
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Cátia Filipa Saraiva Marques

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6194
              cat***@ulusofona.pt
              8015-B7EE-5FFC: https://www.cienciavitae.pt/8015-B7EE-5FFC
              0000-0001-9648-6380: https://orcid.org/0000-0001-9648-6380
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/1f8d9e26-0750-4c32-866b-45cc5ed5f4b3
      : https://www.ulusofona.pt/

        Resume

        Dr. Cátia Marques is, since October 2020, an Assistant Professor at Faculty of Veterinary Medicine from the Lusophone University of Humanities and Technologies. She has concluded her Master Integrated Degree in Veterinary sciences in 2010 and more recently, in 2019, she received her PhD in Veterinary Sciences at the Faculty of Veterinary Medicine from the University of Lisbon. Cátia Marques started to work in research while still a student, in 2005, under the scope of a National entomological study about Culicoides spp., the vectors of bluetongue disease. Later, she conducted her Master´s thesis at the veterinary blood bank from the veterinary teaching hospital from University of Lisbon, which resulted in her first publication in a scientific journal in 2010. She also worked for several years in the parasitology department from the same University, integrating several research projects about tick borne diseases and about the immune response of dogs to leishmaniosis. In these years Dr. Cátia Marques acquired expertise's in molecular biology (PCR, qPCR with taqman or sybergreen, flow cytometry) and project management. In 2014, she received a national grant to enroll a PhD program in the field of veterinary clinical microbiology. Her phD was dedicated to the study of antimicrobial resistance and molecular epidemiology of uropathogenic bacteria from companion animals and humans. During her PhD, Dr. Cátia Marques was awarded several prizes and distinctions at international and national meetings for the quality of the works presented. Her PhD resulted in 5 publications in international peer reviewed journals as a first author, one of which was conducted under the umbrella of a multicentric team (12 countries, 14 laboratories). As a result of her research work, Dr. Cátia Marques has 19 published papers (7 as the first author), 3 chapter books and around 70 scientific communications (oral and poster) in national and international meetings. She is a regular referee in scientific journals (Microbial Drug Resistance, IF: 2.519; Antibiotic journal, IF: 3.893) and was recently invited to become a Guest editor for Topic Issues for the Antibiotic journal (IF: 3.893). She has a total of 389 citations and a h-index of 10 according to the Web of science (https://publons.com/researcher/1408171/catia-marques/). She has also been involved in the writing and active research in several national and international research projects. In parallel, she has had an active role in student mentoring, including of MSc and PhD students. Her current research interest is in the field of microbiology, namely in the study of multidrug resistant and pathogenic bacteria, molecular epidemiology studies through the use of metagenomic analysis and the pursuit of novel prophylactic and therapeutic alternatives to the use of antimicrobials.

        Graus

            * Doutoramento
              Ciências Veterinárias
            * Mestrado integrado
              Medicina Veterinária
            * Outros
              XII Course on Laboratory Animal Science/ XII Curso de Experimentação Animal

        Publicações

        Artigo em revista

          * 2021-12-29, Human and Companion Animal Proteus mirabilis Sharing, Microbiology Research
          * 2021-11, ESBL/AmpC-Producing Enterobacteriaceae Fecal Colonization in Dogs after Elective Surgery, Microbiology Research
          * 2021, Learning Histology: Veterinary Medicine Student Preferences in the digital era, Revista Lusófona de Ciência e Medicina Veterinária
          * 2021, National survey of cat tumors in 2019: A retrospective Study, Revista Lusófona de Ciência e Medicina Veterinária
          * 2019-10-21, Development of Dog Immune System: From in Uterus to Elderly, Veterinary Sciences
          * 2019-10-18, Meglumine Antimoniate and Miltefosine Combined With Allopurinol Sustain Pro-inflammatory Immune Environments During Canine Leishmaniosis Treatment, Frontiers in Veterinary Science
          * 2019-09-16, Detection of multidrug resistance and extended-spectrum/plasmid-mediated AmpC beta-lactamase genes in Enterobacteriaceae isolates from diseased cats in Italy, Journal of Feline Medicine and Surgery
          * 2019-04-03, Evidence of Sharing of Klebsiella pneumoniae Strains between Healthy Companion Animals and Cohabiting Humans, Journal of Clinical Microbiology
          * 2019-03-01, Klebsiella pneumoniae causing urinary tract infections in companion animals and humans: population structure, antimicrobial resistance and virulence genes, Journal of Antimicrobial Chemotherapy
          * 2019-01, Clonal relatedness of Proteus mirabilis strains causing urinary tract infections in companion animals and humans, Veterinary Microbiology
          * 2018-10-05, Emergence of Escherichia coli ST131 H30/H30-Rx subclones in companion animals, Journal of Antimicrobial Chemotherapy
          * 2018-09, Detection of Anaplasma phagocytophilum, Candidatus Neoehrlichia sp., Coxiella burnetii and Rickettsia spp. in questing ticks from a recreational park, Portugal, Ticks and Tick-borne Diseases
          * 2018-05, Risk Factors for Nasal Colonization by Methicillin-Resistant Staphylococci in Healthy Humans in Professional Daily Contact with Companion Animals in Portugal, Microbial Drug Resistance
          * 2018-02-01, Increase in antimicrobial resistance and emergence of major international high-risk clonal lineages in dogs and cats with urinary tract infection: 16 year retrospective study, Journal of Antimicrobial Chemotherapy
          * 2017-01, Guidelines for the Detection of Rickettsia spp., Vector-Borne and Zoonotic Diseases
          * 2017-01, Guidelines for the Detection of Babesia and Theileria Parasites, Vector-Borne and Zoonotic Diseases
          * 2016-01-08, Successful treatment of feline leishmaniosis using a combination of allopurinol and N-methylglucamine antimoniate, Journal of Feline Medicine and Surgery Open Reports
          * 2016, Trends and molecular mechanisms of antimicrobial resistance in clinical staphylococci isolated from companion animals over a 16 year period, Journal of Antimicrobial Chemotherapy
          * 2016, Evaluation of antimicrobial resistance and virulence of enterococci from equipment surfaces, raw materials, and traditional cheeses, International Journal of Food Microbiology
          * 2016, European multicenter study on antimicrobial resistance in bacteria isolated from companion animal urinary tract infections.
          * 2013-09, Leishmaniose felina., Medicina Veterinária
          * 2011, Frequency of blood type A, B, and AB in 515 domestic shorthair cats from the Lisbon area, Veterinary Clinical Pathology

        Tese / Dissertação

          * 2019, Doutoramento, Uropathogenic Proteus mirabilis and Klebsiella pneumoniae in companion animals: molecular epidemiology, antimicrobial resistance and zoonotic potential
          * 2010, Mestrado, Frequência do antigénio eritrocitário DEA 1.1 em canídeos e dos antigénios eritrocitários A, B e AB em felídeos de Lisboa, Portugal

        Capítulo de livro

          * 2020, The public health risk of companion animal to human transmission of antimicrobial resistance during different types of animal infection., Advances in Animal Health, Medicine and Production., Springer
          * 2020, The gut microbiome and antimicrobial resistance in companion animals., Advances in Animal Health, Medicine and Production., Springer
          * 2020, Antimicrobial resistance trends in dogs and cats with urinary tract infection, Advances in Animal Health, Medicine and Production., Springer

        Resumo em conferência

          * 2018-12-19, RESEARCH COMMUNICATIONS OF THE 28th ECVIM-CA CONGRESS
          * 2017-11-07, Research Communications of the 27th ECVIM-CA Congress
          * 2017-01, Research Communications of the 26th ECVIM-CA CONGRESS
          * 2015-11-09, Research Communications of the 25th ECVIM-CA Congress
          * 2015-01, Research Communications of the 24th ECVIM-CA Congress

        Poster em conferência

          * 2022-04, KPC-3 -, OXA-181 - and OXA-48 – producing Enterobacterales found on clinical isolates from companion animals. , 32th European Congress of Clinical Microbiology and Infectious Diseases (ECCMID)
          * 2021-10, Uso da norma ISO 9001:2008 para a implementação e certificação de um sistema de gestão de qualidade num centro de atendimento médico veterinário, XVII Congresso Hospital Veterinário de Montenegro
          * 2021-10, Estudo retrospectivo da frequência de tumores de pele em felinos em Portugal, XVII Congresso Hospital Veterinário de Montenegro
          * 2021-10, Caracterização da expressão proteica de RE e RP em lesões mamárias benignas em gata, XVII Congresso Hospital Veterinário de Montenegro
          * 2021-06, Whole genome sequencing of a K. pneumoniae ST348 from a cat with UTI, International Society of Feline Medicine World Feline Congress 2021
          * 2021-06, Skin and Soft Tissue infection caused by OXA-181 producing Klebsiella pneumoniae ST273 in Portugal, International Society of Feline Medicine World Feline Congress 2021
          * 2021-06, 2019 Cancer Registry of feline tumours in Portugal, International Society of Feline Medicine World Feline Congress 2021
          * 2021-04, Peptides produced by lactic acid fermentation as novel antimicrobial and anti-inflammatory alternatives, 32th European Congress of Clinical Microbiology and Infectious Diseases (ECCMID)
          * 2019, Public health impact of ESBLs/pAmpC- producing Escherichia coli causing urinary tract infections in non-related companion animals and humans., Microbiotec
          * 2019, First report of a OXA-181 producing Escherichia coli from a dog in Portugal., 29th European Congress of Clinical Microbiology and Infectious Diseases
          * 2019, Fecal microbiome of healthy dogs from households and shelters. , 29th European Congress of Clinical Microbiology and Infectious Diseases
          * 2019, Analysis of ESBL-producing Escherichia coli from pets and their owners – faecal carriage of different CTX-M-producing E. coli in a dog and a human in Portugal. , 8th Symposium on Antimicrobial Resistance in Animals and the Environment
          * 2018, Miltefosine and meglumine antimoniate treatments combined with allopurinol restore lymphokine normal levels in canine leishmaniosis, CIISA Congress 2018
          * 2018, Lymphocyte differentiation in dogs treated for canine leishmaniasis. , 1st Caparica International Caparica Congress on Leishmaniasis
          * 2018, Human and companion animal faecal carriage of P. mirabilis: evidence of intra and interspecies sharing, 28th European Congress of Clinical Microbiology and Infectious Diseases
          * 2018, Evidence of Klebsiella pneumoniae sharing between healthy companion animals and co-habiting humans
          * 2018, Companion animals as reservoirs of Klebsiella pneumoniae. , CIISA Congress 2018
          * 2018, Clonal relatedness of community and hospital-acquired Proteus mirabilis strains causing urinary tract infections in companion animals and humans. , 28th European Congress of Clinical Microbiology and Infectious Diseases
          * 2018, Characterization of gut microbiome of healthy companion animals from households and shelters, CIISA Congress 2018
          * 2017, Virulence and antimicrobial resistance mechanisms of uropathogenic Proteus mirabilis from companion animals and humans., 27th European Congress of Clinical Microbiology and Infectious Diseases
          * 2017, Using the formula for rational antimicrobial therapy (FRAT) for prudent antimicrobial use in feline urinary tract Infection., International Society of Feline Medicine World Feline Congress 2017
          * 2017, Use of amoxicillin/clavulanate in the treatment of ESBL-producing Klebsiella pneumoniae feline UTI., International Society of Feline Medicine World Feline Congress 2017
          * 2017, The gut of healthy dogs is a reservoir of antimicrobial resistant and pathogenic Escherichia coli. , 2nd International Caparica Conference in Antimicrobial Resistance (IC2AR)
          * 2017, Multidrug-resistant CMY-2-producing Proteus mirabilis causing UTI in a dog: the therapeutic dilemma. , XIII Congresso Hospital Veterinário de Montenegro
          * 2017, Evidence of sharing of MDR K. pneumoniae between infected and non-infected cats from same household, 27th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2017, Epidemiologia molecular e caracterização genética de estirpes de Klebsiella pneumoniae multirresistentes provenientes de um hospital universitário no Brasil. , 4º Congresso Nacional de Medicina Tropical
          * 2017, Cats with a urinary tract infection are reservoirs of antimicrobial resistant and virulent Escherichia coli isolates., International Society of Feline Medicine World Feline Congress 2017
          * 2016, Spread of major human ESBL and AmpC-producing Escherichia coli lineages in companion animals with UTI over 17 years in Portugal., 26th European Congress of Clinical Microbiology and Infectious Diseases
          * 2016, Resistant CC17 E. faecium causing urinary tract infections in companion animals., 26th European Congress of Clinical Microbiology and Infectious Diseases
          * 2016, Resistance to amoxicillin/clavulanate and third-generation cephalosporins in uropathogenic E. coli from companion animals., XII Congresso Hospital Veterinário Montenegro
          * 2016, Rational empirical antimicrobial therapy (FRAT) for UTI in companion animal , XII Congresso Hospital Veterinário Montenegro
          * 2016, Nosocomial faecal colonization by extended-spectrum ß-lactamase producer Gram-negative bacteria in healthy dogs., 26th European Congress of Veterinary Internal Medicine – Companion Animals
          * 2016, Factores de risco para colonização nasal por staphylococci meticilina-resistente em portadores humanos saudáveis em contacto diário com animais em Portugal, 7º Encontro de Formação da Ordem dos Médicos Veterinários
          * 2016, Expansion of ESBL-producing high-risk virulent ST15 Klebsiella pneumoniae lineage causing urinary tract infection in companion animals. , 26th European Congress of Clinical Microbiology and Infectious Diseases
          * 2016, European multicenter study on antimicrobial resistance in companion animal urinary tract infection. , ASM Microbe 2016
          * 2016, Emergence of CMY-2-producing Proteus mirabilis in companion animals with UTI: 16 years study, ASM Microbe 2016
          * 2016, Companion animals are reservoirs of high-risk human ESBL and AmpC-producing Escherichia coli Lineages, ASM Microbe 2016
          * 2016, CTX-M-15-producing multidrug resistant Klebsiella pneumoniae high-risk lineages cause urinary tract infection in companion animals., ASM Microbe 2016
          * 2015, Multidrug-resistant uropathogenic bacteria in cats: a 13 Year retrospective snapshot., International Society of Feline Medicine Congress 2015
          * 2015, Methicillin-resistant Staphylococcus epidermidis and Staphylococcus haemolyticus in Portugal: a comparison between companion animals and humans in close contact. , 25th European Congress of Clinical Microbiology and Infectious Diseases
          * 2015, Are animals a reservoir of extraintestinal pathogenic Escherichia coli strains and blaCTX-M-1/32 epidemic plasmids for humans? , 25th European Congress of Clinical Microbiology and Infectious Diseases
          * 2015, Antimicrobial resistance in Feline Urinary Tract infections. , International Society of Feline Medicine Congress 2015
          * 2013, Transfusão de componentes eritrocitários em gatos: um estudo retrospectivo, IX Congresso Hospital Veterinário de Montenegro
          * 2013, The forgotten disease of cats: a case of feline leishmaniosis. , 5th World Congress on Leishmaniasis - WorldLeish5
          * 2013, Molecular survey of Leishmania, Ehrlichia/Anaplasma, Rickettsia and Babesia/Theileria genus in dogs from Maio Island, Cape Verde, 5th World Congress on Leishmaniasis - WorldLeish5
          * 2013, Molecular survey of Leishmania, Ehrlichia, Anaplasma, Rickettsia and Babesia genus in wolves [Canis lupus signatus] from Northern Portugal., Canine Leishmaniasis and other vector-borne diseases: current state of knowledge
          * 2013, Impact on the metabolic function and immune activity of dog hepatocytes when exposed to Leishmania infantum, EMBO young scientists fórum 2013
          * 2013, Exocitose enzimática por células polimorfonucleares expostas a Leishmania infantum., 4ªs Jornadas Científicas do IHMT
          * 2013, Canine Leishmaniosis: 16 years of veterinary laboratorial diagnosis, 5th World Congress on Leishmaniasis - WorldLeish5
          * 2012, Tick-borne agentes from Lisbon public spaces, XVI Congresso Português de Parasitologia da Sociedade Portuguesa de Parasitologia
          * 2012, Contribution to the study of the tick fauna in dogs of Portugal. , XVI Congresso Português de Parasitologia da Sociedade Portuguesa de Parasitologia
          * 2012, Anaplasma/Ehrlichia spp., Babesia/Theileria spp. and Mycoplasma spp. in ticks collected from dogs with owner from Portugal., XVI Congresso Português de Parasitologia da Sociedade Portuguesa de Parasitologia
          * 2011, Sucesso no armazenamento de componentes sanguíneos de gato, colhidos em sistema semi-fechado e conservados em refrigeração/congelação até 35/260 dias. , V Congresso da Sociedade Portuguesa de Ciências Veterinárias
          * 2011, Identificação de espécies de Culicoides (DIPTERA:CERATOPOGONIDAE) referidas pela primeira vez em Portugal Continental e no Arquipélago dos Açores por caracterização morfológica no âmbito do Programa Entomológico Nacional de Língua Azul. , V Congresso da Sociedade Portuguesa de Ciências Veterinárias
          * 2009, Prevalence of feline blood types in the Lisbon region of Portugal. , 19th European Congresso of Veterinary Internal Medicine – Companion Animals

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona