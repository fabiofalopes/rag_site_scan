# Response for https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
          PT: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117 EN: https://www.ulusofona.pt/en/teachers/ana-paula-de-oliveira-paulino-5117
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
        fechar menu : https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-paula-de-oliveira-paulino-5117
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Paula Paulino

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5117
              pau***@ulusofona.pt
              0017-93D1-C296: https://www.cienciavitae.pt/0017-93D1-C296
              0000-0001-8249-5366: https://orcid.org/0000-0001-8249-5366
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/db2cab57-d4e2-454a-bad8-c06115000f7b
      : https://www.ulusofona.pt/

        Resume

        Paula Paulino. Concluiu o(a) Doutoramento em Psicologia em 2015 pelo(a) Universidade de Lisboa Faculdade de Psicologia, Mestrado em Psicologia Social e Organizacional em 2006 pelo(a) ISCTE-Instituto Universitário de Lisboa e Licenciatura em Psicologia em 2003 pelo(a) Universidade de Lisboa Faculdade de Psicologia. É Associação EPIS – Empresários pela Inclusão Social. no(a) Associação EPIS – Empresários pela Inclusão Social., Coordenadora do Programa de Mentorado da Escola de Psicologia e Ciências da Vida no(a) Universidade Lusófona de Humanidades e Tecnologias Escola de Psicologia e Ciências da Vida, Psicóloga Educacional no(a) Universidade de Lisboa Faculdade de Psicologia, Investigador no(a) Universidade de Lisboa Faculdade de Psicologia, Professor Auxiliar no(a) Universidade de Lisboa Faculdade de Psicologia e Psicóloga Clínica no(a) Clínica Privada. Publicou 8 artigos em revistas especializadas. Coorientou 1 tese(s) de doutoramento. Coorientou 2 dissertação(ões) de mestrado. Participa e/ou participou como Bolseiro de Investigação em 2 projeto(s). Atua na(s) área(s) de Ciências Sociais com ênfase em Psicologia. No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural são: Mudança atitudinal; alimentação; sedentarismo; Teses de doutoramento - 2015; Domínio/Área Científica::Ciências Sociais::Psicologia; Adolescentes; Saúde; Suporte social recebido; Adolescents; Health; Social support; Cyberbullying. College Students. Victimization. Emotions. Coping strategies.; Cyberbullying. Estudiantes universitarios. Victimización. Emociones. Estrategias de enfrentamiento.; Cyberbullying. Estudantes universitários. Vitimização. Emoções. Estratégias de enfrentamento.; Alimentação saudável; Influência social; Teoria do comportamento planeado; Healthy eating; Social influence; Theory of planned behaviour; Mudança atitudinal; Alimentação; Sedentarismo; Attitude shift; Food habits; Sedentarism; Resolução de problemas; Autoregulação; Aprendizagem; Crenças; Alunos do ensino básico; Teses de mestrado - 2018; alimentação; sedentarismo; adolescents; self- regulation of motivation; motivational beliefs; regulation of motivation strategies; adolescentes; autorregulação da motivação; crenças motivacionais; estratégias de regulação da motivação; Autorregulação da motivação; adolescentes; autoeficácia; metas de realização; valor da tarefa; Desenvolvimento identitário; estudo inicial de validação; adultos emergentes; psicopatologia; Cyberbullying; Autorregulação do comportamento; Autoinstrução; Protocolo cibernético de autoinstrução; dor crónica; expectativas de papel de género; coping; juízos médicos; parentalidade; estratégias parentais; imagemorphing; sacadas; velocidade; .

        Graus

            * Licenciatura
              Psicologia
            * Mestrado
              Psicologia Social e Organizacional
            * Doutoramento
              Psicologia
            * Doutoramento
              Psicologia

        Publicações

        Artigo em revista

          * 2024-02-06, Measuring and characterizing cyberbullying among Chilean university students, Current Psychology
          * 2023-10-26, Utrecht grief rumination scale (UGRS): Psychometric study of validation of the Portuguese version, Death Studies
          * 2022, Self-Regulated Learning and Working Memory Determine Problem-Solving Accuracy in Math, The Spanish Journal of Psychology
          * 2022, Aggressive communication style as predictor of cyberbullying, emotional wellbeing, and personal moral beliefs in adolescence
          * 2022, Aggressive Communication Style as Predictor of Cyberbullying, Emotional Well-being, and Personal Moral Beliefs in Adolescence,Un estilo de comunicación agresivo como predictor del ciberacoso, el bienestar emocional y las creencias morales personales en la adolescencia, Psicologia Educativa
          * 2021-09-19, Percursos de estudantes da Educação Superior com trajetórias de insucesso, Ensaio: Avaliação e Políticas Públicas em Educação
          * 2021-05, Prosociality in Cyberspace: Developing Emotion and Behavioral Regulation to Decrease Aggressive Communication, Cognitive Computation
          * 2020-07-31, Developing children's collaborative problem-solving skills with a serious game, IEEE Computer Graphics and Applications
          * 2020-02-17, Online verbal aggression, social relationships, and self-efficacy beliefs, New Media & Society
          * 2020, Aggressiveness as a determiner of adolescents’ intentions to engage in cyberbullying, emotional well-being and personal moral beliefs.
          * 2019-04, Automatic cyberbullying detection: A systematic review, Computers in Human Behavior
          * 2019, Festarola: A Game for Improving Problem Solving Strategies. , VS Games
          * 2019, Explaining adolescents’ use of verbal aggression online through self-efficacy beliefs and social relationships.
          * 2019, A Step Towards Prosociality: Emotion and Behavioral Regulation to Decrease Aggressiveness in Cyberbullying.
          * 2018, Escala das Dimensões do Desenvolvimento da Identidade: Estudos psicométricos iniciais
          * 2018, Dimensions of Identity Development Scale: Initial psychometric studies
          * 2018, Cyberbullying: Shaping the use of verbal aggression through normative moral beliefs and self-efficacy.
          * 2018, Cyberbullying: Shaping the use of verbal aggression through normative moral beliefs and self-efficacy, New Media and Society
          * 2017-12-15, Família e escola: Perspetivas sobre a utilização de meios tecnológicos e segurança, Revista de Estudios e Investigación en Psicología y Educación
          * 2016-12-01, O cyberbullying em contexto universitário do Brasil e Portugal: vitimização, emoções associadas e estratégias de enfrentamento, Revista Ibero-Americana de Estudos em Educação
          * 2016-09-01, Students’ motivation to learn in middle school - a self-regulated learning approach, Electronic Journal of Research in Educational Psychology
          * 2016, The cyberbullying in context university of Brazil and Portugal: victimization, emotions associates and coping strategies
          * 2016, Students’ motivation to learn in middle school a self-regulated learning approach,Motivación para el aprendizaje en alumnado de Enseñanzas Medias: un enfoque de aprendizaje autorregulado, Electronic Journal of Research in Educational Psychology
          * 2016, Motivation beliefs and strategies in learning: A scale development
          * 2016, Crenças e Estratégias da Motivação na Aprendizagem: Desenvolvimento de uma Escala, Psychologica
          * 2015, Autorregulação da Motivação: Crenças e Estratégias de Alunos Portugueses do 7º ao 9º Ano de Escolaridade, Psicologia: Reflexão e Crítica
          * 2012, Promover a regulação da motivação na aprendizagem, Cadernos de Educação FaE/PPGE/UFPel
          * 2012, O “Jogo dos Alimentos”: Mudança atitudinal face à alimentação e ao sedentarismo em crianças do 1.º Ciclo
          * 2007, Construção e determinação das qualidades psicométricas do Questionário de Suporte Social Institucional na Saúde (QSSIS)
          * 2005, O optimismo comparativo face à saúde: da infância à adolescência , Psychologica

        Tese / Dissertação

          * 2018, Mestrado, Aprendizagem autorregulada e crenças motivacionais na resolução de problemas matemáticos em alunos do 4º ano do 1º ciclo do ensino básico
          * 2015, Doutoramento, Regulação da motivação : avaliação e promoção da dimensão motivacional de aprendizagem autorregulada - contributos de alunos e professores -
          * 2007, Mestrado, A influência social nas escolhas alimentares saudáveis em adolescentes e jovens adultos: formação de impressões, identificação e norma de grupo

        Capítulo de livro

          * 2020, Contraste Mental com Intenções de Implementação: Uma estratégia de autorregulação da aprendizagem, Autorregulação da aprendizagem: Cenários, desafios, perspetivas para o contexto educativo, Editora Vozes.
          * 2010, Do estoicismo face à dor: Uma teoria enraizada sobre as expectativas de papel de género de leigo/as e enfermeiro/as , Gênero e saúde: diálogos Ibero-Brasileiros

        Artigo em boletim informativo

          * 2018, Guia informativo para agentes educativos.

        Relatório

          * 2023-05-23, IO3 and IO4 – Factor and Needs Analysis Report. DIGITAL TOOL FOR MENTORSHIP AGAINST DROPOUT.

        Artigo em conferência

          * WELL-BEING, MOTIVATION, AND ADAPTATION OF UNIVERSITY STUDENTS: THE POTENTIAL INFLUENCE OF MENTORING PROGRAMS, EDULEARN: 15th International Conference on Education and New Learning Technologies
          * Trajetórias académicas dos estudantes da rede federal de educação profissional tecnológica: Um estudo sobre as variáveis motivacionais e contextuais., XV Congreso Internacional Gallego-Portugués de Psicopedagogía
          * Self- regulation of motivation: Contributing to students’ learning in middle school
          * Estudantes universitários em situação de insucesso: Estratégias de autorregulação utilizadas e percebidas como importantes, III Congresso Internacional Envolvimento dos Alunos na Escola: Perspetivas da Psicologia e Educação Motivação para o Desempenho Académico
          * Crenças motivacionais e processos autorregulatórios na resolução de problemas de matemática no 1º ciclo de escolaridade, XV Congreso Internacional Gallego-Portugués de Psicopedagogía.
          * 2019, Festarola: A game for improving problem solving strategies

        Resumo em conferência

          * 2023-06-29, UNIVERSITY STUDENTS' LEARNING MOTIVATION SCALE: VALIDATION FOR THE PORTUGUESE POPULATION, The Future of Education - 13th Edition
          * 2022-07, Mental contrasting with implementation intentions: a metacognitive strategy on educational context, ICPIMP 2022: International Conference on Pedagogy, Innovative Methods and Practices
          * 2022, Detecting hate speech and cyberbullying using natural language processing, ICDID 2022: International Conference on Digital Innovation and Development
          * 2022, As «camadas da aprendizagem»: Níveis de reflexão de alunos do ensino básico e secundário sobre o ensino explícito de uma estratégia autorregulatória. , I Congresso Internacional de Investigação e Intervenção em Psicologia Escolar e da Educação
          * 2022, AUTORREGULAÇÃO E MOTIVAÇÃO NA APRENDIZAGEM: INVESTIGAÇÃO, FORMAÇÃO E INTERVENÇÃO EM CONTEXTOS DO ENSINO SECUNDÁRIO E SUPERIOR, IV International Conference on Student Engagement at School: Social and Psychological Perspectives (IVCIEAE)
          * 2021, Intervir na dimensão motivacional da aprendizagem: Contraste Mental com Intenções de Implementação., XV Congreso Internacional Gallego-Portugués de Psicopedagogía. Braga, setembro 2021
          * 2019, Perspetivas Atuais e Futuras no Estudo da Autorregulação: Investigar e intervir em contexto educacional., II Encontro Luso-Brasileiro de Aprendizagem Autorregulada. Lisboa, setembro 2019
          * 2019, Determinantes da agressão em cyberbullying: Autoeficácia e experiências de vitimização. , XV Congreso Internacional Gallego-Portugués de Psicopedagogía. A Coruña, setembro 2019
          * 2019, Determinantes da agressão em cyberbullying: Autoeficácia e experiências de vitimização, XV Congreso Internacional Gallego- Portugués de Psicopedagogía
          * 2019, Descomprometimento moral no cyberbullying: Perceções de adolescentes no contexto Português. , XV Congreso Internacional Gallego-Portugués de Psicopedagogía
          * 2019, Descomprometimento moral no cyberbullying: Perceções de adolescentes no contexto Português, XV Congreso Internacional Gallego-Portugués de Psicopedagogía. A Coruña, setembro 2019
          * 2019, Crenças motivacionais e processos autorregulatórios na resolução de problemas de matemática no 1º ciclo de escolaridade, XV Congreso Internacional Gallego-Portugués de Psicopedagogía. A Coruña, setembro 2019
          * 2016, Self-regulated learning strategies in problem solving in math: "let's party" as an educational game. , II Congresso Internacional Envolvimento dos Alunos na Escola: Perspetivas da Psicologia e Educação.
          * 2016, Promoção da motivação dos alunos na resolução de problemas na Matemática: O jogo «A Festarola». , II Congresso Internacional Envolvimento dos Alunos na Escola: Perspetivas da Psicologia e Educação
          * 2016, Cyberbullying: a tomada de decisão como um processo educativo na regulação do comportamento. , 3º Congresso da Ordem dos Psicólogos Portugueses
          * 2016, A avaliação das crenças motivacionais, expectativas e avaliação de desempenho na resolução de problemas. , II Congresso Internacional Envolvimento dos Alunos na Escola: Perspetivas da Psicologia e Educação
          * 2016, A "Festarola": Um jogo educativo para a promoção de competências de resolução de problemas. , 3º Congresso da Ordem dos Psicólogos Portugueses
          * 2013, Teachers' beliefs about the promotion of students' self-regulation of motivation, , 35th International School Psychology Association Conference
          * 2013, Motivação na Aprendizagem: crenças e estratégias de autorregulação da motivação de alunos do 3ºciclo de escolaridade, , Congresso Internacional Envolvimento dos Alunos na Escola: Perspetivas da Psicologia e Educação
          * 2012, Challenging Motivation for Learning: "Self- regulation of Motivation for Learning Scale", International Psychological Applications Conference and Trends, Lisboa.
          * 2012, Autorregulação da Motivação na Aprendizagem: Crenças e Estratégias de alunos do 3ºCiclo de Escolaridade, XII Colóquio International Psicologia e Educação
          * 2011, Knowing how to learn and how to teach motivation: Contributions from Self-Regulation of Motivation to more a effective learning", International Conference on Education and Educational Psychology, Istambul
          * 2010, A formação de impressões e as escolhas alimentares: o significado social da alimentação, VII Simpósio de Investigação em Psicologia, Braga.

        Poster em conferência

          * 2018, Com>¿Viver app: Promoting pro-social behavior online

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona