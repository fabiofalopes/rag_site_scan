# Response for https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
          PT: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406 EN: https://www.ulusofona.pt/en/teachers/elsa-maria-bacala-estrela-5406
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
        fechar menu : https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/elsa-maria-bacala-estrela-5406
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Elsa Estrela

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5406
              p54***@ulusofona.pt
              E919-3A7A-E42C: https://www.cienciavitae.pt/E919-3A7A-E42C
              0000-0002-2889-4195: https://orcid.org/0000-0002-2889-4195
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/a66ec045-acc1-47a5-8eab-7a2e8918dada
      : https://www.ulusofona.pt/

        Resume

        I hold the position of Assistant Professor in Education at Lusofona University, where I also serve as Director of the Master of Educational Administration and Regulation of Education. Additionally, I am Co-Chair of Public Policies and Governance in Education Research and Learning Community and co-chair of the Crithinknet - Portuguese Network on Critical Thinking. I performed several positions in CeiED, including membership in the Executive Committee, the Ethics Committee, and the Steering Committee. Furthermore, I am a part of the Scientific Commission of the Institute of Education and the Pedagogical Committee of the Faculty of Social Sciences, Education, and Administration. My research interests stem from my extensive experience as a Portuguese language and literature teacher in secondary school for over two decades. The concerns related to the differences between schools and teachers, including their pedagogical approaches, as well as the construction of the school curriculum, fueled my doctoral research, which entailed a longitudinal study of curriculum history in Portugal. My area of expertise revolves around curriculum policies, with a particular emphasis on the evolution of curriculum design over the years, including the latest modes of regulation and governance within the education sector. I have supervised one post-doctoral study, two doctoral theses, and four Master's dissertations that have all been completed, in addition to two post-doctoral studies, seven doctoral theses, and five Master's dissertations that are currently underway. I have also participated in eleven PhD panels and seven Master's panels during this period. In my latest project, WEENERS - Times of Change and Changing Times: A Study of the Relationship between curricular autonomy and Teacher Involvement and Well-being -, I am working with a team of two Master's students and two PhD researchers. As the Executive Director of CeiED (2019-2023), I was responsible for recruiting staff and researchers, training them in project and science management, and organizing research teams to answer external demands. I have also participated in three summer schools organized by CeiED and co-authored scientific articles with junior researchers. My role in the editions of journals, article revisions, and participation in scientific conference committees has been increasing. Recently, I was invited to Lusofona to revamp the study plan for teachers' training and introduce new academic disciplines based on interdisciplinarity and cooperative work for both students and teachers. As a part of this effort, a new transversal curriculum unit called Knowledge and Creativity for Innovation was created for all students. Between 2017 and 2020, I worked in a large community of 19 schools and their municipalities to develop methodological approaches to research and train teachers. I provided training to teachers in compulsory education and conducted over 17 workshops on topics such as democratic and inclusive education, curriculum management, and diversity and differentiation. Additionally, I have been invited to give keynote speeches at schools, universities, and webinars. In 2017-2018, I coordinated consulting work with two school clusters, and I also developed two consulting works related to curriculum autonomy and flexibility with a teacher training center which resulted in a publication in 2019. I have also served as an external expert for a school cluster that participated in the Pilot Project for Pedagogical Innovation between 2018-2020, and I continue to work as a consultant with the same school. I have participated in television commentary and analysis of the national teachers' strikes and demonstrations (January-April 2023) on six separate occasions. I participated in several projects, namely Remase (EXPL/CED- EDG/1130/2021) as Co-PI and Euridice (DIGITAL-2022-SKILLS-03-SPECIALISED-EDU) as PI.

        Graus

            * Licenciatura
              Línguas e Literaturas Modernas, variante de Estudos Portugueses
            * Mestrado
              Mestrado em Educação, espec. Educação, Desenvolvimento e Políticas Educat.
            * Doutoramento
              Doutoramento em Educação
            * Outros
              Proposal Writing and Project Management for Hprozpn Europe Program
            * Outros
              Financial Administration & Auditing Preparation for E. C. funded Projects
            * Outros
              Diversificando os materiais pedagógicos com o H5P: da teoria à conceção
            * Outros
              Narrative CV
            * Outros
              Introduction to Research Impact

        Publicações

        Artigo em revista

          * 2024, Towards a democratic curriculum: the narrative paradigm to achieve a state of viscosity, Curriculum Perspectives
          * 2022-12-09, What Can AI Learn from Teachers and Students? A Contribution to Build the Research Gap Between AI Technologies and Pedagogical Knowledge, European Journal of Education and Pedagogy
          * 2020-12, Inovação e Mudança: reflexões sobre o processo de autonomia e flexibilização curricular nas escolas portuguesas, Revista Lusófona de Educação
          * 2018-02-27, The Knowledge of Policies: The Personal Dimension in Curriculum Policies in Portugal, British Journal of Educational Studies
          * 2011, Programa Marco Interuniversitário para uma Política de Equidade e Coesão Social na Educação Superior, RIAIPE 3, RAES, Revista Argentina de Educação Superior
          * 2010-10-05, Curriculum Policy in Portugal (1995-2007). Global Agendas and Regional and National Reconfigurations., Journal of Curriculum Studies
          * 2008, As Políticas Curriculares em Portugal (1995-2007). Agendas Globais e Reconfigurações Regionais e Nacionais, Revista Espaço do Currículo

        Tese / Dissertação

          * 2015-07-24, Doutoramento, Alquimia do conhecimento: a construção do conhecimento curricular em Portugal (1970-2009)

        Livro

          * 2022, Desenvolvimento profissional docente e inovação pedagógica na escola. Novas perspectivas para o trabalho docente, FERREIRA, KATIA; Estrela, Elsa

        Capítulo de livro

          * 2023, Curriculum as the fluid for times of unsureness: in between the solid and the liquid., International Handbooks of Education. Handbook of Curriculum Theory and Research, Springer
          * 2022, Nota de encerramento, Do cientista cidadão à ciência cidadã: Olhares cruzados na construção do conhecimento, Edições Universitárias Lusófonas
          * 2020, O movimento da política baseada em evidências e a sua influência nas políticas curriculares portuguesas, Transferencia, transnacionalización y transformación de las políticas educativas (1945-2018), FahrenHouse
          * 2019, The two faces of the same coin. National and individual refraction in curriculum policies in Portugal, Transnational Perspectives on Curriculum History, Routledge
          * 2019, Reflections on territorial capacity - the interplay between education and understanding and acting in the urban fabric, Neighbourhood & City - Between digital and analogue perspectives, Edições Universitárias Lusófonas
          * 2019, A formação de professores num quadro de flexibilização curricular: contributos para um novo modelo de formação contínua, O tempo e o espaço da formação contínua de professores: Diagnóstico, processo e perspetivas, Edições Universitárias Lusófonas
          * 2012, From Prescribed to Narrative Curriculum - An Attempt to Understand Educational Change in Portugal, Globalization - Education and Management Agendas, InTech
          * 2011, Análise das Políticas Curriculares: O Caso de Portugal e Espanha., Análise das Políticas Curriculares: O Caso de Portugal e Espanha, Germania
          * 2010, Between Equity and Academic Excellence. Challenges for Policies on Secondary Education in Portugal. , Portugal in the Era of the Knowledge Society, Edições Universitárias Lusófonas
          * 2009, La reconfiguración de las Políticas Curriculares. El Caso Portugués. , La reconfiguración de las Políticas Curriculares. El Caso Portugués. , Germânia

        Edição de livro

          * 2009, 1, 1, Edições Universitárias Lusófonas

        Manual

          * 2013, Materiais Interativos para Português L2 na Web 2.0

        Artigo em conferência

          * 2022-09-16, Desconstrução e reconstrução da(s) identidade(s) docentes, XVI Congresso da SPCE, Educação e Cidades. Tempos, Espaços, Atores e Culturas
          * 2022-07, Formação contínua de professores em Portugal: O início de uma análise entre 2005 e 2022., 12.º Encontro de Investigadores do CeiED A universidade na interface de ciências e políticas
          * 2020-11, WHEN TECHNOLOGY MEETS PEDAGOGY. AN ERASMUS+ PROJECT PROPOSAL TO CREATE AN INTERDISCIPLINARY HIGHER EDUCATION MODEL
          * 2020-11, HOW CAN NEW TECHNOLOGIES AND ARTIFICIAL INTELLIGENCE COLLABORATE WITH EDUCATION? KNOWLEDGE AND RECOMMENDATIONS FROM EU STUDENTS AND TEACHERS
          * 2010-05-17, Moving Curriculum: A Comparative Study on Educational Trajectories in the Past Decades Portugal-Spain, Seminário Internacional de Políticas Educativas Iberoamericanas Tendências e Desafios

        Resumo em conferência

          * 2023-10-28, Teacher Agency: the role of teachers in the XXI Century’s Education, ATEE Winter Conference
          * 2023-10-28, Reconfiguration of the academic Profession: Processes of Change in the Practice of Higher Education Teachers, ". ATEE Winter Conference
          * 2023-10-28, Continuous teacher training in Portugal: public initiatives between 2005-2022 for professional teacher learning, ATEE Winter Conference
          * 2023-10-28, A time of change or a change of time?, ATEE Winter Conference
          * 2023-07-17, Formação contínua de professores em Portugal: uma análise retrospetiva entre 2005-2022, I Colóquio Internacional de Reflexão sobre Práticas Integradas em Educação
          * 2023-06, Academic Professionalism in the XXI Century: Processes of Change in Teachers’ Practice, XX ISA World Congress of Sociology
          * 2023-01, Valor pedagógico do ensino de metodologias de investigação em educação: contributos para a criação de espaços sociais de aprendizagem, XXX Colóquio da AFIRSE Portugal
          * 2023-01, Towards a pedagogical culture of teaching research methodologies in education: challenges, answers, and ambitions, WCQR2023: 7th World Conference on Qualitative Research
          * 2023-01, O tempo e o espaço de ser professor: a reconfiguração da profissionalidade docente, XXX Colóquio da AFIRSE Portugal
          * 2023-01, Características Espácio-temporais das Componentes Curriculares em Metodologias de Investigação em Educação nos Programas Doutorais em Ciências da Educação em Portugal: mapeando o cenário curricular nacional, XXX Colóquio da AFIRSE Portugal
          * 2023, Teach and Learn Research Methodologies in Education Between Mismatches: Portugal’s Case, The 2nd Paris Conference on Education (PCE2023)
          * 2022-09, Ensinar metodologias de investigação em educação numa sociedade intensiva em dados, XVI Congresso da Sociedade Portuguesa de Ciências de Educação
          * 2022-08, The Evidence-based Education Policy Movement and Its Effects on the Curriculum Policy in Portugal (2011-2019), ECER 2022 The European Conference on Educational Research
          * 2022-08, Curriculum as the Fluid for Unsureness Times: in Between the Solid and the liquid, ECER 2022 The European Conference on Educational Research
          * 2022-07, Research Methods in Advanced Studies in Education: trends and pitfalls, icet2022 - 1st International Conference on Education and Training¿
          * 2022-07, Formação de Professores e Educadores/Teacher and Educators Education, 3rd Porto International Conference on Research in Education
          * 2022-06, O CURRÍCULO COMO NARRATIVA NO TEMPO DO INCERTO DESCONHECIDO: AS SONORIDADES DOS DOCENTES, IAACS 2022 - 7th Triennal Conference
          * 2021-07-07, A docência em Tempo de confinamento. O incerto desconhecido., I Congresso Internacional sobre Metodologia (Qualis2021)
          * 2021-03-08, THE INTEGRATED CURRICULUM: AN INNOVATIVE PEDAGOGICAL PROPOSAL, INTED 2021 Sharing the passion for learning
          * 2020-11-25, Qual o futuro da aprendizagem? O conceito e contexto do professor vai ser desmaterializado?, 3rd WCCES Symposium Professores, Profissão Docente e Educação Comparada: Promover a Educação para os Valores e Fomentar a Liberdade Académica no contexto das Questões Emergentes relacionadas com a COVID-19
          * 2020-02-08, Escolas e Educação Internacional: o contexto e o conceito., Encontro Nacional de Jovens Investigadores em Educação. Investigar em Educação: desafios epistemológicos e metodológicos
          * 2020-02-08, A formação continuada de professores e o uso de pedagogias inovadoras em sala de aula para a melhoria da aprendizagem dos estudantes no século XXI, IV Encontro Nacional de Jovens Investigadores em Educação. Investigar em Educação: desafios epistemológicos e metodológicos
          * 2019-09-23, Tempos de Mudança e Inovação em Educação. O Conhecimento profissional dos professores no âmbito da formação contínua., Congresso Internacional Profissionalidade Docente: Desafios na Formação de Professores
          * 2019-09-23, Inovação pedagógica em sala de aula: perspectivas e desafios para os/as professores no século XXI, Congresso Internacional Profissionalidade Docente: Desafios na Formação de Professores
          * 2019-09-23, Formação de professores - O mito da caverna e a formação PLANGLOCAL, Congresso Internacional Profissionalidade Docente: Desafios na Formação de Professores
          * 2019-07-23, A formação continuada de professores/as e os processos de inovação pedagógica na escola, I Simpósio Internacional e IV Nacional de Tecnologias Digitais na Educação
          * 2019-07-16, O continuum espacial e local da educação. Educação planglocal – International Baccalaureate, 41ª Conferência Internacional ISCHE, Spaces and Places of Education
          * 2019-05-30, Educação para a cidadania Global - As evidências do Sistema International Baccalaurate., I Congresso Internacional Humanismo, Direitos Humanos e Cidadania Global
          * 2019-01-31, A Educação pela Inovação. Novos ambientes, novas aprendizagens, outros conhecimentos., XXVI Congresso Afirse, Tempos, espaços e artefactos em educação
          * 2019-01-25, Dentro dos muros das Escolas Internacionais, III Encontro Nacional de Jovens Investigadores em Educação, Desigualdades Sociais e Educativas: que lugar na investigação?
          * 2018-12-10, The two faces of the same coin. National and individual refraction on curriculum policies in Portugal, 6th World Curriculum Studies Conference, Transnational Curriculum Inquiry: Challenges and Opportunities in a Changing World
          * 2018-07-15, The two faces of the same coin. National and individual refraction on curriculum policies in Portugal., XIX ISA World Congress of Sociology, Power, Violence and Justice: Reflections, Responses and Responsibilities
          * 2018-01, The two faces of the same coin. National and individual refraction on curriculum policies in Portugal, II Conferência Internacional de Educação Comparada - O Professor do Século XXI em Perspetiva Comparada: Transformações e Desafios para a construção de sociedades sustentáveis
          * 2018, O Conhecimento das Políticas. A dimensão pessoal nas políticas curriculares em Portugal (1970-2009)., XXV Congresso AFIRSE - A investigação, a formação, as políticas e as práticas em educação – 30 anos de AFIRSE em Portugal.
          * 2016, The Knowledge of Policy in Curriculum History in Portugal (1970-2009), ECER 2016 - Leading Education: The Distinct Contributions of Educational Research and Researchers
          * 2016, Educational Change beyond National Spaces, 1ª Conferência Internacional SPCE-SEC A Educação Comparada para além dos números: contextos locais, realidades nacionais e processos transnacionais
          * 2016, A Dimensão Pessoal nas Políticas Curriculares em Portugal (1970-2009), XI Congresso Luso Brasileiro de História da Educação, Investigar, Intervir e Preservar – Caminhos da História da Educação Luso-Brasileira
          * 2015, Life Histories and Curriculum Change: The Individual to understand the Collective, ECER 2015
          * 2014, Uma Experiência Integrada entre TIC e Português, Encontro TIC@Portugual’14
          * 2012, Do Currículo Prescrito ao Currículo Narrado. As Histórias de Vida dos Professores para Compreender a Educação em Portugal, XIX Congresso AFIRSE
          * 2011, Inter-university Programme for a Policy Framework For Equity and Social Cohesion in Higher Education, ISA
          * 2010, Moving Curriculum: A Comparative Study on Educational Trajectories in the Past Decades Portugal-Spain., XVII ISA World Congress of Sociology
          * 2010, From Prescribed to Lived Curriculum. Social, Curriculum and Life History to Understand Education in Portugal, XVII ISA World Congress of Sociology
          * 2009, The Curricular Knowledge Construction in Portugal. Historical, Economic, Social and Cultural Features., IX Conferência da Associação Europeia de Sociologia (ESA)
          * 2009, Equity and Academic Excellence in curriculum Policies in Portugal. A Socio-Historical Approach, 3ª Conferência Trienal da IAACS (Internacional Association for the Advancement of Curriculum Studies)
          * 2008, The New Architecture of Educational and Curricular Policies in Portugal: Curricular Knowledge Reconfiguration., 1º Fórum de Sociologia International Sociological Association
          * 2008, Teacher Professionalism: Reconfigurations of the Teacher Identities in Portugal., 1º Fórum de Sociologia International Sociological Association
          * 2008, A Nova Arquitectura das Políticas Educativas e Curriculares em Portugal: A Reconfiguração do Conhecimento Curricular., II Conferência Internacional
          * 2007, As Políticas Curriculares em Portugal (1995-2007): Agendas Globais e Reconfigurações Regionais e Nacionais, III Colóquio Internacional de Políticas e Práticas Curriculares

        Poster em conferência

          * 2010-07-02, A Alquimia do Conhecimento. A Construção do Conhecimento Curricular em Portugal (1971-2009), I Encontro de Investigadores do Centro de Estudos e Intervenção em Educação e Formação

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona