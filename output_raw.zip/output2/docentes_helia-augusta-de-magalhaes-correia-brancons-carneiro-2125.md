# Response for https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
          PT: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125 EN: https://www.ulusofona.pt/en/teachers/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
        fechar menu : https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/helia-augusta-de-magalhaes-correia-brancons-carneiro-2125
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Helia Augusta De Magalhães Correia Bracons Carneiro

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p2125
              hel***@ulusofona.pt
              5A17-D4D5-3659: https://www.cienciavitae.pt/5A17-D4D5-3659
              0000-0002-5363-4897: https://orcid.org/0000-0002-5363-4897
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/dbdd7ec7-d789-4962-9ca4-59c8fbeb2447
      : https://www.ulusofona.pt/

        Resume

        Associate Professor at the Institute of Social Service at Universidade Lusófona - Centro Universitário de Lisboa, Portugal. PhD in Social Service. Graduate and Master in Social Work. Director of the Degree and joint coordinator of Internships in Social Work at ULHT. Collaborating researcher at LusoGlobe, since 2023. Collaborating researcher at the Center for Interdisciplinary Studies in Education and Development (CeiED) ULHT, since June 2022. Editor of the Revista Temas Sociais of the ULHT Social Service Institute. Director of the Postgraduate Course in Social Intervention with Migrants and Refugees (b-learning) (2021). Tutor Professor at the ULHT Social Service Institute (Tutorial Support for external students). https://www.ulusofona.pt/noticias/apoio-tutorial-vamos-externos Coordinator of the Tutorial, Mentoring and Guidance action program at the Lusófona University of Humanities and Technologies integrated into the Portuguese Mentoring Network | Peer Tutoring in Higher Education. Implementation and Tutor of the Mentoring Program in the 2019/2020 academic year. https://www.ulusofona.pt/noticias/programa-mentoria-tutoria-iss Member of the Jury evaluating the Portuguese Test for candidates holding double certification courses at secondary level and specialized artistic courses 2022/2023; 2023/2024. Representative of ULHT Lisboa in the Higher Education Network in Intercultural Mediation (RESMI), since May 2015. Member of the Scientific Advisory Board of the International Journal of New Education (IJNE) University of Málaga. Member of the Editorial Board of the Magazine published by the International Association of Social Sciences and Social Work. EHQUIDAD. International Journal of Bienestar y Trabajo Social Policies. Scientific Council of the Social Service in Perspective Magazine. State University of Montes Claros - Unimontes. Scientific Editorial Board of Katálysis Magazine. Federal University of Santa Catarina, Brazil. Scientific Editorial Board of the Social Service & Health Magazine. State University of Campinas. International Editorial Committee of MODULEMA Magazine. Scientific magazine on Cultural Diversity. University of Granada. DEDiCA Advisory Board. Journal of Education and Humanities. University of Granada.

        Graus

            * Mestrado
              Serviço Social
            * Licenciatura
              Serviço Social
            * Doutoramento
              Doutoramento em Serviço Social

        Publicações

        Artigo em revista

          * 2023-05, Construir relações, valorizar a diversidade, Revista de Estudos Interculturais,nº11
          * 2023-01-01, Mendes Pinto, P., Bracons, H., Martins, N. ., Mineiro, D. ., Bazmandegan, M., Franco, J., Botelho Moniz, J., & Campos, F. (2023). Muçulmanos em Odivelas. Dinâmicas e Comunidade . , (19), 205–220. https://doi.org/10.15257/ehquidad.2023.0009, EHQUIDAD. Revista Internacional De Políticas De Bienestar Y Trabajo Social
          * 2023-01, Muslims in Odivelas. Dynamics and Community, Ehquidad International Welfare Policies and Social Work Journal
          * 2023, Posibilidades de las prácticas creativas para trabajar el enfoque intercultural en el Grado de Trabajo Social , International Journal of New Education
          * 2023, "Muçulmanos em Odivelas. Dinâmicas e Comunidade", Ehquidad: La Revista Internacional de Políticas de Bienestar y Trabajo Social
          * 2022-10-30, A universidade como deve ser, Revista Internacional de Educação Superior
          * 2022, Suicídio e comportamentos suicidas dos jovens trans
          * 2022, Suicídio e comportamentos suicidas dos jovens trans
          * 2022, Suicídio e comportamentos suicidas dos jovens trans
          * 2022, Recensão de “Símbolo, metáfora e mito da comunicação intercultural” de Baptista, M. M. (2017. In R. Cabecinhas; L. Cunha (Eds.), Bracons, Hélia (2022). Recensão de “Símbolo, metáfora e mito da comunicação intercultural” de Baptista, M. M. (2017. In R. Cabecinhas; L. Cunha (Eds.), Comunicação intercultural, perspectivas, dilemas e desafios (pp. 171-177). Vila Nova de Famalicão: Edições Húmus. E- Revista de Estudos Interculturais do CEI–ISCAP. N.º 10, maio de 2022. Obtido de https://www.iscap.pt/cei/e-rei/pt/n10.html
          * 2022, A intervenção do serviço social nas Unidades de Cuidados Continuados Integrados em tempo de pandemia : estudo realizado nas ULDM da Comunidade Intermunicipal do Oeste
          * 2022, A escola de segunda oportunidade - educar e formar para inserir - Lisboa : uma análise sobre a intervenção socieducativa, Revista Temas Sociais
          * 2022, A intervenção do Serviço Social nas Unidades de Cuidados Continuados Integrados em tempo de Pandemia. , Revista Temas Sociais
          * 2021-07-30, Intervenção Comunitária. Conhecimentos e Práticas da Santa Casa da Misericórdia de Lisboa, Trabajo Social
          * 2021-05-31, Dolores Pareja de Vicente y Juan Olivencia (2018). Interculturalidad y cultura de la diversidad en el contexto universitario., Revista de Sociología de la Educación-RASE
          * 2021, Suicídio e comportamentos suicidas dos jovens trans. , Intervenção Social,
          * 2021, Educación universitaria a distancia durante la pandemia de la Covid 19. Reflexiones desde el Trabajo Social. EHQUIDAD. Revista Internacional De Políticas De Bienestar Y Trabajo Social, (16), 247-268. https://doi.org/10.15257/ehquidad.2021.0021, EHQUIDAD. Revista Internacional De Políticas De Bienestar Y Trabajo Social
          * 2020-12-31, Recensão ao livro Gestão das aprendizagens na sala de aula inclusiva, Revista Portuguesa de Pedagogia
          * 2020, Empatia e relação no serviço social que desafios para a profissão?, Revista Intervenção Social
          * 2020, Comunicação intercultural nos cuidados de saúde. Uma abordagem exploratória da interação entre assistentes sociais e doentes imigrantes, Comunicação Pública [Online]
          * 2020, Comunicação intercultural nos cuidados de saúde. Uma abordagem exploratória da interação entre assistentes sociais e doentes imigrantes
          * 2020, Bracons, Hélia (2020). Perceção dos Estudantes Finalistas de Serviço Social Face ao Contexto de Emergência Covid-19. Revista Internacional De Educación Para La Justicia Social, 9(3). Recuperado a partir de https://revistas.uam.es/riejs/article/view/12124, Revista Internacional De Educación Para La Justicia Social
          * 2020, Direitos Humanos: expressões de cultura numa sociedade em mudança. , EHQUIDAD. Revista Internacional De Políticas De Bienestar Y Trabajo Social
          * 2019-07, Culture, Diversity, Interculturality and Cultural Competence: Knowledge and importance of the concepts in Social Work perspective
          * 2019, Culture, diversity, interculturality and cultural competence: knowledge and importance of the concepts in social work perspective. , International Journal of New Education.
          * 2018-02, The competency of advising in professional social relationships
          * 2017-10, Metodologia do atendimento integrado: uma experiência de intervenção local, SOCIOLOGIA ON LINE
          * 2017, Supervisão pedagógica na formação académica : conceções dos estudantes de serviço social, Revista Fluxos & Riscos
          * 2013-07-30, O sistema de ensino em Serviço Social Pós Bolonha. Uma visão crítica, Serviço Social em Revista
          * 2009-06, Entre a Universidade e a comunidade: os estágios académicos da licenciatura em Serviço Social da Universidade Lusófona
          * 2007, Mulheres hindus da Quinta da Vitória : práticas e vivências
          * 2007, Mulheres hindus da Quinta da Vitória: Práticas e Vivências

        Livro

          * 2023, Carta das Religiões de Odivelas Plano Municipal de Integração dos Migrantes (PMIM) 2022, 1, Moniz, Jorge Botelho; Pinto, Paulo Mendes; Bracons, Hélia; Daniel Mineiro, Edições Universitárias Lusófonas
          * 2022, Carta das Religiões Odivelas, AAVV (2022), Carta das Religiões Odivelas. In Paulo Mendes Pinto, Daniel Mineiro (Orgs.), Plano Municipal de Integração
          * 2019, Conhecer para intervir: competência cultural no Serviço Social, Bracons, Hélia, Editorial Caritas
          * 2012, Processo de realojamento e apropriação do espaço num bairro multi-étnico. , Bracons, Hélia, Atena Editora

        Capítulo de livro

          * 2023, Direitos humanos e interculturalidade, Humanismo e Desafios de Cidadania.
          * 2023, ¿Direitos humanos e interculturalidade¿, Centro de Estudos Interdisciplinares em Educação e Desenvolvimento (CeiED)
          * 2022, Comportamentos suicidas dos jovens trans: um olhar mais atento às causas que se esquivam ao diálogo, VIII Congresso Internacional em Estudos Culturais: Sexualidades e Lazer
          * 2022, Bracons, Hélia & Sousa, Paula (2022), “Competências específicas em Serviço Social na intervenção com a diversidade”. Cap.4 (p.79-95). Práticas e Políticas inspiradoras e inovadoras com imigrantes. Coordenação: Elisete Diogo e Raquel Melo. Edições Esgotadas. ISBN:978-989-9092-57-0, Práticas e Políticas inspiradoras e inovadoras com imigrantes
          * 2022, Activismo feminista digital em moçambique: Conquistas, Desafios e Perspectivas, VIII Congresso Internacional em Estudos Culturais: Sexualidades e Lazer
          * 2022, A cristalização cisnormativa nas sociedades atuais – a sexualidade reiventada das pessoas trans, VIII Congresso Internacional em Estudos Culturais: Sexualidades e Lazer
          * 2021, Principais modelos de intervenção social, Manual para a intervenção social. Da teoria à ação
          * 2020, Erasmus: uma experiência inter e transcultural, In Carla Galego (Ed.), Atas do Congresso Internacional 2019 | Profissionalidade Docente: Desafios na Formação de Professores (pp. 43-50). Edições Universitárias Lusófonas.
          * 2020, A Interculturalidade sob o olhar dos estudantes, Atas do 5º Congresso Nacional de Serviço Social - Porto
          * 2019, La educación intercultural en la formación inicial del profesorado: la voz de los docentes universitarios
          * 2019, Knowledge and culture: ability to build appropriate knowledge to intervene in the public field, VIII ICSSW 2019, VIII International Conference of Sociology and Social Work
          * 2019, A relevância da interculturalidade para uma prática mais inclusiva em trabalho social, CECS
          * 2019, Knowledge and culture: ability to build appropriate knowledge to intervene in the public field, Proceedings of the VIII ICSSW 2019 / Livro de Atas da VIII ICSSW 2019, Faculdade de Psicologia e Ciências da Educação da Universidade de Coimbra.
          * 2018, Cultura, diversidade, interculturalidade e mediação: perceções dos estudantes de Serviço Social, 15, ACM
          * 2017, Supervisão pedagógica no ensino profissional: uma realidade ou utopia, Atas 1ª da Conferência Internacional “A Educação comparada para além dos números. Contextos locais, realidades nacionais e processos transnacionais, Edições Universitárias Lusófonas
          * 2017, Educar e sensibilizar para a interculturalidade na formação em Serviço Social , Novas Edições Académicas
          * 2017, Competencia cultural e direitos humanos, Thomson Reuters ARANZADI
          * 2017, A relevância do diário de campo no contexto de estágio: o olhar e o sentir dos estudantes de serviço social, Thomson Reuters ARANZADI
          * 2016, A aprendizagem experiencial e a relação de supervisão no ensino superior , Asociación Española de Psicología Conductual
          * 2015, Serviço Social com famílias imigrantes , LIDEL, Pactor
          * 2015, A Religião como fator integrador das comunidades Imigrantes: Os Hindus da Quinta da Vitória , Edições Universitárias Lusófonas
          * 2013, Quinta da Vitória, Loures – Um estudo de caso para repensar os realojamentos , LNEC
          * 2013, Imigração e Envelhecimento: Estratégias sociais no trabalho com idosos imigrantes , LIDEL, Pactor

        Edição de livro

          * 2023, Edições Universitárias Lusófonas
          * 2022, Edições Un, Edições Universitárias Lusófonas
          * 2019, Edições Universitárias Lusófonas
          * 2019, 1 , Edições Universitárias Lusófonas
          * 2019

        Tradução

          * 2022, O multiculturalismo e a promessa de felicidade, Grácio Editor
          * 2022, Ahmed, Sara. (2008). “Multiculturalism and the Promise of Happiness” (pp.121-137). New Formations: A Journal of Culture, Theory, Politics, Nº63. Género e Performance: Textos Essenciais 5 (2022). Tradução de Rosely Cubo, Daniela Piva, Maria Manuel Baptista, Larissa Latif, Gabriela dos Santos, Hélia Bracons (pp.119-146). ISBN: 978-989-53448-9-5;978-989-53448-8-8. https://ria.ua.pt/bitstream/10773/34

        Entrada de dicionário

          * 2020, Competência cultural; comunicação intercultural; cultura; educação intercultural; empatia; interculturalidade; intervenção social e mediação intercultural

        Relatório

          * 2022, Charter of Religions Odivelas (Lisbon), https://cienciadasreligioes.ulusofona.pt/wp-content/uploads/sites/86/2022/10/Livro-Espaco-Religiosos-em-Odivelas.pdf

        Documento de trabalho

          * 2020-04, Ensino à distância em tempo de emergência: reflexões para o Serviço Social
          * 2019-09, Programa de ação Tutorial, Mentoria e Orientação da Universidade Lusófona de Humanidades e Tecnologias
          * 2019-05, Regulamento de Delegados de Turma do Curso de Serviço Social da ULHT (2019/2020)

        Manual

          * 2019, Introdução à Teoria Social. Autores escolhidos, Edições Universitárias Lusófonas
          * 2018, Interculturalidade: Elementos para uma melhor compreensão, Edições Universitárias Lusófonas

        Artigo em conferência

          * Humanismo e desafios de cidadania
          * A Educação Comparada para além dos números : contextos locais, realidades nacionais, processos transnacionais

        Resumo em conferência

          * 2021-03-30, TRANSEXUALIDADE: UM ESTUDO SOBRE O SUICÍDIO E COMPORTAMENTOS SUICIDAS DOS JOVENS TRANS MASCULINOS, XI Congresso Português de Sociologia

        Poster em conferência

          * 2019-06, The importance of tutorials in Social Work Training , Meanings of quality of Social Work Education in a changing Europe Madrid, Spain
          * 2019-06, Estágio curricular na formação em Serviço Social: alguns dados para reflexão., Meanings of quality of Social Work Education in a changing Europe Madrid, Spain 2019
          * 2010, O estágio académico de Serviço Social - espaço e tempo de desenvolvimento de competências Perspectiva dos estágios de serviço social na ULHT, I Seminário Internacional de Serviço Social na Universidade Lusófona: Serviço Social entre o Passado e o Futuro, as exigências do Presente

        Outra produção

          * 2022-04-29, Editorial - Revista Temas Socias, n.º 2, 2022, https://doi.org/10.53809/TS_ISS_2022_n.2_5-6
          * 2021-07-28, Editorial - Revista Temas Sociais n.º 1, Revista Temas Sociais
          * 2020, Número com dossiê temático

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona