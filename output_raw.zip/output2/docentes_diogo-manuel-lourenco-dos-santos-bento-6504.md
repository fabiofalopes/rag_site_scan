# Response for https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
          PT: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504 EN: https://www.ulusofona.pt/en/teachers/diogo-manuel-lourenco-dos-santos-bento-6504
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
        fechar menu : https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/diogo-manuel-lourenco-dos-santos-bento-6504
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Diogo Manuel Lourenço Dos Santos Bento

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6504
              5111-3029-313F: https://www.cienciavitae.pt/5111-3029-313F
              0009-0001-3422-1376: https://orcid.org/0009-0001-3422-1376
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/865b57e9-0039-4012-8fc5-ffddaed8f16f
      : https://www.ulusofona.pt/

        Resume

        Diogo Bento. Visual artist, curator, visiting assistant at Lusófona University (Lisbon) and collaborating researcher at CICANT (Centre for Research in Applied Communication, Culture and New Technologies) and ICNOVA (NOVA Institute of Communication). Graduated in Landscape Architecture in 2009 from the University of Lisbon - Instituto Superior de Agronomia, studied photography at Ar.Co (Centre for Art and Visual Communication, Lisbon) and earned a postgraduate certificate in Photography, Project and Contemporary Art in 2011 at Instituto Superior Autónomo de Estudos Politécnicos / Atelier de Lisboa. Currently studying for a PhD in Media Arts and Communication at Lusófona University. He is a Guest Lecturer in Documentary Photography and History of Photography at the same institution. He has collaborated in different artistic and cultural projects as an Artist, Photographer, Curator and Cultural Producer. His artistic practice is situated in the fields of photography and installation, where he explores the visual and narrative possibilities of the nuanced space between documentary practices and speculative realism. The thematic core of his work revolves around post/de/colonial issues, engaging with concepts of ecology, landscape, science, and architecture. Author of photography for various publications, he has a regular presence in group and solo exhibitions.

        Graus

            * Licenciatura
              Arquitectura Paisagista
            * Pós-Graduação
              Fotografia, Projecto e Arte Contemporânea
            * Bachelor
              Landscape Architecture
            * Curso de Especialização Tecnológica
              Curso Completo de Fotografia
            * Doutoramento
              Arte dos Media e Comunicação

        Publicações

        Artigo em revista (magazine)

          * 2018-04, [Portfólio de Fotografia], Revista Cais
          * 2015-05, [Portfólio de Fotografia], Próximo Futuro 18
          * 2013, [Portfólio de Fotografia], Revista 2
          * 2010, [Portfólio de Fotografia], Scopio Magazine

        Tese / Dissertação

          * 2009, Licenciatura, Decadência e Emergência. Desenvolvimento Rural e Evolução da Paisagem na Serra Malagueta, Santiago de Cabo Verde.

        Capítulo de livro

          * 2021, [Fotografia], Boka Panu: O Padrão da Panaria Cabo-verdiana enquanto Matéria Criativa, Centro Nacional de Arte, Artesanato e Design (CNAD)
          * 2020, [Portfólio de Fotografia], Fisheye Photo Review 2020.21, Fisheye Éditions
          * 2019, [Fotografia], Meridiano dos Ofícios, Centro Nacional de Arte, Artesanato e Design
          * 2018, [Fotografia], Identidade Interior das Nossas Casas, Centro Nacional de Arte, Artesanato e Design (CNAD)
          * 2016, [Portfólio de Fotografia] Reinterpreting Historical Photographs, Multiple Gazes of a Country's Photographed Past, African Photography Initiatives
          * 2014, [Fotografia], Pinheiro silvestre em Portugal: o extremo sudoeste ou apenas o fim?, UTAD, ICNF, IICT
          * 2012, [Fotografia] Trees Shaping Landscapes, Exploring the Boundaries of Landscape Architecture, Routledge
          * 2010, [Fotografia], PROAP 20 Anos, Note
          * 2010, [Fotografia], João Ferreira Nunes: Works, Asflor

        Artigo em jornal

          * 2016-06-09, [Fotografia] Cabo Verde, um hipermercado de escravos, Público
          * 2016-03-07, [Fotografia] Cabo Verde importa do Ocidente a política de "domesticar" os imigrantes, Público
          * 2016-01-03, [Fotografia] Ser africano em Cabo Verde é um tabu, Público

        Catálogo de exposição

          * 2023, Propeller #4 - Spectrum, Hélice Press e Galerias Municipais / EGEAC
          * 2023, Encontros da Imagem 2023, Encontros da Imagem - Festival Internacional de Fotografia e Artes Visuais
          * 2019, Currents Shift, Le Château d'Eau / Parallel Platform
          * 2019, Atlas, Parallel Platform
          * 2016, BF16 Bienal de Fotografia de Vila Franca de Xira, Bienal de Fotografia / Câmara Municipal de Vila Franca de Xira

        Exposição artística

          * 2022, Fundação e Emergência, Centro Nacional de Artesanato e Design, São Vicente, Cabo Verde
          * 2019, LUUANDA, Geração 80, Luanda, Angola
          * 2018, 16º 51' 49 N 24º 52' 02 W, Centro Nacional de Artesanato e Design, São Vicente, Cabo Verde
          * 2016, Escuta os Bárbaros em Primeiro Lugar, Bienal de Fotografia de Vila Franca de Xira, Vila Franca de Xira, Portugal
          * 2013, Casa para Outros, Praça D. Luís, São Vicente, Cabo Verde
          * 2012, Cabral ka Mori, Espaço Experimental de Arte e Design, M_EIA, São Vicente, Cabo Verde

        Arte visual

          * Tchon d'Holanda (2017-2019)
          * Journey (2014)
          * Escuta os Bárbaros em Primeiro Lugar (2016)
          * Desvio Padrão (2017-2019)
          * Cigarettes and Poo (2011)
          * Casa para Outros (2013)
          * Cabral ka Mori (2010-2011)

        Exposição de curadoria/museu

          * 2023, Desvio Padrão
          * 2022, Spectrum
          * 2019-09-14, Zeitgeist
          * 2019, Currents Shift
          * 2019, Adaptação e Transição
          * 2018, Parallel Showcase
          * 2015, On Landscape #2
          * 2013, Ocupações Temporárias - Documentos
          * 2012, Estrangeiros
          * 2011, Quinze Ensaios
          * 2010, Na Superfície - A Periferia do Centro: Álvares Cabral/Campanhã

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona