# Response for https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
          PT: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705 EN: https://www.ulusofona.pt/en/teachers/david-jose-rodrigues-dos-santos-7705
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
        fechar menu : https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/david-jose-rodrigues-dos-santos-7705
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          David José Rodrigues Dos Santos

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p7705
              p77***@ulusofona.pt
              201A-0128-1472: https://www.cienciavitae.pt/201A-0128-1472
              0000-0003-1539-1350: https://orcid.org/0000-0003-1539-1350
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/98496091-5e59-4012-b0f9-12092c89a9f8
      : https://www.ulusofona.pt/

        Resume

        David dos Santos is currently an FCT Ph.D. grantee doing a doctorate in Philosophy of Science, Technology, Art and Society at The University of Lisbon. He is a member of the Center for Philosophy of Sciences and of the Science and Art Philosophy Lab (UL). He holds a Master’s degree in Multimedia Culture and Art (FEUP|UT Austin) and a Bachelor's Degree in Theatre Studies (ESMAE). In scientific research, he has been an ongoing associate partner of the project Blackbox: Arts & Cognition, a researcher grantee in the international project Transmedia Knowledge-Base for Performing Arts (UNL), the Project Manager and Organizer of the first TKB International Conference on "Multimodal Communication: Language, Performance and Digital Media”, founder and board member of iGesto-Research on Gesture. On Art, he was an Assistant Director and Movement Director in stage plays at National Theatre Sa~o Joa~o, Casa da Mu´sica and others where he assisted several directors. Producer at RE.AL-AND_Lab - Artistic Research and Scientific Creativity Lab. Teacher of Theatre and Dance in diverse Schools, Theatres and Universities. Performer of Theatre, Dance and Cinema in several national and international projects. As Theatre Director he directed diverse authors like “Dia Conseguido” by Peter Handke. As Choreographer he made original creations such as the Peak Leisure Park in the Project Ensemble Tanzlabor 21_1 at the Mousonturm Theatre in Frankfurt am Main, Germany. In the Creative industries, he has worked with Ivity Brand Corp. as Creative Copywriter, MighT as Head of Concept, This is That as Creative Consultant and Facilitator of Leadership, Communication & Creativity.

        Graus

            * Doutoramento
              Filosofia da Ciência, Tecnologia, Arte e Sociedade
            * Doutoramento
              Media Digitais
            * Mestrado
              Mestrado em Multimédia - Cultura e Artes
            * Licenciatura
              Teatro - Estudos Teatrais
            * Curso de Especialização Tecnológica
              Certificado de Competências Pedagógicas
            * Curso de Especialização Tecnológica
              Human-Centered Design
            * Curso de Especialização Tecnológica
              Digital Marketing Proficiency
            * Curso de Especialização Tecnológica
              Idea Generation
            * Curso de Especialização Tecnológica
              Design Thinking
            * Outros
              Design Thinking (d.school)
            * Curso de Especialização Tecnológica
              The Future of Storytelling
            * Outros
              Classes with Pina Bausch Cpª
            * Outros
              Master Class with Trisha Brown Dance Company
            * Outros
              Gyrokinesis
            * Outros
              Master Class with Francisco Camacho
            * Outros
              Dance Profitraining
            * Outros
              Contact Improvisation - Dieter Heitkamp
            * Outros
              Estagiário|Bolseiro - Lab de Composição em Tempo Real com o coreógrafo João Fiadeiro
            * Outros
              The represented Body, The body in the Arts
            * Outros
              Alexander Technique
            * Outros
              Contemporary Dance, Composition, Improvisation
            * Outros
              Body-Voice - Margarida Mestre
            * Outros
              Contemporary Dance - Antonio Carallo
            * Outros
              Vertical Danse - Bruno Dizien
            * Outros
              Ballet, Contemporary Dance, Modern Dance, Floor barre, Contact Improvisation, Composition and Improvisation

        Publicações

        Tese / Dissertação

          * 2011, Mestrado, Dramaturgia multimodal : anotação digital de corpora multimodais

        Capítulo de livro

          * 2019, TKB: An open platform as "archive" of compositional processes in Performing Arts, Práticas de arquivo em Artes Performativas, Imprensa da Universidade de Coimbra

        Poster em conferência

          * 2019-10-24, Suspension of the Self and Embodied Creativity , Avant-Conference. Trends in Interdisciplinary Studies
          * 2019-09-19, Suspension of the Self and Embodied Creativity - How the use of Metaphor enables a more embodied creative process, International Conference on Dance Data, Cognition and Multimodal Communication
          * 2018-09, Science and Art Connections: Case Studies, POND III [Philosophy Of Science Around the Mediterranean]

        Programa de rádio / tv

          * 2012, Ator - "Depois do Adeus", SP - RTP
          * 2003, Dobrador e Locutor - Porto Editora, Porto Editora

        Obra teatral

          * 2014, Criador, Encenador e Actor do "Dia Conseguido" inspirado no Ensaio do Dia Conseguido de Peter Handke, com o apoio à Criação de Cristina Carvalhal., Causas Comuns, Teatro da Comuna, Lisboa, Portugal.
          * 2013, Actor e Coordenador de Movimento no espectáculo "I.B.S.E.N." com encenação de Cristina Carvalhal. Projecto vencedor do Prémio "Norwegian Ibsen Awards", Causas Comuns, Teatro da Trindade, Inatel, Lisboa, Portugal.
          * 2011, Encenador - "Normal" - Eugene Ionesco , CITAC
          * 2010, Assistente de Encenação - "O Livro do desassossego" de Fernando Pessoa com encenação de Michel Van der Aa, Casa da Música
          * 2010, "Notações para a descida do pano de cena" da Artista Mariana Silva , Serralves
          * 2010, "Solidariamente Convosco" com direcção de Nicoline Van Harskampp, Serralves
          * 2009, Encenador - "Sem Saída" de Jean Paul Sartre, Universidade Lusíada
          * 2009, Co-Director|criador com Cristina Carvalhal e Primeiro Andar do espetáculo "Botox" com textos de Miguel Castro Caldas e Pedro Eiras., Primeiro Andar
          * 2009, Actor - "Maria Stuart" de Burleigh com encenação de Cristina Carvalhal e Nuno M. Cardoso, Companhia Cão Danado
          * 2009, Actor - "Emilia Galotti" de Lessing com encenação de Nuno M. Cardoso, Teatro Nacional São João
          * 2008, Performer - "Caixa da Música" com encenação Ricardo Pais & Drumming, Teatro Nacional São João
          * 2008, Encenador - "Salto de Pardal", Universidade Lusíada
          * 2007, Assistente de encenação - "Barba Azul" de Béla Bartók com encenação de João Henriques, Casa da Música
          * 2007, Assistente de Encenação - "O Rapaz de Bronze" de Sophia de Mello Breyner com encenação de João Henriques, Casa da Música
          * 2006, Co-Encenador e Ator - "Contos & Assassino Leitor" com textos de Marta Freitas, Comédias do minho
          * 2006, Ator e apoio ao movimento - "Falta" de Martin Crimp e Sarah Kane, encenado por Gonçalo Amorim, Escola Superior de Música e das Artes do Espectáculo
          * 2006, Assistente de encenação e Coordenador de movimento - "D.João" de Moliére, encenado por Ricardo Pais, Teatro Nacional São João
          * 2006, Assistente de Encenação e Coreografia - "A Little Madness in the Spring" dirigido por Giuseppe Frigenni, Casa da Música
          * 2005, Encenador | ator - "dEUS" de Woody Allen, ESMAE - Teatro Universitária da Corunha
          * 2005, "Tio Vânia" de Tcheckov com encenação de Nuno Carinhas (Ator estagiário), Teatro Nacional São joão
          * 2004, Ator|Bailarino e Assistente de Encenação - "A história do Soldado" com encenação de Cláudia Marisa, ESMAE
          * 2001, Histórias para contar, Teatro Art'imagem
          * 2001, A fé dos corpos, Eclipsearte
          * 2000, Ator - "M3 - Aime ao Cubo", Teatro de Renascimento

        Gravação vídeo

          * 2002, Ator - "Por baixo do pano" , Luís Beires - Vigia Produções

        Coreografia

          * 2011, "Impertinência da Presença", David dos Santos, Festival Tell - Algarve
          * 2008, "Mercador de Veneza" de Shakespeare com encenação de Ricardo Pais - Coordenador de movimento do espetáculo, Teatro Nacional São João
          * 2007, Coreógrafo e Performer - "Peak Leasure Park" com artistic coaching de Nik Haffner, Mousounturm
          * 2007, Coordenador de movimento - "O Café" de Goldonni com encenação de Giorgio Corsetti, Teatro Nacional São João
          * 2006, solo performer - "Olimpo" , André Guedes, o rumo do fumo; mad woman in the attic
          * 2006, Coordenador de movimento - "Teatro Escasso" encenado por António Durães, António Durães; David dos Santos, Teatro Nacional São João
          * 2006, Coordenador de movimento - "O Saque" de Joe Orton, encenado por Ricardo Pais, Teatro Nacional São João
          * 2006, Coordenador de movimento - "Maria de Buenos Aires" de Astor Piazzolla, encenado por João Henriques, Teatro Nacional São joão
          * 2005, Consultor de Performance - "Lilly 05" de João Costa, João Costa
          * 2005, Bailarino - "Fragilidade" da coreógrafa Susana Queiroz, Festival da Fábrica
          * 2005, "SWAP" de Tiago Dionísio e Rudolfo Quintas - Consultor de Performance
          * 2004, solo performer - "Scanner" do videasta Sérgio Cruz
          * 2004, Solo performer - "Um outro fumador" criada por André Guedes, Serralves
          * 2004, Dancer - "Hautsache Bewegung" (Dancing Through the Skin) do Coreógrafo Dieter Heitkamp Ciª Ind. - Frankfurt Main, HFMDK - Frankfurt University of Music and Performing Arts
          * 2003, solo performer - "Processamento humano " de Helena Figueiredo, Escola das Artes da Universidade Católica do Porto
          * 2002, "Undress" - dancer by Ronit Ziv, Ronit Ziv, Companhia instável - Teatro Rivoli
          * 2001, Ama-zonas , Paola Moreno, Centro de Dança do Porto

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona