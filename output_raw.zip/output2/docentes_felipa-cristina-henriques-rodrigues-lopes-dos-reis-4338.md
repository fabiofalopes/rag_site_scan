# Response for https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
          PT: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338 EN: https://www.ulusofona.pt/en/teachers/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
        fechar menu : https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/felipa-cristina-henriques-rodrigues-lopes-dos-reis-4338
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Felipa Cristina Henriques Rodrigues Lopes Dos Reis

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4338
              p43***@ulusofona.pt
              B919-CF84-98D3: https://www.cienciavitae.pt/B919-CF84-98D3
              0000-0001-8462-0810: https://orcid.org/0000-0001-8462-0810
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/d97aaa6b-04a5-4d9a-bd51-8b26b3c51f84
      : https://www.ulusofona.pt/

        Resume

        Felipa Lopes dos Reis. Professora Associada na Universidade Lusófona - Centro Universitário Lisboa e membro dos Conselho Pedagógico e Conselho Científico. Possui doutoramento e licenciatura em Gestão pela Universidade Lusíada. Organizou 7 eventos. Autora de 11 livros nas áreas de Gestão, Capital Humano e Metodologia Científica. Realizou 46 comunicações em conferências científicas. Possui 3 capítulos de livros. É referee de algumas revistas internacionais. Orientou 180 relatórios de estágio e 86 dissertações de mestrado e teses de doutoramento. Participou em 102 provas académicas na qualidade de arguente e presidente. Autora de 67 publicações em livros de atas de conferências internacionais e 57 artigos científicos. Recebeu 1 prémio e/ou homenagem. Membro do Intrepid Lab, CETRAD (Centre for Transdisciplinary Development Studies). Nas suas atividades profissionais interagiu com 35 colaborador(es) em coautorias de trabalhos científicos. No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica, tecnológica e artístico-cultural: Comunicação; Resultados de aprendizagem; Competências; Higher Education; e-learning, Cuidados Continuados Integrados; Sustentabilidade; Ciências Sociais; Motivação; Educação; Gestão; Gestão de Recursos Humanos; Capital Humano; Capital intelectual; Liderança; Motivação; Serviço Social; Psicossociologia das Organizações; Instituições de Ensino Superior; Organizações; Aeronáutica; Estudos de caso; Ensino a distância; Comportamento do consumidor; Gestão nipónica; Aeroportos; Metodologias de investigação.

        Graus

            * Doutoramento
              Gestão
            * Licenciatura
              Gestão

        Publicações

        Artigo em revista (magazine)

          * 2011-11, Dimensão dos Recursos Humanos no Sistema de Gestão Nipónico em Portugal, Recursos Humanos Magazine

        Artigo em revista

          * 2024-04, Online Teaching During Pandemic in Portugal: University teachers' perspective and consequences, Educational Administration: Theory and Practice. ISSN: 2148-2403 (Scientific Journal Rankings:Q3)
          * 2024-02, The Impact Of COVID-19 On University Education In Portugal: Insights From Students And Teachers, Revista Cientifica de Educação A Distancia. ISSN: 1982-6109.
          * 2024, The relationship between internal communication and employee satisfaction Case study: Fenicius Charme Hotel in Portugal, International Journal Knowledge Management in Tourism and Hospitality. ISSN: 1756-0330
          * 2024, The relationship between communication and sports performance on the contexts of soccer and futsal in Portugal, Asian Journal of Management Science and Applications
          * 2024, The impact of São Tome and Principe's socio-economic development arising from the expansion and modernization of its international airport: an empirical study using PLS-R and ANOVA analysis, International Journal of Business Innovation and Research. ISSN: 1751-0260. (Scientific Journal Rankings:Q2)
          * 2024, The Importance Of Transformational Leadership In Times Of Pandemic COVID-19: An Application Of PLS-R, International Journal of Business Excellence. ISSN: 1756-0047. (Scientific Journal Rankings:Q3)
          * 2024, Motivação Organizacional: Estudo de Caso em Instituições Particulares de Solidariedade Social do distrito de Lisboa, Revista Temas Sociais. ISSN: 2184-982X
          * 2024, Dynamics of the online teaching-learning process management applied to the Portuguese Higher Education System post-Covid19, Cadernos de Pesquisa. ISSN: 0100-1574 e-ISSN: 1980-5314. (Scientific Journal Rankings: Q2)
          * 2024, Determinants that influence Consumer Behavior - An Empirical Study Applied to Air Transport in Portugal, International Journal of Business Excellence. ISSN: 1756-0047. (Scientific Journal Rankings:Q3)
          * 2024, Desempenho e satisfação dos alunos universitários portugueses durante a pandemia SARS-CoV-2, Revista Brasileira de Educação. ISSN: ISSN 1809-449X . (Scientific Journal Rankings: Q3)
          * 2024, Analysis of Tourist Behaviors: A Study of Hotel Units in Portugal, International Journal of Knowledge Management in Tourism and Hospitality. ISSN: 1756-0330
          * 2024, Analysis of Business Models of Legacy and Low-Cost Airlines - An Empirical Study Applied in Portugal, International Journal of Business Innovation And Research. ISSN: 1751-0260. (Scientific Journal Rankings:Q2)
          * 2024, Analysis of Angolan public enterprises' financial performance - an econometric modelling approach., Brazilian Business Review. ISSN: 1808-2386. (Scientific Journal Rankings: Q3)
          * 2024, A relação entre a auto-liderança e a criatividade: O papel moderador da auto-dúvida – Estudo Aplicado no Grupo Lusófona, em Portugal, Brazilian Business Review. ISSN: 1808-2386. (Scientific Journal Rankings: Q3)
          * 2024, A Importância da Avaliação e Gestão de Desempenho na Motivação Organizacional. O Caso da Unidade de Cuidados Continuados Integrados Rainha D. Leonor da Santa Casa da Misericórdia de Vila de Rei, Revista Temas Sociais,. ISSN: 2184-982X
          * 2024, The challenges of single-use plastic in food and beverage establishments in the tourist center of Ericeira (Portugal), Journal of Tourism and Development. ISSN: 2182-1453. (Scientific Journal Rankings: Q3)
          * 2023-10, Scouting Leadership in Portugal., European Journal of Humanities and Social Science. ISSN: 2736-5522
          * 2023-10, O impacto dos Influencers no processo de decisão e compra no Instagram em Portugal, Revista Portuguesa de Gestão contemporanea. ISSN: 2184-8319.
          * 2023-10, Influence of communication on the productivity of portuguese military organization, European Journal of Communication and Media Studies. ISSN: 2976-7431
          * 2023-08-09, The Limitations of the Traditional Safety Metrics Applied to Safety on a Dynamic Civil Aviation Industry - An Empirical Study Applied To Hofstede s Cultural Dimensions Theory., International Journal of Knowledge Management in Tourism and Hospitality. ISSN: 1756-0330
          * 2023, Quality Management in Times of Pandemic Case Study of S.R.A, a Freight Transportation Company, European Journal of Business and Management Research. ISSN: 2507-1076
          * 2023, Os Estilos dos Líderes da Hotelaria de Luxo Estudo de caso: hotel Palácio do Estoril e Sheraton cascais Resort em Portugal, Revista Portuguesa de Gestão Contemporanea. ISSN: 2184-8319
          * 2023, Online teaching; An emerging reality, New Trends and Issues Proceedings on Humanities and Social Sciences. ISSN: 2547-8818. Web of Science Conference Proceedings Citation Index (CPCI)
          * 2023, A relevância da inteligência emocional na gestão de conflitos Caso de estudo na estrutura residencial para idosos da Associação Casapiana de Solidariedade de Lisboa (Portugal), Revista Portuguesa de Gestão Contemporanea. ISSN: 2184-8319
          * 2023, A Sustentabilidade Económica-Financeira das Instituições Particulares de Solidariedade Social Paralesia Cerebral, Revista Temas Sociais. ISSN: 2184-982X
          * 2023, O Impacto da Liderança no Desempenho Organizacional em Contexto de Pandemia Caso de estudo da Residência Sénior Avós Arco-íris , Revista Temas Sociais. ISSN: 2184-982X
          * 2023, A Gestão de Pessoas nas Organizações Estudo de Caso da Luz dos Pastorinhos, Revista Temas Sociais. ISSN: 2184-982X
          * 2022-11-22, Female Leadership And Its Repercussions On Employees' Motivation In Portugal, Journal of Business and Management Research. ISSN: 2507-1076
          * 2022, The determinants of air transport passenger demand of the Chinese and Taiwan aviation markets from Lisbon International Airport: an Empirical modelling analysis, International Journal of Business Excellence. ISSN: 1756-0047. (Scientific Journal Rankings: Q3)
          * 2022, Determinants behaviour analysis of demand for passengers to the Portuguese air travel leisure market: Application with PLS, International Journal of Business Excellence. ISSN: 1756-0047. (Scientific Journal Rankings: Q2)
          * 2022, Burnout Level on Portuguese Audiologists, European Journal of Business and Management Research. ISSN: 2507-1076
          * 2022, A Atual Percepção da Cultura de Segurança - Um Caso de Estudo no Aeroporto Humberto Delgado em Lisboa/Portugal, Revista Portuguesa de Gestão Contemporanea. ISSN: 2184-8319
          * 2021, The transition from face-to-face teaching to distance learning in higher education: An empirical study with students at Universidade Lusófona, iated Digital Library. ISSN: 2340-1095
          * 2021, Estudos dos Fatores de Estímulos Motivacionais em Equipas Virtuais. , Revista Lusófona de Economia e Gestão das Organizações. ISSN:2183-5845
          * 2021, Challenges of online teaching-learning/distance learning context in Higher Education due to COVID-19: An empirical study applied to Lusófona University Humanities and Technologies students (Lisbon), iated Digital Library. ISSN: 2340-1095
          * 2019, A Inteligência Emocional Como Fator Determinante da Liderança, Revista Lusófona de Economia e Gestão das Organizações. ISSN:2183-5845
          * 2018, Outsourcing e a Satisfação do Consumidor nos Serviços Alimentares - Estudo de caso da Escola de Dança e da Escola de Música do Conservatório Nacional, Revista Lusófona de Economia e Gestão das Organizações. ISSN:2183-5845
          * 2018, Comportamento dos Consumidores e a Evolução do Mercado de Combustíveis em Portugal e os Combustíveis Simples, Revista Lusófona de Economia e Gestão das Organizações. ISSN:2183-5845
          * 2018, A Avaliação dos Impactos da Formação de Utilização da Metodologia Return of Investment: uma análise comparada, Revista Lusófona de Economia e Gestão das Organizações. ISSN:2183-5845
          * 2017, Impacto dos Fatores Motivacionais no Desempenho dos Colaboradores e Docentes Estudo de Caso na UNI-Mindelo, Revista Lusófona de Economia e Gestão das Organizações. ISSN 2183-5845
          * 2015, O Impacto das Práticas de Gestão de Recursos Humanos na Motivação dos Colaboradores da Administração Pública Cabo-Verdiana, Revista Lusófona de Economia e Gestão das Organizações. ISSN:2183-5845
          * 2015, Contributo para a classificação da funcionalidade dos utentes na Rede Nacional de Cuidados Continuados Integrados segundo a Classificação Internacional de Funcionalidade, Revista Portuguesa de Saúde Pública. ISSN: 0870-925. 7. (Scientific Journal Rankings)
          * 2012, Japanese management and salary productivity: the case of the electronic and automotive industries in Portugal, The International Journal of Human Resource Management. ISSN: 1466-4399. 7. (Scientific Journal Rankings: Q1)
          * 2011, Regular Airlines Flying Towards a Low Cost Strategy, International Business Research. ISSN: 1913-9004.
          * 2010, O Impacto da Diversidade do Género na Eficiência da Gestão e Sua Influência no PNB de um País, Revista Economia Global e Gestão. ISSN: 0873-74444
          * 2010, As Novas Fronteiras da Gestão A Era do Conhecimento, Revista Gestin. ISSN: 1645-2534
          * 2009, Um novo paradigma na teoria económica: a necessidade de repensar a escassez de recursos, Revista Lusiada. Economia&Empresa. ISSN: 1645-6750.
          * 2009, Relato de Uma Experiência no Ensino Virtual em Portugal, Revista Gestão e Desenvolvimento. ISSN: 1646-2408
          * 2009, A importância da comunicação no e-learning, Revista Paidéi@. ISSN: 1982-6109.
          * 2008, Las Claves del Éxito de la Competitividad del Sistema Empresarial Japonés, Revista Empresa Y Humanismo. ISSN: 1139-7608
          * 2008, Gestão Nipónica dos Recursos Humanos: Influências e Determinantes do Desempenho , Revista Economia e Sociologia. ISSN: 0870-6026
          * 2008, Benefícios do E-Learning no Ensino Universitário, Iberian Conference on Information Systems and Technologies, CISTI. Pages ICU03. ISSN: 21660727 21660735. (Indexado Scopus)
          * 2008, A Importância dos Fóruns de Debate na Comunicação e Inteiração no Ensino Online, Revista de Estudos da Comunicação. ISSN: 1518-9775. (Indexada no Latindex)
          * 2008, A Avaliação da Aplicabilidade do Sistema de Gestão de Recursos Humanos Nipónico em Portugal, Revista Encontros Científicos Tourism & Management Studies. ISSN: 1646-2408.
          * 2007, Modelos típicos de gestão nipónica: perspetiva de desenvolvimento em Portugal, Lusíada. Economia & Empresa. ISSN: 1645-6750.

        Livro

          * 2024, Manual Prático para a Elaboração e Apresentação de Trabalhos Académicos – Guia do Estudante, Reis, F. L., Edições Silabo
          * 2022, Manual de Estratégia Empresarial, Inovação e Empreendedorismo. ISBN: 978-989-561-203-1. , Reis, F. L.; Reis, R., Edições Sílabo
          * 2022, Investigação Cientifica e Trabalhos académicos Guia prático.. 2ª edição ISBN: 978-989-561-211-6., 2, Reis, F. L., Edições Sílabo
          * 2022, Capital Humano- Temas para uma boa gestão das organizações.. 3ª edição. ISBN:978-989-561-258-1, 3, Silva, V.; Reis, F. L., Edições Silabo
          * 2020, Manual de Gestão Das Organizações Teoria e Prática.. 2ªedição ISBN:978-989-561-089-1, 2, Reis, F. L., Edições Silabo
          * 2014, Princípios de Gestão. ISBN: 987-972-618-699-1, Reis, F. L., Edições Silabo
          * 2011, Desenvolvimento Empresarial em Portugal O Sistema de Gestão Nipónico. ISBN: 978-972-8871-36-9, Reis, F. L., Editora RH
          * 2011, Como Elaborar Uma Dissertação De Mestrado Segundo Bolonha. ISBN: 978-989-693-000-4, 2, Reis, F. L., Pactor Grupo LIDEL
          * 2010, Recrutamento, Seleção E Integração,. ISBN: 978-972-8871-31-4, Reis, F. L., Editora RH
          * 2008, Gestão Da Produção E Operações, Universidade Aberta, Textos de Base N.º306. ISBN: 978-972-674-495-5, Reis, F. L.

        Capítulo de livro

          * 2012, Recrutamento, In Gestão de Recursos Humanos de A a Z, Augusto Lobato Neves e Ricardo Fortes da Costa. Editora Recursos Humanos. ISSN: 978-972-8871-41-3, Gestão de Recursos Humanos , Editora RH

        Artigo em conferência

          * Virtual teaching in a society of learning, W4A 2009 - International Cross Disciplinary Conference on Web Accessibility. (Books of Proceedings are indexed in Scopus. EID: 2-s2.0-85015878000)
          * The system of management nipónico of marketing: Perspectives of development in Portugal, 14th International Business Information Management Association Conference, IBIMA 2010. (Books of Proceedings are indexed in Scopus. EID: 2-s2.0-84905079125)
          * The Performance of Japanese Management of Research and Development in Companies in Portugal, GBATA 2009 Global Business and Technology Association - 11th Annual International Conference
          * The New Economic Order: Knowledge Economy, 14th International Business Information Management Association Conference, IBIMA 2010. (Books of Proceedings are indexed in Scopus. EID: 2-s2.0-84905119059)
          * The New Boundaries of Management: The Era of Knowledge, Conference Global Management (edição em CD-ROM, ISBN: 978-989-95806-8-8)
          * The Japanese Management of Human Resources in the Iberian Peninsula, GBATA 2009 Global Business and Technology Association - 11th Annual International Conference
          * The Development and Use of Information and Communication Technologies in Universitie, V Congresso Internacional de Creatividad e Innovación
          * Team Management Leadershio in Private Social Solidarity Institutions the Social Worker as a Leader, 11th International OFEL Conference. (Books of Proceedings are indexed in Web Of Science),
          * Teaching-Learning Models in Context of COVID-19 Pandemic: The Online Teacher and Student , 82nd International Scientific Conference on Economic and Social Development. (Books of Proceedings are indexed in Web of Science)
          * Performance Evaluation And Mamangement Importance In Organizational Motivation, 86th International Scientific Conference on Economic and Social Development. (Books of Proceedings are indexed in Web of Science)
          * O Ensino On-Line na Sociedade do Conhecimento, XIV Seminário da APEC
          * New Technologies Importance in Distance Education, 82nd International Scientific Conference on Economic and Social Development. (Books of Proceedings are indexed in Web of Science)
          * Labor Market Gender Discrimination - Case Study In Private And Public Sector Companies, 86th International Scientific Conference on Economic and Social Development. (Books of Proceedings are indexed in Web of Science)
          * Evaluation of the Applicability of the Japanese Human Resources Management System in Portugal, GBATA 2009 Global Business and Technology Association - 11th Annual International Conference
          * Endogenous Determinants on the Behaviour of Total Revenue in Legacy Type Air Transport Company: A Empirical Study, 39th International Scientific Conference on Economic and Social Development
          * E-Learning: A Way in Teaching / Learning, 5th International Conference on Hands-on Science Formal and Informal Science Education
          * Comunidades Virtuais de Aprendizagem, Conferência Ibero-Americana InterTIC2009 (edição em CD-ROM, ISBN: 978-989-95806-6-4)
          * As Percepções de Justiça Organizacional na Avaliação de Desempenho em Enfermagem, Conferência Investigação e Intervenção em Recursos Humanos
          * A Reflexion on the Importance of Web in Long-Distance Teaching, Workshop ICIS 08 Information Systems Research and Education in Developing Countries
          * A Liderança Como Factor de Sucesso na Implementação de Sistemas de Informação Clínica, III Seminário de Gestão em Saúde, Universidade da Beira Interior
          * A Importância do E-learning na Educação a Distância, VIII Colóquio sobre Questões Curriculares / IV Colóquio Luso-Brasileiro
          * 2023-10-20, Stress and Organizational Conflict The influence of the organizational environment on the employee's life: a study in the Lusófona University (Lisbon), 102nd International Scientific Conference on Economic and Social Development
          * 2023-10-20, Stress and Conflict in Agricultural and Wine Companies in the Interior of the Country, 102nd International Scientific Conference on Economic and Social Development
          * 2023-10-20, Emotional and transparent communication in times of crisis, 102nd International Scientific Conference on Economic and Social Development
          * 2023-02-03, Online teaching; An emerging reality. Selected Papers of the 15th World Conference on Educational Sciences (WCES 2023). New Trends and Issues Proceedings on Humanities and Social Sciences. 10(1), 12-17, 15th World Conference on Education Sciences
          * 2022-12-03, Paradigm Change in University Education Format in Portugal Arising the SARS-Cov-2 Pandemic. ISBN: 978-605-71219-9-8 (e-book), 15th International Conference on Economic, Social, and Environmental Sustainability in the Post Covid-19 World
          * 2022-12-03, Leadership in Changing Context. Case Study: Elderly Residential. ISBN: 978-605-71219-9-8 (e-book), 15th International Conference on Economic, Social, and Environmental Sustainability in the Post Covid-19 World
          * 2022-12-02, A new reality arising from SARS-COV-2 coronavirus pandemic: Portuguese Private and Public Higher Education Institutions. ISBN: 978-605-71219-9-8 (e-book), 15th International Conference on Economic, Social, and Environmental Sustainability in the Post Covid-19 World
          * 2022-02-03, Teacher Training Specificities Adapted To New Technologies, 14th World Conference on Educational Sciences
          * 2022-02-03, Distance Education Perspectives in University Education in Portugal After COVID-19 Pandemic, 14th World Conference on Educational Sciences
          * 2021-11-18, Social Assistant Manager Role in Conflict Management. Case Study in a Home Support Service of an IPSS , 74th International Scientific Conference on Economic and Social Development
          * 2021-11-18, Paradigm transition in knowledge creation. Learning and teaching forms in pandemic times: face-to-face teaching versus b-learning teaching, 74th International Scientific Conference on Economic and Social Development
          * 2021-11-08, The transition from face-to-face teaching to distance learning in higher education: An empirical study with students at Universidade Lusófona, ICERI2021: 14th annual International Conference of Education, Research and Innovation. (Books of Proceedings are indexed in Web Of Science).
          * 2021-11-08, Challenges of online teaching-learning/distance learning context in Higher Education due to COVID-19: : An empirical study applied to Lusófona University Humanities and Technologies students (Lisbon), ICERI2021: 14th annual International Conference of Education, Research and Innovation. (Books of Proceedings are indexed in Web Of Science).
          * 2021-07-12, A Psicossociologia das Organizações como promotora de pensamento crítico: um estudo de campo., 7.º Congresso Nacional de Práticas Pedagógicas no Ensino Superior
          * 2012-10-27, Da motivação ao Desempenho dos Funcionários Públicos Cabo-Verdianos, Conferência Investigação e Intervenção em Recursos Humanos
          * 2011-11-04, Assessing E-Learning: Finding a Model for Higher Education, 9th European Conference on e-Learning, ECEL 2010, (edição em CD-ROM), (Books of Proceedings are indexed in Scopus. EID: 2-s2.0-84901987450)
          * 2010-11-04, Using Social Software to Enhance the Student e-Learning Experiences and Activities in Higher Education, 9th European Conference on e-Learning, ECEL 2010, (edição em CD-ROM). (Books of Proceedings are indexed in Scopus. EID: 2-s2.0-84902001205)
          * 2010-11-04, Perspectives of online education, 9th European Conference on eLearning 2010, ECEL 2010 (Books of Proceedings are indexed in Scopus. EID: 2-s2.0-84901999423)
          * 2010-04-16, Os Escolhos da Avaliação do Desempenho, III Seminário de Gestão em Saúde, Universidade da Beira Interior
          * 2010-04-15, Mercantilização, Elo de Ligação entre Técnica e Desqualificação. Caso do Ensino Superior, I the Conference Learning and Teaching in Higher Education
          * 2010-04-15, E-learning in the Context of Higher Education, I the Conference Learning and Teaching in Higher Education
          * 2010-04-15, Contributo das Redes Sociais na Aprendizagem em Ambiente E-Learning, I the Conference Learning and Teaching in Higher Education
          * 2010-04-15, A Importância da Motivação no Sucesso da Liderança, III Seminário de Gestão em Saúde, Universidade da Beira Interior
          * 2010-02-04, Japanese Management and Salary Productivity The Case of the Industries in Portugal, Jornadas Hispano Lusas de Gestion Cientifica
          * 2009-07-15, The Knowledge Management as Personnel Management, International Conference on Managing Services in the Knowledge Economy
          * 2009-06-22, The Impact of the Information Systems for Human Resource Management, E-Activity and Leading Technologies 2009 Conference
          * 2009-06-22, The Education of Teachers in New Technologies, E-Activity and Leading Technologies 2009 Conference
          * 2009-06-22, Os Novos Modos de Aprender na Sociedade do Conhecimento, Conferência Ibero-Americana InterTIC2009 (edição em CD-ROM, ISBN: 978-989-95806-6-4)
          * 2009-04-22, Long Distance Teaching: The Online Student and Teacher, V International Conference on Multimedia and Information & Communication Technologies in Education
          * 2009-02-04, A Inovação no Ensino Aplicações ao Ensino a Distância, X Congresso Luso-Afro-Brasileiro de Ciências Sociais (edição em CD-ROM, ISBN: 978-972-8746-90-2
          * 2008-12-03, Gerações de Inovação Tecnológica no Ensino a Distância, Conferência Ibero-Americana InterTIC (edição em CD-ROM, ISBN: 978-989-95806-4-0)
          * 2008-12-03, Evolução Tecnológica do Ensino Tradicional / Educação a Distância, Conferência Ibero-Americana InterTIC (edição em CD-ROM, ISBN: 978-989-95806-4-0)
          * 2008-11-28, Proposal For Analytical Model: Intellectual Capital, 5th Workshop on Corporate Governance
          * 2008-11-18, The Debate Forums in the E-learning Regime, EADTU European Association of Distance Teaching Universities Annual Conference, Centre National d¿Enseignement à Distance (CNED). (Books of Proceedings are indexed in Scopus)
          * 2008-11-17, Uma Perspectiva Empresarial do Sistema de Gestão Nipónico na Península Ibérica, Congresso Internacional de Criatividade e Inovação
          * 2008-11-13, E-learning como Modalidade de Educação a Distância: contributo para o processo de Bolonha, X Seminário Hispano-Luso de Economia Empresarial
          * 2008-10-13, The Notion of Capital Intellectual in the Context of Globalization, Global Management 2008 Conference (edição em CD-ROM, ISBN: 978-989-95806-2-6)
          * 2008-10-13, Proposed Definition of the Concept of Intellectual Capital, Global Management 2008 Conference (edição em CD-ROM, ISBN: 978-989-95806-2-6)
          * 2008-09-22, The Globalization of Knowledge, 6th Workshop on International Strategy and Cross Cultural Management
          * 2008-09-12, A Importância das Plataformas no Ensino a Distância, II Encontro Moodle e Comunidades de Aprendizagem
          * 2008-06-30, Metodologia de Ensino e Aprendizagem: Fóruns de Debate, Seminário sobre a Utilização Educativa das Tecnologias de Informação e Comunicação
          * 2008-06-25, Explicative Model of Intellectual Capital, First International Conference on Business Sustainability (edição em CD-ROM, ISBN: 978-989-95907-1-7)
          * 2008-06-19, Benefícios do E-Learning no Ensino Universitário, Iberian Conference on Information Systems and Technologies, CISTI 2008. (Books of Proceedings are Indexed in Scopus, EID: 2-s2.0-84893103512)
          * 2008-05-02, Os Desafios do Professor no Contexto do Ensino Online, V Simpósio sobre a Organização e Gestão Escolar
          * Os Indicadores do Balanced Scorecard que Melhoram a Performance das Organizações, Conferência Investigação e Intervenção em Recursos Humanos

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona