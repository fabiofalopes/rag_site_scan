# Response for https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
          PT: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284 EN: https://www.ulusofona.pt/en/teachers/ana-ines-aires-mesquita-vieira-ferreira-6284
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
        fechar menu : https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-ines-aires-mesquita-vieira-ferreira-6284
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Inês Vieira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6284
              ine***@ulusofona.pt
              F619-D693-D3E9: https://www.cienciavitae.pt/F619-D693-D3E9
              0000-0001-7709-2271: https://orcid.org/0000-0001-7709-2271
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/5395b0f4-e82d-4c4b-86bb-a49888d1c38e
      : https://www.ulusofona.pt/

        Resume

        Inês Vieira is a post-doctoral integrated researcher at CeiED - Interdisciplinary Research Centre for Education and Development, and assistant professor at Lusófona University, with a focus on education and/for development. Active in the fields of Social Sciences, Education, Ecology and Territory. She has a PhD (Doctor Europæus, NOVA FCSH and Università di Bologna) and a MSc (NOVA FCSH) in Human Ecology, and a BSE in Childhood Education (ESE/P.Porto). Activities developed include research and science management grants in European and national projects on issues related to mobilities/migrations, social diversity, territory and ecology, education, youth and public policies. Among the projects in which she participated, she was the executive coordinator and manager of the Portuguese team at the European project [ALLMEET - Actions of Lifelong Learning addressing Multicultural Education and Tolerance in Russia] (Tempus, EU, 2013-2017). She is presently engaged at social/educational intervention projects for sustainability [Energia que move] (EDP Energia Solidária, 2023-2025), [Roda Viva] (BIP/ZIP, Lisbon Municipality, 2021-2024), and [Recurso Educativo Digital - Viver melhor na Terra, garantindo a sustentabilidade do Planeta] (DGE/Ministry of Education, 2023-2024), and integrates the research teams at [AGGRIN - Generative bodies: from aggression to the insurgency. Contributions to a decolonial pedagogy] (PTDC/CED-EDG/3644/2021-FCT, 2023-2026) and [RePeME - And after the pandemic? Recovery, continuities and changes in basic education in Portugal] (COFAC, 2023-2024). Current research interests include decolonial education, inequalities in education, critical education for sustainability, mobilities, territory and social diversity, and participatory research in the interface of science, arts and education. She is co-coordinator of ESA RN27 - Research Network on Southern European Societies of the European Sociological Association (since 2019) and member of the nuclear committee of APS ST-SCEAV - Thematic Section on Civil Society, Diverse Economies and Volunteering of the Portuguese Sociological Association. Within CeiED, she is engaged at the ReLeCo ART.DS - Socio-Artistic Studies for Decoloniality and Sustainability, a permanent team member of Op.Edu - Observatory for Education and Training Policies, a member of the Steering and Executive Committees of the research center and director of its Public Science Forum.

        Graus

            * Doutoramento
              Ecologia Humana
            * Mestrado
              Ecologia Humana e Problemas Sociais Contemporâneos
            * Licenciatura
              Educação de Infância

        Publicações

        Artigo em revista

          * 2023, Percursos para a mobilidade sustentável em territórios desiguais - reflexões a partir de um projeto de investigação-ação, Revista Brasileira de Sociologia - RBS
          * 2023, Multi-level Education for Sustainability through Global Citizenship, Territorial Education and Art Forms, Frontiers in Education
          * 2018, Healing or fleeing? Reflecting on international protection and health challenges from three refugee pathways, L'altro diritto, “Freedom and Healthcare. Exploring mutual interconnections in contemporary societies” (Eds. Botrugno, C. e Zózimo, J.R.), RUEBES
          * 2017, Nota acerca do Seminário Internacional 'Como apoiar pessoas refugiadas: abordagens e iniciativas de trabalho voluntário na Europa', Lisboa, 9 de Junho de 2017, Forum Sociológico
          * 2016-12-30, Interculturalidade e reflexão pedagógica em contexto de mudança social - Entrevista a Antonio Genovese, Forum Sociológico
          * 2016-12-30, A inclusão de minorias no desenho de territórios educativos interculturais : reflexões a partir do Projecto ALLMEET, Forum Sociológico
          * 2016, The Construction of the Mediterranean Refugee Problem from the Italian Digital Press (2013-2015): Emergencies in a Territory of Mobility, Networking Knowledge, "Fortress Europe: Media, Migration and Borders" (Eds. Sara Marino e Simon Dawes)
          * 2012, The Portuguese Press Portrait of «Environmental Refugees», World Academy of Science, Engineering and Technology, Open Science Index 64, International Journal of Humanities and Social Sciences
          * 2011, Jovens da Europa do Sul num contexto de mudança social: dados portugueses, SOCIOLOGIA ON LINE
          * 2006, Mozambique: ¿Cahora Bassa para quién?, Ecología Política

        Tese / Dissertação

          * 2019-01-25, Doutoramento, “Entre a seca africana e a utopia europeia”. A percepção do papel do ambiente na mobilidade de refugiados e migrantes etíopes e eritreus em Itália e cabo-verdianos em Portugal.
          * 2010, Mestrado, Migrações e ambiente. Imigrantes ambientais no contexto europeu

        Livro

          * 2020, “Próximo”: os territórios de Sintra em palco. Reflexões sobre um projecto de teatro documental, Gaspar, Susana C.; Vieira, Inês, Chão de Oliva

        Capítulo de livro

          * 2023, Políticas dirigidas aos Antigos Combatentes e Deficientes Militares, Políticas de Defesa em Portugal, Instituto da Defesa Nacional
          * 2023, O método do etnodrama e o princípio da participação entre etnografia e dramaturgia, Évora, I. e Amorim, S. (Orgs.) (2023). Diálogos de Campo - Pesquisas de Campo Participativas em Debate, CeSA CSG ISEG
          * 2022, O programa ‘Cidade Amiga das Crianças’ em Portugal e no Brasil, Gobbi, M.A., Anjos, C.I., Seixas, E.C. e Tomás, C. (Orgs.) O direito das crianças à cidade: perspectivas desde o Brasil e Portugal, FEUSP
          * 2020, Um laboratório ao ar livre para criar biodiversidade através do trabalho coletivo - o exemplo da HortaFCUL, Alimentar boas práticas — Da produção ao consumo sustentável, CICS.NOVA
          * 2020, Refugees and Borders: Simmel’s Contributions on Space and Strangeness to Reflect on the Condition of Contemporary Refugees in Europe, Inequality and Uncertainty: current challenges for cities, Springer Singapore
          * 2020, Raízes - Todos os momentos são de educação viva, Alimentar boas práticas: Da produção ao consumo sustentável , CICS.NOVA, FCSH
          * 2020, Monte Mimo - A agricultura familiar construindo paisagens regeneradas, Alimentar boas práticas: Da produção ao consumo sustentável , CICS.NOVA - FCSH
          * 2020, Da habitação ao prato - Minga, uma cooperativa integral, Alimentar boas práticas — Da produção ao consumo sustentável, CICS.NOVA
          * 2020, Crise urbana, política e social no Brasil e formas de resistência. Entrevista a Ermínia Maricato, O Brasil contemporâneo e a democracia, Outro Modo
          * 2020, Cem Soldos, BONS SONS: quando uma aldeia em manifesto se transforma em festival, Alimentar boas práticas — Da produção ao consumo sustentável, CICS.NOVA
          * 2018, Environmental Migrations Without Environmental Migrants? Perceptions and Policies on Environmental and Mobility Issues, Theory and Practice of Climate Adaptation, Springer International Publishing
          * 2016, Promoting interculturalism through non-formal approaches – Proposing a framework to observe and analyse intercultural initiatives, Intercultural dialogue: learning, speaking, and sharing. Proceedings of the international seminar and study visit ALLMEET in Lisbon '15, CICS.NOVA
          * 2016, Overview on intercultural issues in Portugal, Intercultural dialogue: learning, speaking, and sharing. Proceedings of the international seminar and study visit ALLMEET in Lisbon '15, CICS.NOVA
          * 2016, Frontiers and diversity in metropolitan contexts: the case of Cape Verdeans in Lisbon Metropolitan Area, Ethnopolitics and Migration: The conflicts, consensus and tolerance in the 21st century, Kazan (Volga Region) Federal University
          * 2016, ALLMEET in Lisbon ’15: report of the study visit, Intercultural dialogue: learning, speaking, and sharing. Proceedings of the international seminar and study visit ALLMEET in Lisbon '15, CICS.NOVA

        Edição de livro

          * 2016, CICS.NOVA

        Revisão de livro

          * Recensão crítica da obra de Franco Ferrarotti (2011). L’empatia creatrice. Potere, autorità e formazione umana, Roma: Armando Editore
          * Recensão crítica da obra de Federico Zannoni (org.) (2012). Società della discordia. Prospettive pedagogiche per la mediazione e la gestione dei conflitti. Bolonha: CLUEB
          * Recensão - Allocca, Daniela; Capone, Nicola; Ferrante, Nina; Iengo, Ilenia; Orlandini, Giuseppe; Sciarelli, Roberto; Valisena, Daniele (orgs.) (2021), Trame. Pratiche e saperi per un’ecologia politica situata

        Relatório

          * 2022-09-20, Estudo participativo sobre a mobilidade em Marvila, Lisboa, https://issuu.com/resdochao/docs/2022_relat_rio_do_estudo_participativo_sobre_a_mob
          * 2021, Centro de Recursos de Stress em Contexto Militar

        Documento de trabalho

          * 2012, Lo stato sociale portoghese e le sfide per l'educazione dell'infanzia

        Manual

          * 2014, D2.3 – Intercultural Glossary

        Artigo em conferência

          * O Mediterrâneo como território de mobilidade de refugiados, IX Congresso Português de Sociologia — Portugal, território de territórios
          * Latin language, cultural proximities and cultural domination: Southern European Metropolis and immigration, a comparative approach between Portugal and Italy, ESA 9th Conference — European Sociological Association
          * Jovens e Forças Armadas, VII Congresso Português de Sociologia
          * Inovar de forma colaborativa e participativa através da bicicleta: contextualização do projeto ‘Pedalada’ em Marvila, Lisboa, Comunidades e Redes para a Inovação Territorial
          * Excombatientes: un análisis comparativo a través de la revisión de la literatura, I Congreso Civico-Militar de Sociología - La cohesión en organizaciones jerarquizadas y los nuevos retos sociales en el Horizonte 2035
          * Estatuto do Antigo Combatente: Um direito longamente adiado
          * Environmental migrants from Africa to Europe: state of the art and research clues, 7th Congress of African Studies — CIEA7
          * Bicicletas em Marvila? Um inquérito à mobilidade na periferia lisboeta
          * 2022-09, A curadoria participativa de um festival de cinema: reflexões educativas a partir de uma prática social inovadora, XVI Congresso da Sociedade Portuguesa de Ciências da Educação

        Arte visual

          * Bello essere Habesha (filme documentário)

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona