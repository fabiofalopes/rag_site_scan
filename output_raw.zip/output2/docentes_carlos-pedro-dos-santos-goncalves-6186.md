# Response for https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
          PT: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186 EN: https://www.ulusofona.pt/en/teachers/carlos-pedro-dos-santos-goncalves-6186
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
        fechar menu : https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carlos-pedro-dos-santos-goncalves-6186
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carlos Pedro Gonçalves

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6186
              p61***@ulusofona.pt
              8E1C-A8B3-78C5: https://www.cienciavitae.pt/8E1C-A8B3-78C5
              0000-0002-0298-3974: https://orcid.org/0000-0002-0298-3974
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/a2a0679d-8d50-488a-9e5d-2f26dea1c0d8
      : https://www.ulusofona.pt/

        Resume

        Associate Professor at Lusophone University of Humanities and Technologies and Researcher on Complexity Sciences, Quantum Technologies, Artificial Intelligence, Strategic Studies, Studies in Intelligence and Security, FinTech and Financial Risk Modeling. Progammer with programming experience in: A) Quantum Computing using Qiskit Python module and IBM Quantum Experience Platform, with software developed on the simulation of Quantum Artificial Neural Networks and Quantum Cybersecurity; B) Artificial Intelligence and Machine learning programming in Python; C) Artificial Intelligence, Multiagent Systems Modeling and System Dynamics Modeling in Netlogo, with models developed in the areas of Chaos Theory, Econophysics, Artificial Intelligence, Classical and Quantum Complex Systems Science, with the Econophysics models having been cited worldwide and incorporated in PhD programs by different Universities. Received an Arctic Code Vault Contributor status by GitHub, due to having developed open source software considered relevant to be preserved in the "Arctic Code Vault" for future generations (https://archiveprogram.github.com/arctic-vault/), with the Strategy Analyzer A.I. module for decision making support (based on my PhD thesis, used in my Classes on Decision Making and in Strategic Intelligence Consulting Activities) and QNeural Python Quantum Neural Network simulator both software modules preserved in the "Arctic Code Vault", for access to these software modules see: https://github.com/cpgoncalves

        Graus

            * Doutoramento
              Management with Specialization in Quantitative Methods in the Branch of Risk Mathematics
            * Mestrado
              Finance
            * Licenciatura
              Corporate Organization and Management

        Publicações

        Preprint

          * 

        Journal article

          * 2023-10-29, Chaos-Induced Self-Organized Criticality in Stock Market Volatility-An Application of Smart Topological Data Analysis , International Journal of Swarm Intelligence and Evolutionary Computation
          * 2023-01-13, Low Dimensional Chaotic Attractors in Daily Hospital Occupancy from COVID-19 in the USA and Canada, International Journal of Swarm Intelligence and Evolutionary Computation
          * 2022-11-07, Low Dimensional Chaotic Attractors in SARS-CoV-2's Regional Epidemiological Data, International Journal of Swarm Intelligence and Evolutionary Computation
          * 2022-08-12, Coupled Stochastic Chaos and Multifractal Turbulence in an Artificial Financial Market, International Journal of Swarm Intelligence and Evolutionary Computation
          * 2022-05-02, Quantum Neural Networks, Computational Field Theory and Dynamics, International Journal of Swarm Intelligence and Evolutionary Computation
          * 2021-01-27, Comparing Decision Tree-Based Ensemble Machine Learning Models for COVID-19 Death Probability Profiling, Journal of Vaccines & Vaccination
          * 2019, Quantum robotics, neural networks and the quantum force interpretation, NeuroQuantology
          * 2019, Quantum Stochastic Neural Maps and Quantum Neural Networks, SSRN Electronic Journal
          * 2017-09, Review of John Cramer's book "The quantum handshake. Entanglement, nonlocality and transactions", Newsletter of the European Mathematical Society
          * 2017, Quantum neural machine learning: Backpropagation and dynamics, NeuroQuantology
          * 2017, A.I. Awakening - A Technological Singularity, SSRN Electronic Journal
          * 2015, Quantum cybernetics and complex quantum systems science: A quantum connectionist exploration, NeuroQuantology
          * 2015, Ontologies of Presence, SSRN Electronic Journal
          * 2015, Financial Market Modeling with Quantum Neural Networks, Review of Business and Economics Studies
          * 2013, Quantum financial economics - risk and returns, Journal of Systems Science and Complexity
          * 2013, Ontological Dynamics of Truth, SSRN Electronic Journal
          * 2012, Risk Governance - A Framework for Risk Science-Based Decision Support Systems, SSRN Electronic Journal
          * 2012, Quantum Financial Economics of Games of Strategy and Financial Decisions, SSRN Electronic Journal
          * 2012, On Systems and Their Fields of Sustainability, SSRN Electronic Journal
          * 2012, Financial Turbulence, Business Cycles and Intrinsic Time in an Artificial Economy, Algorithmic Finance
          * 2010, Multifractal Financial Chaos in an Artificial Economy, SSRN Electronic Journal
          * 2010, Chaos, Artificial Life and Risk Mathematics, SSRN Electronic Journal
          * 2010, Chaos in Binary Category Computation, SSRN Electronic Journal
          * 2009, The Problem of Time in Quantum Cosmology and Non-Chronometric Temporality, SSRN Electronic Journal
          * 2009, Ontologies: On the Concepts of: Possibility, Possible, 'Acaso', Aleatorial and Chaos, SSRN Electronic Journal
          * 2009, A Systems Theoretical Formal Logic for Category Theory, SSRN Electronic Journal
          * 2007, An Evolutionary Quantum Game Model of Financial Market Dynamics - Theory and Evidence, SSRN Electronic Journal
          * 2004, Tail Risk and pK-Tail Risk, SSRN Electronic Journal

        Thesis / Dissertation

          * 2010, PhD, Contributos para os Fundamentos Categoriais da Matemática do Risco
          * 2004, Master, A Method for Tail Risk and Model pK-Tail Risk Control in (Sub)Market Risk Measurement Systems

        Book

          * 2020, The New Intelligence Game - An Intelligence Study, Gonçalves, Carlos

        Book chapter

          * 2020, Cyberspace and Artificial Intelligence: The New Face of Cyber-Enhanced Hybrid Threats, {IntechOpen
          * 2019, Quantum Neural Machine Learning: Theory and Experiments, {IntechOpen
          * 2005, Um Método de Controlo de Risco de Cauda, Perspectivas do Cálculo Financeiro, Edições Sílabo

        Book review

          * Zentralblatt MATH Review of The quantum handshake. Entanglement, nonlocality and transactions
          * Zentralblatt MATH Review of Quantum zero-error information theory
          * Zentralblatt MATH Review of Quantum computation with topological codes. From qubit to topological fault-tolerance
          * Zentralblatt MATH Review of Principles of quantum artificial intelligence
          * Zentralblatt MATH Review of Finite and profinite quantum systems
          * Zentralblatt MATH Review of Entropy and sustainable growth
          * Zentralblatt MATH Review of Book Chapter: Quantum game theoretical frameworks in economics. Haven, Emmanuel (ed.) et al., The Palgrave handbook of quantum models in social science. Applications and grand challenges
          * Zentralblatt MATH Review of A matrix algebra approach to artificial intelligence
          * Zentralblatt MATH Review of A first introduction to quantum computing and information
          * Zentralblatt MATH Review of Foundations and applications of complexity economics

        Musical composition

          * 2024-01, Strigoi - Álbum produzido com recurso a I.A. generativa (https://youtube.com/playlist?list=PLmLUR-kyF1qVdhytQ8y53HpL2nNIOHUKg&si=w0wGmC5ohJhFKNfg)
          * 2023-04, Faust - Álbum produzido com recurso a I.A. generativa (https://youtube.com/playlist?list=PLmLUR-kyF1qV4-nEk6xKg-GlDjEZufko-&si=oIfz7vU9KWtQ27Fh)
          * 2023-02-04, Shinobi no Mono peça musical composta com recurso a I.A. generativa (https://youtu.be/LYhlv-4Sl9U?si=FFXfbz9z949AF-eT)

        Visual artwork

          * Woodland Dream (Deep Fractal Dream Artwork, Sep 26, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Woodland-Dream-765665600)
          * Werewolves (Steampunk Art, Jul 31, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Werewolves-924337004)
          * Wave (Deep Fractal Dream Artwork, Aug 17, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Wave-759916735)
          * Watcher (Deep Dream Artwork, Jan 12, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Watcher-826749408)
          * War of the Worlds - Steampunk (Steampunk Art, Aug 11, 2022, available at: https://www.deviantart.com/cpgoncalves/art/War-of-the-Worlds-Steampunk-925625999)
          * Walking Pace (Deep Dream Artwork, Mar 16, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Walking-Pace-789892914)
          * Vortex (Deep Fractal Dream Artwork, Aug 22, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Vortex-760530587)
          * Voices (Deep Dream Artwork, Jan 10, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Voices-826516353)
          * Visitors (Steampunk Art, Jul 13, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Visitors-922349855)
          * Urban Expressions 2 (Deep Dream Artwork, Oct 9, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Urban-Expressions-2-816193040)
          * Urban Expressions (Deep Dream Artwork, Oct 9, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Urban-Expressions-816187516)
          * Twilight (Deep Fractal Dream Artwork, Nov 23, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Twilight-898751814)
          * Travelling (Fractal Artwork, Jul 11, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Travelling-753908375)
          * Traveller (Deep Dream Artwork, Feb 27, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Traveller-787490197)
          * Tiger Spirit (Deep Dream Artwork, Nov 23, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Tiger-Spirit-821242576)
          * Think for Yourself (Deep Dream Artwork, May 16, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Think-for-Yourself-797926664)
          * There are Monsters in the Woods (Steampunk/Horrorpunk Art, Aug 15, 2022, available at: https://www.deviantart.com/cpgoncalves/art/There-are-Monsters-in-the-Woods-926069027)
          * The Witches Park - Gothic Steampunk (Steampunk Art, Aug 7, 2022, available at: https://www.deviantart.com/cpgoncalves/art/The-Witches-Park-Gothic-Steampunk-925166977)
          * The Webmaker (Steampunk Art, Jul 13, 2022, available at: https://www.deviantart.com/cpgoncalves/art/The-Webmaker-922308766)
          * The Revenant's Castle - Steampunk Horrorpunk (Steampunk/Horrorpunk Art, Aug 13, 2022, available at: https://www.deviantart.com/cpgoncalves/art/The-Revenant-s-Castle-Steampunk-Horrorpunk-925808663)
          * The Field (Deep Dream Artwork, Jan 19, 2020, available at: https://www.deviantart.com/cpgoncalves/art/The-Field-827493956)
          * The Estate (Steampunk Art, Jul 30, 2022, available at: https://www.deviantart.com/cpgoncalves/art/The-Estate-924269779)
          * The Dream of the Djinn (Deep Dream Artwork, May 11, 2019, available at: https://www.deviantart.com/cpgoncalves/art/The-Dream-of-the-Djinn-797307853)
          * The Cube (Fractal Artwork, Jul 29, 2018, available at: https://www.deviantart.com/cpgoncalves/art/The-Cube-756818482)
          * Tejo Deep Dreaming (Deep Dream Artwork, Sep 9, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Tejo-Deep-Dreaming-763245019)
          * Tejo (Deep Dream Artwork, Sep 9, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Tejo-763244852)
          * Swamp Creatures (Horror Art, Aug 8, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Swamp-Creatures-925292814)
          * Struggle (Deep Dream Artwork, Jun 14, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Struggle-845469809)
          * Street Pulse (Deep Dream Artwork, Feb 22, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Street-Pulse-786672751)
          * Street Art Dreaming (Deep Dream Artwork, Jan 19, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Street-Art-Dreaming-827497427)
          * Steampunk Sorcerer (Steampunk/Horrorpunk Art, Aug 25, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Steampunk-Sorcerer-927143843)
          * Steampunk Sheol (Steampunk/Horrorpunk Art, Aug 15, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Steampunk-Sheol-926815097)
          * Steampunk City 3 (Steampunk Art, Jul 30, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Steampunk-City-3-924271436)
          * Steampunk City 2 (Steampunk Art, Jul 15, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Steampunk-City-2-922614062)
          * Steampunk City (Steampunk Art, Jul 12, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Steampunk-City-922307871)
          * Spirits in the Storm (Deep Dream Artwork, Jan 22, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Spirits-in-the-Storm-827828820)
          * Spaces (Deep Fractal Dream Artwork, Jul 28, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Spaces-756759582)
          * Sorcerer (Deep Dream Artwork, Jun 14, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Sorcerer-845458711)
          * Shaman's Dream (Deep Dream Artwork, Jan 15, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Shaman-s-Dream-827037709)
          * Serengeti (Deep Dream Artwork, Dec 29, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Serengeti-778652949)
          * Ruins (Deep Fractal Dream Artwork, Aug 17, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Ruins-759917079)
          * Risen (Deep Dream Artwork, Feb 27, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Risen-787497104)
          * Remembering (Deep Fractal Dream Artwork, Apr 22, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Remembering-913860070)
          * Refuge (Fractal Artwork, Jul 11, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Refuge-753908523)
          * Portal 2 (Deep Dream Artwork, Jan 26, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Portal-2-828322506)
          * Portal (Deep Dream Artwork, Jan 12, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Portal-826745651)
          * Paths Through the Woods (Deep Dream Artwork, Jan 15, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Paths-Through-the-Woods-827052078)
          * Passage to the Underworld (Deep Fractal Dream Art, Aug 17, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Passage-to-the-Underworld-926283398)
          * Off-World Scape 4 (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Off-World-Scape-4-752439822)
          * Off-World Scape 3 (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Off-World-Scape-3-752439634)
          * Off-World Scape 2 (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Off-World-Scape-2-752439479)
          * Off-World Scape 1 (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Off-World-Scape-1-752439168)
          * Off Path (Deep Dream Artwork, Aug 22, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Off-Path-760529933)
          * Notre-Dame (Deep Fractal Dream Artwork, Dec 30, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Notre-Dame-778904607)
          * Northern Escape Deep Dream Variations 2 (Deep Dream Artwork, Jun. 15, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Northern-Escape-Deep-Dream-Variations-2-882778435)
          * Northern Escape Deep Dream Variation 1 (Deep Dream Artwork, Jun. 15, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Northern-Escape-Deep-Dream-Variation-1-882778157)
          * Northern Escape (Deep Fractal Dream Artwork, Jun. 12, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Northern-Escape-882463994)
          * Night at the Park - Steampunk (Steampunk Art, Jul 28, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Night-at-the-Park-Steampunk-924050623)
          * Night Spirits (Deep Dream Artwork, Feb 27, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Night-Spirits-787489328)
          * Mirrors (Deep Dream Artwork, Apr 18, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Mirrors-794317806)
          * Messengers (Deep Dream Artwork, May 11, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Messengers-797306523)
          * Matrix (Deep Dream Artwork, Jun 25, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Matrix-846649138)
          * Made of Stone (Deep Dream Artwork, Apr 18, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Made-of-Stone-794319520)
          * Life Force (Deep Fractal Dream Artwork, May 1, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Life-Force-914766113)
          * Jazz Dream (Deep Fractal Dream Artwork, Aug 17, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Jazz-Dream-759917721)
          * Jacked into Cyberspace (Neuromancer) (Fractal Artwork, Jul 2, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Jacked-into-Cyberspace-Neuromancer-752561709)
          * Intersections (Fractal Artwork, Jul 5, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Intersections-753090850)
          * Innocence (Deep Dream Artwork, Mar 16, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Innocence-789897521)
          * In the Rhythm (Deep Fractal Dream Artwork, Aug 22, 2018, available at: https://www.deviantart.com/cpgoncalves/art/In-the-Rhythm-760530976)
          * In Flux 3 (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/In-Flux-3-752371091)
          * In Flux 2 (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/In-Flux-2-752370982)
          * In Flux (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/In-Flux-752310432)
          * I Robot (Deep Dream Artwork, Sep 26, 2020, available at: https://www.deviantart.com/cpgoncalves/art/I-Robot-856315669)
          * Huntress - Cyberpunk Art (Cyberpunk Art, Aug 9, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Huntress-Cyberpunk-Art-925420821)
          * Fractal Street 1 (Deep Fractal Dream Artwork, Jun. 18, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Fractal-Street-1-883035512)
          * Fractal Deep Dream 2 (Deep Fractal Dream Artwork, Jan. 29, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Fractal-Deep-Dream-2-868684230)
          * Fractal Deep Dream 1 (Deep Fractal Dream Artwork, Jan. 26, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Fractal-Deep-Dream-1-868318586)
          * Fractal Deep Dream - Strange Attractor GIF (Deep Fractal Dream Artwork, Jun. 18, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Fractal-Deep-Dream-Strange-Attractor-GIF-883036625)
          * Fractal Deep Dream - Strange Atractor (Deep Fractal Dream Artwork, Feb. 25, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Fractal-Deep-Dream-Strange-Atrractor-871523168)
          * Fractal Deep Dream - Mandelbrot Deep Dreaming (Deep Fractal Dream Artwork, Jun. 18, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Fractal-Deep-Dream-Mandelbrot-Deep-Dreaming-883042658)
          * Forest Yokai (Deep Dream Artwork, Nov 9, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Forest-Yokai-819729614)
          * Flowing Code (Deep Dream Artwork, Apr. 22, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Flowing-Code-838952019)
          * Flowing City (Deep Fractal Dream Artwork, Fev. 25, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Flowing-City-871522944)
          * Flesh Bricks and Metal (Cyberpunk Art, Jul 17, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Flesh-Bricks-and-Metal-922794927)
          * Fading into Form (Fractal Artwork, Jul 5, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Fading-into-Form-753090662)
          * Earth Spirit (Deep Dream Artwork, Oct 9, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Earth-Spirit-816183953)
          * Early Morning (Deep Fractal Dream Artwork, Sep 27, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Early-Morning-765805828)
          * Dwelling 2 (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Dwelling-2-752371392)
          * Dwelling (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Dwelling-752371178)
          * Dream (Deep Dream Artwork, Aug 29, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Dream-761658641)
          * Dragons (Steampunk Art, Jul 15, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Dragons-922628384)
          * Distortion (Deep Fractal Dream Artwork, Jun. 15, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Distortion-882777665)
          * Dimensions (Deep Dream Artwork, Jan 14, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Dimensions-826929266)
          * Digital Soul (Deep Dream Artwork, Aug 9, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Digital-Soul-808946251)
          * Desert's Dream (Deep Dream Artwork, Feb 29, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Desert-s-Dream-832154935)
          * Deep Fractal Dreaming - Transitions (Deep Fractal Dream Artwork, Nov 9, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Deep-Fractal-Dreaming-Transitions-771930610)
          * Deep Fractal Dreaming - At World's Edge (Deep Fractal Dream Artwork, Nov 9, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Deep-Fractal-Dreaming-At-World-s-Edge-771928249)
          * Deep Fractal Dream - TechnoFlow (Deep Fractal Dream Artwork, Aug 30, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Deep-Fractal-Dream-TechnoFlow-890356538)
          * Deep Fractal Dream - Shaman (Deep Fractal Dream Artwork, Aug 30, 2021, available at: https://www.deviantart.com/cpgoncalves/art/Deep-Fractal-Dream-Shaman-890356486)
          * Daydreaming (Deep Fractal Dream Artwork, Apr 22, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Daydreaming-913859111)
          * Cube (Fractal Artwork, Jul 1, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Cube-752371288)
          * Crowfall (Steampunk Art, Jul 12, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Crowfall-922307195)
          * Countryside (Deep Dream Artwork, Aug 23, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Countryside-760748430)
          * Cosmic Gaze (Fractal Artwork, Jul 11, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Cosmic-Gaze-753908136)
          * Connected (Deep Dream Artwork, Dec 26, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Connected-778331319)
          * Clockwork (Deep Dream Artwork, Aug 8, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Clockwork-808945555)
          * City Spirits (Deep Fractal Dream Artwork, Dec 12, 2018, available at: https://www.deviantart.com/cpgoncalves/art/City-Spirits-776392981)
          * City Sounds (Deep Fractal Dream Artwork, Jul 30, 2018, available at: https://www.deviantart.com/cpgoncalves/art/City-Sounds-756915346)
          * City (Deep Fractal Dream Artwork, Dec 30, 2018, available at: https://www.deviantart.com/cpgoncalves/art/City-778904147)
          * Bridge (Deep Dream Artwork, Jan 10, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Bridge-826510474)
          * Breaking Fences (Deep Dream Artwork, Aug 9, 2019, available at: https://www.deviantart.com/cpgoncalves/art/Breaking-Fences-808945970)
          * Belem Lisbon (Deep Dream Artwork, Sep 9, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Belem-Lisbon-763244438)
          * Apocalypse (Deep Dream Artwork, May 3, 2020, available at: https://www.deviantart.com/cpgoncalves/art/Apocalypse-840402091)
          * Another Place (Deep Fractal Dream Artwork, Dec 8, 2018, available at: https://www.deviantart.com/cpgoncalves/art/Another-Place-775924915)
          * Afterlife (Steampunk/Horrorpunk Art, Aug 25, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Afterlife-927144017)
          * ''Skrik'' (Cyberpunk Art, Jul 17, 2022, available at: https://www.deviantart.com/cpgoncalves/art/Skrik-922795232)
          * A Day at the Park - Steampunk (Steampunk Art, Jul 29, 2022, available at: https://www.deviantart.com/cpgoncalves/art/A-Day-at-the-Park-Steampunk-924161386)

        Invention

          * 2022-07, Coupled map lattice simulator exemplifying a coupled circle map, with local coupling and periodic boundary conditions. Used at the International Management and Governance In Times of Crisis - Risk, Sustainability, Resilience, Agility in the presentation Gonçalves (2022) "Can we Survive? Chaos Complexity and Risk" https://youtu.be/iAeLlEJuEkU
          * 2021-12, System dynamics model of airline ticket sales with limits to market growth, associated with competition strength and a potential market. The model is linked to the project http://modelingcommons.org/projects/181
          * 2021-12, Simulation model of an Unmanned Ground Vehicle in a circular motion around a target, using system dynamics and agent-based technologies. The model is linked to the project http://modelingcommons.org/projects/181
          * 2021-12, Simulation model of an Unmanned Aerial Vehicle in a circular flight around a target, at constant height, using system dynamics and agent-based technologies. The model is linked to the project http://modelingcommons.org/projects/181
          * 2021-12, Evolutionary game model of four airline competition for market share adapted from Vano, JA, Wildenberg, JC, Anderson, MB, Noel, JK and Sprott, JC (2006) "Chaos in low-dimensional Lotka-Volterra models of competition" Nonlinearity 19, 2391-2404.. The model is linked to the projects http://modelingcommons.org/projects/190 and http://modelingcommons.org/projects/181.
          * 2020, Random String Generation: Jupyter notebook with Python code for a Quantum Random String Generator using Qiskit and the cloud-based access to IBM's Quantum Computers and integrated in the research project Quantum Cybersecurity (https://cpgoncalves.github.io/Quantum-Cybersecurity/). Page: https://github.com/cpgoncalves/Quantum-Cybersecurity/blob/master/Random%20String%20Generation.ipynb
          * 2020, QRobot: Jupyter notebook with Python code for a Quantum Recurrent Neural Network Simulator applied to quantum robotics using Qiskit and the cloud-based access to IBM's Quantum Computers and integrated in the research project Quantum Cybersecurity (https://cpgoncalves.github.io/Quantum-Cybersecurity/). Page: https://github.com/cpgoncalves/Quantum-Cybersecurity/blob/master/QRobot.ipynb
          * 2020, Drones - Target Convergence: swarm intelligence model programmed in Netlogo, with communication between drones with target convergence. http://modelingcommons.org/browse/one_model/6416#model_tabs_browse_nlw
          * 2020, DenseCodingHack: Jupyter notebook with Python code for a Superdense Coding Hack using Qiskit and the cloud-based access to IBM's Quantum Computers and integrated in the research project Quantum Cybersecurity (https://cpgoncalves.github.io/Quantum-Cybersecurity/). Page: https://github.com/cpgoncalves/Quantum-Cybersecurity/blob/master/DenseCodingHack.ipynb
          * 2019, QNeural (2019): quantum neural network simulation programmed in Python and used for the author's research in Quantum Neural Networks simulations (software selected for GitHub's Arctic Code Vault https://archiveprogram.github.com/arctic-vault/). Page: https://github.com/cpgoncalves/qneural
          * 2019, Analytics Engine: data science and analytics engine programmed in Python combining Data Science and Machine Learning for Business Intelligence, used in Statistics for Management classes. Page: https://github.com/cpgoncalves/Analytics-Engine
          * 2017, Strategy Analyzer: percolation-based Artificial Intelligence (A.I.) software programmed in Python for Strategic Intelligence Analytics, based on my PhD thesis, the software has been used in classes on Decision Making Techniques and Methods (software selected for GitHub's Arctic Code Vault https://archiveprogram.github.com/arctic-vault/). Page: https://github.com/cpgoncalves/strategy-analyzer
          * 2016, Artificial Financial Market (Modified): Modified version of Gonçalves (2013) model, to include volume effects and market sentiment broadcasting. http://modelingcommons.org/browse/one_model/4954#model_tabs_browse_info
          * 2015, Gameplayer: Artificial Intelligence software programmed in Python for game theory in the support to scenario analysis in the context of decision analytics and strategic intelligence, used in classes on Decsion Making techniques and methods. Page: http://cpgoncalves.github.io/gameplayer/
          * 2014, Strategy Bot V1.0: Artificial Intelligence Software programmed in Python aimed at decision making support in complex environments applying statistical analysis of dynamical networks (developped for Decision Making Techniques Lectures in the Strategy Masters Course at ISCSP-University of Lisbon). Page: https://sites.google.com/site/autonomouscomputingsystems/strategy-bot
          * 2014, ALife Somatic Computation: ALife and AI model worked in Gonçalves, C.P. (2014) Emotional Responses in Artificial Agent-Based Systems: Reflexivity and Adaptation in Artificial Life. arXiv:1401.2121 [cs.AI]) expanding the model presented at the 2005 Seminar in conference format “Grupos, Tecnologia e Criatividade” that took place at ISCTE-IUL. http://modelingcommons.org/browse/one_model/3950
          * 2013, Synergetics - Lorenz Field Dynamics: Haken's Synergetics implemented in a network model driven by order parameters that follow Lorenz equations.
          * 2013, Risk Quantum Simulator II - Cyber Threats: network event simulator based on my PhD Thesis, worked in the article Risk Mathematics and Quantum Games on Quantum Risk Structures - A Nuclear War Scenario Game. arxiv:1211.6683 [physics.soc-ph] and used in MsC classes' Cyberwar Games. http://modelingcommons.org/browse/one_model/3471#model_tabs_browse_info
          * 2013, Risk Quantum Simulator I - Nuclear War: network event simulator based on my PhD Thesis and worked in the article Risk Mathematics and Quantum Games on Quantum Risk Structures - A Nuclear War Scenario Game. arxiv:1211.6683 [physics.soc-ph]. http://modelingcommons.org/browse/one_model/3470#model_tabs_browse_info
          * 2013, Quantum Primordial Soup: Quantum Cellular Automaton model programmed in Netlogo. http://modelingcommons.org/browse/one_model/3436#model_tabs_browse_info
          * 2013, Quantum Artificial Economy: Netlogo programmed model of an evolutionary quantum game applied to an Artificial Economy Simulation, worked in the article Gonçalves, C.P. (2012). Chaos and Nonlinear Dynamics in a Quantum Artificial Economy. arxiv:1202.6647 [nlin.CD]. http://modelingcommons.org/browse/one_model/3393#model_tabs_browse_info
          * 2013, Excitable Media model programmed in Netlogo. http://modelingcommons.org/browse/one_model/3466#model_tabs_browse_info
          * 2013, Cyber Threats to Global Governance: Netlogo programmed model of morphic web based on my PhD Thesis. http://modelingcommons.org/browse/one_model/3423#model_tabs_browse_info
          * 2013, Coalition Game: collaborative AI model programmed in Netlogo for the formation of coalitions in a network of artificial agents. http://modelingcommons.org/browse/one_model/3469#model_tabs_browse_info
          * 2012, Quantum Evolutionary Financial Economics: Netlogo programmed simulator of multiasset financial market with quantum evolutionary model worked in the article Gonçalves, C.P. (2011). Financial Turbulence, Business Cycles and Intrinsic Time in an Artificial Economy. Algorithmic Finance, 1:2, 141-156. http://modelingcommons.org/browse/one_model/3443#model_tabs_browse_info
          * 2010, Quantum Life I : Quantum Game of Life model programmed in Netlogo as a model of a Quantum Cellular Automaton. http://ccl.northwestern.edu/netlogo/models/community/Quantum%20Life%20I
          * 2007, Quantum Financial Market: Quantum Artificial Financial Market model programmed in Netlogo and worked in the article: Gonçalves, C.P. and Gonçalves, C. (2007). An evolutionary quantum game model of financial market dynamics - theory and evidence. DOI: 10.2139/ssrn.982086 (model and article internationally cited). http://ccl.northwestern.edu/netlogo/models/community/Quantum_Financial_Market
          * 2007, Artificial Financial Market II - Tail Risk: expansion of Gonçalves (2003) Artificial Financial Market, programmed in Netlogo, including different variants of market agents and that integrates my MsC Thesis work. http://ccl.northwestern.edu/netlogo/models/community/Artificial%20Financial%20Market%20II%20-%20Tail%20Risk
          * 2003, Pile of Sand: modified version of Per Bak's Pile of Sand, programmed in Netlogo. http://ccl.northwestern.edu/netlogo/models/community/PileOfSand
          * 2003, Logistic: Model of Coupled Map Lattice programmed in Netlogo http://ccl.northwestern.edu/netlogo/models/community/Logistic
          * 2003, Herding: Herding behavior in a spin network programmed in Netlogo. http://ccl.northwestern.edu/netlogo/models/community/Herding
          * 2003, Artificial Financial Market: heterogeneous multiagent spin network model for Artificial Financial Market programmed in Netlogo, the model was cited worldwide and the subject of articles and theses by different authors and integrated in PhD programs. http://ccl.northwestern.edu/netlogo/models/community/Artificial%20Financial%20Market

        Other output

          * 2021-05-15, Cyberattacks on Quantum Networked Computation and Communications -- Hacking the Superdense Coding Protocol on IBM's Quantum Computers
          * 2020-12-08, Comparing Decision Tree-Based Ensemble Machine Learning Models for COVID-19 Death Probability Profiling
          * 2020, The Race for Quantum Supremacy and the Quantum Artificial Intelligence of Things
          * 2020, A.I. System to Predict COVID-19 Active Cases and Hospitalizations.
          * 2019, Blockchain and Augmented Intelligence Ecosystems – An Assessment of (Cyber)Security Risks
          * 2018, Financial Risk and Returns Prediction with Modular Networked Learning
          * 2017, STRATEGY ANALYZER: A PYTHON MODULE FOR A PERCOLATION-BASED INTELLIGENT SYSTEM FOR DECISION SUPPORT AND STRATEGIC PLANNING
          * 2016, Casos Resolvidos de Teoria dos Jogos com Recurso ao Python
          * 2016, Capital Humano e I&D+i Análise Comparativa dos BRICS, EUA, Japão e Europa
          * 2015, Python Aplicado a Problemas de Gestão de Recursos Humanos
          * 2014, Emotional Responses in Artificial Agent-Based Systems: Reflexivity and Adaptation in Artificial Life
          * 2013, Singularidade Tecnológica e a Terceira Revolução Industrial
          * 2013, Ciência Geral do Risco e Ciência dos Sistemas – Risco, Sistema e Sustentabilidade
          * 2013, As Quatro Fases da Cibernética e a Ciência da Tomada de Decisão
          * 2012, Risk Mathematics and Quantum Games on Quantum Risk Structures - A Nuclear War Scenario Game
          * 2012, Quantum Chaos and Quantum Computing Structures
          * 2012, Chaos and Nonlinear Dynamics in a Quantum Artificial Economy

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona