# Response for https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
          PT: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730 EN: https://www.ulusofona.pt/en/teachers/celia-maria-silverio-quico-2730
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
        fechar menu : https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/celia-maria-silverio-quico-2730
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Célia Quico

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p2730
              cel***@ulusofona.pt
              4C17-143A-08E9: https://www.cienciavitae.pt/4C17-143A-08E9
              0000-0001-7284-6433: https://orcid.org/0000-0001-7284-6433
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/d3f92d55-c4a4-48c8-8fa6-43e1f079a9e4
      : https://www.ulusofona.pt/

        Resume

        Célia Quico is an associate professor and researcher at Lusófona University, with a PhD in Communication Sciences from Universidade Nova de Lisboa. She specializes in research and development in interactive media and immersive media, currently having as main areas of interest content production about Portuguese cultural and natural heritage, as well as the promotion of media literacy, health literacy and ocean literacy among specific audiences. Since 2009, Celia is a full-time professor and researcher at Lusófona. Currently, she participates in the following research projects: Beyond the Lighthouse (FilmEU RIT, 2023-2024), ClimAID (CREA-CULT-2022-COOP), Curiositas (FCT, PTDC/COM-OUT/4851/2021), YouNDigital (FCT, PTDC/COM-OUT /0243/2021). Previously, Célia was a team member of research projects such as LusofonAtiva (ULHT, 2021-2022), Nazaré Imersiva (ULHT-CICANT, 2020-2021), MuSEAum (FCT-P2020, 2018 -2020), ReThink Before Act (EU-ISFP, 2018-2020), MigratED (Erasmus+, 2018-2020), ResponSEAble (H2020, 2015-2018), In_Nova MusEUm (2016-2018), among others. Furthermore, she coordinated and co-authored the projects ADOPT_DTV: Barriers to digital television Adoption in the context of the digital switchover (2010-2011) and iDTV-HEALTH: Inclusive services to promote health and well-being via Interactive digital television (2011-2014), both funded by FCT. Regarding teaching, Celia has been a professor in the doctoral courses in Communication Sciences and in Media Arts, in the master degree Communication in Organizations and in the international master's degree in Cinema KinoEyes, as well as in the degrees in Cinema, Communication Sciences and Sound Sciences, all in Lusófona University. Before joining Lusófona, Celia worked as a project manager in the areas of Digital Interactive Television and Multimedia for the telecommunications operator TV Cabo (currently NOS), from 2000 to 2009, which included the collaboration as a consultant for Portugal Telecom's PT Escolas social responsibility initiative to promote digital literacy among young Portuguese people.

        Graus

            * Licenciatura
              Ciências da Comunicação
            * Mestrado
              MBA de Audiovisual e Multimédia
            * Doutoramento
              Ciências da Comunicação

        Publicações

        Edição de número de revista

          * Media Literacy and Civic Cultures
          * International Journal of Film and Media Arts - Special Issue on CIIA 2021 , 7
          * Audiovisual and Creative Industries - Present and Future, 7
          * "The muSEAum: Water, Fire, Earth, Air" - thematic dossier

        Artigo em revista

          * 2023, Memórias imersivas da Nazaré: mergulhar no passado e especular sobre o futuro com as fotografias estereoscópicas de Álvaro Laborinho, Revista Lusófona de Educação (RLE)
          * 2022-09, Nazaré Imersiva: Exploring Old and New Immersive Media to Create a Sense of Presence in Portuguese Seascapes, Tangible Territory Journal
          * 2022-09, Nazaré Imersiva: Exploring Old and New Immersive Media to Create a Sense of Presence in Portuguese Seascape, Tangible Territory Journal
          * 2022-05-15, muSEAum: branding e comunicação dos museus de mar de Portugal, Midas
          * 2021-10, Nazaré and immersive media: New Approaches to Cultural Heritage through Mixing Old and New Media, International Journal of Creative Media Research
          * 2019-12, Television reshaped by big data: impacts and implications for Netflix-like platforms in the age of dataism, INTERNATIONAL JOURNAL OF FILM AND MEDIA ARTS
          * 2014-06-25, Using digital interactive television for the promotion of health and wellness, International Journal of Health Promotion and Education
          * 2014, The role of social media: The TravelPlot Porto case study, Journal of Tourism and Development
          * 2014, How mobile can factor into a location based transmedia storytelling overall strategy: The TravelPlot Porto case study, Journal of Tourism and Development [Revista Turismo & Desenvolvimento],
          * 2012-06-07, Digital TV switchover in Portugal: What is in it for the viewer?, International Journal of Digital Television
          * 2012, Porto As a Tourism Destination
          * 2012, Location based transmedia storytelling: The TravelPlot Porto Experience Design
          * 2009, ADOPT_DTV: Barreiras à adopção da televisão digital no contexto da transição da televisão analógica para o digital em Portugal, Revista Prisma.com – revista de Ciências da Informação e Comunicação
          * 2008, Participação nos media e os jovens dos 12 aos 18 anos: estudo de avaliação de um formato ‘cross-media’, PRISMA.COM - revista de Ciências da Informação e da Comunicação do CETAC, Universidade do Porto
          * 2004, Televisão Digital e Interactiva: o desafio de adequar a oferta às preferências dos utilizadores, Observatório Nº 10 - Televisão interactiva: avanços e impactos
          * 2004, Interactive Television Usage and Applications: the Portuguese Case-study, Computers & Graphics - Special Issue on "Video Technology and Interactive Broadcasting
          * 2003, “It came from outer space”: jogos de computador invadem programação e serviços de televisão digital, Caleidoscópio : Revista de Comunicação e Cultura

        Tese / Dissertação

          * 2008-09, Doutoramento, “Audiências dos 12 aos 18 anos no contexto da convergência dos media: emergência de uma cultura participativa?”
          * 2000-12, Mestrado, “Interactive Television: a new media industry in Portugal?”

        Capítulo de livro

          * 2022, Portuguese Sea Museums and the Communication of Maritime Heritage in the 21st Century, Maritime Spaces and Society , A. Kolodzi, Brill
          * 2021, O uso dos webdocumentários em 360º como ferramenta geradora de empatia no jornalismo, Audiovisual e Indústrias Criativas, II, McGraw-Hill Interamericana de Espana S.L
          * 2020, Nazaré Criativa: how can creative tourism initiatives contribute towards sustainable tourism?, Creative Tourism Dynamics: connecting travellers, communities, cultures and places, Grácio Editor
          * 2020, Migrant Stories: producing Participatory Videos to Promote Global Citizenship Education Among Students from Basic School to University Level, Comunicación Especializada: História Y Realidad Actual, McGraw-Hill Interamericana de Espana S.L
          * 2020, Media Imersivos e Paisagens Marítimas: representações da Nazaré desde as fotografias estereoscópicas de inícios do século XX aos vídeos 360º de inícios do século XXI., MuSEAum
          * 2020, A Nazaré é mais do que apenas “grandes ondas”: redescobrir e reinventar o património cultural através de workshops criativos., Creatour: catalizando o turismo criativo em cidades de pequena dimensão e em áreas rurais, Coimbra University Press
          * 2015, Transmedia Storytelling Meets Tourism: The TravelPlot Porto Case Study, Now Ever Absent, Inter-Disciplinary Press
          * 2014, Porto As a Tourism Destination, CEPESE / Formalpress
          * 2012, Digital terrestrial TV switchover process in Portugal: viewers between a rock and a hard place, Digital Communication Policies in the Information Society Promotion Stage, Universidade do Minho
          * 2009, Audience participation in television and internet: attitudes and practices of young people in Portugal, Social Interactive Television: Immersive Shared Experiences and Perspectives, IGI Global
          * 2006, Serviço de TV Digital ‘MTV Europe Music Awards Lisboa 2005”: o primeiro evento musical com transmissão de 4 sub-canais de conteúdos extra em Portugal, Novos Media: Produção, Desenvolvimento, Distribuição, Edições Universitárias Lusófonas
          * 2005, Acessibilidade e Televisão Digital e Interactiva: o caso particular do serviço de Áudio-Descrição destinado a pessoas invisuais ou com deficiências visuais graves, Estratégias de 8 Produção em Novos Media, Edições Universitárias Lusófonas
          * 2004, Cross-Media em emergência em Portugal: o encontro entre a Televisão Digital Interactiva, as Comunicações Móveis e a Internet, Televisão Interactiva: Conteúdos, Aplicações e Desafios, Edições Universitárias Lusófonas

        Edição de livro

          * 2022
          * 2015, Casas do Quico/ Quico Turismo Lda

        Artigo em jornal

          * 2022-10-12, Nazaré: ir além das ondas gigantes..., Jornal Sol

        Relatório

          * 2020, Global Citizenship and Multimedia: Guidelines for teachers and educators. MigratED. MigratED project. , https://issuu.com/4-change/docs/me_guidelines_en_def
          * 2019, Web Documentary - an interactive internet guidance for supporting the development of costeffective ocean-focused awareness raising strategies. Work Package 7 Deliverable 7.3 - ResponSEAble project.
          * 2018, In_Nova MusEUm “Introduction to Audience Development, https://issuu.com/innovamuseum/docs/innovamuseum_peripheralmuseumsaudie
          * 2018, Audience Development in Practice - Portugal In Ibranhimi, A.; Ranchi, A & Torres, N.C. (2018) In-Nova MusEUm "Peripheral Museums and the Art-Food Alliance, https://issuu.com/innovamuseum/docs/in_nova_museum____introduction_to_a
          * 2014, IDTV Health: Final Progress Report
          * 2011, ADOPT-DTV: Relatório Final, https://pt.slideshare.net/cquico/adopt-dtv-relatoriofinalout2011
          * 2011, ADOPT-DTV: Inquérito Quantitativo, https://pt.slideshare.net/cquico/adopt-dtv-inqueritoquantitativoout2011
          * 2011, ADOPT-DTV: Estudo Etnográfico, https://pt.slideshare.net/cquico/adopt-dtv-estudoetnograficoout2011
          * 2011, ADOPT-DTV: Entrevistas com Stakeholders, https://pt.slideshare.net/cquico/adopt-dtv-estudoetnograficoout2011
          * 2003, Televisão Interactiva: o estado da arte em 2002 e linhas de evolução”. relatório para projecto de investigação “Validação e Desenvolvimento de um modelo de programas educativo baseado em Televisão Interactiva"

        Website

          * 2021, LusofonAtiva, - gestão de projecto, especificações, actualização de conteúdos - webdesign: Valter Arrais, https://lusofonativa.ulusofona.pt
          * 2020, Nazaré Imersiva, , http://nazareimersiva.ulusofona.pt/
          * 2020, CIIA 2021 - congress website, - specifications, project management, content production in Portuguese and English, content updating - webdesign: Valter Arrais
          * 2019-06, (Re)Think: "Critical Thinking Tools", Website for campaing "Critical Thinking Tools", from (Re)Think project., http://criticalthinking.rethinkproject.eu
          * 2018-05, Lagoa Vai ao Mar - vídeo 360º e website, Guião e pesquisa para vídeo imersivo 360º sobre a abertura anual ao mar da Lagoa de Santo André, na Costa Alentejana, bem como coordenação e produção de conteúdos para website de suporte ao vídeo. Janeiro 2017 – Maio 2018. , http://lagoavaiaomar.ulusofona.pt
          * 2017, In_NovaMusEUm, Website for In_NovaMusEUm project., http://www.innovamuseum.eu
          * 2016-06, “Cavalgar a Onda da Nazaré” - web documentário (versão interactiva), Realização e produção de projecto-piloto de web documentário interactivo sobre a Praia do Norte da Nazaré e os impactos económicos, sociais e ambientais da notoriedade global que atingiu na sequência da obtenção do record mundial da maior onda surfada, por Garrett McNamara. Novembro 2015 - Junho 2016 , http://cavalgaraondanazare.ulusofona.pt/
          * 2008, “Nazaré – Vista à Lupa”, Blog pessoal sobre a região da Nazaré, com o objectivo de partilhar informação curiosa e pouco conhecida sobre esta região Portuguesa. De 2008 a 2013., http://nazare-portugal.blogspot.com

        Artigo em conferência

          * Participatory Culture and Media Usage: exploring Participatory Media potential as a platform for Young People Civic Engagement, EuroITV 2007
          * 2021-07, NAZARÉ IMMERSIVE/ NAZARÉ IMERSIVA: IMMERSIVE MEDIA AS A TOOL TO ENGAGE YOUNG PEOPLE IN CRITICAL THINKING
          * 2021-07, CHALLENGING UNDERGRADUATE STUDENTS TO DISCONNECT FROM DIGITAL MEDIA: MAIN FINDINGS FROM AUTO-ETHNOGRAPHIES PRODUCED DURING THE COVID-19 PANDEMIC IN PORTUGAL
          * 2014-04-11, Seniores e Comunicação em Saúde: avaliação de conteúdos audiovisuais lineares e aplicações interactivas sobre saúde e bem-estar, LUSOCOM 2014
          * 2013-07, Using digital interactive television to promote healthcare and wellness inclusive services, 15th Int. Conf. Human-Computer Interaction
          * 2012-09-27, The potential of digital interactive television in the provision of healthcare and wellness services, IAMCR 2012: South-North Conversations
          * 2012-09-27, The potential of digital interactive television for the provision of healthcare and wellness services, IAMCR 2012
          * 2012-09-27, O potencial da televisão do futuro para a prestação de serviços de saúde e bem-estar, Lusocom 2012
          * 2012-09, Serviços inclusivos de promoção da saúde e bem-estar via televisão digital: reportagem e debate interativos sobre Diabetes, Celia Quico
          * 2012-07-17, Knowledge, attitudes and expectations of 30 Portuguese families in the context of the switchover from analogue terrestrial television to digital terrestrial television, IAMCR 2012: South-North Conversations
          * 2012-07, Digital TV adopters and non-adopters in the context of the analogue terrestrial TV switchover in Portugal, EuroiTV'12
          * 2012, Incentives and Barriers to the Adoption of Digital Terrestrial Television in Portugal: Perspectives of the stakeholders involved in the transition process, ICA 2012
          * 2011-07-13, Profiles of digital TV adopters in the switchover context in Portugal, IAMCR 2011. Kadir Has University
          * 2011-06-29, Drivers and barriers to the adoption of the digital television in Portugal: The perspectives of the TV viewers and other main stakeholders, EuroiTV 2011
          * 2011, Drivers and barriers to digital television adoption in Portugal: the perspectives of the TV viewers and other main stakeholders
          * 2010, Understanding Barriers to Digital Television Adoption in the Context of the Digital Switchover in Portugal, IAMCR 2010
          * 2009, Conteúdos criados pelos utilizadores: atitudes e práticas dos jovens portugueses dos 12 aos 18 anos, SOPCOM 2009
          * 2008-11, Seniors and the uses of media and ICT: exploring social iTV and social media sites potential to improve sociability and participation, uxTV 2008 - First International Conference on Designing Interactive User Experiences for TV and Video
          * 2007, O desafio da Literacia dos Novos Media em Portugal: o contributo da iniciativa PT Escolas II, SOPCOM 2007
          * 2005-03-30, User Centred Design methodologies applied to the development of an Electronic Programming Guide: the partnership experience of PT Multimédia and Universidade Lusófona, European Conference on Interactive Television: User Centred ITV Systems, Programmes and Applications
          * 2004-04-21, Televisão Digital e Interactiva: o desafio de adequar a oferta às necessidades e preferências dos utilizadores, SOPCOM 2004
          * 2004-03-31, T-Learning and Interactive Television Edutainment: the Portuguese Case Study, European Conference on Interactive Television: Enhancing the Experience
          * 2004, Televisão Digital e Interactiva: a modelação social como variável na avaliação de usabilidade, IHC2004 - Simpósio “Fatores Humanos em Sistemas Computacionais
          * 2003-04-02, Are Communication Services the Killer Applications for Interactive TV?, European Conference on Interactive Television: from Viewers to Actors?

        Resumo em conferência

          * 2023-02, Immersive media and ocean literacy: exploring the potential of virtual reality as a tool to understand and improve our connection to the seas, INN 2023 – I International Conference on Media Innovation,
          * 2022-11, To be or not to be active: taking arms against sedentarism with the co-created communication campaign LusofonAtiva, ELIA Biennial Conference 2022 - No Stone Unturned
          * 2022-10, LusófonAtiva: lessons learned from a co-created communication campaign to promote active and healthy lifestyles among university students, faculty and staff, ECREA, 9th European Communication Research Conference,
          * 2022-10, LusófonAtiva: lessons learned from a co-created communication campaign to promote active and healthy lifestyles among university students, faculty and staff, ECREA 2022
          * 2022-07, To be or not to be active”: first findings from the communication campaign LusófonAtiva to promote active and healthy lifestyles among university students, faculty and staff, IAMCR 2022
          * 2022-07, To be or not to be active: first findings from the communication campaign LusófonAtiva to promote active and healthy lifestyles among university students, faculty and staff, IAMCR 2022 Conference
          * 2022-05, Memórias imersivas da Nazaré: mergulhar no passado com as fotos estereoscópicas de Álvaro Laborinho de inícios do século XX, 11ª Conferência Internacional de Viana de Castelo
          * 2022-04, Nazaré Imersiva: especular sobre o futuro com os media imersivos, SOPCOM 2022
          * 2022-04, Nazaré Imersiva: exploring old and new immersive media to create a sense of presence in Portuguese seascapes, Ecstatic Truth VI
          * 2021-07, Challenging undergraduate students to disconnect from digital media: main findings from auto-ethnographies produced during the Covid-19 pandemic in Portugal., EDULearn 2021
          * 2019-11-15, Nazaré, Zona de Turismo e Praia de Pescadores”: filmes turísticos e turistificação de uma comunidade piscatória Portuguesa, SOPCOM 2019, Universidade da Madeira
          * 2019-10, "Nazaré Criativa": how creative tourism initiatives can contribute towards sustainable tourism?, CREATOUR 2019
          * 2019, Para além das “fake news”: investigação, desenvolvimento e avaliação de ferramentas de pensamento crítico para lidar com a desordem informativa. , SOPCOM 2019, Universidade da Madeira
          * 2019, Critical Thinking Tools: researching, developing and evaluating a communication campaign about Information Disorder, MILT 2019
          * 2018-07, Portugal's unique waves captured creatively: the immersive video "The Lagoon Goes to the Sea" and web documentary "Riding the Nazaré Wave", TOCRIA 2018, FCSH-UNL
          * 2018-07, Art & food creative events for peripheral museums audience development: the overall strategy and main results from In-Nova MusEUm project in Portugal, TOCRIA 2018, FCSH-UNL
          * 2018-07, A Lagoa Vai ao Mar"/ "The Lagoon Goes to the Sea": a multi-disciplinary approach to the production of a 360º video”, Stereo Media and Immersive Media 2018, ULHT
          * 2018-06, Participatory Art & Food events in European peripheral museums: main lessons from the In-Nova MusEUm project, CREATOUR 2018, Universidade do Minho
          * 2016-12, Communicating the issues and challenges of “sustainable fisheries” across Europe: trends and issues, CommOcean 2016 conference
          * 2014-11-12, Using Storytelling And Interactive Applications For Health Communication: Seniors' Evaluation Of Linear TV Content And Interactive TV And Mobile Applications., ECREA 2014
          * 2014-11-12, Seniors' Evaluation Of Digital Interactive TV Health Applications: How Does Health Literacy Influence Their Overall Satisfaction, ECREA 2014

        Prefácio / Posfácio

          * 2011, EuroITV'11 - Proceedings of the 9th European Interactive TV Conference
          * 2010, EuroITV'10 - Proceedings of the 8th International Interactive TV and Video Conference

        Guião

          * 2020, Nazaré Imersiva
          * 2019, Critical Thinking Tools: What is Fake News?
          * 2019, Critical Thinking Tools: How to manufacture and spread Fake News?
          * 2019, Critical Thinking Tools: How to manipulate people with Propaganda?
          * 2019, Critical Thinking Tools: How to detect and debunk Fake News?
          * 2018, A Lagoa Vai ao Mar
          * 2016, Cavalgar a Onda da Nazaré - web documentário

        Gravação vídeo

          * 2020, “Nazaré Imersiva", Célia Quico, https://nazareimersiva.ulusofona.pt
          * 2019-06, Critical Thinking Tools: “How to manufacture and spread Fake News?”, Célia Quico, Universidade Lusófona de Humanidades e Tecnologias.
          * 2019-06, Critical Thinking Tools: “How to manipulate people with Propaganda?", Célia Quico
          * 2019-06, Critical Thinking Tools: “How to detect and debunk Fake News?”, Célia Quico, Universidade Lusófona de Humanidades e Tecnologias.
          * 2019-06, Critical Thinking Tools: "What is Fake News?", Célia Quico, Universidade Lusófona de Humanidades e Tecnologias
          * 2017, “Daqui é Pró Cemitério - a Propósito dos 75 Anos do Bairro dos Pescadores da Nazaré” , Câmara Municipal da Nazaré, Museu Dr. Joaquim Manso, Mútua dos Pescadores, Casas do Quico/ Quico Turismo Lda
          * 2016-06, “Cavalgar a Onda da Nazaré” - web documentário (versão linear), Célia Quico, Universidade Lusófona de Humanidades e Tecnologias

        Arte visual

          * “Senses: penetrations of flesh and silicone” – ensaio sobre o corpo e as novas tecnologias (CD-Rom) 1998

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona