# Response for https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
          PT: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904 EN: https://www.ulusofona.pt/en/teachers/diogo-soares-pereira-gil-morais-1904
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
        fechar menu : https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/diogo-soares-pereira-gil-morais-1904
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Diogo Soares Pereira Gil Morais

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p1904
              dio***@ulusofona.pt
              4C1D-CDD1-F221: https://www.cienciavitae.pt/4C1D-CDD1-F221
              0000-0002-7482-1448: https://orcid.org/0000-0002-7482-1448
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/d8cdb481-8081-46a2-afd7-2eedb8f4ece9
      : https://www.ulusofona.pt/

        Resume

        Diogo Morais. Completed the Mestrado in Comunicação nas Organizações in 2009 by Universidade Lusófona de Humanidades e Tecnologias, Mestrado in Comunicação nas Organizações in 2009/01/18 by Universidade Lusófona de Humanidades e Tecnologias, Licenciatura in Psicologia in 2004/07/05 by Universidade Lusófona de Humanidades e Tecnologias and Licenciatura in Psicologia - especialização em Organizações e trabalho in 2004 by Universidade Lusófona de Humanidades e Tecnologias. Attends the Doutoramento in Ciências da Comunicação by Universidade Lusófona de Humanidades e Tecnologias since 2023/09. Is Assistant in Universidade Lusófona de Humanidades e Tecnologias Escola de Psicologia e Ciências da Vida, Assistant in Universidade Lusófona de Humanidades e Tecnologias, Assistant in Universidade Lusófona de Humanidades e Tecnologias, Researcher in Universidade Lusófona de Humanidades e Tecnologias Centro de Investigação em Comunicação Aplicada Cultura e Novas Tecnologias, Investigador in Universidade Lusófona de Humanidades e Tecnologias, Research Scientist II (Medical Writer) in CTI Clinical Trial and Consulting Services Lisbon, Researcher in Universidade Lusófona de Humanidades e Tecnologias, Professor do ensino básico e secundário in Escola Técnica Psicossocial de Lisboa (ETPL) and Researcher in Associação Ares do Pinhal (ONG). Published 58 articles in journals. Has 10 section(s) of books and 3 book(s). Organized 1 event(s). Supervised 5 work(s) of course completion of LSc/BSc. Participates and/or participated as Researcher in 3 project(s). Works in the area(s) of Social Sciences with emphasis on Political Sciences, Social Sciences with emphasis on Media and Communications and Social Sciences with emphasis on Psychology. In their professional activities interacted with 193 collaborator(s) co-authorship of scientific papers. In his curriculum Ciência Vitae the most frequent terms in the context of scientific, technological and artistic-cultural output are: Immersion; Cybersickness; Acute Stress Disorder; attention; sobrevivência; Memória de Reconhecimento; Motor Vehicle Accidents; War; Novas Tecnologias; Eye tracking; Serious Games; Emoção; VR; adaptação; Anxiety; Internet; emotional cues; brain injury; Especialização Hemisférica; Audiências; Uso dos media; Website pages; memory training; PTSD; Presence; agressão; a; Virtual Reality; Head-mounted Display (HMD); Translucid Screen; advertising; Cybertherapy; agressividad; CIÊNCIA POLÍTICA; POLITICAL SCIENCE; ELEIÇÕES; ELECTIONS; AUTARQUIAS; LOCAL GOVERNMENT; MORAIS, ISALTINO; INOVAR; IOMAF; ÉTICA; ETHICS; PORTUGAL; OEIRAS; PARTIDOS POLÍTICOS; POLITICAL PARTIES; ESTRATÉGIA; STRATEGY; SINTRA; HORTA, BASÍLIO; SINTRENSES COM MARCO ALMEIDA; movimentos oculares; atenção; memória; capacidades cognitivas; realidade virtual; Systemic Lisbon Battery; Adolescents; Internet addiction; Internet use; ATENÇÃO; INTERNET; PUBLICIDADE; ATTENTION; PUBLICITY; NEUROCIÊNCIAS; PROCESSAMENTO DE INFORMAÇÃO; MEMÓRIA; EYE TRACKING; ESTÍMULOS EMOCIONAIS; MEDO; EMOTIONAL STIMULI; .

        Graus

            * Licenciatura
              Psicologia - especialização em Organizações e trabalho
            * Pós-Graduação
              Comunicação nas Organizações
            * Curso médio
              Curso de especialização em entrevista de selecção
            * Mestrado
              Comunicação nas Organizações
            * Curso médio
              Statistics One
            * Curso médio
              Gamification
            * Curso médio
              Video Games and Learning
            * Curso médio
              Foundations of Virtual Instruction
            * Curso médio
              Writing in the Sciences
            * Curso médio
              Blended Learning: Personalizing Education for Students
            * Curso médio
              Model Thinking
            * Curso médio
              Securing Digital Democracy
            * Licenciatura
              Psicologia
            * Mestrado
              Comunicação nas Organizações
            * Outros
              COVID-19 Training for Healthcare Workers
            * Outros
              COVID-19 Contact Tracing
            * Outros
              COVID-19: What You Need to Know
            * Outros
              Customer Analytics
            * Outros
              Español para extranjeros A2
            * Doutoramento
              Ciências da Comunicação

        Publicações

        Journal article

          * 2020-08-19, Adaptive Non-Immersive VR Environment for Eliciting Fear of Cockroaches: A Physiology-Driven Approach Combined with 3D-TV Exposure, International Journal of Psychological Research
          * 2019, Cognitive Stimulation of Elderly Individuals with Instrumental Virtual Reality-Based Activities of Daily Life: Pre-Post Treatment Study, Cyberpsychology, Behavior, and Social Networking
          * 2018-11-02, Performance on naturalistic virtual reality tasks depends on global cognitive functioning as assessed via traditional neurocognitive tests, Applied Neuropsychology: Adult
          * 2017, The art gallery test: A preliminary comparison between traditional neuropsychological and ecological VR-based tests, Frontiers in Psychology
          * 2017, Eye movement analysis and cognitive assessment: The use of comparative visual search tasks in a non-immersive vr application, Methods of Information in Medicine
          * 2017, Eye Movement Analysis and Cognitive Assessment, Methods of Information in Medicine
          * 2017, Cognitive training through mhealth for individuals with substance use disorder, Methods of Information in Medicine
          * 2016-05-04, Systemic Lisbon Battery: Normative Data for Memory and Attention Assessments, JMIR Rehabilitation and Assistive Technologies
          * 2016-05, Frequency is not enough: Patterns of use associated with risk of Internet addiction in Portuguese adolescents, Computers in Human Behavior
          * 2016, Uso de eye tracking em realidade virtual não imersiva para avaliação cognitiva
          * 2016, The Immersive Virtual Reality Experience: A Typology of Users Revealed Through Multiple Correspondence Analysis Combined with Cluster Analysis Technique, Cyberpsychology, Behavior, and Social Networking
          * 2016, Evaluation of cognitive functions through the systemic lisbon battery: Normative data, Methods of Information in Medicine
          * 2016, Cognitive stimulation through mhealth-based program for patients with alcohol dependence syndrome: A randomized controlled study, Journal of Pain Management
          * 2015-03-05, Cognitive training on stroke patients via virtual reality-based serious games, Disabil Rehabil
          * 2015, Virtual Kitchen Test. Assessing frontal lobe functions in patients with alcohol dependence syndrome., Methods of Information in Medicine
          * 2014-08-08, Evaluation of the effectiveness of the implementation of the A PAR parental intervention programme in Portugal. Child development and parenting support, European Early Childhood Education Research Journal
          * 2014-01-01, Virtual exercises to promote cognitive recovery in stroke patients: the comparison between head mounted displays versus screen exposure methods, International Journal on Disability and Human Development
          * 2014, Executive Functioning in Alcoholics Following an mHealth Cognitive Stimulation Program: Randomized Controlled Trial, Journal of Medical and Internet Research
          * 2014, Executive Functioning in Alcoholics Following an mHealth Cognitive Stimulation Program: Randomized Controlled Trial, J Med Internet Res
          * 2014, Eliciting nicotine craving with virtual smoking cues. , Cyberpsychol Behav Soc Netw
          * 2014, Effects of fear-relevant stimuli on attention: integrating gaze data with subliminal exposure, Medical Measurements and Applications (MeMeA), 2014 IEEE International Symposium on
          * 2014, Comparison of interpretation of cat's behavioral needs between veterinarians, veterinary nurses, and cat owners, Journal of Veterinary Behavior: Clinical Applications and Research
          * 2014, Cognitive training on stroke patients via virtual reality-based serious games, Disabilities and Rehabilitation
          * 2014, Cognitive assessment of stroke patients with mobile apps: a controlled study. , Studies in Health Technology and Informatics
          * 2014, Cognitive assessment of stroke patients with mobile apps: a controlled study.
          * 2014, Cognitive assessment of stroke patients with mobile apps: A controlled study, Annual Review of CyberTherapy and Telemedicine
          * 2013-00, Assessment of frontal brain functions in alcoholics following a health mobile cognitive stimulation approach.
          * 2013, Executive functioning in addicts following health mobile cognitive stimulation Evidence from alcohol and heroin patients, Proceedings of the 2013 7th International Conference on Pervasive Computing Technologies for Healthcare and Workshops, PervasiveHealth 2013
          * 2013, Assessment of frontal brain functions in alcoholics following a health mobile cognitive stimulation approach., Stud Health Technol Inform
          * 2013, Assessment of frontal brain functions in alcoholics following A health mobile cognitive stimulation approach, Annual Review of CyberTherapy and Telemedicine
          * 2012, Nicotine craving: ERPs correlates after VR exposure to smoking cues. Studies in Health Technology and Informatics, Studies in Health Technology and Informatics
          * 2012, Nicotine Craving: ERPs correlates after VR exposure to s moking cues, Annual Review of CyberTherapy and Telemedicine
          * 2011, Virtual reality exposure on nicotine craving., Studies in health technology and informatics
          * 2011, Virtual reality exposure on nicotine craving, Annual Review of CyberTherapy and Telemedicine
          * 2011, Virtual reality exposure on nicotine craving, Annual Review of CyberTherapy and Telemedicine
          * 2011, Traumatic Brain Injury memory training: a Virtual Reality online solution. Journal on Disability and Human Development, Journal on Disability and Human Development
          * 2011, The contribution of a VR-based programme in cognitive rehabilitation following stroke, 2011 International Conference on Virtual Rehabilitation, ICVR 2011
          * 2011, Hemispheric asymmetries in recognition memory for negative and neutral words, Journal of Eyetracking Visual Cognition and Emotion
          * 2011, Attentional orienting to biologically fear-relevant stimuli: data from eye tracking using the continual alternation flicker paradigm, Journal of Eyetracking Visual Cognition and Emotion.
          * 2011, Grabbing attention while reading website pages: the influence of verbal emotional cues in advertising, Journal of Eye Tracking, Visual Cognition and Emotion
          * 2010, Training presence: the importance of virtual reality experience on the “sense of being there, Stud Health Technol Inform.
          * 2010, Training presence: The importance of virtual reality experience on the "sense of being there", Annual Review of CyberTherapy and Telemedicine
          * 2010, PTSD elderly war veterans: A clinical controlled pilot study, Cyberpsychology, Behavior, and Social Networking
          * 2010, Agrido, logo existo: para além do carácter não-adaptativo da agressão., In-Mind Portugues
          * 2009, Virtual reality therapy controlled study for war veterans with PTSD. Preliminary results, Annual Review of Cybertherapy and Telemedicine 2009 – Advanced Technologies in the Behavioral, Social and Neurosciences.
          * 2009, Virtual reality therapy contolled study for war veterans with PTSD. preliminary results, Annual Review of CyberTherapy and Telemedicine
          * 2009, Presence in Virtual Reality Scenarios: the importance of viewpoint and of linear or non-linear narrative, VRIC’09 –Laval Virtual – Book of Proceedings of the 11th Virtual Reality International Conference
          * 2009, PTSD Elderly War Veterans: A Clinical Controlled Pilot Study, CyberPsychology & Behavior
          * 2008, Presence, immersion and cybersickness assessment through a test anxiety virtual environment, Annual Review of Cybertherapy and Telemedicine
          * 2008, Physiological assessment during VR PTSD treatment of a motor vehicle accident patient, Journal of Cyber Therapy and Rehabilitation
          * 2008, Physiological Assessment of Motor Vehicle Accident Posttraunatic Stress Disorder patient during Virtual Reality Exposure – A Clinical Case Study, Annual Review of Cybertherapy and Telemedicine
          * 2007, War PTSD: a VR pre-trial case study, Annual Review of Cybertherapy and Telemedicine
          * 2007, VR exposure: reducing acute stress disorder derived from motor vehicle accidents, Annual Review of Cybertherapy and Telemedicine
          * 2007, The use of VR exposure in the treatment of motor vehicle PTSD: A case-report. , Annual Review of Cybertherapy and Telemedicine
          * 2006, Presence in a Virtual War Scenario – a Posttraumatic Stress Disorder exploratory case study, Proceedings of the 8th Virtual Reality International Conference

        Book

          * 2015, Assessing cognitive functions with VR-based serious games that reproduce daily life: Pilot testing for normative values, Gamito, P.; Oliveira, J.; Brito, R.; Lopes, P.; Morais, D.; Pinto, L.; Rodelo, L.; Gameiro, F.; Rosa, B.
          * 2014, Cognitive assessment of stroke patients with mobile apps: A controlled study, Oliveira, J.; Gamito, P.; Morais, D.; Brito, R.; Lopes, P.; Norberto, L.
          * 2013, Assessment of frontal brain functions in alcoholics following a health mobile cognitive stimulation approach, Gamito, P.; Oliveira, J.; Lopes, P.; Morais, D.; Brito, R.; Saraiva, T.; Bastos, M.; et al

        Book chapter

          * 2014, Virtual exercises to promote cognitive recovery in stroke patients, Virtual reality: Rehabilitation in motor, cognitive and sensorial disorders, Nova Science
          * 2014, Eye of the beholder: Voting on a face: the importance of appearance-based trait inferences in a political candidate evaluation - an eye tracking approach., I see me, you see me: inferring cognitive and emotional processes from gazing behavior , Cambridge Scholars Publishing.
          * 2014, A pupillometric approach to the study of the strength of memory signal following intra- and interhemispheric word recognition. , I see you, you see me: Inferring cognitive and emotional processes from gazing behaviour, Cambridge Scholars Publishing
          * 2013, Do ábaco aos átomos, Nascidos Digitais: Novas Linguagens, Lazer e Dependências, Coisas de Ler
          * 2011, Serious Games for Serious Problems: from Ludicus to Therapeuticus, Virtual Reality, 0, 0, InTech, Publishing
          * 2011, PSPT e Veteranos da Guerra do Ultramar: um Estudo Cliníco Controlado, Estudos de Intervenção Psicológica em Situações de Emergência, Crise e Catástrofe , ISMAT
          * 2011, O homo emocionalis e a tomada de decisão: a irracionalidade da escolha, Neuromarketing e a tomada decisão, Psicosoma
          * 2011, NeuAR ¿ a look into AR applications in the neurosciences area, Augmented Reality, INTECH
          * 2011, Estudos de Intervenção Psicológica em Situações de Emergência, Crise e Catástrofe , PSPT e Veteranos da Guerra do Ultramar: um Estudo Cliníco Controlado, ISMAT
          * 2009, Virtual reality therapy controlled study for war veterans with PTSD., Annual Review of Cybertherapy and Telemedicine 2009 – Advanced Technologies in the Behavioral, Social and Neurosciences., IOS Press

        Conference paper

          * Social Capital and Internet Use: Portuguese Social Capital Scale, Cost Action Meeting ISO906. Transforming Audiences, transforming societies. Lisbon, November 11-13
          * Presentation of the portuguese version of two different scales: Pleasure in Parenting Scale - PPS (Escala de Gratificação Parental, EGP) and Parent-Child Joint Activity Scale - PJAS (Escala de Actividades de Interacção Pais-Filhos, EAIP/F), XIIIème Congrès International de l’Association Internationale de Formation et de Recherche en Education Familiale (AIFREF)
          * Normative data for a cognitive VR rehab serious games-based approach, 8th International Conference on Pervasive Computing Technologies for Healthcare
          * Grabbing attention while reading website pages: the influence of verbal emotional cues in advertising, EMAC 4oth Conference
          * Executive functioning in addicts following health mobile cognitive stimulation Evidence from alcohol and heroin patients, PervasiveHealth
          * 2016, The effect of virtual reality-based serious games in cognitive interventions: A meta-analysis study
          * 2016, Ecologically-oriented approach for cognitive assessment in the elderly
          * 2016, Computer-assisted assessment of cognitive functioning in the elderly through the Systemic Lisbon Battery
          * 2015, Show me your eyes! the combined use of eye tracking and virtual reality applications for cognitive assessment
          * 2015, Computer-assisted therapy: Cognitive training of heroin abusers
          * 2015, Cognitive stimulation of alcoholics through VR-based Instrumental Activities of Daily Living
          * 2014, Cognitive assessment of stroke patients with mobile Apps: A controlled study
          * 2013, Executive functioning in addicts following health mobile cognitive stimulation Evidence from alcohol and heroin patients
          * 2012, Nicotine craving: ERPs correlates after VR exposure to smoking cues
          * 2011, The contribution of a VR-based programme in cognitive rehabilitation following stroke
          * 2010, Training presence: The importance of virtual reality experience on the "sense of being there"
          * 2009, Virtual reality therapy controlled study for war veterans with PTSD. Preliminary results

        Conference abstract

          * 2013, Loosing Snoopy: Grieving processes after the loss of a pet, 9th International Veterinary Behaviour Meeting/19th Meeting of the European Society of Veterinary Clinical Ethology/3rd Annual Meeting of the European College of Animal Welfare and Behavioural Medicine/3rd Annual Meeting of the Portugue
          * 2009, Virtual Reality Therapy Controlled Study for War Veterans with PTSD: Preliminary Results, Proc. 7th ICDVRAT with ArtAbilitation

        Conference poster

          * 2011, PTSD old war veterans: a clinical controlled pilot study , VI Encontro Nacional da Associação Portuguesa de Psicologia Experimental

        Dataset

          * Presence: Head Mounted Display vs. Translucid Screen, (695432011-062)
          * Brief Internet Addiction Questionnaire

        Other output

          * 2017, Os movimentos autárquicos não-partidários: o caso de Oeiras, Oeiras representa um laboratório para o estudo do sistema político português no que concerne ao sistema de partidos e à qualidade da representação. Este ensaio traça a evolução política do município. Para tal, estuda as relações dos partidos políticos e dos movimentos não-partidários com os eleitores do conce-lho e mostra a importância da figura do líder e da obra feita em detrimento de valores ét
          * 2017, Os movimentos autárquicos não-partidários nas eleições autárquicas no concelho de Sintra, Desde as primeiras eleições autárquicas, Sintra tem sido sempre governada por partidos. No entanto, a impossibilidade de recandidatura de um Presidente, devido à lei de limitações de mandatos, originou uma cisão no bloco dominante e o surgimento de um movimento independente que, desde então, tem constituído a segunda força eleitoral no concelho. Este texto apresenta a cronologia dos vários atos el
          * 2017, Neuropsychological Predictors of Alcohol Abtinence Following a Detoxification Program
          * 2017, Assessment of Attentional and Mnesic Processes Through Gaze Tracking Analysis: Inferences from Comparative Search Tasks Embedded in VR Serious Games
          * 2016, Frequency is not enough : Patterns of use associated with risk of Internet addiction in portuguese adolescents, This paper reports an exploratory analysis of the relation between Internet addiction and patterns of use among Portuguese adolescents (n ¼ 2617) from the WHO 2010 Health Behavior in School-aged children study, with a short version of Young's Internet Addiction Test (the brief Internet Addiction Questionnaire e bIAQ) and self-reports on online behaviors and access. Two-Step Cluster analysis identi
          * 2015-01, 15. Active Confluence: A Proposal to Integrate Social and Health Support with Technological Tools
          * 2011, NeuAR – A Review of the VR/AR Applications in the Neuroscience Domain, Augmented Reality - Some Emerging Application Areas
          * 2011, Attentional orienting to biologically fear-relevant stimuli: data from eye tracking, Snakes are thought as fear-relevant stimuli (biologically prepared to be associated with fear) which can lead to an enhanced attentional capture when compared fear-irrelevant stimuli. Inherent limitations related to the key-press behaviour might be bypassed with the measurement of eye movements, since they are more closely related to attentional processes than reaction times. An eye tracking techn

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona