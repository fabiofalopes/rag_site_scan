# Response for https://www.ulusofona.pt/acao-social-escolar/apoios-diretos

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
          PT: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos EN: https://www.ulusofona.pt/en/acao-social-escolar/direct-support
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
        fechar menu : https://www.ulusofona.pt/acao-social-escolar/apoios-diretos

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes
          SAS - Serviço de Ação Social
        https://www.ulusofona.pt/images/apoios-diretos-acao-social_600.jpg

            Bolsas e Ação Social

          SAS - Serviço de Ação Social
        : https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
      ConteúdoNavegação

          Bolsas de Estudo

            * Bolsa da DGES - Direção-Geral de Ensino Superior: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos#b_dges
            * Bolsas de Mérito: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos#b_merito
            * Bolsas de Excelência: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos#b_excelencia
            * Bolsas de Doutoramento: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos#b_doutoramento
            * Bolsas para Estudantes dos Países CPLP: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos#b_cplp
            * Bolsas da União Europeia: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos#b_ue


          Bolsa da DGES - Direção-Geral de Ensino Superior

          Os estudantes da Universidade Lusófona têm a possibilidade de se candidatarem às bolsas de estudo da Direção-Geral do Ensino Superior (Ministério da Ciência, Tecnologia e Ensino Superior), bolsas que se destinam a apoiar estudantes economicamente carenciados.

          A análise das bolsas de estudo dos estudantes da UL são geridas pela própria Universidade, através do SAS, no cumprimento do estabelecido no Regulamento para Atribuição de Bolsas de Estudo a Estudantes do Ensino Superior (RABEEES) .

          As referidas bolsas de Estudo traduzem-se numa prestação pecuniária anual para comparticipação dos encargos com a frequência de curso de 1º e 2º ciclo de estudos, realização de um estágio profissional de caráter obrigatório e eventual complemento de bolsa para alojamento para estudantes deslocados.

          Para informações mais detalhadas poderá consultar o site da DGES: https://www.dges.gov.pt/pt/pagina/prazos-de-candidatura?plid=373 .

          Candidaturas às Bolsas da DGES

          A candidatura à Bolsa de Estudo é efetuada online, através da Plataforma BeOn.: https://www.dges.gov.pt/wwwBeOn/Files/GuiaCandidato.pdf

          Deverá requerer as credenciais de acesso (nome de utilizador e password) no Serviço de Ação Social, presencialmente ou através de:

            * Universidade Lusófona - Centro Universitário Lisboa - siga@ulusofona.pt: mailto:siga@ulusofona.pt
            * Universidade Lusófona - Centro Universitário Porto - sas@ulusofona.pt: mailto:sas@ulusofona.pt

          Saiba aqui: https://www.ulusofona.pt/faqs/estudantes/acao-social/quero-candidatar-me-a-uma-bolsa-da-dges-o-que-devo-fazer como.

          Recomenda-se antes de iniciar a candidatura, que leia com atenção:

            * Regulamento de Atribuição de Bolsas de Estudo a Estudantes do Ensino Superior: https://www.dges.gov.pt/pt/pagina/legislacao-bolsas-de-estudo
            * As instruções/informações de preenchimento, disponíveis no Guia Prático de Candidatura a Bolsa de Estudo: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
            * E nas Perguntas Frequentes: https://www.dges.gov.pt/pt/pagina/bolsas-de-estudo

          Bolsas de Estudo da DGES para Estudantes com Grau de Incapacidade Igual ou Superior a 60%

          Estudantes com grau de incapacidade igual ou superior a 60% têm a possibilidade de se candidatarem a uma bolsa de estudo independentemente da situação financeira do seu agregado familiar.

          A bolsa de estudo corresponde ao valor da propina efetivamente paga pelo estudante, até ao limite do valor máximo anual de 2.750 €.

          Condições de elegibilidade:

            * Estar matriculados e inscritos numa instituição de ensino superior em curso que confira grau;
            * Comprovar o grau de incapacidade através do atestado de incapacidade multiuso;
            * Ter a situação tributária e contributiva regularizada.

          Para mais informações, consulte a informação: https://www.dges.gov.pt/pt/pagina/bolsas-de-estudo-para-frequencia-de-estudantes-com-incapacidade?plid=373 disponível no site da DGES ou contacte-nos.

          A candidatura à Bolsa de Estudo é efetuada online, através da Portal da DGES. Efetue aqui: https://www.dges.gov.pt/wwwnee/ a sua candidatura.

          Gabinete de Apoio aos Estudantes com Necessidades Educativas Especiais - GAENEE

          Consulte aqui a informação sobre os apoios existentes no âmbito do Gabinete de Apoio aos Estudantes com Necessidades Educativas Especiais - GAENEE

          Bolsas de Mérito

          A Universidade Lusófona incentiva os seus estudantes a elevarem o nível de conhecimento e aproveitamento no ensino superior.

          Anualmente são atribuídas Bolsas de Mérito aos estudantes com a média mais alta relativa ao ano anterior.

          As bolsas são apuradas pelos serviços não sendo necessário submeter candidatura.

          Para mais informações consulte o Regulamento para Atribuição de Bolsas de Mérito - 2024/2025: https://www.ulusofona.pt/media/atribuicao-de-bolsas-de-merito-24-25.pdf


          Bolsas de Excelência

          A Universidade Lusófona cultiva a Excelência!

          Anualmente são atribuídas Bolsas de Excelência aos melhores estudantes que ingressem num curso conferente de grau.

          As bolsas são apuradas pelos serviços não sendo necessário submeter candidatura.

          Para mais informações consulte o Regulamento de Atribuição de Bolsas para Premiar a Excelência - 2024/2025: https://www.ulusofona.pt/media/atribuicao-de-bolsas-de-excelencia-24-25.pdf


          Bolsas de Doutoramento

          Quer realizar um Doutoramento?

          Veja abaixo o vídeo sobre os Programas de Bolsas de Doutoramento que a Universidade Lusófona oferece aos estudantes de excelência, nas várias áreas do conhecimento.

          O processo de candidatura ao Programa de Bolsas de Doutoramento da Universidade Lusófona é realizado no ato da candidatura ao respetivo programa de Doutoramento.

          Os candidatos ao programa de doutoramento devem no ato da candidatura ao mesmo escolherem a opção "Quero candidatar-me a uma Bolsa de Doutoramento".

          As candidaturas ao programa de Bolsas de Doutoramento não têm desta forma calendário próprio.

          São abrangidos pelo Programa de Bolsas de Estuda da Universidade Lusófona os seguintes Doutoramentos:

            * Doutoramento em Arquitetura: https://www.ulusofona.pt/lisboa/doutoramentos/arquitetura
            * Doutoramento em Arte dos Media e Comunicação: https://www.ulusofona.pt/lisboa/doutoramentos/arte-dos-media-e-comunicacao
            * Doutoramento em Ciências da Comunicação: https://www.ulusofona.pt/lisboa/doutoramentos/ciencias-da-comunicacao
            * Doutoramento em Comunicação e Ativismos: https://www.ulusofona.pt/porto/doutoramentos/comunicacao-e-ativismos
            * Doutoramento em Direito: https://www.ulusofona.pt/lisboa/doutoramentos/direito
            * Doutoramento em Educação: https://www.ulusofona.pt/lisboa/doutoramentos/educacao
            * Doutoramento em Educação Física e Desporto: https://www.ulusofona.pt/lisboa/doutoramentos/educacao-fisica-e-desporto
                + Normas Específicas Educação Física e Desporto 2022/2025 - Lisboa: https://www.ulusofona.pt/media/normas-especificas-educacao-fisica-e-desporto-20222025.pdf
                + Normas Específicas Educação Física e Desporto 2023/2026 - Lisboa: https://www.ulusofona.pt/media/normas-especificas-educacao-fisica-e-desporto-20232026.pdf
                + Normas Específicas Educação Física e Desporto 2024/2027 - Lisboa: https://www.ulusofona.pt/media/normas-especificas-educacao-fisica-e-desporto-20242027.pdf
                + Formulário de Candidatura - Bolsa de Doutoramento em Educação Física e Desporto: https://www.ulusofona.pt/media/educacao-fisica-e-desporto-formulario-candidatura.docx
            * Doutoramento em Informática: https://www.ulusofona.pt/lisboa/doutoramentos/informatica
            * Doutoramento em Sociomuseologia: https://www.ulusofona.pt/lisboa/doutoramentos/sociomuseologia
            * Doutoramento em Psicologia Clínica, Orientação Cognitivo-Comportamental: https://www.ulusofona.pt/lisboa/doutoramentos/psicologia-clinica-orientacao-cognitivo-comportamental
            * Doutoramento em Urbanismo: https://www.ulusofona.pt/lisboa/doutoramentos/urbanismo

          Emprego Científico e Bolsas de Investigação: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao

              * Programa de Bolsas de Doutoramento - Triénio 2024/2027 Lisboa e Porto

                Download (PDF) : https://www.ulusofona.pt/media/regulamento-do-programa-de-bolsas-de-doutoramento-20242027.pdf

              * Programa de Bolsas de Doutoramento - Triénio 2023/2026 Lisboa e Porto

                Download (PDF) : https://www.ulusofona.pt/media/bolsas-de-doutoramento-2326.pdf

              * Programa de Bolsas de Doutoramento - Triénio 2022/2025 Lisboa

                Download (PDF) : https://www.ulusofona.pt/media/programa-de-bolsas-de-doutoramento-da-ulht-trienio-20222025.pdf

              * Programa de Bolsas de Doutoramento - Triénio 2021/2024 Lisboa

                Download (PDF) : https://www.ulusofona.pt/media/programa-de-bolsas-de-apoio-trienio-20212024.pdf

              * Regulamento geral do Programa de Bolsas de Estudo para Doutoramento Lisboa

                Download (PDF) : https://www.ulusofona.pt/media/regulamento-do-programa-de-bolsas-de-estudo-para-doutoramento.pdf

              * Bolsa de Doutoramento - Centro de Intervenção e Investigação em Psicologia da Performance e Desporto Lisboa

                DownLoad (PDF) : https://www.ulusofona.pt/media/bolsa-de-doutoramento-ciippd.pdf


          Bolsas para Estudantes dos Países CPLP

          Os benefícios educacionais concedidos aos estudantes provenientes dos países da Comunidade de Língua Portuguesa integram o programa de apoio Institucional dedicado a formação e capacitação de recursos humanos, altamente qualificados, para os Estados-Membros a fim de contribuir para o desenvolvimento dos países e povos lusófonos, nos diversos domínios.

          Consulte o Regulamento e Candidate-se às Bolsas CPLP: https://www.ulusofona.pt/media/bolsas-de-estudo-isencaoreducao-propinas-cplpgrupo-lusofona.pdf

          O pedido é efetuado através do netPA (Portal Académico). Saiba aqui: https://www.ulusofona.pt/faqs/estudantes/questoes-administrativas/como-efetuar-um-pedido-no-netpa como.


          Bolsas da União Europeia

          O Guia de Financiamento Europeu funciona através de um algoritmo que apresenta apenas as bolsas, financiamentos e prémios que realmente correspondem ao perfil individual de cada aluno. Os 12.000 programas de apoio disponíveis cobrem um vasto leque de domínios para os quais os alunos universitários podem requerer apoio (financeiro). Esse apoio cobre despesas diárias, propinas e estágios a custos extra para semestres no estrangeiro, cursos de línguas e custos associados a projetos científicos.

          Mais informações em www.european-funding-guide.eu: http://www.european-funding-guide.eu

              SAS - Serviço de Ação Social: https://www.ulusofona.pt/acao-social-escolar
                Alojamento: https://www.ulusofona.pt/acao-social-escolar/alojamento
                Bolsas: https://www.ulusofona.pt/acao-social-escolar/apoios-diretos
                Apoios: https://www.ulusofona.pt/acao-social-escolar/apoios
                Desporto e bem-estar: https://www.ulusofona.pt/acao-social-escolar/desporto-e-bem-estar
        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona