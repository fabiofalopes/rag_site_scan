# Response for https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
          PT: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247 EN: https://www.ulusofona.pt/en/teachers/claudia-sofia-dinis-camilo-902247
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
        fechar menu : https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/claudia-sofia-dinis-camilo-902247
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Cláudia Sofia Dinis Camilo

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p902247
              p90***@ulusofona.pt
              341B-2F3E-B0D8: https://www.cienciavitae.pt/341B-2F3E-B0D8
              0000-0002-3691-1397: https://orcid.org/0000-0002-3691-1397
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/0cd3a8e2-88c0-47cc-81e6-46bc0073df31
      : https://www.ulusofona.pt/

        Resume

        PhD in Psychology (2020, Iscte-IUL) and MSc in Community Psychology and Child Protection (2010, Iscte-IUL). Currently, I am a researcher at the Center for Psychological Research and Social Intervention (CIS/Iscte), working on the project "All4Children - The Integrated Family Fostering Model (MIAF) to promote the quality of fostering and protection practices in Portugal" (funded by FCT). Also, I am teaching in the Master of Forensic Psychology at the Lusófona University of Lisbon (since 2020). My research interests have focused on maladaptive parenting, namely neglect, and the explanatory mechanisms of emotional and cognitive deprivation in parent-child interactions, particularly in contexts of poverty. I have also professional experience in intervention with children, young people, and families in the child protection system.

        Graus

            * Licenciatura
              Social Work
            * Mestrado
              Community Psychology and Child Protection
            * Licenciatura
              Psychology
            * Doutoramento
              Psychology

        Publicações

        Journal article

          * 2023-11-16, The youth-caregiver relationship quality in residential youth care: Professionals’ perceptions and experiences, Journal of Social and Personal Relationships
          * 2023-11, Social schemas about human trafficking involving girls and women: A systematic review, Aggression and Violent Behavior
          * 2023-11, Is it the Childs Fault? Maternal Attributions in Child Abuse and Neglect, Psicothema
          * 2023-07, Maltreatment History and Internalizing and Externalizing Symptoms in Out-ofhome Care: A Three-Level Meta-analysis, The European Journal of Psychology Applied to Legal Context
          * 2023-02-01, Information and communication technologies-assisted after-hours work: A systematic literature review and meta-analysis of the relationships with work–family/life management variables, Frontiers in Psychology
          * 2023, Childhood Poly-victimization and Adults’ Psychoticism: A Moderated Mediation Model Testing an Affective Pathway, Anuario de Psicología Jurídica
          * 2022, Parental Attitudes in Child Maltreatment, Journal of Interpersonal Violence
          * 2021, Recognizing children's emotions in child abuse and neglect, Aggressive Behavior
          * 2020-12-01, Victimization Experiences and Well-Being in Adulthood: A Systematic Review and Meta-Analysis, Violence and Victims
          * 2020-10, The social information processing model in child physical abuse and neglect: A meta-analytic review, Child Abuse & Neglect
          * 2019-12-03, A revisão sistemática de literatura em psicologia: Desafios e orientações [Systematic review in psychology: Challenges and guidelines], Análise Psicológica
          * 2019-07-05, How Does Mothering Look Like: A Multidimensional Approach to Maternal Cognitive Representations, Journal of Family Issues
          * 2019, Children's right to participate in early childhood education settings: a systematic review, Children and Youth Services Review
          * 2018, Subjective ratings and emotional recognition of children’s facial expressions from the CAFE set, PLoS One
          * 2016-07, Implicit measures of child abuse and neglect: A systematic review, Aggression and Violent Behavior
          * 2013, Desenho e avaliação de programas de desenvolvimento de competências parentais para pais negligentes: uma revisão e reflexão, Análise Psicológica
          * 2013, Desenho e avaliação de programas de desenvolvimento de competências parentais para pais negligentes: Uma revisão e reflexão [Design and evaluation of intervention programs for neglectful parents: A review and reflection], Analise Psicológica
          * 2012, Negligência parental: Uma abordagem experimental a problemas comunitários [Parental neglect: An experimental approach to comunity problems], In-Mind Português

        Book chapter

          * 2023, Polivitimação na Infância e Adolescência e Saúde Mental na Idade Adulta: Teste de um Modelo Dual, Crianças em Risco e Perigo - Contextos, Investigação e Intervenção, 6, Sílabo
          * 2023, Perceção de Competência Parental e Estilos de Parentalidade Maternos. O papel Protetor do Suporte Social, Crianças em Risco e Perigo - Contextos, Investigação e Intervenção, 6, Sílabo
          * 2014, pRó.paRental: Um programa de intervenção com pais [Pró-parental: An intervention program with parents], Crianças em risco e perigo: Contextos, investigação e intervenção, 4, Edições Sílabo
          * 2013, Avaliação de um programa de desenvolvimento de competências parentais [Evaluation of a parenting program], Crianças em risco e perigo: Contextos, investigação e intervenção, 3, Edições Sílabo

        Report

          * 2023-08-01, Child Sexual Abuse: A Meta-analysis of Protective Factors, https://doi.org/10.37766/inplasy2023.8.0002
          * 2023-03-18, Parents’ executive functioning in parenting outcomes: A meta-analytic review, https://doi.org/10.37766/inplasy2023.3.0067
          * 2015, Programa de Territorialização de Politicas Educativas de Intervenção Prioritária (TEIP3) [Intervention program in at-risk educational territories]

        Manual

          * 2023, e-Qual Program: Promoting Quality Relationships in Residential Care. Program Manual. Center for Research in Psychological Science, Faculty of Psychology, University of Lisbon. https://e-qual.pt/

        Conference paper

          * 2015, Intervenção da equipa de peritos externos TEIP ISCTE-IUL: Perspectiva organizacional multinível e multifactor [OM2] na promoção do sucesso educativo [ Intervention by the TEIP ISCTE-IUL team of consultants: Multilevel and multifactor organizational perspective [OM2] in promoting educational success]
          * 2012, Pró.parental: Construção, implementação e avaliação de um programa de formação parental [Pró.parental: Design, implementation and evaluation of a parenting program]

        Conference abstract

          * 2012, Pró.Parental: Intervenir por la educación parental [Pró.Parental: Intervening in parenting], Congreso Internacional de infancia maltratada: Construyendo puentes entre investigación y práctica

        Conference poster

          * 2023-11-23, Friendship quality and psychological adjustment of youth in residential care: A moderation analysis, 9th International Congress of Clinical and Health Psychology in Children and Adolescents
          * 2022-06-21, Perceção de competência parental e estilos de parentalidade maternos: O papel protetor do suporte social [Perceived parental competence and maternal parenting styles: The protective role of social support], XI Simpósio Nacional de Investigação em Psicologia
          * 2017-08-29, Cognitive representations of children: Difference between referred and non-referred mothers. , European Conference on Developmental Psychology
          * 2017-07-03, Implicit measures in child maltreatment and neglect: A systematic review, Encontro Ciência 2017
          * 2017-06-29, O uso de medidas implícitas na avaliação do mau trato e negligência parental: Uma revisão sistemática de literatura [Implicit measures in child abuse and neglect: a systematic literature review], IV Encontro Nacional de Psicologia Comunitária
          * 2015-03-12, Maternal beliefs about parenting: A multidimensional approach , International Convention of Psychological Science
          * 2012-05-11, Pró.parental: programa de formação parental para famílias negligentes [Pró.parental: an intervention program to neglectful families], 1º Encontro Nacional sobre Crianças e Jovens em Perigo - Contextos, Investigação e Intervenção
          * 2012-03-28, Pró.parental: Construção, implementação e avaliação de um programa de formação parental [Pró.parental: Design, implementation and evaluation of a parenting program], 3º Congresso Internacional de Psicologia da Criança e do Adolescente
          * 2012-03-16, Programas de formação parental: Uma abordagem experimental [Parenting intervention programs: An experimental approach], 7º Encontro da Associação Portuguesa de Psicologia Experimental

        Other output

          * 2023, Resilience in residential care: evidence from systematic and meta-analytic reviews, 9th International Congress of Clinical and Health Psychology in Children and Adolescents
          * 2019, Cuidar também é pensar: Revisão sistemática e meta-análise sobre os fatores cognitivos do abuso e negligência parental
          * 2018, The complex link between poverty and child abuse and neglect: A systematic review
          * 2016, What mothers think about parenting? Cognitive representations of parenting in mothers referenced to child protection services.
          * 2016, A aplicação de medidas implícitas ao estudo do mau trato e negligência parental.
          * 2015, Intervenção da equipa de peritos externos TEIP ISCTE-IUL: Perspetiva organizacional multinível e multifator [OM2] na promoção do sucesso educativo
          * 2015, Implicit measures in child maltreatment and neglect: A brief literature review.
          * 2014, Ideias maternas: Uma abordagem multidimensional da representação da parentalidade
          * 2014, As percepcoes das maes sobre a parentalidade:Uma abordagem multidimensional
          * 2013, O papel das cognições maternas nas práticas parentais maltratantes: Validação de uma escala de crenças parentais
          * 2013, Maternal beliefs and attributions: A comparative study between abusive and non-abusive mothers
          * 2013, Beliefs about child rearing: A new implicit measure.
          * 2012, Pró.parental: Construção, implementação e avaliação de um programa de formação parental

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona