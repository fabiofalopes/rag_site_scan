# Response for https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
          PT: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890 EN: https://www.ulusofona.pt/en/teachers/andreia-barbosa-valenca-5890
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
        fechar menu : https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/andreia-barbosa-valenca-5890
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Andreia Barbosa Valença

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5890
              and***@ulusofona.pt
              3612-8A7A-0F47: https://www.cienciavitae.pt/3612-8A7A-0F47
              0000-0002-1241-9701: https://orcid.org/0000-0002-1241-9701
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/c0b696e1-c6aa-4e28-82a8-eeae2bef86c0
      : https://www.ulusofona.pt/

        Resume

        Andreia Valença. Completed the PhD in Veterinary Science in 2019 from the University of Lisbon in collaboration with the Autonomous University of Barcelona. Prior to her doctoral studies, she worked as a research fellow at CIISA. She completed her Master's research in Maastricht University and earned a Master's degree in Human Biology and Environment in 2010 from the University of Lisbon. She also holds a Bachelor's degree in Genetics and Molecular Biology. Assistant Professor in Universidade Lusófona - Faculty of Veterinary Medicine since 2019, Coordinator Professor in Instituto Politécnico da Lusofonia since 2020, and Invited Adjunct Professor in Instituto Politécnico de Lisboa. Researcher in CIISA since 2011, Member of the Scientific and Pedagogical Council of FMV-ULusófona, and Member of the Animal Welfare and Ethics Committee of FMV-ULusófona. Published 22 articles in journals. Has 1 book(s). Has received 2 awards and/or honors. Participates and/or participated as Principal investigator in 1 project, Co-Principal Investigator (Co-PI) in 2 projects, Researcher in 7 projects, Research Fellow in 1 project. Currently, she divides her time between teaching and research. Besides focusing her research on retinopathy mechanisms, especially alterations of blood retinal vessels during eye disease and aging, and the impact of genetic variability on gene expression leading to pathological phenotypes, she has also developed an interest in pedagogy and education, which led to her enrollment in a postgraduate course in higher education pedagogy aiming to work towards shaping and improving more effective educational practices.

        Graus

            * Mestrado
              Mestrado em Biologia Humana e Ambiente
            * Licenciatura
              Licenciatura em Biologia, Ramo de Biologia Molecular e Genética
            * Doutoramento
              Ciências Veterinárias
            * Pós-Graduação
              Pedagogia do Ensino Superior

        Publicações

        Journal article

          * 2022-12-29, Grupo de interesse em Biologia Molecular. , Revista Lusófona de Ciências e Medicina Veterinária
          * 2022-01, Transferrin and TfR1 expression in the retina of a deficient TIM2 mouse., Anatomia, Histologia, Embryologia
          * 2022-01, Sirt1 as a novel promotor of blood vessel stability in the retina. , Anatomia, Histologia, Embryologia
          * 2021-11, Decreased endostatin in db/db retinas is associated with optic disc intravitreal vascularization, Experimental Eye Research
          * 2021-01, TIM2 modulates retinal iron levels and is involved in blood-retinal barrier breakdown, Experimental Eye Research
          * 2020, Contenção física: opções para a raça Brava de Lide. , Revista Portuguesa das Ciências Veterinárias
          * 2019-02-01, Vascular Interstitial Cells in Retinal Arteriolar Annuli Are Altered During Hypertension, Investigative Opthalmology & Visual Science
          * 2018-12, TIM2: a new player in iron homeostasis in the retina, Acta Ophthalmologica
          * 2018-12, SIRT1 overexpression induces VEGF expression and pericyte recruitment in the retina, Acta Ophthalmologica
          * 2018-12, Epiretinal membranes in a db/db model of diabetic retinopathy, Acta Ophthalmologica
          * 2017-06-22, Correction: L-Ferritin Binding to Scara5: A New Iron Traffic Pathway Potentially Implicated in Retinopathy, PLOS ONE
          * 2016, Effects of voluntary imipramine intake via food and water in paradigms of anxiety and depression in naïve mice, Translational Neuroscience and Clinics
          * 2015, Animal Models of Depression and Drug Delivery with Food as an Effective Dosing Method: Evidences from Studies with Celecoxib and Dicholine Succinate, BioMed Research International
          * 2014-09-26, L-Ferritin Binding to Scara5: A New Iron Traffic Pathway Potentially Implicated in Retinopathy, PLoS ONE
          * 2014-05-10, Abstracts presented at the Joint Meeting of the British Association of Clinical Anatomists, the 12th Congress of the European Association of Clinical Anatomy and the Portuguese Anatomical Society, 26th - 29th June 2013 at the Faculty of Medicine, Universi, Clinical Anatomy
          * 2013-12-05, Altered emotionality, hippocampus-dependent performance and expression of NMDA receptor subunit mRNAs in chronically stressed mice, Stress
          * 2013-08, Scara5 involvement in retinal iron metabolism, Acta Ophthalmologica
          * 2013-08, Müller cell response during degenerative retinopathy in mice, Acta Ophthalmologica
          * 2012-12, Pregnancy or stress decrease complexity of CA3 pyramidal neurons in the hippocampus of adult female rats, Neuroscience
          * 2012-08-06, Blood-retinal barrier serum ferritin transport in mouse retina, Acta Ophthalmologica
          * 2012-05, Intercapillary bridging cells: Immunocytochemical characteristics of cells that connect blood vessels in the retina, Experimental Eye Research
          * 2011-09, Interleukin-10 promotes macrophage infiltration in mouse retina, Acta Ophthalmologica

        Thesis / Dissertation

          * 2019-05-28, PhD, Analysis of TIM2 deficiency in the mouse retina
          * 2010-11-25, Master, Effects of stress on CA3 pyramidal neurons in the pregnant female rat

        Book

          * 2016, Morphological Mouse Phenotyping: Anatomy, Histology, and Imaging, Ruberte, Jesús; Navarro, Marc; Carretero, Ana, Editorial Me´dica Panamericana

        Conference poster

          * 2023-07-25, Rumen chroma phenotype in different biohydrogenation pathways in lambs. , XXXIV Congress of the European Association of Veterinary Anatomists – EAVA Congress
          * 2023-05-19, Salmonella spp. serovars isolated from healthy Leopard geckos (Eublepharis macularius) in Lisbon, Portugal.
          * 2023-05-19, Non-Helicobacter pylori in feline gastrointestinal neoplasia
          * 2023-05-19, Evaluation of aerobic oral flora of healthy ball pythons (Python regius)., FMVet Research Meetings - II Encontro de Investigação da FMV da Universidade Lusófona
          * 2022-11-11, Retinal iron overload is associated with BRB breakdown and leakage, The CIISA Congress 2022 under the theme ¿Innovation in Animal, Veterinary and Biomedical Research
          * 2022-11-11, Evaluation of normal aerobic oral flora of ball pythons (Python regius)., The CIISA Congress 2022 under the theme ¿Innovation in Animal, Veterinary and Biomedical Research
          * 2022-11-11, Does reticulo-rumen morphology explain lambs´ susceptibility to altered rumen biohydrogenation pathways?, The CIISA Congress 2022 under the theme ¿Innovation in Animal, Veterinary and Biomedical Research
          * 2021-07-28, Transferrin and TfR1 expression in the retina of a deficient TIM2 mouse. , XXXIIIrd Congress of the European Association of Veterinary Anatomists – EAVA Congress
          * 2021-07-28, Sirt1 as a novel promotor of blood vessel stability in the retina., XXXIIIrd Congress of the European Association of Veterinary Anatomists – EAVA Congress
          * 2021-06-08, Engaging students through a Trivial Pursuit-like activity – a tool for an active learning environment. , II International Congress on Education in Animal Sciences - ICEAS 2021
          * 2020-03-06, Contenção física: opções para a raça Brava de Lide., XII Jornadas Hospital Veterinário Muralha de Évora
          * 2019-11-07, ENDOSTATIN IS DECREASED IN THE RETINA OF DIABETIC DB/DB MICE, 15th ISOPT Clinical
          * 2018-11-16, TIM2: a new membrane receptor for H-ferritin in the mouse retina, CIISA Congress 2018
          * 2018-11-16, Response to local pain in Brava de Lide cows., CIISA Congress 2018
          * 2018-10-04, TIM2: a new player in iron homeostasis in the retina. , EVER Congress 2018
          * 2018-10-04, SIRT1 overexpression induces VEGF expression and pericyte recruitment in the retina. , EVER Congress 2018
          * 2018-10-04, Epiretinal membranes in a db/db model of diabetic retinopathy., EVER Congress 2018
          * 2018-03-03, Índices reprodutivos na raça Brava de Lide., X Jornadas Hospital Veterinário Muralha de Évora
          * 2018-03-02, Sorte de varas: resposta à dor na raça Brava de Lide. , X Jornadas Hospital Veterinário Muralha de Évora
          * 2018-03-01, TIM2 involvement in retinal iron homeostasis., 14th ISOPT Clinical 2018
          * 2018-03-01, SIRT1 overexpression induces pericyte recruitment in the retina., 14th ISOPT Clinical 2018
          * 2017-10-20, Termografía en la raza Brava de Lide: ventajas de la utilización de la termografía dorsolumbar como método de evaluación de la temperatura sistémica. , XIII Symposium del Toro de Lidia
          * 2017-10-20, Los niveles de cortisol y la nota de Tienta: respuesta al dolor en foco., XIII Symposium del Toro de Lidia
          * 2013-09-18, Müller cell response during degenerative retinopathy in mice., EVER Congress 2013
          * 2013, Serum ferritin transport across blood-retinal barrier into the retina, European Join Congress of Clinical Anatomy
          * 2013, GFAP expression patterns during degenerative retinopathy, European Join Congress of Clinical Anatomy
          * 2012-11-10, Blood-retinal barrier serum ferritin transport in mouse retina., EVER Congress 2012
          * 2011-10-05, Interleukin-10 promotes macrophage infiltration in mouse retina. , EVER Congress 2011
          * 2010-11-13, Stress during pregnancy affects dendritic morphology of CA3 pyramidal neurons in the pregnant rat. , 40th Annual Meeting of Neuroscience 2010
          * 2010-03-24, Behavioral Effects of Chronic Administration of Imipramine With Food and Water in Tests for Depression and Anxiety in Naïve C57BL/6N Mice., Euron School “Drugs and the Brain: an update in psychopharmacology” 2010

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona