# Response for https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
          PT: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295 EN: https://www.ulusofona.pt/en/teachers/alcina-manuela-de-oliveira-martins-3295
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
        fechar menu : https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/alcina-manuela-de-oliveira-martins-3295
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Alcina Martins

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3295
              alc***@ulusofona.pt
              5416-ECBE-008A: https://www.cienciavitae.pt/5416-ECBE-008A
              0000-0002-0290-747X: https://orcid.org/0000-0002-0290-747X
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/0b499eba-e5ca-43ad-8203-f8c1acc61662
      : https://www.ulusofona.pt/

        Resume

        Alcina Manuela de Oliveira Martins is a Full Professor at the Universidade Lusófona do Porto. She is a Professor of Epistemology of Social Sciences and Research Methodologies in Education at the Universidade Lusófona do Porto. She is the director of the Master 's course in Educational Sciences, and responsible for the core of Porto's CeiED ( Interdisciplinary Center for Research in Education and Development). She was Vice Dean of the Lusófona University of Porto( 2008-2012). As a University Professor and researcher, Alcina de Oliveira Martins currently participates in the OECD Creative and Critical Thinking on Higher Education Project and the Innovation for Education Project, funded by the European Union. She has been leading the Municipal Plan against domestic violence in the city of Porto (2013-2015). She has published 24 articles in specialized magazines. She has 4 book chapters and 4 books and has interacted with 37 collaborators in co-authoring scientific papers. Supervised 4 PhD thesis and co-supervised 7. Supervised 51 master's dissertations

        Graus

            * Licenciatura
              Licenciatura em Ciências Históricas
            * Mestrado
              Mestrado em História Medieval
            * Título de Agregado
              História
            * Doutoramento
              História

        Publicações

        Artigo em revista

          * 2023-07, Impacto do Programa Cooperjovem em uma Escola do Município de Pedras de Fogo – PB, Revista Cocar
          * 2023-02-07, The Experience of Remote Teaching in Higher Education: A Scenario of Challenges and Opportunities, Journal of Higher Education Theory and Practice
          * 2022-11-14, Teachers and students’ perceptions about remote teaching in higher education: online qualitative research, Revista Pesquisa Qualitativa
          * 2021-08-30, Apresentação, Revista Liberato
          * 2021-01, Education and innovation: impacts during a global pandemic in a higher education institution, SHS Web of Conferences
          * 2020-12-29, A Marca (In)Visível do Género na Família: Perceções de Jovens Estudantes, Fronteiras: Journal of Social, Technological and Environmental Science
          * 2020-08, A mediação de conflitos no plano de melhoria: um contributo em contexto escolar, Campo Abierto. Revista De Educación
          * 2020-05-04, Pedagogical Supervision and Change: Dynamics of Collaboration and Teacher Development, THE INTERNATIONAL JOURNAL OF MANAGEMENT SCIENCE AND BUSINESS ADMINISTRATION
          * 2019-12-09, Metodologias ativas para a inovação e qualidade do ensino e aprendizagem no ensino superior, Revista EDaPECI
          * 2018, Mediação escolar: a análise qualitativa da dimensão interpessoal/ social de um projeto de intervenção numa escola TEIP, Revista Lusófona de Educação
          * 2016, School`s Images: Students` Perceptions about Teaching and Learning in the Geography, Journal of Modern Education Review
          * 2016, Morning-Evening Types in Kindergarten, Time-of-Day and Performance on Basic Learning Skills, International Online Journal of Educational Sciences
          * 2016, Desafios colocados pela avaliação de um projeto de mediação escolar, Revista Eixo
          * 2015, Significados e perspectivas do insucesso escolar no ensino profissional em Portugal, Cadernos de Educação
          * 2014-12-30, Practical reflectivity as a context for teachers´ professional development: a mixed-methods study., Advances in Social Sciences Research Journal
          * 2014-01, Evasão Escolar: desigualdade e exclusão social, Revista Liberato. Novo Hamburgo
          * 2014, Case Studying Educational Research: A Way of Looking at Reality., American Journal of Educational Research
          * 2013, O estudo de caso como abordagem metodológica no ensino superior, Revista Nuances: Estudos sobre educação
          * 2012-07-13, Namoro: uma relação de afetos ou de violência entre jovens casais?, Revista Peritia
          * 2012, Formação e supervisão: O que move os professores?, Revista Lusófona de Educação
          * 2011, A consolidação da Educação e Formação Profissional na Escola Secundária nos últimos 50 anos em Portugal, Revista Lusófona de Educação
          * 2009, No crepúsculo da vida: um olhar sentido sobre a vivência conjugal. , Universitas Tarraconensis, Revista de Ciències de l’Éducació
          * 2006, A violência doméstica por detrás do abandono escolar, Universitas Tarraconensis, Revista de Ciències de l’Éducación
          * 2005, A (des)construção do paradigma da masculinidade , Universitas Tarraconensis. Revista de Ciències de l’Éducació
          * 2004, Memória Arquivística medieval e moderna: os principais fundos arquivísticos portugueses, Revista de Ciências da Informação e da Documentação
          * 2003, Os forais manuelinos enquanto estratégia de poder do Venturoso, Vária Escrita
          * 2003, A protecção concedida por D. Manuel às Monjas de Vairão, Revista de Ciências Históricas
          * 1999, Estratégias de afirmação do poder no feminino na Alta Idade Média: o exemplo de Vairão, Revista de Ciências Históricas
          * 1995, O foral de S. Tomé: de D. João I a D. João III, Revista de Ciências Históricas
          * 1995, Entre-os-Rios e o seu foral manuelino, Revista Poligrafia
          * 1993, A implantação dos Votos de S. Tiago no bispado do Porto, Revista Poligrafia
          * 1993, A contestação tributária dos moradores da Capitania do Funchal, Revista de Ciências Históricas
          * 1992, O foral Manuelino de Torre de Moncorvo, Revista de Ciências Históricas

        Tese / Dissertação

          * 2021, Mestrado, Impacto da violência doméstica nas relações interpessoais e na aprendizagem das crianças de uma escola pública municipal de Goiânia
          * 2020, Mestrado, O papel do professor na mediação pedagógica da aprendizagem no ensino superior
          * 2020, Mestrado, Acesso de acadêmicos de direito à advocacia : perfis e percursos educativos em instituições de Ensino Superior de Goiânia
          * 2020, Doutoramento, O dito e o não dito na educação: políticas públicas educacionais de gênero no Brasil à luz do curso gênero e diversidade na escola_GDE
          * 2019, Mestrado, Processo de gestão escolar : das políticas públicas para a autonomia e uma educação de qualidade
          * 2018, Mestrado, Escola atual e gestão democrática : participação reflexiva da comunidade educativa
          * 2018, Mestrado, Análise do impacto do programa cooperjovem em uma escola do município de Pedras de Fogo-PB
          * 2017, Mestrado, O desenvolvimento de competências práticas essenciais á formação do estudante do ensino médio e à sua inserção na vida ativa
          * 2017, Mestrado, Avaliação da interação em ambiente virtual do curso de administração de uma instituição de ensino superior na modalidade educação a distância
          * 2017, Mestrado, Ausência familiar e suas repercussões na construção da aprendizagem de crianças institucionalizadas
          * 2017, Doutoramento, Violência doméstica e envolvimento parental na escola : perspetivas de mães e filhos
          * 2017, Doutoramento, Supervisão e formação de profissionais de educação reflexivos : estudo de caso num estágio de um curso de formação inicial de educadores de infância
          * 2017, Doutoramento, Stand up… quality! Fazeres e dizeres na avaliação da escola
          * 2017, Doutoramento, A interação entre os docentes de educação especial e os docentes titulares de turma nas perspetivas de atores educativos de escolas do Funchal
          * 2016-08, Doutoramento, Cronótipo no 1º Ciclo do Ensino Básico, hora-do-dia/ dia-da-semana e o desempenho em aptidões básicas para a aprendizagem
          * 2016, Mestrado, O papel do pedagogo na empresa: gestão de uma pedagogia empresarial
          * 2016, Mestrado, Gestão Democrática na escola pública: a atuação do conselho escolar na rede municipal de ensino em Santa Luzia do Itanhi/Se
          * 2016, Mestrado, Educação integral e ensino e aprendizagem : o caso de uma escola pública de tempo integral no Município de João Pessoa
          * 2016, Doutoramento, Mediação de conflitos: construção de um projeto de melhoria de escola
          * 2015, Mestrado, O dilema da (in)disciplina escolar
          * 2015, Mestrado, Implantação de um sistema de gestão integrado numa escola pública do Município de Ipojuca
          * 2015, Mestrado, Gestão democrática de uma escola pública numa visão integrada dos participantes no Conselho Escolar
          * 2014, Mestrado, O processo de inclusão digital para jovens de 14 a 17 anos no projeto estação digital barra de Jangada – Jaboatão dos Guararapes/PE
          * 2014, Mestrado, Influência da liderança e cultura organizacional na gestão democrática de escola pública
          * 2014, Mestrado, Estratégias de ensino-aprendizagem para a superação de dificuldades na leitura e na escrita nas séries iniciais do ensino fundamental
          * 2014, Mestrado, Ensino superior e políticas públicas : o voluntariado do projeto escola legal e a formação universitária
          * 2014, Mestrado, A educação das crianças e a relação escola-família : um estudo de gênero com mães trabalhadoras
          * 2013, Mestrado, Formação corporativa a distancia em uma instituição pública federal de ensino superior: um estudo de caso
          * 2013, Mestrado, De volta aos bancos da escola: percursos e motivações do curso EFA
          * 2013, Mestrado, As perceções dos professores de um agrupamento de escolas sobre a influência da liderança de topo no seu clima e cultura organizacional
          * 2013, Mestrado, A construção da identidade e da prática docente do professor das escolas do campo
          * 2012, Mestrado, O fio de Ariadne : a formação contínua do PNEP e desenvolvimento da competência da leitura no 1.º CEB
          * 2012, Mestrado, Evasão escolar no ensino fundamental : a concepção de egressos do projovem urbano em Carmópolis/SE : um estudo de caso

        Livro

          * 2019, Foral Manuelino da Honra de Sobrosa- 1519, 1, Martins, Alcina Manuela de Oliveira, Câmara Municipal de Paredes
          * 2001, O mosteiro de S. Salvador de Vairão na Idade Média: o percurso de uma comunidade feminina, 1, Martins, Alcina Manuela de Oliveira, Universidade Portucalense
          * 1999, Os Votos de S. Tiago no Norte de Portugal (sécs XII-XV), 1, Martins, Alcina Manuela de Oliveira, Xunta de Galicia
          * 1994, Figuras da realeza portuguesa em peregrinação a Santiago In Santiago, Caniño de Europa (Culto e cultura en la peregrinação a Compostela), 1, Martins, Alcina Manuela de Oliveira; Moreno, Humberto Baquero, Xunta de Galicia
          * 1993, Os Votos de S. Tiago no Norte de Portugal (sécs XII-XV), Alcina Manuela De Oliveira Martins, Xunta de Galicia

        Capítulo de livro

          * 2024, The Teaching Profession and the Renewal of Pedagogical Practices in Higher Education in Times of the Pandemic, Fortering Values Education and Engaging Academic Freedom amidst Emerging Issues Related to COVID-19, 20, 1, BRILL
          * 2021, Efeitos interpessoais e sociais da implementação de um Projeto de Mediação Escolar, Educação Contemporânea – Volume 28 – Artes, Formação Docente, 28, 1ª, Editora Poisson
          * 2018, O corpo feminino na Idade Média: Um lugar de tentações, O outro lado do espelho: percursos de investigação (CeiED 2013-2017), Edições Universitárias Lusófonas
          * 2016, Gabinetes de mediação de conflitos: estruturas de pacificação, dinâmica e resultados, Sustentabilidade da Mediação Social: processos e práticas , CECS
          * 2003, A mulher entre a norma e a prática na Idade Média, Os reinos ibéricos na Idade Média: livro de Homenagem ao Professor Doutor Humberto Baquero Moreno, 2, Livraria Civilização
          * 2001, Votos de S. Tiago , Dicionário de História Religiosa de Portugal, 5, Círculo de Leitores
          * 1999, O concelho de Valongo em meados do século XIII: uma época de expansão, Estudos de Homenagem a Joaquim M. da Silva Cunha, 1, Universidade Portucalense Infante D. Henrique

        Artigo em jornal

          * 1994-03-04, As relações de Portugal com o exterior na época do Infante D. Henrique. In Como se vivia no tempo do Infante D. Henrique, Jornal de Notícias

        Artigo em conferência

          * Uma contenda entre o mosteiro de S. Salvador de Vairão e Simão Martins, tabelião do rei nas terras da Maia, Actas das Jornadas Interdisciplinares, Poder e Sociedade
          * Da devoção a S. Tiago à contestação dos Votos Jacobeios, Congresso Internacional dos Caminhos Portugueses de Santiago de Compostela
          * 2021-11-19, Educação para Risco: Formação e Prevenção, XIII Congresso de Geografia Portuguesa: O compromisso da Geografia para territórios de mudança
          * 2018-07, A posição estratégia da Mediação de Conflitos no Plano de Melhoria de Escola , Investigação Qualitativa em Educação/Investigación Cualitativa en Educación
          * 2017-07, A investigação qualitativa como metodologia compreensiva da dimensão interpessoal/social de um projecto de mediação de conflitos, Investigação Qualitativa em Educação/Investigación Cualitativa en Educación
          * 2015-07-24, Ser ou não ser professor reflexivo: uma questão de formação e desenvolvimento profissional docente, I Seminário Internacional Educação, territórios e desenvolvimento Humano. Volume II
          * 2015-07-23, O projeto de mediação de conflitos como dispositivo de melhoria de Escola, Seminário Internacional Educação, territórios e desenvolvimento Humano
          * 2015, Do Éden ao Inferno: Representações do corpo feminino na Idade Média , I Congresso Lusófono de Ciência das Religiões. Religiões e Espiritualidades – Culturas e Identidades
          * 2007-07-05, Educação e Tempo Livre: o papel do animador sócio-cultural em contexto escolar, II Congreso Iberoamericano de Pedagogía Social y XXI Seminário Interuniversitario de Pedagogía Social
          * 2006-09-18, O lado oculto da violência doméstica: “um olhar de dentro”, XX Seminário Interuniversitario de Pedagogía Social sobre “Educación Social e Igualdad de Género”
          * 2005-07-14, Sexo, Género e Educação em Portugal, Congresso Internacional de Educação e Cidadania
          * 2005-07-06, Educação e Sociedade: a criação de um novo contexto educativo, 1er Congreso Internacional e Interdisciplinar sobre Participación, Animación e Intervención Socioeducativa, Universitat Autónoma de Barcelona, Departament de Pedagogia Sistemática i Social”
          * 2004-10-18, Género e cidadania: um exemplo português, 1er Congreso Iberoamericano de Pedagogia Social
          * 2003-07, História e memória de uma comunidade feminina: o mosteiro de S. Salvador de Vairão, II Jornadas de Vila do Conde
          * 2002-07, A contestação das igrejas portuguesas à tutela de Santiago a propósito dos votos jacobeus, Jornadas dos Caminhos de Santiago

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona