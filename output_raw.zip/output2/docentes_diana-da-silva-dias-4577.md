# Response for https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
          PT: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577 EN: https://www.ulusofona.pt/en/teachers/diana-da-silva-dias-4577
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
        fechar menu : https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/diana-da-silva-dias-4577
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Diana Da Silva Dias

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4577
              dia***@ulusofona.pt
              4E1E-17C5-30F8: https://www.cienciavitae.pt/4E1E-17C5-30F8
              0000-0003-2067-5243: https://orcid.org/0000-0003-2067-5243
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/0ebcd14c-9482-4b70-92cb-27abf78e9f3a
      : https://www.ulusofona.pt/

        Resume

        I am passionate about research that has the power to catalyze transformative change in the world. I firmly believe that education stands as a privileged realm for such profound transformation. My academic journey began with undergraduate and postgraduate studies in Psychology, progressing to a Ph.D. in Education Sciences. Throughout this transformative experience, I skillfully balanced diverse roles as a teacher, education specialist, and researcher. Advancing further, I pursued my first habilitation examination in 2017, specializing in Learning Psychology. Subsequently, in 2022, I presented my second habilitation examination in Management, with a specific emphasis on social innovation and fortifying the link between academia, business and society. My professional career as an academic manager started in 2003, initially as the deputy director at a higher school specializing in social and community development. For over 8 years, I held the position of Vice-Rector for Research, Quality, and Academic Innovation at Univ. Europeia, where I also served as interim rector. Leading the Executive Committees for two Ph.D. programs—one in Management and another in Psychology—further enriched my diverse experience. Currently, I am Full Professor at Univ. Lusófona. Concurrently, I am actively engaged as the Pro-Rector for Innovation and Research and serve as the Director of two faculties: Faculty of Economic, Social and Business Sciences in Porto, and the School of Economic Sciences and Organizations in Lisbon. Additionally, I am the Director of the INTREPID Lab, a branch of CETRAD. Throughout my career, I have significantly contributed to scientific literature, with publications in indexed scientific journals and authorship of several books spanning the fields of Management, Psychology, and Education. Furthermore, I play an active role as a consultant on education policies, collaborating with esteemed organizations, including POCH, DGEEC, A3ES, CNE, CPLP, EUA, UNESCO, and OECD.

        Graus

            * Pós-Graduação
              Psychotherapy and career Management
            * Licenciatura
              Psychology
            * Título de Agregado
              Psychology
            * Título de Agregado
              Management
            * Doutoramento
              Educational Sciences
            * Doutoramento
              Ciências da Educação

        Publicações

        Artigo em revista

          * 2023-07-26, Wine Companies’ Profitability in the Old World: Working Capital’s Impact, Administrative Sciences
          * 2023-07-24, Study to Live or Live to Study: The Link between Social Role Investment and Academic Success in First-Year Higher Education Students, Education Sciences
          * 2023-05-01, Creative Environment in the Classroom and Students’ Satisfaction with School, Revista Colombiana de Educación
          * 2023-01-10, Engineering Learning Outcomes: The Possible Balance between the Passion and the Profession, Social Sciences
          * 2023, PARENTAL INVOLVEMENT IN SCHOOL: PARENTS’ AND STUDENTS’ PERCEPTIONS, Psicologia Escolar e Educacional
          * 2022-08-24, Students strategies to survive the academic transition: recycling skills, reshaping minds, European Journal of Engineering Education
          * 2022-03-23, The Higher Education Commitment Challenge, Education Sciences
          * 2020-08-31, Contextualizar o (in)sucesso escolar: proposta de uma metodologia de avaliação bioecológica, Revista Meta: Avaliação
          * 2020-06-24, For a Healthy (and) Higher Education: Evidences from Learning Outcomes in Health Sciences, Education Sciences
          * 2020-05-06, Designing Learning Outcomes in Design Higher Education Curricula, International Journal of Art & Design Education
          * 2020, For a healthy (and) higher education: evidences from learning outcomes in health sciences
          * 2020, For a healthy (and) higher education: evidences from learning outcomes in Health Sciences
          * 2020, Designing learning outcomes in design higher education curricula
          * 2019, DROP-OUT AND COMPLETION AMONG PORTUGUESE STUDENTS
          * 2018-12-23, Perspectives of lifelong education in Portuguese higher education: a critical analysis of learning outcomes, International Journal of Lifelong Education
          * 2018-04-03, Civic learning outcomes: a step towards an inclusive higher education, International Journal of Inclusive Education
          * 2018, Towards the university entrepreneurial mission: Portuguese academics’ self-perspective of their role in knowledge transfer, Journal of Further and Higher Education
          * 2018, O que se “ensina” no ensino superior: avaliando conhecimentos, competências, valores e atitudes
          * 2018, O que se “ensina” no Ensino Superior: avaliando conhecimentos, competencias, valores e atitudes, Revista Meta: Avaliacão
          * 2017-12-17, Resultados de aprendizagem no quadro do ensino superior português: definição e medida, Revista de Estudios e Investigación en Psicología y Educación
          * 2017-12-17, Resultados de aprendizagem no quadro do ensino superior português: O caso da psicologia e da educação, Revista de Estudios e Investigación en Psicología y Educación
          * 2017-06-05, Validação de um instrumento de avaliação dos fatores promotores da motivação para o trabalho: Um estudo cm profissionais de saúde oncológica portugueses, Análise Psicológica
          * 2017, Working with cancer: motivation and job satisfaction, International Journal of Organizational Analysis
          * 2017, Validação de um instrumento de avaliação dos fatores promotores da motivação para o trabalho: Um estudo com profissionais de saúde oncológica portugueses
          * 2017, Validação de um instrumento de avaliação dos fatores promotores da motivação para o trabalho: Um estudo cm profissionais de saúde oncológica portugueses
          * 2017, Validação de um instrumento de avaliação dos fatores promotores da motivação para o trabalho : um estudo cm profissionais de saúde oncológica portugueses
          * 2017, Resultados de aprendizagem no quadro do ensino superior português: definição e medida
          * 2017, Managing research or managing knowledge? A device tool for quality assurance
          * 2016, Academic promises and family (dis)enchantments: clues for guidance and counselling in higher education, British Journal of Guidance and Counselling
          * 2015, Has massification of higher education led to more equity? Clues to a reflection on Portuguese education arena, INTERNATIONAL JOURNAL OF INCLUSIVE EDUCATION
          * 2015, As potencialidades da implementação de atividades práticas de caráter investigativo e interdisciplinar em ciências no 1.º ciclo, Saber & Educar
          * 2014-01-02, Transition to higher education: the role of initiation practices, Educational Research
          * 2014, Waves of (dis)satisfaction: effects of the numerus clausus system in Portugal
          * 2014, The family social-cultural status as vector of career decision: Promises, illusions and disillusions in higher education access | O estatuto sociocultural familiar como vetor da decisão vocacional: Promessas e (des)ilusões da entrada na educação superior, Revista Brasileira de Orientacao Profissional
          * 2014, The Impact of the Transition to HE: emotions, feelings and sensations, EUROPEAN JOURNAL OF EDUCATION
          * 2014, O estatuto sociocultural familiar como vetor da decisão vocacional: promessas e (des)ilusões da entrada na educação superior. , Revista Brasileira de Orientação Profissional.
          * 2014, Initiation rituals in university as lever for group cohesion, Journal of Further and Higher Education
          * 2013-08-16, Waves of (Dis)Satisfaction: Effects of theNumerus Clausussystem in Portugal, European Journal of Education
          * 2013-08, Why is it Difficult to Grasp the Impacts of the Portuguese Quality Assurance System?, European Journal of Education
          * 2013-01, The faculty conjugated as feminine: a portrait of Portuguese academia, Journal of Further and Higher Education
          * 2013, Students' choices in Portuguese higher education: Influences and motivations, European Journal of Psychology of Education
          * 2013, Becoming young or student: a developmental challenge, Revista Portuguesa de Pedagogia
          * 2012-09, From high school to university: students’ competences recycled, Research in Post-Compulsory Education
          * 2012, Democratização do acesso e do sucesso no ensino superior: uma reflexão a partir das realidades de Portugal e do Brasil, Avaliação: Revista da Avaliação da Educação Superior (Campinas)
          * 2012, Democratização do acesso e do sucesso no ensino superior: uma reflexão a partir das realidades de Portugal e do Brasil, Avaliação (Campinas)
          * 2012, Democratização do acesso e do sucesso no ensino superior: uma reflexão a partir das realidades de Portugal e do Brasil
          * 2011-11, The EUA Institutional Evaluation Programme: an account of institutional best practices, Quality in Higher Education
          * 2011-08, Reasons and motivations for the option of an engineering career in Portugal, European Journal of Engineering Education
          * 2011-04, The democratisation of access and success in higher education, Higher Education Management and Policy
          * 2011, The democratisation of access and success in higher education: the case of Portugal and Brazil
          * 2011, The democratisation of access and success in higher education : the case of Portugal and Brazil, Given that higher education systems everywhere have opened to the masses, this paper analyses to what extent this phenomenon has really been accompanied by an effective democratisation of access and success in Portugal and Brazil. It looks at the expansion of higher education and discusses how the political system and higher education institutions have responded to the need for better educated pop
          * 2011, Higher education (related) choices in Portugal: Joint decisions on institution type and leaving home, Studies in Higher Education
          * 2010, Does the {EUA} Institutional Evaluation Programme Contribute to Quality Improvement?, Quality Assurance in Education
          * 2009-11, Supra-national accreditation, trust and institutional autonomy, Higher Education Management and Policy
          * 2009, Funding Allocation and Staff Management. A Portuguese Example, EUROPEAN JOURNAL OF EDUCATION
          * 2008, Students' preferences and needs in Portuguese higher education, European Journal of Education
          * 2006, Institutional consequences of quality assessment, Quality in Higher Education

        Tese / Dissertação

          * 2023, Doutoramento, Basic Design innovation with the contribution of Virtual Reality-based tools
          * 2022, Mestrado, Aprendizagem e Envelhecimento na Gestão de Recursos Humanos
          * 2022, Mestrado, A importância do acolhimento e da integração na cultura organizacional da empresa Grupo Carrinho S.A.: estudo de caso
          * 2021, Mestrado, Liderança e Assédio Moral em contexto laboral: ligações perigosas
          * 2020, Doutoramento, Competências chave no acesso e na profissão de Contabilista
          * 2018, Mestrado, Gestão de Recursos Humanos em Portugal: as competências que as Instituições de Ensino Superior pretendem desenvolver nos seus estudantes: uma comparação entre graus académicos e subsistemas de Ensino Superior
          * 2018, Mestrado, Gestão de Recursos Humanos em Portugal: as competências que as Instituições de Ensino Superior pretendem desenvolver nos seus estudantes: uma comparação entre graus académicos e subsistemas de Ensino Superior
          * 2018, Doutoramento, Learning Outcomes no Ensino Superior Português: Perfis de Competências da Área das Ciências Empresariais
          * 2018, Doutoramento, Learning Outcomes no Ensino Superior Português: Perfis de Competências da Área das Ciências Empresariais
          * 2017, Mestrado, As Soft Skills de finalistas universitários: Alinhamento ou Gap com o mercado de trabalho?
          * 2017, Mestrado, As Soft Skills de finalistas universitários: Alinhamento ou Gap com o mercado de trabalho?
          * 2016, Mestrado, Os riscos psicossociais nos tripulantes da aviação comercial
          * 2016, Mestrado, Os riscos psicossociais nos tripulantes da aviação comercial
          * 2016, Mestrado, Gestores de topo em empresas multinacionais e internacionais em Portugal
          * 2016, Mestrado, Gestores de topo em empresas multinacionais e internacionais em Portugal
          * 2016, Mestrado, Autoconhecimento
          * 2016, Mestrado, Autoconhecimento
          * 2016, Mestrado, A inteligência emocional
          * 2016, Mestrado, A inteligência emocional
          * 2016, Mestrado, A Gestão Emocional na Relação com o Outro
          * 2016, Mestrado, A Gestão Emocional na Relação com o Outro
          * 2015, Mestrado, Competências de RH
          * 2015, Mestrado, Competências de RH
          * 2015, Mestrado, Análise e avaliação de competências no Ensino Superior
          * 2015, Mestrado, Análise e avaliação de competências no Ensino Superior
          * 2014, Mestrado, O Perfil dos Diplomados do Ensino Superior em Portugal
          * 2014, Mestrado, O Perfil dos Diplomados do Ensino Superior em Portugal
          * 2014, Mestrado, O Perfil dos Diplomados do Ensino Superior em Portugal
          * 2014, Mestrado, O Perfil dos Diplomados do Ensino Superior em Portugal
          * 2014, Mestrado, O Perfil dos Diplomados do Ensino Superior em Portugal
          * 2014, Mestrado, Impacto da percepção da avaliação de desempenho na satisfação no trabalho no Município de Sousel
          * 2014, Mestrado, Impacto da percepção da avaliação de desempenho na satisfação no trabalho no Município de Sousel
          * 2014, Mestrado, Fundação da Juventude
          * 2014, Mestrado, Fundação da Juventude
          * 2014, Mestrado, A Conciliação da Vida Profissional com a Vida Familiar
          * 2014, Mestrado, A Conciliação da Vida Profissional com a Vida Familiar
          * 2013, Mestrado, A Liderança no Feminino

        Livro

          * 2021, O Que Se Diz Que Se Aprende: Resultados de Aprendizagem do Ensino Superior em Portugal. Lisboa: A3ES Readings., Dias, Diana, A3ES Readings
          * 2019, Psicologia em Palavras: 500 Termos Técnicos, Dias, Diana, Chiado
          * 2018, Sistemas de Gestão da Qualidade na Administração Pública, Dias, Diana, Diário de Bordo
          * 2018, Psicologia da Aprendizagem: Paradigmas, Motivações e Dificuldades, Dias, Diana, Sílabo
          * 2013, Tendências Recentes no Ensino Superior Português, Dias, Diana; Tavares, Orlanda; Carla Sá, A3ES Readings
          * 2008, O Superior Ofício de Ser Aluno: Manual de Sobrevivência para Caloiros., Dias, Diana, Sílabo

        Capítulo de livro

          * 2022, Anticipating the Impact of Virtual Reality for Learning the Design Fundamentals: Students Perceptions and Perspectives, Human Dynamics and Design for the Development of Contemporary Societies, 25, AHFE Open Access
          * 2021, Living with Uncertainty in Times of Pandemic: The View of Working Students in Higher Education, Anxiety, Uncertainty, and Resilience During the Pandemic Period - Anthropological and Psychological Perspectives, IntechOpen
          * 2019, Resultados de Aprendizagem: Da intençãoi do professor à ação do estudante, Estudantes do Ensino Superior: Desafios e Oportunidades, ADIPSIEDU
          * 2019, Integração no Ensino Superior: reciclagem do ofício do aluno, 31 Desafios, Universidade da MAdeira
          * 2019, Da Ilusão da Democratização à Realidade da Massificação: os cravos de uma revolução no Sistema superior de Ensino, 45 de Democracia, Almedina
          * 2016, UNDERSTANDING LIFELONG LEARNING THROUGH THE EYES OF PORTUGUESE HIGHER EDUCATION INSTITUTIONS
          * 2016, LEARNING BASIC DESIGN WITH VIRTUAL REALITY: A METHODOLOGICAL APPROACH
          * 2016, Academics’ Professional Characteristics and Trajectories: The Portuguese Case
          * 2015, Massificação versus Democratização: um olhar do acesso ao sucesso, Acesso ao Ensino Superior: Desafios para o Século XXI, Conselho Nacional de Educação
          * 2014, Thematic areas of IEP evaluations., A Twenty-Year Contribution to Institutional Change: EUA’s Institutional Evaluation Programme, European University Association
          * 2014, Assessment of Higher Education Learning Outcomes (AHELO): An OECD Feasibility Study
          * 2014, Assessment of Higher Education Learning Outcomes (AHELO), Quality Assurance in Higher Education, Palgrave Macmillan
          * 2013, Teaching and Research: Perspectives from Portugal, Teaching and Research in Contemporary Higher Education, Springer Netherlands
          * 2013, Envolvimento dos Académicos em Empreendedorismo: o Caso Português, Handbook de Educação em Empreendedorismo no contexto Português, Católica Editora
          * 2012, Será que o programa de avaliação institucional da EUA contribui para o aumento da produtividade? , Alberto Amaral: um cientista entre a academia e a ágora, UPorto Editora
          * 2012, Portugal: Dimensions of Academic Job Satisfaction, Job Satisfaction around the Academic World, Springer Netherlands
          * 2012, Democratização e Expansão da Educação Superior em Portugal., Análise dos Sistemas de Educação Superior no Brasil e em Portugal: o que apontam as políticas educacionais, EdiPCURS
          * 2012, Consequências Institucionais da Avaliação da Qualidade, Alberto Amaral: um cientista entre a academia e a ágora. , UPorto Editora
          * 2012, Alocação de financiamento e gestão de pessoal: o exemplo português, Alberto Amaral: um cientista entre a academia e a ágora, UPorto Editora
          * 2011, The Increasing Role of Market Forces in He
          * 2009, A regional mismatch? Student application and institutional responses in the Portuguese public higher education system, Public Universities and Regional Development, Sichuan University Press
          * 2009, A Regional Mismatch? An exploratory analysis of students’ applications and institutional responses in the Portuguese public higher education system., Public Universities and Regional Development, Sichuan University Press
          * 2007, Portugal, The Rising Role and Relevance of Private Higher Education in Europe, CEPES – UNESCO
          * 2007, Assessment as a tool for different kinds of action. From quality management to compliance and control, Quality Assessment for Higher Education in Europe, Portland Press
          * 2007, Acesso ao Ensino Superior e Equidade, Políticas de Ensino Superior: Quatro Temas em Debate, Conselho Nacional de Educação
          * 2006, National Study Report, Funding Systems and their Effects on Higher Education Systems, Education Working Paper n. o 6. Paris: IMHE – OCDE.
          * 2005, The Portuguese Case, Private Higher Education in Europe and Quality Assurance and Accreditation from the Perspective of the Bologna Process Objectives, UNESCO CEPES

        Edição de livro

          * 2021, Almedina

        Artigo em conferência

          * WHAT STUDENTS WANT: PREFERENCES ABOUT SCHOOL AND EXTRACURRICULAR ACTIVITIES IN PRIMARY SCHOOL
          * THE JANUS FACES OF SUCCESS: SOCIAL AND PERSONAL TRAITS AS PREDICTORS OF STUDENTS' PERFORMANCE IN ELEMENTARY SCHOOL
          * Implementação de learning outcomes : a experiência recente em Portugal
          * 2023-07, WHAT IS THE RELATIONSHIP BETWEEN SELF-CONCEPT AND SCHOOL PERFORMANCE IN PRIMARY SCHOOL?
          * 2023-07, SOCIAL WORK THROUGH THE AGES: THE CASE STUDY OF PORTUGUESE HIGHER EDUCATION
          * 2023-07, SOCIAL WORK CURRICULAR DESIGN AND THE INTERNATIONAL STANDARDS FOR THE PROFESSION: ALIGNMENT AND MISALIGNMENT IN PORTUGAL
          * 2023-07, DIVERSITY IN HIGHER EDUCATION: STUDENTS' GRITS AND FEARS
          * 2020-07, SCHOOL READINESS: ROLE OF SCHOOLS REVISITED BY PARENTS, TEACHERS AND PRINCIPALS
          * 2020-07, I CAN'T GET NO SATISFACTION: THOUGHTS AND FEELINGS ABOUT ELEMENTARY SCHOOL
          * 2020-03, GLASS CEILING IN ACCOUNTING PROFESSION: MYTH OR REALITY?
          * 2019-03-11, TO BE OR NOT TO BE: DECISION MAKING AS A CRITICAL SKILL TO DEVELOP IN HIGHER EDUCATION STUDENTS, 13th International Technology, Education and Development Conference
          * 2019-03, RESTYLING THE HIGHER EDUCATION LANDSCAPE: REGIONAL (A)SYMMETRIES ACROSS PORTUGAL
          * 2018-11, AS BASIC DESIGN PROMOTES THE DESIGN LEARNING: FEATURING THE PORTUGUESE HIGHER EDUCATION SETTING
          * 2018-09, The Marquis of Pombal reforms in accounting and today´s implications, XVIII Encuentro Internacional AECA
          * 2018-07, WHAT MAKES THE DIFFERENCE IN STUDENTS’ SOFT SKILLS DEVELOPMENT: AN ANALYSIS OF LPA RESULTS
          * 2018-07, WHAT ACTUALLY MATTERS IN A PHILOSOPHY CURRICULUM?
          * 2018-07, TEACHING PSYCHOLOGY OR TEACHING EDUCATION? THE HIDDEN TRUTH BEHIND THE LEARNING OUTCOMES
          * 2018-07, NAVIGATING ROUND HIGHER EDUCATION DEGREES: A CROSS COMPARISON OF BACHELOR, MASTER AND PHD LEARNING OUTCOMES
          * 2018-07, DROP-OUT AND COMPLETION AMONG PORTUGUESE STUDENTS
          * 2018-07, CREATIVITY IS INTELLIGENCE HAVING FUN: IS CREATIVITY A REAL LEARNING OUTCOME OF HIGHER EDUCATION?
          * 2018, WHAT IS BEST FOR FUTURE ACCOUNTANTS PROFESSIONAL SUCCESS: AN INTERNSHIP OR A BUSINESS PROJECT?
          * 2018, KEY SKILLS TO BE AN ACCOUNTANT: THE GAP BETWEEN THE LEARNING OUTCOMES AND THE OPINION OF THE PRACTITIONERS ACCOUNTANTS
          * 2018, Is Portuguese higher education developing students capacities for innovation? The truth behind learning outcomes
          * 2018, Basic Design at IADE: Drawing the line, Design Doctoral Conference¿18: TRANSgression
          * 2017-11, ACADEMIC QUALIFICATIONS ON THE CERTIFIED PUBLIC ACCOUNTANT PROFESSION
          * 2017, The impact of a Virtual Reality-based tool on a Basic Design rooted discipline: early perceptions, Design Doctoral Conference¿17: TRANScendency
          * 2017, The Impact of a Virtual Reality-based Tool on a Basic Design Tooted Discipline: Early perceptions, Design Doctoral Conference¿17: TRANScendency
          * 2017, TRANSLATING CRITICAL THINKING SKILLS TO HIGHER EDUCATION PRACTICES
          * 2017, TRAINING ACCOUNTING STUDENTS TO ACT ETHICALLY: THE BALANCE BETWEEN ACADEMIC KNOWLEDGE AND SOFT SKILLS
          * 2017, MORE COMPETENT AND MORE EQUAL: HIGHER EDUCATION AS A SUPPORTER OF SOFT SKILLS DEVELOPMENT
          * 2017, MANAGING RESEARCH OR MANAGING KNOWLEDGE? A DEVICE TOOL FOR QUALITY ASSURANCE
          * 2017, LIFELONG LEARNING AS A CRUCIAL VECTOR FOR DESIGNING HIGHER EDUCATION CURRICULA
          * 2017, LEARNING OUTCOMES IN HIGHER EDUCATION: DESIGNING A CONCEPTUAL MAP FOR PORTUGUESE ACADEMIA
          * 2017, LEARNING OUTCOMES AND EMPLOYABILITY: A CASE STUDY ON MANAGEMENT ACADEMIC PROGRAMMES
          * 2017, HIGHLIGHTING ENTREPRENEURSHIP SKILLS IN ACADEMIC CURRICULA: “I STILL HAVEN'T FOUND WHAT I'M LOOKING FOR”
          * 2017, A BLIND DATE BETWEEN ACADEMIC CURRICULUM AND JOB MARKET: THE STRATEGIC ROLE OF SOFT SKILLS
          * 2016, RETRIEVING CIVIC DIMENSIONS IN HIGHER EDUCATION CURRICULA: IS LEARNING IMPROVING STUDENTS’ CIVIC DEVELOPMENT?
          * 2016, DESIGN LEARNING OUTCOMES IN PORTUGUESE HIGHER EDUCATION CURRICULA: HOW ARE THEY DEFINED AND IMPLEMENTED?
          * 2016, Basic Design meets Virtual Reality: A tentative methodology, Design Doctoral Conference¿16: TRANSversality

        Resumo em conferência

          * 2020-06-26, DOES PARENTAL INVOLVEMENT REALLY MAKE A DIFFERENCE? A STUDY WITH PARENTS OF PRIMARY SCHOOL STUDENTS IN URBAN CONTEXT, International Conference on Education and New Developments 2020

        Outra produção

          * 2019-07, WORK WITH QUALITY FOR A QUALITY WORK IN HIGHER EDUCATION: ACADEMICS’ PERCEPTIONS
          * 2019-07, TRANSITION TO HIGHER EDUCATION AS A LIFE UPGRADE
          * 2019-07, THE GAP BETWEEN REAL AND DESIRED STUDENTS: INSTITUTIONAL STRATEGIES TO MANAGE HETEROGENEITY IN AN ENGINEERING SCHOOL
          * 2019-07, TECHNOLOGY RESOURCES FOR SOCIAL AND PSYCHOLOGICAL ASSESSMENT IN CHILDHOOD: EXPLORATORY STUDY OF “GPS4SUCCESS” APP FOR USE IN SCHOOL SETTINGS
          * 2019-07, PUBLIC-PRIVATE HIGHER EDUCATION INSTITUTION CHOICE: QUALITY OR CONVENIENCE?
          * 2019-07, EARLY IDENTIFICATION OF STUDENTS AT RISK OF SUCCESS/FAILURE IN PRIMARY EDUCATION: NEEDS, CHALLENGES AND GOALS OF A LONGITUDINAL ASSESSMENT
          * 2019-07, AN APPROACH TO UNIVERSITY SOCIAL RESPONSIBILITY AS FORERUNNER OF STUDENTS’ SATISFACTION
          * 2019-03, HOW BUSINESSMEN ARE TRAINED TO LEARN TO KNOW, TO DO, TO BE AND TO LIVE TOGETHER? DELORS’ FOUR PILLARS OF LEARNING UNDER ANALYSIS
          * 2017, Peer Instruction in Higher Education
          * 2017, Learning Outcomes in European Higher Education
          * 2011, Implementação de learning outcomes : a experiência recente em Portugal, Grupo de Investigación en Psicoloxia do desenvolvemento e da aprendizaxe escolar - Universidade da Coruña (GIPDAE). CER. Xunta de Galicia - Consellería de Educación e Ordenación Universitaria (Secretaría Xeral). Ministerio de Educación y Ciencia Coruña. Base de Datos - ISOC. Fundación Universidade da Coruña. Ayuntamiento de La Coruña - Consello de A Coruña. Universidade do Minho

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona