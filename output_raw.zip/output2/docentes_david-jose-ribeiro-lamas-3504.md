# Response for https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
          PT: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504 EN: https://www.ulusofona.pt/en/teachers/david-jose-ribeiro-lamas-3504
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
        fechar menu : https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/david-jose-ribeiro-lamas-3504
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          David Lamas

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3504
              dav***@acm.org
              F31E-D02F-DD58: https://www.cienciavitae.pt/F31E-D02F-DD58
              0000-0003-0295-453X: https://orcid.org/0000-0003-0295-453X
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/c7fdcc58-7a88-476b-a82a-04c6262215eb
      : https://www.ulusofona.pt/

        Graus

            * Doctor of Philosophy
              Computing
            * Mestrado
              Informática (Ciências da Computação)
            * Licenciatura
              Informática (Matemáticas Aplicadas)
            * Postgraduate Certificate
              Dirección Estratégica de las Universidades
            * Postgraduate Certificate
              Dirección Estratégica: gestión del cambio e implicación de la comunidad en los objectivos estratégicos
            * Doctor of Philosophy
              Computer Science

        Publicações

        Journal article

          * 2023, Towards Context-Aware Facial Emotion Reaction Database for Dyadic Interaction Settings, Sensors
          * 2023, Automatic reaction emotion estimation in a human-human dyadic setting using Deep Neural Networks, Signal, Image and Video Processing
          * 2021, Psychophysiological Modeling of Trust in Technology: Influence of Feature Selection Methods, Proceedings of the ACM on Human-Computer Interaction
          * 2021, Moving from VR into AR using bio-cybernetic loops and physiological sensory devices for intervention on anxiety disorders, Virtual Reality
          * 2020-04-22, A Systematic Literature Review on Existing Digital Government Architectures: State-of-the-Art, Challenges, and Prospects, Administrative Sciences
          * 2020, Measuring trust with psychophysiological signals: A systematic mapping study of approaches used, Multimodal Technologies and Interaction
          * 2019-10-02, A Systematic Mapping Study of HCI Practice Research, International Journal of Human–Computer Interaction
          * 2019, Design, development and evaluation of a human-computer trust scale, Behaviour and Information Technology
          * 2018, Exploring the State of Human-centred Design Practice in Software Development Companies: A Cross-Case Analysis of Three Nigerian Software Companies, Interacting with Computers
          * 2017, Computer Supported Qualitative Research Preface, Mathematics of the Uncertain: a Tribute to Pedro Gil
          * 2016, Theory, Practice and Policy: An Inquiry into the Uptake of HCI Practices in the Software Industry of a Developing Country, International Journal of Human-Computer Interaction
          * 2014, Reflection on the role of semiotic engineering in co-design of interaction, IEEE Latin America Transactions
          * 2014, A Model for Human-Computer Trust Contributions Towards Leveraging User Engagement, Lecture Notes in Computer Science
          * 2013, Promoting Human-Computer Interaction Values and Practices in Small and Emerging Economies, Lecture Notes in Computer Science
          * 2013, Mobile Access to Digital Libraries in Developing Countries: A Reflection on Motives, Options and Sustainability, INTERNATIONAL CONFERENCE ON CYBER SCIENCE AND ENGINEERING (CYBERSE)
          * 2012, Brain edema in diseases of different etiology, Neurochemistry International
          * 2011, Exploring the Effects of Enabling Web 2.0 in e-Government Services, 2011 Ieee International Conference on Information Reuse and Integration (Iri)
          * 2010, Learning Flow Management and Semantic Data Exchange between Blog-Based Personal Learning Environments, Hci in Work and Learning, Life and Leisure
          * 2001, WEB3D: modelos 3D na world wide web

        Book

          * 2019, Foreword, Zaphiris, P.; Lamas, D.
          * 2019, Foreword, Zaphiris, P.; Lamas, D.
          * 2019, Foreword, Zaphiris, P.; Lamas, D.
          * 2019, Foreword, Zaphiris, P.; Lamas, D.
          * 2017, Preface, Costa, A.P.; Reis, L.P.; de Sousa, F.N.; Moreira, A.; Lamas, D.
          * 2017, Modelling trust: An empirical assessment, Gulati, S.; Sousa, S.; Lamas, D.
          * 2017, Assessment model for HCI practice maturity in small and medium sized software development companies, Ogunyemi, A.; Lamas, D.; Stage, J.; Lárusdóttir, M.
          * 2015, HCI practices in the Nigerian software industry, Ogunyemi, A.; Lamas, D.; Adagunodo, E.R.; Da Rosa, I.B.
          * 2015, Current state of HCI practice in the Estonian software development industry, Ogunyemi, A.; Lamas, D.; Sarapuu, H.; da Rosa, I.B.
          * 2014, Trust for supporting learning creativity in online learning communities, Sousa, S.; Lamas, D.; Toming, K.
          * 2014, Towards a design space for ubiquitous computing, Shmorgun, I.; Lamas, D.
          * 2014, Timeliner: Supporting collaborative scientific writing, Tomberg, V.; Lamas, D.; Laanpere, M.; Sillaots, M.
          * 2014, Situating a design space for sustainable software appropriation, Arakelyan, A.; Lamas, D.
          * 2014, Preface, Lamas, D.; Buitelaar, P.; Larsen, B.; Bogers, T.
          * 2014, Identifying intention and perception mismatches in digitally augmented museum settings, Pender, H.-L.; Lamas, D.
          * 2014, Exploring creativity with e-learning 2.0: A personal account, Toming, K.; Lamas, D.
          * 2014, Design artefacts as business decision prompts: Tackling the design and business values gap, Kwiatkowska, J.; Szóstek, A.; Lamas, D.
          * 2014, A model for human-computer trust: Contributions towards leveraging user engagement, Sousa, S.; Lamas, D.; Dias, P.
          * 2013, Mobile and federated access to DSpace-based digital libraries, Da Rosa, I.B.; Lamas, D.R.
          * 2012, Using digital and traditional libraries in developing countries, Da Rosa, I.B.; Ribeiro Lamas, D.; Peña Saavedra, V.
          * 2011, Interrelation between trust and sharing attitudes in distributed personal learning environments: The case study of LePress PLE, Sousa, S.C.; Tomberg, V.; Lamas, D.R.; Laanpere, M.

        Book chapter

          * 2023, Trust in Facial Recognition Systems: A Perspective from the Users
          * 2023, Towards Cross-Cultural Assessment of Trust in High-Risk AI
          * 2023, Body-Centric Vibrotactile Display for Social Support During Public Speaking
          * 2023, Be Me Vest - Exploring the Emotional Effects of Music and Sound-Based Vibrotactile Stimuli
          * 2021, Wearable Confidence — Concept and Prototype Design, Springer International Publishing
          * 2019, VibroSquare: Vibro-Tactile Display for Body-Centric Implicit Interactions, Springer International Publishing
          * 2019, Vibro-Tactile Implicit Interactions: So What?, Springer International Publishing
          * 2019, Initial Steps Towards Infrastructuring Body-Centric Computing, Springer International Publishing

        Conference paper

          * 2023-11-27, Unmasking Trust: Examining Users' Perspectives of Facial Recognition Systems in Mozambique
          * 2023-02-26, Vibmory - Mapping Episodic Memories to Vibrotactile Patterns
          * 2021, Psychophysiological modelling of trust in technology: Comparative analysis of psychophysiological signals
          * 2021, Psychophysiological modelling of trust in technology: Comparative analysis of algorithm ensemble methods
          * 2020, Risk and trust in artificial intelligence technologies: A case study of autonomous vehicles
          * 2020, Desired Content versus Digital Advertisements: An Eye-Tracking User Experience Study
          * 2019, Towards an empirically developed scale for measuring trust
          * 2019, The Challenging Front Ends of Accelerated Transdisciplinary Design Processes
          * 2019, Predictive model to assess user trust: A psycho-physiological approach
          * 2019, Augmented reality and sensory technology for treatment of anxiety disorders
          * 2018, Towards development of a reference architecture for E-government
          * 2018, The interplay between emotion and trust in technology
          * 2018, Taxonomies in DUI design patterns
          * 2018, Scaffolding students on connecting STEM and interaction design: Case study in Tallinn University Summer School
          * 2018, Modelling trust in human-like technologies
          * 2018, How to tame a transdisciplinary interaction design process
          * 2017, The BrainHack project: Exploring art - BCI hackathons
          * 2017, Aesthetic categories of interaction: Aesthetic perceptions on smartphone and computer
          * 2016, Understanding aesthetics of interaction: A repertory grid study
          * 2016, Towards a pattern language for distributed user interfaces
          * 2016, Loyalty theory flashcards as a design tool in a design research project a case study of the food delivery app.
          * 2016, Do contexts make a difference? Software practitioners' perspectives on HCI practice and integration to software engineering processes
          * 2016, Current health records practices in Afghanistan and possible future development
          * 2015, Methods for human-computer interaction research
          * 2015, Exploring the use of the human-Artifact model for studying ubiquitous interactions
          * 2015, Challenges and opportunities in ehealth: The Afghan Case
          * 2015, Applying generative techniques to avoid technology push effect in ideas and prototypes created by technology-oriented people
          * 2015, Aesthetics of interaction design: A literature review
          * 2014, Workshop: Mapping and bridging the design and business gap
          * 2014, Readiness of Afghan government for the deployment of e-government solutions
          * 2014, Interplay between human-computer interaction and software engineering
          * 2014, Evaluating aesthetics during interaction episodes
          * 2014, Design artefacts as service design concepts- A case study from a telecommunication domain
          * 2014, Design and business gaps: From literature to practice
          * 2014, Assessing HCI-related practices, needs and expectations of estonian software companies
          * 2014, A model for Human-computer trust: A key contribution for leveraging trustful interactions
          * 2014, A model for Human-computer Trust A key contribution for leveraging trustful interactions
          * 2014, A design space for trust-enabling interaction design
          * 2014, (Un)structured sources of inspiration: Comparing the effects of game-like cards and design cards on creativity in co-design process
          * 2013, The evaluation of interface aesthetics
          * 2013, Leveraging engagement and participation in e-learning with trust
          * 2013, Foundations for the reconceptualization of the e-textbook
          * 2013, Facilitation of sustainability through appropriation-enabling design
          * 2013, Exploring the role of the semiotic engineering in interaction co-design
          * 2013, A sample of technology substitution
          * 2012, The implications of trust on moderating learner's online interactions: A socio-technical model of trust
          * 2012, Enhancing learning analytics in distributed personal learning environments
          * 2012, Enabling mobile access to digital libraries in digital divide contexts
          * 2012, Designing mobile access to DSpace-based digital libraries
          * 2012, Building digital libraries in developing countries
          * 2012, Bringing DSpace-based digital libraries into mobile devices
          * 2012, A conceptual model for collaborative scientific writing
          * 2011, Trustful online learning communities
          * 2011, Trust in distributed personal learning environments: The case study of lepress PLE
          * 2011, Towards the design of Estonia's m-Government Services
          * 2011, Towards a comprehensive call ontology for research 2.0
          * 2011, The interrelation between communities, trust and their online social patterns
          * 2011, Minu Viljandi: A case study on the effects of introducing Web 2.0 features in e-government services on the overall user experience perception
          * 2011, Emerging trust patterns in online communities
          * 2011, AM I WILLING TO RELATE ONLINE? A COMPREHENSIVE UNDERSTAND OF E-LEARNING CONTEXTS
          * 2011, A framework for understanding online learning communities
          * 2009, Use of digital versus traditional libraries in info-exclusive context,Uso de bibliotecas digitais versus tradicionais em contexto de info-exclusão
          * 2007, Digital libraries in the developing countries
          * 2007, Building digital libraries in info-exclusion contexts: The case of the Jean Piaget University of Cape Verde,Construção de bibliotecas digitais em contextos de info-exclusão: O caso da Universidade Jean Piaget de Cabo Verde
          * 2006, An academic information system for the Jean Piaget University of Cape Verde,Um sistema de informação académico para a universidade jean piaget de cabo verde
          * 2001, Mapping the semantic asymmetries of virtual and augmented reality space
          * 2000, An empirical study on the usability of an information navigation aid

        Other output

          * 2017, Shaping loyalty: Experiences from design research practice
          * 2016-07-05, Stepping into the Era of Personal Big Data: a Roadmap to the Design of a Personal Digital Life Coach (Preprint)

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona