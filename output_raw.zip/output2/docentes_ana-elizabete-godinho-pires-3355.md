# Response for https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
          PT: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355 EN: https://www.ulusofona.pt/en/teachers/ana-elizabete-godinho-pires-3355
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
        fechar menu : https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-elizabete-godinho-pires-3355
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ana Elisabete Pires

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3355
              p33***@ulusofona.pt
              FB19-697F-5944: https://www.cienciavitae.pt/FB19-697F-5944
              0000-0002-1118-8569: https://orcid.org/0000-0002-1118-8569
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/58f1405e-a246-4d7d-b6bc-fbc505f21e59
      : https://www.ulusofona.pt/

        Resume

        Population Genetics and Phylogenetics have been the area of my scientific research. For the last few years, I have been interested in understanding the genetic variability, population structure, and phylogeography of a very particular human domesticate species-the domestic dog, from two interesting geographic areas - the Iberian Peninsula and North-West Africa. Why dog breeds? Because 1) domestic dog is one of the most interesting domesticated species, 2) peripheral dog breeds such as the ones from the Iberia Peninsula and North Africa, have been poorly studied and 3) these represent a great case study to address issues such as local domestication, processes of local hybridization post-domestication and movement of animals associated with human migrations. The origin of these breeds, their genetic structure, and phylogenetic affinities with other breeds and the Iberian wolf have been my favorite research topics. I have developed skills and expertise in the area of ancient DNA analysis to be able to understand dog origin and its evolutionary trajectory in Iberia and North Africa, and headed and collaborated on multiple projects aiming at these research topics. I have also developed activity in the area of Conservation Biology, through the application of non-invasive molecular methods for wild species monitorization (Iberian lynx and Iberian wolf). I am also interested in the area of Immunology and Education, and recently I was the principal scientific researcher responsible for the development of the ImunoGénius Kit (Association of Portuguese Biologists) aiming students and teachers of secondary level schools for the learning and teaching of Immunology and the importance of vaccination. I also have competences as a lecturer. As Assistant Professor I teach "Genetics and Animal Improvement", "Immunology", "Genetics Applied to Veterinary Sciences" and "Biochemistry" to students of Veterinary Medicine and Biology courses at Universidade Lusófona-Centro Universitário de Lisboa since 2008. Regularly, I participate in the European Night of Researchers and other Festivals/Science Fairs and I have been invited to present talks and prepare hands-on activities about Animals & Domestication for primary school students (Ciência Viva). My activities in Science have been awarded a few times: Special Award from the jury for the the movie "The Muge dog - a pre-historic friend" - contest for the best 2020 Educational Resource - Casa das Ciências Award, awarded in 2021 (Portugal); 1st Award ex aequo for the short illustrated movie "The Muge Dog a pre-historic friend" awarded in 2020 (Ciencia en Acción, Spain); Mulher Ciência Viva Award, awarded in 2019 (Ciência Viva, Portugal) and Ágora prize for ImunoGénius Kit awarded in 2016 (Ciencia en Acción, Spain)

        Graus

            * Licenciatura
              Biologia Aplicada aos Recursos Animais
            * Mestrado
              Bioquímica
            * Doutoramento
              Molecular Biology

        Publicações

        Magazine article

          * 2004, Aspetos demográficos do Rafeiro do Alentejo, Os Nossos Cães
          * 2004, Aspetos demográficos das raças caninas autóctones portuguesas, Os Nossos Cães
          * 2004, Aspetos demográficos da raça Podengo Português, Os Nossos Cães
          * 2004, Aspetos demográficos da raça Perdigueiro Português, Os Nossos Cães
          * 2004, Aspetos demográficos da raça Cão de Água Português, Os Nossos Cães
          * 2004, Aspetos demográficos da raça Cão de Fila de São Miguel, Os Nossos Cães
          * 2004, Aspetos demográficos da raça Cão de Castro Laboreiro., Os Nossos Cães
          * 2004, Aspetos demográficos da raça Cão da Serra de Aires, Os Nossos Cães
          * 2004, Aspetos demográficos da raça Cão da Serra da Estrela da variedade de pelo curto, Os Nossos Cães
          * 2004, Aspetos demográficos da raça Cão da Serra da Estrela da variedade de pelo comprido, Os Nossos Cães

        Journal article

          * 2023-01-13, Genome-wide assessment of the population structure and genetic diversity of four Portuguese native sheep breeds, Frontiers in Genetics
          * 2023, Genomic Analyses of Iron Age Cattle Specimens from Althiburos, Tunisia, Support an Independent and Local Origin of African Taurine Cattle in the Maghreb (accepted) (Authors: C.Ginja, S.Guimarães, R.da Fonseca, R.Rasteiro, R.Rodríguez-Varela, L. G.Simões, C.Sarmento, M.C.Belarte, N.Kallala, J.R.Torres, J. Sanmartí, A.M.Arruda, C.Detry, S.Davis, J.Matos, A.Götherström, A.E.Pires, S.Valenzuela-Lamas, iscience
          * 2023, Genome sequencing of 2000 canids by the Dog10K consortium advances the understanding of demography, genome function and architecture (Authors: Meadows et al), Genome Biology
          * 2022-05, The Facial Reconstruction of a Mesolithic Dog, Muge, Portugal (Cicero Moraes, Hugo Matos Pereira, João Filipe Requicha, Lara Alves, Graça Alexandre-Pires, Sandra de Jesus, Silvia Guimarães, Catarina Ginja, Cleia Detry, Miguel Ramalho, Ana Elisabete Pires), Applied Sciences
          * 2022, The potential of computed tomography in odontometry: application to a Mesolithic dog (Authors: Hugo Matos Pereira, João Filipe Requicha, Lara Alves, David Gonçalves, Joana Belo Correia, Graça Alexandre-Pires, Sandra de Jesus, Carlos Viegas, Miguel Ramalho, Catarina Ginja, Cleia Detry, Ana Elisabete Pires), Journal of Archaeological Science: Reports
          * 2022, Caracterização imagiológica do esqueleto apendicular do porco em idade pediátrica, Revista Portuguesa de Ciências Veterinárias
          * 2022, A multidisciplinary study of Iberian Chalcolithic dogs (L Blaschikoff, A Daza-Perea, J Requicha, C Detry, R Rasteiro, S Guimarães, I Ureña, O Serra, R Schmidt, A Valera, NJ. Almeida, E Porfírio, AB Santos, C Delicado, Simões, JA Matos, I Rosário Amorim, F Petrucci-Fonseca, S J. M. Davis, A Muñoz-Merida, A Götherström, C Fernández-Rodríguez, JL Cardoso, C Ginja, AE Pires), Journal of Archaeological Science: Reports
          * 2020-02, Dental pathology of the wild Iberian wolf (Canis lupus signatus): the study of a 20th century Portuguese museum collection, Veterinary and Animal Science
          * 2019-05-03, Consequences of breed formation on patterns of genomic diversity and differentiation: the case of highly diverse (Rute R. da Fonseca, Irene Ureña, Sandra Afonso, Ana Elisabete Pires, Emil Jørsboe, Lounès Chikhi & Catarina Ginja) peripheral Iberian cattle, BMC Genomics
          * 2019-05, The curious case of the Mesolithic Iberian dogs: An archaeogenetic study (A.E. Pires, C. Detry, L. Chikhi, R. Rasteiro, I.R. Amorim, F. Simões, J.Matos, F. Petrucci-Fonseca, M. Ollivier, C. Hänni, J.L. Cardoso, P. Arias, M.Diniz, A.C. Araújo, N.Bicho, A.C. Sousa, A.M. Arruda, C. Fernández-Rodríguez, E. Porfírio. C. Ginja), Journal of Archaeological Science
          * 2018-03, Roman dogs from the Iberian Peninsula and the Maghreb - A glimpse into their morphology and genetics, Quaternary International
          * 2017-12, Cremation under fire: a review of bioarchaeological approaches from 1995 to 2015, Archaeological and Anthropological Sciences
          * 2017-06-11, New insights into the genetic composition and phylogenetic relationship of wolves and dogs in the Iberian Peninsula, Ecology and Evolution
          * 2015, Testes moleculares no apoio à clínica veterinária
          * 2013, Treatment with low doses of polyclonal immunoglobulin improves B cell function during immune reconstitution in a murine model, Journal of Clinical Immunology
          * 2013, Evidencia de mejoras de ovino y vacuno durante época andalusí y cristiana en Portugal a partir del análisis zooarqueológico y de ADN antiguo
          * 2013, Broadened T-cell repertoire diversity in ivIg-treated SLE patients is also related to the individual status of regulatory T-cells, Journal of Clinical Immunology
          * 2012, Molecular and osteometric sexing of cattle metacarpals: a case study from 15th century AD Beja, Portugal, Journal of Archaeological Science
          * 2010, Treatment With Polyclonal Immunoglobulin During T-cell Reconstitution Promotes Naive T-cell Proliferation, Journal of Immunotherapy
          * 2009, Molecular structure in peripheral dog breeds: Portuguese native breeds as a case study, Animal Genetics
          * 2009, A multiplex snapshot assay for detection of Y-chromosome SNPs in dogs and the Iberian wolves. , Arch. Zootec.
          * 2006, Mitochondrial DNA sequence variation in Portuguese native dog breeds: diversity and phylogenetic affinities, Journal of Heredity
          * 2003, Last lynxes in Portugal? Molecular approaches in a pre-extinction scenario [Author: Pires, A., Fernandes, M.], Conservation Genetics
          * 2000, Livestock Guarding Dogs and Wolf Conservation in Portugal, Galemys

        Thesis / Dissertation

          * 2006-11-22, PhD, Phylogeny, Population Structure and Genetic Diversity of Dog Breeds in the Iberian Peninsula and North Africa

        Book chapter

          * 2022, A study on Burrows-Wheeler Aligner´s performance optimization for ancient DNA mapping (Authors: Cindy Sarmento, Sílvia Guimarães, Gülsah Merve Kilinç, Anders Götherström, Ana Elisabete Pires, Catarina Ginja, and Nuno A. Fonseca), Practical Applications of Computational Biology & Bioinformatics, 15th International Conference (PACBB 2021), Springer
          * 2021, On the improvement of cattle (Bos taurus) in the cities of Roman Lusitania: some preliminary results (Detry, Cleia; Valenzuela-Lamas, Silvia; Davis, Simon J.M.; Pires, Ana Elisabete; Ginja, Catarina), Cattle and People: Interdisciplinary approaches to an ancient relationship, Lockwood Press
          * 2021, Genomic analysis of cattle from the Roman Republican fortification of Chibanes, Palmela, Portugal (Authors: Ferreira, M.L.; Silvia de Lima Guimaraes Chiarelli ; Soares, J.; Tavares da Silva, C.; Detry, Cleia; Valenzuela-Lamas, Silvia; Götherström, A.; Pires, A. E.; Ginja, C., O Castro de Chibanes na conquista Romana. Intervenções arqueológicas de 1996 a 2017, MAEDS/AMRS-Museu de Arqueologia e Etnografia do Distrito de Setúbal/Associação de Municípios da Região de Setúbal, 2021.
          * 2021, An Archaeogenetic Study of Cattle Bone from seventeenth century Carnide, Lisbon, Portugal (Ureña, Irene; Guimaraes, Silvia; Davis, Simon J.M.; Detry, Cleia; da Fonseca, Rute; Dussex, Nicolas; Simões, Luciana; et al.), Cattle and People: Interdisciplinary approaches to an ancient relationship, Lockwood Press
          * 2004, Contributo para a caracterização genética e evolução demográfica do Cão de Fila de S. Miguel , O Cão de Fila de S. Miguel , Câmara Municipal de Vila Franca do Campo, Vila Franca do Campo
          * 2001, Genética das cores da pelagem (Genetics of fur colour), O Podengo Português (The Portuguese Warren hound), Anex III , author

        Edited book

          * 2020, Oxbow Books, Lda

        Online resource

          * 2023-06-16, Seria assim o cão de Muge? Uma tentativa de reconstrução facial de um achado arqueológico com 7,600 anos (Portugal) (Authors: Cicero Moraes, Hugo Matos Pereira, João Filipe Requicha, Lara Alves, Graça Alexandre-Pires, Sandra de Jesus, Silvia Guimarães, Catarina Ginja, Cleia Detry, Miguel Ramalho, Ana Elisabete Pires, https://drive.google.com/file/d/1fb_Puu63eT33Ls7g7BJlKkAbdME6JkNX/view
          * 2023-06-16, Esqueleto de Sus scrofa domesticus em idade pediátrica - um contributo digital para a colecção osteológica de referência do LARC (Ana Elisabete Pires, Sónia Gabriel, Dulce Ferreira, Maria Soares, Mariana Batista, Margarida Alves, Rute Canejo-Teixeira, Ana Santana, Giovana Braga, Joana Catita, https://www.youtube.com/watch?v=rT9fXT_A3jQ

        Website

          * 2022, Woof Project, TRACING THE ORIGINS AND EVOLUTIONARY PATHS OF THE IBERIAN AND THE MAGHREB DOG No encalce das origens e evolução do cão na Ibéria e no Magrebe, woofproject.wordpress.com/

        Conference poster

          * 2023-10-10, Getting to know ancient dogs through a genomic approach (accepted) (Authors: Mahaut Goor, Ludmilla Blaschikoff , Silvia Guimarães, Octávio Serra, Fernanda Simões, Cleia Detry, Macarena Bustamante-Álvarez, Stéphanie Brehard, Adrian Balasescu, Hossein Davoudi, Marjan Mashkour, Regis Debruyne, Christophe Hitte, Catarina Ginja, Ana Elisabete Pires, Morgane Ollivier), 10th ICAZ AGPM (International Council for Archaeozoology- Archaeozoology, Genetics, Proteomics and Morphometrics working group)
          * 2023-05-19, Iberian dogs - a diachronic genomic analysis (Authors: na Elisabete Pires, Ludmilla Blaschikoff, Silvia Guimarães, Mahaut Goor, Octávio Serra, Fernanda Simões, Cleia Detry, Catarina Ginja), FMVetResearch meeting II
          * 2022-11, Canine humerus supratrochlear foramen morphological study (Authors: Joana Catita, Eduardo Marcelino, Mariana Batista, Giovana Braga, Brunna Ciobanu, Luísa Mendes-Jorge, Graça Pires, Cleia Detry, Sónia Gabriel, Dulce Ferreira, Ana Elisabete Pires), Innovation in Animal, Veterinary and Biomedical Research
          * 2022-09-28, Identifying young-aged animal remains: the case of Rua da Sé, a Medieval Islamic context in Silves, Portugal (Authors: Pires AE, Valente MJ, Gabriel S, Ferreira D, Soares M, Batista M, Alves M, Canejo-Teixeira R, Santana A, Braga G, McGrath KM, Ginja C, Guimarães S, Catita J), 1st ICAZ Medieval Period Working Group Meeting (Bergen, Noruega)
          * 2022-08-14, Genomes of ancient iberian dogs - a story with at least 7,600 years (Authors: S.Guimarães, R.Schmidt, C.Detry, L.Blaschikoff, M.Diniz, P.Arias, N.Bicho, J.L.Cardoso, A.C.Sousa, M.Moreno-García, C.Fernández-Rodríguez, A.Beltrán-Ruiz, J.A.Riquelme-Cantal, A.Gonçalves, S.J.M. Davis, M.Bustamante-Álvarez, F.Heras, A.Götherström, C.Ginja, A.E.Pires), Congress of the European Society for Evolutionary Biology
          * 2021, We must talk about Iberia! -an overview of ancient domestic animals through DNA analysis (Pires, Ana Elisabete; Guimaraes, Silvia; Ureña, Irene; Simões, Luciana; Detry, Cleia; Davis, S.J.M.; Luís, Cristina; et al.), 2º Encuentro de Zooarqueología Ibérica - EZI
          * 2021, Mitogenome analysis of cattle from the Roman Republican fortification of Chibanes, Palmela, Portugal (Authors: Leonor Ferreira; Silvia de Lima Guimaraes Chiarelli (FE19-D7B4-3750); Joaquina Soares; Carlos Tavares da Silva; Detry, Cleia; Anders Götherström; Ana Elisabete Pires; Ginja, Catarina), Encontro de Investigação Jovem Universidade do Porto.
          * 2019-11-14, Unraveling the genomes of ancient Iberian Canis (Authors: L Blaschikoff, O Serra, JL Cardoso, C Fernández-Rodríguez, AC Sousa, M Moreno-Garcia, S Guimarães, F Simões, C Detry, A Götherström, C Ginja, AE Pires, XV ENBE (Portuguese Meeting of Evolutionary Biology)
          * 2019, Iberian Chalcolithic Canis: a genomic approach to know them better (Authors: L Blaschikoff, O Serra, JL Cardoso, C Fernández-Rodríguez, Ana C Sousa, M Moreno-Garcia, S Guimarães, F Simões, C Detry, E Ferreira, A Götherström, C Ginja, AE Pires, 8th meeting of the ICAZ Archaeozoology, Genetics, Proteomics and Morphometrics (AGPM) Working Group
          * 2019, Bioinformatic tools in the study of ancient dogs: preliminary results of an Iberian case study, Bioinformatics Open Days
          * 2014-07, "Sharing of maternal lineages between aurochs and domestic cattle in the Iberian Peninsula: introgression and/or local domestication? (Authors: C Ginja, S Davis, A E Pires, J Matos, C Fernandez, C Hänni, E Svensson and A Götherström) , 34th International Society for Animal Genetics Conference, (Xi'an, China, July 2014).
          * 2010, Tracing back animal domestication in Iberia: clues from zooarchaeology and ancient DNA - a project (authors: C Ginja, IR Amorim, JL Cardoso, C Detry, S Davis, J Matos, F Simões, P Sá-Pereira, D Mendonça, F Petrucci-Fonseca, L Gama, Penedo C Penedo, L Chikhi, A Gotherstrom, E Svensson, M Gautier, C Hanni, AE Pires), 11th International Conference of Archaeozoology - ICAZ (Paris, France).
          * 2010, Improvement of Portuguese cattle by the Christians following the evidence based on osteometry and molecular sexing¿ (authors: S Davis; E Svensson; C Ginja; C Detry; IR Amorim; A Gotherstrom; U Albarella; AE Pires) , VI Encontro Nacional de Biologia Evolutiva, (Lisboa, Portugal)
          * 2010, Immunoglobulin treatment improves reconstitution of B cell compartment after autologous stem cell transplantation (ASCT) (authors: Justo, L., Afonso, A.F., Queirós, A.C., Fesel, C., Pires, A.E., João, C.), 15th Congress of European Hematology Association (EHA) (Barcelona, Spain)
          * 2010, A research project on zooarchaeogenetics: tracing back animal domestication and breeding in Iberia (authors: C Ginja; IR Amorim; JL C; C Detry; S Davis; J Matos; F Simões; P Sá Pereira; D Mendonça; F Petrucci-Fonseca; L Gama; C Penedo; L Chikhi; A Gotherstrom; E Svensson; M Gautier; C Hanni; AE Pires), VI Encontro Nacional de Biologia Evolutiva, (Lisboa, Portugal)
          * 2009, ALTERAÇÕES IMUNOLÓGICAS EM DOENTES COM LINFOMA NÃO HODGKIN B (LNH B) INDUZIDAS PELO TRATAMENTO COM POLIQUIMIOTERAPIA E RITUXIMAB. (Authors: Pires AE , Barahona AF, Caetano J, Francisco F, Silva MG, João C), Annual Meeting of The Portuguese Society of Hematology (Troia, Portugal)
          * 2008, PORTUGUESE NATIVE DOMESTIC DOG BREEDS – A MULTIDISCIPLINARY APPROACH TO THEIR CHARACTERIZATION (Authors: AE Pires, C Cruz, FP-Fonseca, J Matos, MW Buford), VI Iberian Congress on Animal Genetic Resources (Lisbon, Portugal) 2008.
          * 2008, CANINE Y-CHROMOSOME VARIABILITY IN THE IBERIAN PENINSULA (Autores: C Borges, F Simões, FP-Fonseca, J Matos, AE Pires), VI Iberian Congress on Animal Genetic Resources (Lisbon, Portugal)
          * 2007, The effect of infusion of polyclonal immunoglobulin or its fragments in the improvement of the immune reconstitution after autologous stem cells transplantation (ASCT) in a murine model (Authors: AE Pires, S. Cabral, S. Esteves, MG Silva, L. Porrata, SN Markovic, C. João), American Society of Hematology Meeting (Atlanta, GA, USA)
          * 2004, "Domestic dog - The oldest human domesticate. Multiple DNA-based approaches on the study of Portuguese dog breeds and their genetic affinities" (authors: Pires AE, Gomes M, Petrucci-Fonseca F & Bruford MW), 7th edition of Portugalia Genetica "Humans and other domesticates" (Oporto, Portugal)
          * 1998, "The Recovery of Livestock Guarding Dog Breeds: Analysis of Polymorphic Microsatellites" (authors: Pires AE, Ribeiro S and Petrucci-Fonseca F), 8th International Congress of the International Council for Archaeozoology, (ICAZ) (British Columbia-Canada).
          * 1996, “The use of TLC (Thin Layer Chromatography) for wolf and dog scats biochemical distinction” (authors: Pires AE, Reis A, Crespo A and Petrucci-Fonseca F), I Iberian Congress Biologists-Environment (Lisbon, Portugal)

        Other output

          * 2018-11-09, Consequences of breed formation on patterns of genomic diversity and differentiation: the case of highly diverse peripheral Iberian cattle
          * 2018, O Cão de Muge - um amigo pré-histórico (The Muge dog - a pre-historic friend) (digital animation short movie), Science divulgation - digital animation video This short digital animation film reflects the happy fusion between cinema and science. It tells the story of a dog who lived 7600 years ago - the oldest almost complete dog skeleton recorded so far from the Iberian Peninsula. Funded by Woof project (PTDC/HAR-ARQ/29545/2017 and POCI-01-0145-FEDER-029545).
          * 2015, ImunoGénius kit (laboratory kit, secondary school level), The ImunoGénius Kit from Association of Portuguese Biologists was created for students and teachers of the secondary level school. This kit allows laboratorial classes and the understanding of the positive effects of vaccination to stimulate the immune system. I was the principal scientific researcher responsible for the development of the ImunoGénius Kit

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona