# Response for https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
          PT: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211 EN: https://www.ulusofona.pt/en/teachers/andreia-de-almeida-rosatella-6211
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
        fechar menu : https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/andreia-de-almeida-rosatella-6211
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Andreia A. Rosatella

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6211
              and***@ulusofona.pt
              951B-491D-E79C: https://www.cienciavitae.pt/951B-491D-E79C
              0000-0002-2691-3110: https://orcid.org/0000-0002-2691-3110
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/4b9931d0-eafb-4bb9-9f06-f0a14aa9e69b
      : https://www.ulusofona.pt/

        Resume

        I am a synthetic chemist devoted to the development of smart materials for various applications, including drug delivery and for the general population protection from chemical or bio-hazards. One of the main goals of my research is to develop materials that are more sustainable, as well as biodegradable and biocompatible, with direct application to society. I'm currently an Assistant Professor in Universidade Lusófona. I have completed my Ph.D. degree in January 2011, from Instituto Superior Técnico ¿ University of Lisbon (IST-UL) where I have developed novel Ionic Liquids (ILs). For one year I was a research fellow in a ERA Chemistry project where I have developed different Magnetic Ionic Liquids (MILs). In 2012 I earned an FCT funded Post-doc grant and join the Bioorganic Chemistry group (iMed-ULisboa), where I have synthetized more than 100 structurally diverse ILs from mg to kg scale, resulting in different publications, in collaboration with different research groups. In 2018 I have join the Solid-State group from IST, a multidisciplinary research group focused on the study of selected new materials with unconventional electrical and magnetic properties. With the main goal of pursuing my scientific independence, I have join again iMed-ULisboa in 2019 as junior researcher, for the development of novel materials for biological application. From 2021, I have join CBIOS where I have been developing novel materials for biological application. Here at Lusófona, I had the opportunity to start a small group, where I supervised two researchers within the scope of two funded projects, and managed the acquisition of necessary equipment and reagents for the success of these projects. Since 2019, I've successfully obtained funding for research projects. I was the Principal Investigator (PI) for a project focusing on developing materials for dermal application using ILs. Since then, I've participated in a total of eleven funded projects, leading three national projects as PI and co-coordinating an international project funded by SPS-NATO. Works in the area(s) of Exact Sciences with emphasis on Chemical Sciences with emphasis on Organic Chemistry. In my professional activities interacted with 99 collaborator(s) co-authorship of scientific papers. In mycurriculum Ciência Vitae the most frequent terms in the context of scientific, technological and artistic-cultural output are: Ionic Liquids; Magnetic Ionic Liquids; green chemistry; organo-metal-catalysis; glycosidase inhibition; Antimalarials; Hybrid drugs; Chiral Ionic Liquids; Asymmetric Catalysis; Chiral Separations; Biocompatible Ionic Liquids; Flow chemistry; Becker-Adler Reaction; Green Chemistry.

        Graus

            * Licenciatura
              Química Aplicada
            * Doutoramento
              Chemistry

        Publicações

        Journal issue

          * Special Issue "Synthesis and Applications of Magnetic Ionic Liquids"
          * Abstract Book - InnovDelivery '22 - I Lusophone Meeting on Innovative Delivery Systems". Journal Biomedical and Biopharmaceutical Research

        Journal article

          * 2024-03-15, Anticancer Diterpenes of African Natural Products: Current Advances in Cancer Treatment, Phytomedicine
          * 2022-07-12, Stereoselective Synthesis and Isolation of (±)-trans,trans-Cyclohexane-1,2,4,5-tetraol, AppliedChem
          * 2022-03, One-Pot Transformation of Salicylaldehydes to Spiroepoxydienones via the Adler–Becker Reaction in a Continuous Flow, ACS Omega
          * 2022, Abstract Book - InnovDelivery '22 - I Lusophone Meeting on Innovative Delivery Systems, Journal Biomedical and Biopharmaceutical Research
          * 2021-09-22, Self-Assembly Nanoparticles of Natural Bioactive Abietane Diterpenes, International Journal of Molecular Sciences
          * 2021-01, Tuning the 1H NMR Paramagnetic Relaxation Enhancement and Local Order of [Aliquat]+-Based Systems Mixed with DMSO, International Journal of Molecular Sciences
          * 2020-11, Chitin-glucan complex – Based biopolymeric structures using biocompatible ionic liquids, Carbohydrate Polymers
          * 2017, Ecotoxicological evaluation of magnetic ionic liquids, Ecotoxicology and Environmental Safety
          * 2017, 1H NMR Relaxometry and Diffusometry Study of Magnetic and Non-Magnetic Ionic Liquid-Based Solutions: Co-Solvent and Temperature Effects, The Journal of Physical Chemistry B
          * 2016, New low viscous cholinium-based magnetic ionic liquids, New Journal of Chemistry
          * 2016, Effect of water activity on carbon dioxide transport in cholinium-based ionic liquids with carbonic anhydrase, Separation and Purification Technology
          * 2014-08, Hydraulic pressures generated in Magnetic Ionic Liquids by paramagnetic fluid/air interfaces inside of uniform tangential magnetic fields, Journal of Colloid and Interface Science
          * 2014-05, Synthesis and characterization of Magnetic Ionic Liquids (MILs) for CO 2 separation, J. Chem. Technol. Biotechnol
          * 2014, Integrated desulfurization of diesel by combination of metal-free oxidation and product removal by molecularly imprinted polymers, RSC Adv.
          * 2013, Toxicological evaluation of magnetic ionic liquids in human cell lines, Chemosphere
          * 2013, Solubility of carbon dioxide in ammonium based CO2-induced ionic liquids, Fluid Phase Equilibria
          * 2013, Solubility and phase behavior of binary systems containing salts based on transitional metals, Journal of Chemical Thermodynamics
          * 2012, Toxicity assessment of various ionic liquid families towards Vibrio fischeri marine bacteria, Ecotoxicology and Environmental Safety
          * 2011, Oxidation of cyclohexene to trans-1,2-cyclohexanediol promoted by p-toluenesulfonic acid without organic solvents, Journal of Chemical Education
          * 2011, Dissolution and transformation of carbohydrates in ionic liquids, Current Organic Synthesis
          * 2011, Brønsted acid-catalyzed dihydroxylation of olefins in aqueous medium, Advanced Synthesis and Catalysis
          * 2011, 5-Hydroxymethylfurfural (HMF) as a building block platform: Biological properties, synthesis and synthetic applications, Green Chemistry
          * 2009, Toxicological evaluation on human colon carcinoma cell line (CaCo-2) of ionic liquids based on imidazolium, guanidinium, ammonium, phosphonium, pyridinium and pyrrolidinium cations, Green Chemistry
          * 2009, Studies on dissolution of carbohydrates in ionic liquids and extraction from aqueous phase, Green Chemistry
          * 2008, ORGN 355-Effect of ionic liquids on human colon carcinoma cell lines, Abstracts of Papers of the American Chemical Society
          * 2006, Synthesis of 2,4,6-tri-substituted-1,3,5-triazines, Molecules

        Thesis / Dissertation

          * 2011-01-11, PhD, Development of more sustainable methodologies in organic synthesis

        Book chapter

          * 2016, Organocatalysed trans-dihydroxylation of olefins, Comprehensive Organic Chemistry Experiments for the Laboratory, Royal Society of Chemistry
          * 2015, The dissolution of biomass in ionic liquids towards pre-treatment approach, Ionic Liquids in the Biorefinery Concept, Royal Society of Chemistry
          * 2015, Metal-Catalyzed Oxidation of C-X (X = S, O) in Ionic Liquids, 51
          * 2011, trans-Di-hidroxilação de olefinas por organocatálise, 100 experiências de química orgânica, IST-Press
          * 2011, Extração e purificação de lupanina, 100 experiências de química orgânica, IST-Press

        Conference abstract

          * 2022-06-30, Antioxidant Essential Oils as Innovative Ingredients in Facial Masks, InnovDelivery’22, Virtual meeting, Biomed. Biopharm. Res. 2022; 19(2): InnovDel 1-54.
          * 2022-06, Self-assembly nanoparticles of bioactive compounds isolated from Plectranthus spp. , InnovDelivery’22, Virtual meeting, Biomed. Biopharm. Res. 2022; 19(2): InnovDel 1-54.
          * 2022-05-24, Antioxidant Essential Oils impregnated in Novel Gelatin based film Masks, 1st African Conference on Natural Products & Related Fields, Biomed Biopharm Res., 2022; 19(2): ACNP1-54
          * 2008, ORGN 355-Effect of ionic liquids on human colon carcinoma cell lines, Abstr. Pap. Am. Chem. Soc.

        Conference poster

          * 2023-11-21, Exploring DASA Stability in Ionic Liquids, ILMAT2023 - 7th International Conference on Ionic Liquid-Based Materials, Instituto Pernambuco, Porto, Portugal.
          * 2023-11-21, Efficient Decontamination of Chemical Warfare Agents by Ionic Liquids, ILMAT2023 - 7th International Conference on Ionic Liquid-Based Materials, Instituto Pernambuco, Porto, Portugal.
          * 2023-11-10, The Influence of Ionic Liquids and Deep Eutectic Solvents on DASA isomerization, V CBIOS Seminars, Universidade Lusófona, Centro Universitário de Lisboa, Lisbon, Portugal.
          * 2023-11-10, Optimization of DASA Precursors Synthesis for Biological Applications, V CBIOS Seminars, Universidade Lusófona, Centro Universitário de Lisboa, Lisbon, Portugal.
          * 2023-11-10, New bioactive extracts with potential skin application from marine waste, Jornadas CBIOS
          * 2023-11-10, Ionic Liquids as Efficient Sorbents for Chemical Warfare Agents, V CBIOS Seminars, Universidade Lusófona, Centro Universitário de Lisboa, Lisbon, Portugal.
          * 2023-07-05, - Chemical Warfare Agents - Novel Decontamination System, Ciência 2023, Aveiro, Portugal
          * 2023-06-27, Development of decontamination systems for Chemical Warfare Agents, Jornadas Científicas 2023, Universidade de Lisboa, Portugal.
          * 2023-06-26, Ionic Liquids As Highly Efficient Decontamination Systems For Chemical Warfare Agents, 14th iMed.ULisboa Meeting Postgraduate Students Meeting, Faculty of Pharmacy, 26th June 2023, Lisbon, Portugal
          * 2023-04-24, New ILs based Photoswitchable Materials, COIL-9 - 9th International Congress on Ionic Liquids, Lyon, France
          * 2023-04-24, Development of decontamination systems for Chemical Warfare Agents, COIL-9 - 9th International Congress on Ionic Liquids, Lyon, France
          * 2022-11-11, The Portuguese Physiology Roadmap ¿ From molecules to the individual ¿ perspectives from CBIOS
          * 2022-01-12, Descontaminação Superficial de Agentes Químicos de Guerra usando Líquidos Iónicos, COMEMORAÇÕES DO DIA DA ACADEMIA MILITAR
          * 2021-09-28, Study of the solubility of different photoswitchable compounds in green solvents, 5th European Conference on Green and Sustainable Chemistry
          * 2020-11-23, Study of Donor–acceptor Stenhouse adducts (DASA) stability in different solvents, IV Jornadas CBIOS "There is research beyond COVID 19"
          * 2020-11, COVerskIn-D: O dispositivo para prevenção das lesões cutâneas causadas por EPIs, APFH Immersive Virtual Congress 30 Anos a Criar Valor
          * 2019-09-22, Magnetic Liquids based on metal complexes, 13th International Symposium on Crystalline Organic Metals, Superconductors and Magnets (ISCOM2019)
          * 2019-07-16, Becker-Adler reaction in Flow, 4th Meeting of the College of Chemistry
          * 2015-07-12, Magnetic Ionic Liquids based on Choline – Synthesis and biological evaluation, 19th European Symposium on Organic Chemistry
          * 2013-09-04, Smart Magnetic Liquids as novel magnetic materials, 10º Portuguese National Meeting of Organic Chemistry
          * 2012-02-02, ILs as Extractors of Carbohydrates from Aqueous Solutions, International Workshop on Ionic Liquids– Seeds for New Engineering Applications
          * 2010-04-21, More Sustainable Approach For The Trans-1,2-Dihydroxylation of Olefins, 2nd Portuguese Young Chemists Meeting
          * 2009-08-02, Extraction of mono- and disaccharides from aqueous solutions by hydrophobic ionic liquids, 42nd IUPAC Congress-Chemistry Solutions
          * 2009-01-20, Carbohydrates Extraction From Aqueous Solutions Using Ionic Liquids, Carbohydrates as Organic Raw Materials V
          * 2008-09-16, Olefin dihydroxylation promoted by sulfonic acids in water, 2nd EuCheMS Chemistry Congress

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona