# Response for https://www.ulusofona.pt/contactos

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/contactos
          PT: https://www.ulusofona.pt/contactos EN: https://www.ulusofona.pt/en/contacts
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/contactos
        fechar menu : https://www.ulusofona.pt/contactos

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/contactos
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/contactos
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/contactos
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/contactos
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/contactos
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/contactos
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/contactos
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/contactos
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/contactos
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/contactos
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes
          * Lisboa: https://www.ulusofona.pt/contactos
          * Porto: https://www.ulusofona.pt/contactos

          * Geral

              217 515 500: tel:21751500 (Custo da chamada para rede fixa nacional)
              info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
              WhatsApp 96 36 40 100: https://api.whatsapp.com/send?phone=351963640100

            Morada

              Campo Grande, 376
              1749-024 Lisboa,
              Portugal

            Redes

                + : https://www.facebook.com/u.lusofona
                + : https://twitter.com/ulusofona
                + : https://www.youtube.com/@UniversidadeLusofonaVideos
                + : https://www.instagram.com/ulusofona/
                + : https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/
                + : https://api.whatsapp.com/send?phone=351963640100

            Estrutura Organizacional

                Orgãos de Gestão Académica e Administrativa

                  Reitoria                 Professor Doutor           reitoria@ulusofona.pt: mailto:#     
                                           José Bragança de Miranda                                       
                  Administração            Professor Doutor           administracao@ulusofona.pt: mailto:#
                                           Manuel de Almeida Damásio                                      
                  Administrador Executivo  Professor Doutor           mjdamasio@ulusofona.pt: mailto:#    
                                           Manuel José Damásio                                            
                  

                  SIGA - Serviço Integrado de Gestão de Alunos

                  Serviço onde pode de forma integrada tratar de assuntos administrativos, financeiros, de mobilidade, ação social e bolsas, e solicitar informações sobre a Universidade e os seus cursos.

                    SIGA - Serviço Integrado de Gestão de Alunos  Atendimento presencial - 2ª a 6ª feira das 10h00 às 19h00  siga@ulusofona.pt: mailto:siga@ulusofona.pt            
                                                                  Atendimento telefónico - 2ª a 6ª feira das 09h00 às 21h00                                                         
                                                                  Email                                                      siga@ulusofona.pt: mailto:siga@ulusofona.pt            
                                                                                                                                                                                    
                    SAS - Serviço de Ação Social                  Horário de atendimento                                     Quartas-feiras, das 10h30 às 13h00 e das 14h30 às 19h00
                                                                                                                                                                                    
                                                                  Localização                                                Edifício A, piso 0, junto ao SIGA                      
                    

                    GIP - Gestão Integrada de Processos

                      GIP - Gestão Integrada de Processos  2ª a 6ª feira das 10h00 às 19h00  gip@ulusofona.pt: mailto:gip@ulusofona.pt
                      

                      LIO | Lusófona International Office

                        LIO | Lusófona International Office  Mobilidades                mobilidade@ulusofona.pt: mailto:mobilidade@ulusofona.pt                    
                        LIO | Lusófona International Office  Para Acordos e Cooperação  international.office@ulusofona.pt: mailto:international.office@ulusofona.pt
                        

                        EVA - Estágios, Vida Ativa e Formação ao longo da Vida

                          Coordenação do EVA                 Tânia Almeida     tania.leite@ulusofona.pt: mailto:tania.leite@ulusofona.pt          
                          Estágios e Inserção na Vida Ativa  Verónica Almeida  veronica.almeida@ulusofona.pt: mailto:veronica.almeida@ulusofona.pt
                          

                          Provedor do Estudante

                            Provedor do Estudante  Diogo Mateus  provedor.aluno@ulusofona.pt: mailto:provedor.aluno@ulusofona.pt
                            

                            Biblioteca

                              Biblioteca  José Carlos Carvalho  biblioteca@ulusofona.pt: mailto:biblioteca@ulusofona.pt'
                              

                              Unidades Orgânicas

                                Escola de Ciências e Tecnologias da Saúde                              Secretariado                                                             marisa.paiva@ulusofona.pt: mailto:marisa.paiva@ulusofona.pt           
                                                                                                       Marisa Paiva                                                                                                                                   
                                Escola de Ciências Económicas e das Organizações                       Secretariado                                                             sec.deg@ulusofona.pt: mailto:sec.deg@ulusofona.pt                     
                                                                                                       Adelaide Pereira                                                                                                                               
                                Escola de Comunicação, Arquitetura, Artes e Tecnologias da Informação  Secretariado                                                             filipa.vieira@ulusofona.pt: mailto:filipa.vieira@ulusofona.pt         
                                                                                                       Filipa Vieira                                                                                                                                  
                                Escola de Psicologia e Ciências da Vida                                Secretariado                                                             carla.madeira@ulusofona.pt: mailto:carla.madeira@ulusofona.pt         
                                                                                                       Carla Madeira                                                                                                                                  
                                Faculdade de Ciências Sociais, Educação e Administração                Secretariado                                                             teresa.candeias@ulusofona.pt: mailto:teresa.candeias@ulusofona.pt     
                                                                                                       Teresa Candeias                                                                                                                                
                                Faculdade de Direito                                                   Secretariado                                                             paula.almeida@ulusofona.pt: mailto:paula.almeida@ulusofona.pt         
                                                                                                       Paula Almeida                                                                                                                                  
                                Faculdade de Educação Física e Desporto                                Secretariado                                                             defdl@ulusofona.pt: mailto:defdl@ulusofona.pt                         
                                                                                                       Susana Sousa                                                                                                                                   
                                                                                                           Natália Raileanu                                                                                                                           
                                Faculdade de Engenharia                                                    natalia.raileanu@ulusofona.pt: mailto:natalia.raileanu@ulusofona.pt    natalia.raileanu@ulusofona.pt: mailto:natalia.raileanu@ulusofona.pt 
                                                                                                           Tânia Pereira                                                          tania.pereira@ulusofona.pt: mailto:tania.pereira@ulusofona.pt       
                                                                                                           tania.pereira@ulusofona.pt: mailto:tania.pereira@ulusofona.pt                                                                              
                                Faculdade de Medicina Veterinária                                      Secretariado                                                             sec.medvet@ulusofona.pt : mailto:sec.medvet@ulusofona.pt              
                                                                                                       Catarina Afilhado e Mariana Ribeiro                                                                                                            
                                Instituto de Serviço Social                                            Secretariado                                                             daniela.rodrigues@ulusofona.pt : mailto:daniela.rodrigues@ulusofona.pt
                                                                                                       Daniela Rodrigues                                                                                                                              
                                

                        * Geral

                            Tel: 222 073 230: tel:222073230 (Custo da chamada para rede fixa nacional)
                            WhatsApp 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                            info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt

                          Morada

                            Rua Augusto Rosa, nº 24, (à Pç. da Batalha)
                            4000-098 Porto,
                            Portugal

                          Redes

                              + : https://www.facebook.com/ulporto
                              + : https://twitter.com/ulusofonaporto
                              + : https://www.youtube.com/@UniversidadeLusofonaVideos
                              + : https://www.instagram.com/ulporto/
                              + : https://www.linkedin.com/school/universidade-lusofona-do-porto
                              + : https://api.whatsapp.com/send?phone=351961135355

                          Estrutura Organizacional

                              SIGA - Serviço Integrado de Gestão de Alunos

                              Serviço onde pode de forma integrada tratar de assuntos administrativos, financeiros, de mobilidade, ação social e bolsas, e solicitar informações sobre a Universidade e os seus cursos.

                                SIGA - Serviço Integrado de Gestão de Alunos  Atendimento presencial - 2ª a 6ª feira das 10h00 às 19h00  siga@ulusofona.pt: mailto:siga@ulusofona.pt                      
                                                                              Atendimento telefónico - 2ª a 6ª feira das 09h00 às 20h00                                                                   
                                SAS - Serviço de Ação Social                  Email                                                      alexandra.pinto@ulusofona.pt: mailto:alexandra.pinto@ulusofona.pt
                                

                                LIO | Lusófona International Office

                                  LIO | Lusófona International Office  Mobilidades                mobilidade@ulusofona.pt: mailto:mobilidade@ulusofona.pt                    
                                  LIO | Lusófona International Office  Para Acordos e Cooperação  international.office@ulusofona.pt: mailto:international.office@ulusofona.pt
                                  

                                  Unidades Orgânicas

                                    Faculdade de Ciências Económicas, Sociais e da Empresa                    Secretariado  Carla Silva: mailto:carla.moreira.silva@ulusofona.pt
                                    Faculdade de Ciências Naturais, Engenharias e Tecnologias                 Secretariado  Carla Silva: mailto:carla.moreira.silva@ulusofona.pt
                                    Faculdade de Comunicação, Arquitetura, Artes e Tecnologias da Informação  Secretariado  Susana Oliveira: mailto:susana.oliveira@ulusofona.pt
                                    Faculdade de Direito e Ciência Política                                   Secretariado  Mónica Ribeiro: mailto:monica.ribeiro@ulusofona.pt  
                                    Faculdade de Psicologia, Educação e Desporto                              Secretariado  Gisela Ribeiro: mailto:gisela.ribeiro@ulusofona.pt  
                                    
                              Política de Cookies
                                Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
                                  Rejeitar
                                  Escolher >
                                  Permitir Todos
                                    Necessários
                                  Cookies necessários para o funcionamento do website.
                                    Analíticos
                                  Cookies de análise e comportamento do website.
                                    Marketing
                                  Cookies de tracking para o propósito de anúncios.
                                  Rejeitar
                                  Permitir Selecionados
                                  Permitir Todos

                                Newsletter

                                  Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

                            Subscreva a Newsletter

                            Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
                                  * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
                                  * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
                                  * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
                                * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
                                  * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
                                  * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

                                  Serviços

                                    * Contactos: https://www.ulusofona.pt/contactos
                                    * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
                                    * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
                                    * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

                                  Ensino

                                    * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                                    * Mestrados: https://www.ulusofona.pt/mestrados
                                    * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                                    * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                                    * Todos os Cursos: https://www.ulusofona.pt/cursos

                                  Documentos

                                    * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
                                    * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
                                    * Formulários: https://www.ulusofona.pt/documentos?cat=13
                                    * Relatórios: https://www.ulusofona.pt/documentos?cat=4
                                    * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
                                  Lisboa
                                  Campo Grande, 376
                                  1749-024 Lisboa, Portugal
                                  Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
                                  WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
                                  Porto
                                  Rua Augusto Rosa, nº 24
                                  4000-098 Porto - Portugal
                                  Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
                                  WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                                      2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
                                  https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona