# Response for https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
          PT: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256 EN: https://www.ulusofona.pt/en/teachers/ana-isabel-gusmao-lima-6256
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
        fechar menu : https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-isabel-gusmao-lima-6256
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Ana Lima

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6256
              p62***@ulusofona.pt
              B71D-BA06-8908: https://www.cienciavitae.pt/B71D-BA06-8908
              0000-0001-8251-6286: https://orcid.org/0000-0001-8251-6286
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/61bf0837-89fd-4a42-ac1f-a4f674b87c44
      : https://www.ulusofona.pt/

        Resume

        Ana Lima is an experienced PI researcher with expertise in agronomy, food engineering, and One Health. She currently serves as an Assistant Professor and the Research Coordinator at the FMV-ULusófona. She has a MsC in Toxicology, a PhD in Biology, and completed her post-doc in Food Biochemistry. Previously, she was co-Group Leader at the Higher Institute for Agronomy at the University of Lisbon, and now she is the Head of the Food Safety and Bioactivities Group at the FMV-ULusófona. She has participated in more than 25 national and European projects and was PI of 5. She has supervised numerous students at various academic levels and has 122 publications, of which 60 are peer-reviewd papers. She received the Born from Knowledge Award in 2018 for her contributions to food innovation and holds three international patents for her discoveries in functional foods.

        Graus

            * Mestrado
              Mestrado em Toxicologia - ano curricular
            * Licenciatura
              Licenciatura em Biologia
            * Mestrado
              Mestrado em Toxicologa
            * Doutoramento
              Doutoramento
            * Pós-doutoramento
              Post-doc

        Publicações

        Edição de número de revista

          * Special issue: Molecular Compounds for One Health Approaches.
          * Food Bioactive Compounds for the Microbiome

        Artigo em revista

          * 2024-02-26, Effects of Particle Size on Physicochemical and Nutritional Properties and Antioxidant Activity of Apple and Carrot Pomaces, Foods
          * 2024-02-03, Milk Antiviral Proteins and Derived Peptides against Zoonoses, International Journal of Molecular Sciences
          * 2023-12-15, One Health Perspectives on Food Safety in Minimally Processed Vegetables and Fruits: From Farm to Fork, Microorganisms
          * 2023-11-29, Influence of Particle Size and Extraction Methods on Phenolic Content and Biological Activities of Pear Pomace, Foods
          * 2023-09, RuBisCO as a protein source for potential food applications: A review, Food Chemistry
          * 2023-02, Milk's Bioactive Peptides: Are We Disregarding Nature's Miracle?, Novel Techniques in Nutrition and Food Science
          * 2022-12-14, Therapeutic Potential of Deflamin against Colorectal Cancer Development and Progression, Cancers
          * 2022-08-17, Applications of Contrast-Enhanced Ultrasound in Splenic Studies of Dogs and Cats, Animals
          * 2022-07-14, New Alternatives to Milk From Pulses: Chickpea and Lupin Beverages With Improved Digestibility and Potential Bioactivities for Human Health, Frontiers in Nutrition
          * 2022-05, Lupin Protein Concentrate as a Novel Functional Food Additive That Can Reduce Colitis-Induced Inflammation and Oxidative Stress, Nutrients
          * 2022-03-31, Applications of Essential Oils as Antibacterial Agents in Minimally Processed Fruits and Vegetables—A Review, Microorganisms
          * 2022, Assessment of the Microbiological Quality and Safety in Takeaway Sushi Meals in Portugal, Portuguese Journal of Public Health
          * 2021-12-10, Lupinus albus Protein Components Inhibit MMP-2 and MMP-9 Gelatinolytic Activity In Vitro and In Vivo, International Journal of Molecular Sciences
          * 2021-10, Sourdough Fermentation as a Tool to Improve the Nutritional and Health-Promoting Properties of Its Derived-Products, Fermentation
          * 2021-10, Extended Cheese Whey Fermentation Produces a Novel Casein-Derived Antibacterial Polypeptide That Also Inhibits Gelatinases MMP-2 and MMP-9, International Journal of Molecular Sciences
          * 2021-10, Combination of Trans-Resveratrol and e-Viniferin Induces a Hepatoprotective Effect in Rats with Severe Acute Liver Failure via Reduction of Oxidative Stress and MMP-9 Expression, Nutrients
          * 2021, Mota J, Ferreira RB, Raymundo A, Lima A. (2021). Development of a lupin protein concentrate as a nutraceutical delivery system for addition to cancer-preventing foods., Foods
          * 2021, M. I. S. Santos, A. I. G. Lima, J. Mota, P. Rebelo, R. M. S. B. Ferreira, L. Pedroso, I. Sousa (2021). Extended fermentation produces a broad-range antibacterial peptide that also targets matrix metalloproteases related to inflammation and cancer. , Journal of Advanced Research
          * 2021, An Up-Scalable and Cost-Effective Methodology for Isolating a Polypeptide Matrix Metalloproteinase-9 Inhibitor from Lupinus albus Seeds, Foods
          * 2021, Actinic keratosis treated by topical Aloe barbadensis Mill. (Aloe Vera) leaf gel, Academia letters
          * 2020-12, Differential inhibition of gelatinase activity in human colon adenocarcinoma cells by Aloe vera and Aloe arborescens extracts, BMC Complementary Medicine and Therapies
          * 2020-10-04, Glycemic Response and Bioactive Properties of Gluten-Free Bread with Yoghurt or Curd-Cheese Addition, Foods
          * 2020-08-05, Lupin Seed Protein Extract Can Efficiently Enrich the Physical Properties of Cookies Prepared with Alternative Flours, Foods
          * 2020, Deflamin-an-edible-antiinflammatory-protein-isolated-from-legume-seeds, Journal of Nutraceutics and Food Science
          * 2020, A Novel Way for Whey: Cheese Whey Fermentation Produces an Effective and Environmentally-Safe Alternative to Chlorine, Eco Novel Food and Feed
          * 2019-10, Reduction of inflammation and colon injury by a Pennyroyal phenolic extract in experimental inflammatory bowel disease in mice, Biomedicine & Pharmacotherapy
          * 2019-07-12, A Novel Way for Whey: Cheese Whey Fermentation Produces an Effective and Environmentally-Safe Alternative to Chlorine, Applied Sciences
          * 2019-06-22, New Lectins from Mediterranean Flora. Activity against HT29 Colon Cancer Cells, International Journal of Molecular Sciences
          * 2019-06-06, Reduction of Inflammation and Colon Injury by a Spearmint Phenolic Extract in Experimental Bowel Disease in Mice, Medicines
          * 2017-10-09, Essential oils as antibacterial agents against food-borne pathogens: Are they really as useful as they are claimed to be?, Journal of Food Science and Technology
          * 2017-08, Dyospiros kaki phenolics inhibit colitis and colon cancer cell proliferation, but not gelatinase activities, The Journal of Nutritional Biochemistry
          * 2017-02-27, Proteins in Soy Might Have a Higher Role in Cancer Prevention than Previously Expected: Soybean Protein Fractions Are More Effective MMP-9 Inhibitors Than Non-Protein Fractions, Even in Cooked Seeds, Nutrients
          * 2016-08, Preliminary Study on the Effect of Fermented Cheese Whey on Listeria monocytogenes, Escherichia coli O157:H7, and Salmonella Goldcoast Populations Inoculated onto Fresh Organic Lettuce, Foodborne Pathogens and Disease
          * 2016-04, Legume seeds and colorectal cancer revisited: Protease inhibitors reduce MMP-9 activity and colon cancer cell migration, Food Chemistry
          * 2012, Looking for suitable biomarkers in benthic macroinvertebrates inhabiting coastal areas with low metal contamination: Comparison between the bivalve Cerastoderma edule and the Polychaete Diopatra neapolitana, Ecotoxicology and Environmental Safety
          * 2012, Cd-induced signaling pathways in plants: Possible regulation of PC synthase by protein phosphatase 1, Environmental and Experimental Botany
          * 2011, Health concerns of consuming cockles (Cerastoderma edule L.) from a low contaminated coastal system, Environment International
          * 2010, Sensitivity of biochemical markers to evaluate cadmium stress in the freshwater diatom Nitzschia palea (Kützing) W. Smith, Aquatic Toxicology
          * 2009, Mercury intracellular partitioning and chelation in a salt marsh plant, Halimione portulacoides (L.) Aellen: Strategies underlying tolerance in environmental exposure, Chemosphere
          * 2009, Accumulation, distribution and cellular partitioning of mercury in several halophytes of a contaminated salt marsh, Chemosphere
          * 2006, The importance of glutathione in oxidative status of Rhizobium leguminosarum biovar viciae under Cd exposure, Enzyme and Microbial Technology
          * 2006, Screening possible mechanisms mediating cadmium resistance in Rhizobium leguminosarum bv. viciae isolated from contaminated Portuguese soils, Microbial Ecology
          * 2006, Heavy metal toxicity in Rhizobium leguminosarum biovar viciae isolated from soils subjected to different sources of heavy-metal contamination: Effects on protein expression, Applied Soil Ecology
          * 2006, Glutathione-mediated cadmium sequestration in Rhizobium leguminosarum, Enzyme and Microbial Technology
          * 2006, Cadmium uptake in PEA plants under environmentally-relevant exposures: The risk of food-chain transfer, Journal of Plant Nutrition
          * 2006, Cadmium detoxification in roots of Pisum sativum seedlings: Relationship between toxicity levels, thiol pool alterations and growth, Environmental and Experimental Botany
          * 2005, Cadmium tolerance plasticity in Rhizobium leguminosarum bv. viciae: Glutathione as a detoxifying agent, Canadian Journal of Microbiology

        Capítulo de livro

          * 2023, A Realistic View of Essential Oils as Antibacterial Agents for Ready-to-Eat Fruits and Vegetables, Advances in Public Health , 1, 1, Academic reads
          * 2021, Industrial waste whey as a low-cost, efficient, and environmentally safe disinfectant, with potential applications for minimally processed foodstuff., Current Approaches in Science and Technology Research. BP International, BP International. India.
          * 2012, The influence of GSH on Rhizobium tolerance to cadmium, Toxicity of Heavy Metals to Legumes and Bioremediation, Springer-Verlag
          * 2011, Metal signaling in plants: new possibilities for crop management under cadmium contaminated soils, Biomanagement of Metal Contaminated Soils, Springer-Verlag
          * 2010, Mercury tolerance in higher plants: emerging views, Heavy Metal Stress Tolerance in Plants: Recent Advances in Physiology & Molecular Biology, Springer-Verlag
          * 2008, Rhizobium leguminosarum isolated from agricultural ecosystems subjected to different climatic influences: the relation between genetic diversity, salt tolerance and nodulation efficiency, Soil Ecology Research Development, Nova Science Publishers Inc.
          * 2006, The role of phytochelatins in cadmium detoxification in Pisum sativum L., Cadmium Stress in Plants, Springer-Verlag

        Artigo em jornal

          * 2024-01-01, O açúcar escondido nos alimentos processados, Carrilhão
          * 2023-11-15, Botulismo e o perigo das conservas caseiras, Carrilhão
          * 2023-10-15, Leite: muito mais do que um alimento completo, Carrilhão
          * 2023-08-01, Ovos e Salmonella, Carrilhão
          * 2023-03-15, E se os antibióticos deixarem de funcionar? , Carrilhão
          * 2023-01-01, Doenças com origem nos alimentos, Carrilhão
          * 2022-10-15, Pessoas saudáveis, animais saudáveis, num planeta mais saudável
          * 2022-10-01, Contaminação cruzada na preparação de alimentos, Carrilhão

        Entrada de enciclopédia

          * Minimally Processed Fruits and Vegetables and One Health. Encyclopedia, Scohlarly Community Encyclopedia
          * Applications of Essential Oils as Antibacterial Agents. Encyclopedia, Scohlarly Community Encyclopedia

        Resumo em conferência

          * 2022-12-19, Compostos bioativos para a saúde e segurança alimentar, FMVet Research Meeting, 2022. 1º Encontro de Investigação da FMV Universidade Lusófona
          * 2022-11, Opuntia ficus-indica as resilient and sustainable food and feed crop with a high potential for One Health, 1st International Congress on Food, Nutrition & Public Health Towards a Sustainable Future, INSA
          * 2022-10-23, Fruit and vegetable pomaces from Juice Industry as a source of bioactive compounds, XVI Encontro de Quimica dos Alimentos
          * 2022-10-19, Peptides produced by fermentation by lactic acid bacteria as new antimicrobial and anti-inflammatory alternatives, Microbiologia 2022 Congresso Internacional de Microbiologia em Língua Portuguesa
          * 2022-02-05, Novel protein food-based MMP inhibitors and their potential for cancer and gut inflammatory diseases, 3rd International Conference on Nutrition, Food Science & Food Chemistry (Plenary Presentation)
          * 2021-07-13, The technological potential of fermented cheese whey-A natural product as natural disinfectant agent, Food Safety Summit 2021, 8th International conference on Food Science and Food Safety
          * 2019-06-10, Foodborne proteins and peptides with strong antibacterial activity: are they a turning point against bacterial resistance? , IC2AR 2019, 3rd INTERNATIONAL CAPARICA CONGRESS IN ANTIBIOTIC RESISTANCE

        Poster em conferência

          * 2023-12-01, Multidrug-resistant Escherichia coli and Salmonella spp. in pigs slaughtered for human consumption, a potential source for Humans? , The 2nd International Electronic Conference on Microbiology
          * 2023-07-07, Are Food Producing animals a source of multidrug-resistant E. coli and Salmonella spp.?, 6th International Congress of CiiEM¿Immediate and Future Challenges to Foster One Health, Almada
          * 2023-07-05, The impact of pomace particle size on fiber and sugar content. , Ciência 2023, Encontro com a Ciência e a Tecnologia em Portugal, Campus Universitário de Santiago, Aveiro
          * 2023-07-05, Potential of salicornia for food safety and human health, Ciência 2023, Encontro com a Ciência e a Tecnologia em Portugal, Campus Universitário de Santiago, Aveiro
          * 2023-07-05, Fisetine reduces MMP-9 in fibroblast-like synoviocytes, Ciência 2023, Encontro com a Ciência e a Tecnologia em Portugal, Campus Universitário de Santiago, Aveiro
          * 2023-07-05, Cardoon in Cheese Rennet Presents Antibacterial and Anti-Inflamatory Potential, Ciência 2023, Encontro com a Ciência e a Tecnologia em Portugal, Campus Universitário de Santiago, Aveiro
          * 2023-07-05, Antibiotics Residues in Meat Samples in Portugal: Do You Dare to Know the Truth? , Ciência 2023, Encontro com a Ciência e a Tecnologia em Portugal, Campus Universitário de Santiago, Aveiro
          * 2023-05-18, Potential Health Benefits of Cardoon in Cheese Production, FMVet Research Meetings - II Encontro de Investigação da FMV da Universidade Lusófona
          * 2023-05-18, Frequency and phenotypic characterization of Campylobacter coli strains in pigs slaughtered for human consumption in Portugal., FMVet Research Meetings - II Encontro de Investigação da FMV da Universidade Lusófona
          * 2023-05-18, Assessment of the Microbiological Quality and Safety in Takeaway Sushi Meals in Portugal, FMVet Research Meetings - II Encontro de Investigação da FMV da Universidade Lusófona
          * 2023-05-18, Assessment of multidrug resistance in Campylobacter spp. isolated from different species of birds slaughtered for human consumption in Portugal, FMVet Research Meetings - II Encontro de Investigação da FMV da Universidade Lusófona
          * 2023-05-18, Application of salicornia as an alternative to salt in cured meat products: Potential for food safety and human health, FMVet Research Meetings - II Encontro de Investigação da FMV da Universidade Lusófona
          * 2023-05-18, Acrylamide levels in chips: are potato chips the only bad guys? , FMVet Research Meetings - II Encontro de Investigação da FMV da Universidade Lusófona
          * 2022-11-17, Whey fermentation as a sustainable and circular-economy based way to produce novel alternatives to antibiotics and food disinfectants, 1st International Congress on Food, Nutrition & Public Health Towards a Sustainable Future, INSA
          * 2022-10, Fruit and vegetable pomaces from Juice Industry as a source of bioactive compounds, XVI Encontro de Quimica dos Alimentos
          * 2021-10-22, Uso da norma ISO 9001:2008 para a implementação e certificação de um sistema de gestão de qualidade num centro de atendimento médico veterinário. , XVII Congresso Internacional Veterinário Montenegro, Medicina Interna sem segredos
          * 2021-06-28, Protective effect of stilbenes in rats with severe acute liver failure. A new role for grapevine., Encontro Ciência 2021, Lisboa (June 28-30).
          * 2021-06-28, New alternatives to milk from pulses: digestibility and bioactivity, Encontro Ciência 2021, Lisboa (June 28-30).
          * 2021-06-28, Lupin Seed Protein Extract Can Enrich the Physical Properties of Cookies Prepared with Alternative Flours, Encontro Ciência 2021, Lisboa (June 28-30).
          * 2021-06-28, Emerging new possibilities on bioactive whey peptides: extended fermentation produces a novel casein-derived peptide with broad-range antibacterial activities that also inhibits MMP-2 and MMP-9, Encontro Ciência 2021, Lisboa (June 28-30).
          * 2021-06-28, Anti-inflammatory and anticancer activities of a protein isolated from Lupinus seeds and its application in functional foods., Encontro Ciência 2021, Lisboa (June 28-30).
          * 2021-05-26, New alternatives to milk from pulses: digestibility and bioactivity, Agri-Food Ecosystem, Santarém (May, 26-27)
          * 2021, Duarte CM, Mota J, Assunção R, Martins C, Ribeiro A, Lima A, Raymundo A, Nunes C, Boavida-Ferreira R, Sousa I. (2021). New alternatives to milk from pulses: digestibility and bioactivity. Agri-Food Ecosystem, , Encontro Ciência 2021, Lisboa (June 28-30).
          * 2018, Rheological properties evaluation of bread dough with different levels of fermented whey, AERC2018 - The Annual European Rheology Conference
          * 2018, Pão enriquecido com soro de leite fermentado: uma alternativa sustentável., Food Bioactives and Health Conference
          * 2018, Fermented cheese whey as a novel alternative to chlorine in lettuce disinfection, 5º Simpósio Nacional “Promoção de uma Alimentação Saudável e Segura – SPASS 2018
          * 2018, Deflamin, an edible anti-inflammatory and anticancer protein isolated from legume seeds, Ciência 2018
          * 2014-09, M. Biological potential of fermented whey: improving the isolation of bioactive peptides., 7th International Whey Conference
          * 2014-04, Aloe species reduces colon cancer cell invasion through specific MMP-9 inhibition, Jornadas de Biologia.
          * 2013-09, Antimicrobial peptides produced by whey fermentation, ISOPOL
          * 2011-05-02, Avaliação da contaminação metálica em duas espécies de macroinvertebrados da ria de Aveiro por marcadores bioquímicos, Jornadas da Ria, Universidade de Aveiro
          * 2007-11-26, Hg-induced oxidative stress in diferent salt marsh species, SOWETOX 2007 Soil and Wetland Toxicology
          * 2007-11-26, Hg accumulation by different salt marsh species: potential use for phytoremediation, SOWETOX 2007 Soil and Wetland Toxicology International Meeting
          * 2007-11-26, Are phytochelatins a mechanism for Hgphytoremediation in salt marshes?, SOWETOX 2007 Soil and Wetland Toxicology
          * 2007-08, Calcium sensors are regulated by different stress signals, World Stress Conference
          * 2007-07-24, The role of the B subunit of PP2B in plant stress signaling, Europhosphatases
          * 2006-07, Uptake and distribution of mercury in a salt marsh plant, Atriplex patula (L.), International Symposium on Environmental Biotechnology
          * 2006-07, Sulphide incorporation and time-maturation of PC-Cd complexes in Pisum sativum, International Symposium on Environmental Biotechnology
          * 2006-07, DNA isolation from recalcitrant tissues of grapevine, FESPB 15th Congress on Plant Molecular Biology
          * 2006-07, Cadmium and GSH absorption and exclusion during exposure to Cd in Rhizobium leguminosarum., International Symposium on Environmental Biotechnology
          * 2005-09-18, Maturation of phytochelatincadmium complexes in roots of Pisum sativum L., IX Congresso Luso-Espanhol de Fisiologia Vegetal
          * 2005, Identification of Cd-protein complexes in Cd tolerant Rhizobium leguminosarum strain, BioMicroworld, I Congress in Microbiology
          * 2005, Heavy metal toxicity in Rhizobium leguminosarum biovar viciae isolated from soils neighbouring metalomechanics industries, BioMicroworld, I Congress in Microbiology
          * 2005, Cadmium tolerance of Rhizobium leguminosarum bv. viciae isolated from Portuguese soils contaminated with heavy metals: mechanisms of tolerance., BioMicroworld, I Congress in Microbiology
          * 2004, The relationship between thiol pool alterations, phytochelatin production and growth in Pisum sativum under different cadmium exposures, Simpósio de Nutrição Mineral em Plantas
          * 2004, Metal tolerance in Rhizobium leguminosarum bv. viciae: an overview of possible tolerance mechanisms, In: X Simpósio de Nutrição Mineral em Plantas
          * 2004, Involvement of Glutathione in Rhizobium leguminosarum heavy metal tolerance, XIV Congresso de Bíoquimica
          * 2002-12-05, Protein profile alterations induced after cadmium exposure in Rhizobium leguminosarum, XIII Congresso Nacional de Bioquímica
          * 2002-12-05, Effects of salinity on protein patterns of Rhizobium leguminosarum strains with different salt tolerances, XIII Congresso Nacional de Bioquímica
          * 2002-12-05, Effects of Cadmium on Pisum sativum / Rhizobium leguminosarum symbiosis., XIII Congresso Nacional de Bioquímica

        Patente

          * SKOPOBIOTA, Blad & Bentochar: Plant treatment PCT/EP2020/06574, PCT/EP2020/06574
          * Process of obtaining a purified RuBisCO preparation from a photosynthetic material. PCT/EP2022/057046, Ref: P13435 GB, Ana Lima, Ricardo Boavida Ferreira, Madalena Gracio
          * DEFLAMIN: Therapeutic protein PCT/EP2017/07502, PCT/EP2017/07502

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona