# Response for https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
          PT: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692 EN: https://www.ulusofona.pt/en/teachers/claudia-raquel-marques-martins-lima-4692
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
        fechar menu : https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/claudia-raquel-marques-martins-lima-4692
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Cláudia Lima

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4692
              cla***@gmail.com
              0C13-00E4-AEF0: https://www.cienciavitae.pt/0C13-00E4-AEF0
              0000-0002-3279-4808: https://orcid.org/0000-0002-3279-4808
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/0c6609b1-cbbd-4e86-9e06-f5670aa12618
      : https://www.ulusofona.pt/

        Resume

        Researcher at ID+ / Unexpected Media Lab – Faculty of Fine Arts, University of Porto and design educator at Lusófona University, Faculty of Fine Arts, University of Porto and ESAP - Escola Superior Artística do Porto. Cláudia Lima research is focused on the recovery of community stories and local art and design stories through biographical testimonies and visual analysis. This was done within research projects funded by FCT including: “Wisdom Transfer: towards the scientific inscription of individual legacies in contexts of retirement from art and design higher education and research” (POCI-01-0145-FEDER-029038), under which she developed a post-doctoral project; “Echoing the Communal Self: designing the dissemination and replication of self-initiated practices in underprivileged urban communities in a post-pandemic world” (EXPL/ART-DAQ/0037/2); “An Infodemic of Disorientation: communication design as mediator between scientific knowledge and cognitive bias” (2022.08322.PTDC). She is currently coordinating the research REMIND: Design for People with Dementia, under which pedagogical practices are being developed in partnership with Alzheimer Portugal. She has coordinated national and international events including conferences, symposia, seminars, exhibitions, and workshops; and developed pedagogical projects aimed at the interpretation of works of art from the past generations through digital media, in partnership with museums including Tate Modern, UK; the Soares dos Reis National Museum, Portugal; and the WOW Museum, Portugal.

        Graus

            * Mestrado
              Communication Sciences
            * Master
              Diseño i Producción Multimedia
            * Licenciatura
              Estudos Superiores Especializados em Design - Comunicação Visual
            * Doutoramento
              Doctoral Program in Digital Media
            * Pós-doutoramento
              First pedagogical practices in design at the Porto School of Fine Arts (post-doctorate)
            * Outros
              Dementia Therapies and Art
            * Outros
              Dementia Therapies and Art

        Publicações

        Magazine article

          * 2021-07, O Designer escultor: João Machado, DL – Revista Online Design ULP
          * 2017-01, Fotomontagem na Alemanha: do movimento Dada à manifestação antifascista, DL – Revista Online Design ULP
          * 2017, Os usos da fotomontagem na URSS, DL – Revista Online Design ULP
          * 2016, Arte e Design: pontos de encontro, DL – Revista Online Design ULP

        Journal article

          * 2023-11-30, Um contributo do design para a questão dos desperdícios gerados pelo setor da Construção Civil, Convergences - Journal of Research and Arts Education
          * 2022-07-07, Visual archives towards the recovery and reactivation of artistic and pedagogical heritage at the School of Fine Arts in Porto, Fotocinema. Revista Científica de Cine y Fotografía
          * 2022, Case Studies of a Trans-Generational Pedagogy of Art and Design, The International Journal of Design in Society
          * 2021-09, Da materialidade da obra à imaterialidade da representação digital: uma reinterpretação das obras de Francis Bacon em um contexto pedagógico, Rotura - Revista de Comunicação, Cultura e Artes
          * 2020-01-28, Traveling as a source of inspiration for artistic practice, Tsantsa. Revista De Investigaciones Artísticas
          * 2020, O designer escultor João Machado, Revista GAMA, Estudos Artísticos
          * 2020, Na Serra de Arga com João Nunes: design, política e feijoada, ArtCiência.com. Revista de Arte, Ciência e comunicação
          * 2019-10, O momento criativo: a mais-valia pedagógica de testemunhos biográficos de artistas portugueses, Tsantsa. Revista De Investigaciones Artísticas
          * 2019-01, Caminhos cruzados de Armando Alves, Revista Gama, Estudos Artísticos
          * 2019, Reading Through Pictures. An interpretative study of art and design academics between 1960s and late 1970s in Porto, Revista Mátria Digital
          * 2019, O Digital é de Ontem: Entrevista a Elvira Leite, Interact: Revista Online de Arte, Cultura e Tecnologia
          * 2018-07-10, Photomontage as a revolutionary agent [Fotomontaje como agente revolucionario], Fotocinema. Revista científica de cine y fotografía
          * 2016, Culturas participativas e bibliotecas públicas: análise da realidade portuguesa, Cadernos BAD
          * 2015, Bibliotecas públicas portuguesas 2.0: resultados de um estudo, Páginas a&b Arquivos & Bibliotecas
          * 2013, A utilização de plataformas web nas práticas comunicativas das bibliotecas públicas portuguesas, Revista Prisma.com

        Book

          * 2021, Threads of a Legacy. Towards a pedagogical heritage in art and design: the Porto School of Fine Arts, 1956-1984, Barreto, Susana (8B13-EA50-0F87); Alvelos, Heitor; Penedos-Santiago, Eliana; Lima, Cláudia; Martins, Nuno (C718-14EA-9B14), ID+ The Research Institute for Design, Media and Culture
          * 2015, Biblioteca em Rede: Comunicação integrada no contexto das culturas participativas, Lima, Cláudia; Heitor Alvelos; Viviana Fernández Marcial, Novas Edições Acadêmicas

        Book chapter

          * 2023, When in Memeland, Speak in Memes: Contributions of Design Towards the Betterment of Online Behavior Regarding Public Health, Advances in Design and Digital Communication IV, Springer Nature Switzerland
          * 2023, Intervention of Product Design in E-Commerce: Contribution to a Sustainable Proposal in Supermarket Delivery Services, Advances in Design and Digital Communication IV, Springer Nature Switzerland
          * 2023, Intersections between craft and sewing practices: A case study on community housing in Portugal, Cross Media Arts: Social Arts and Collaboration
          * 2023, Designing for People with Dementia: A Portuguese Case Study, Dementia Lab 2022: The Residue of Design, Springer International Publishing
          * 2023, Designing for People with Dementia: A Portuguese Case Study
          * 2023, Designing Playful Artefacts for People Living with Dementia: A Methodological Approach with Undergraduate Students, Perspectives on Design and Digital Communication IV, Springer Nature Switzerland
          * 2023, Design Contributions to Raise Awareness of Dementia and Tackle Stigma, Advances in Design and Digital Communication IV, Springer Nature Switzerland
          * 2022, Sci-Stories in Design: Guidelines for Curricular Inscription and Dissemination Through Visual Narratives, Perspectives on Design and Digital Communication III, Springer International Publishing
          * 2022, Designing for People with Dementia in Academic Contexts, Perspectives on Design and Digital Communication III, Springer International Publishing
          * 2022, Anti-Amnesia: Developing a Collaborative e-learning and Digital Archive Platform Towards Contributing to the Preservation and Revitalization of Handicrafts Industries, Developments in Design Research and Practice, Springer International Publishing
          * 2021, The rise of the first Design course at the School of Fine Arts of Porto, Threads of a Legacy. Towards a pedagogical heritage in art and design: the Porto School of Fine Arts, 1956-1984
          * 2021, The School of Carlos Ramos: A Lasting Legacy of a Revolution, Perspectives on Design and Digital Communication II, Springer International Publishing
          * 2021, The Designer Trail: José Brandão, A Life in Design Education, Perspectives on Design and Digital Communication II, Springer International Publishing
          * 2021, The Birth of Graphic Design in a School of Fine Arts: How the Specificity of a Learning Environment Determined a Course’s Vocation, Springer Series in Design and Innovation, Springer International Publishing
          * 2020, The Viability of Heritage Craft in a Global Marketplace, Handbook of Research on Driving Industrial Competitiveness With Innovative Design Principles, IGI Global
          * 2020, The Rise of the First Design Course at the School of Fine Arts of Porto, Springer Series in Design and Innovation, Springer International Publishing
          * 2020, The Rise of Communication Design in Portugal: An Overview of the Higher Education Teaching Methodologies, Advances in Human Factors in Training, Education, and Learning Sciences, Springer International Publishing
          * 2020, The Infographic Process of Synthesizing Complex Information About the Individual Legacies of Retired Teachers and Researchers in Art and Design, Advances in Human Factors in Training, Education, and Learning Sciences, Springer International Publishing
          * 2020, From Painting to Graphic Arts: The Unique Legacy of Armando Alves, Perspectives on Design and Digital Communication, Springer International Publishing
          * 2020, E-learning as a Strategic Solution for the Preservation and Revitalization of Disappearing Industrial Cultures in Portugal, Advances in Human Factors in Training, Education, and Learning Sciences, Springer International Publishing
          * 2018, Photomontage as a revolutionary agent, LUME: Unexpected Media, UA Editora/ IPCA/ ID+

        Report

          * 2021, Primeiras práticas pedagógicas em Design na Escola Superior de Belas Artes do Porto

        Conference paper

          * The rise of Communication Design in Portugal: an overview of the higher education teaching methodologies
          * Digital Media and Sustainable Development Goals Breathe New Life into the Artworks from the Soares Dos Reis National Museum, The European Conference on Arts, Design & Education (ECADE2022)
          * Design of a digital platform for the preservation and dissemination of Portuguese handicraft products
          * Bridging Art and Design teaching generations
          * 2023-11, When in Memeland, Speak in Memes: contributions of design towards the betterment of online behavior regarding public health, DIGICOM 2023 - 7th International Conference on Design and Digital Communication, 2023
          * 2023-11, Intervention of product design in e-commerce: contribution to a sustainable proposal in supermarket delivery services, DIGICOM 2023 - 7th International Conference on Design and Digital Communication, 2023.
          * 2023-11, Design contributions to raise awareness of dementia and tackle stigma , DIGICOM 2023 - 7th International Conference on Design and Digital Communication, 2023.
          * 2022, The importance of design and digital media for the promotion and sustainability of cultural and religious tourism, AHFE 2022 International Conference on Applied Human Factors and Ergonomics and the Affiliated Conferences
          * 2022, Self-initiated practices in the urban community of Balteiro: Design challenges in a post-pandemic setting., AHFE 2022 International Conference on Applied Human Factors and Ergonomics and the Affiliated Conferences
          * 2022, Interpreting Francis Bacon's Work through Contemporary Digital Media: Pedagogical Practices in University Contexts, AHFE 2022 International Conference on Applied Human Factors and Ergonomics and the Affiliated Conferences
          * 2022, Design practices within contemporary societies, AHFE 2022 International Conference on Applied Human Factors and Ergonomics and the Affiliated Conferences
          * 2021-07-15, From classroom to reality: Pedagogical practices in design oriented towards community contexts, CIVAE 2021 - 3rd Interdisciplinary and Virtual Conference on Arts in Education
          * 2020-04-06, O Designer escultor: João Machado, XI Congresso Internacional CSO, Criadores Sobre outras Obras
          * 2020-01-11, Learning Ecologies: From Past Generations to Current Higher Education, The IAFOR International Conference on Education – Hawaii 2020
          * 2020, Infographics of Wisdom
          * 2019-11-15, Connecting Graphic Design with its purpose: a private legacy of Armando Alves, DIGICOM 2019 - 3rd International Conference on Design and Digital Communication
          * 2019-11, Wisdom Transfer: The infographic study on the individual legacies from retired academics in art and design higher education and research, 10th Biennal International Conference in Design: Senses & Sensibility – Lost in (G)localization
          * 2019-07, Contributions of knowledge from past generations in current contexts of arts education, ECAH2019 Conference
          * 2019-04, Caminhos cruzados de Armando Alves, CSO’2019
          * 2019, Reading Through Pictures. An interpretative study of art and design academics between 1960s and late 1970s in Porto, GFIC 2019
          * 2013-10, Vantagens práticas da utilização de plataformas participativas para a promoção e disseminação de bens culturais: caso de estudo da Biblioteca Pública Municipal do Porto, 8º Congresso SOPCOM: Comunicação Global e Cultura
          * 2013-07-13, Biblioteca em Rede: Comunicação Integrada no Contexto das Culturas Participativas, UDesign'13, 2º encontro nacional doutoramentos em design
          * 2013-05-10, A descentralização da comunicação enquanto forma de promoção e expansão do conhecimento e desenvolvimento intelectual, 2º Congresso Literacia, Media e Cidadania
          * 2012-11, Virtualização da Biblioteca: Novas abordagens face à emergência de culturas digitais, 6th International Conference on Digital Arts. Artech 2012 - Crossing Digital Boundaries
          * 2012-07, Biblioteca em Rede: Comunicação Integrada no Contexto das Culturas Participativas, UDesign'12, 1º encontro nacional doutoramentos em design

        Conference abstract

          * 2024-06, Traversing the Infodemic: Analyzing Communication Practices and Strategies in Portuguese Media During and After the Covid-19 Pandemic, Design4Health2024
          * 2024-06, Designing games for people living with dementia: an approach centred on the person's biographical and cultural characteristics, Design4Health2024
          * 2023-09, Controversial Heritage: Designing Museum didactic materials for Porto’s schools, DRHA2023 Digital Research in the Humanities and Arts 2023
          * 2023-07, Co-designing Leisure Artefacts Based on Life Experiences: Contributions to Improve the Well-being of People Living with Dementia, The European Conference on Arts & Humanities (ECAH2023)
          * 2023-05, Communicating the experience of the pandemic through memes: a design approach in higher education, The European Conference on Arts & Humanities (ECAH2023)
          * 2023, THE ROLE OF LIFELONG LEARNING PRACTICES IN ARTS AND CRAFTS IN A SOCIAL NEIGHBOURHOOD: THE CASE STUDY OF THE ESCOLA OFICINA, The 11th European Conference on Arts & Humanities (ECAH)
          * 2023, CO-DESIGNING MEANINGFUL LEISURE PRODUCTS BASED ON LIFE EXPERIENCES: CONTRIBUTIONS TO IMPROVE THE WELL-BEING OF PEOPLE LIVING WITH DEMENTIA, The 11th European Conference on Arts & Humanities (ECAH)
          * 2022-06, Creative Ageing: Research Methods With Older Artists at the School of Fine Arts in Porto, The Paris Conference on Arts & Humanities (PCAH2022)
          * 2022, Contributions of Design in the Creation of Cognitive Stimulation Artefacts for Portuguese People with Dementia, The European Conference on Arts, Design & Education (ECADE2022)
          * 2022, Bringing Traditions and celebrations into the classroom: a Pedagogical Exercise, International Congress Festivals, Cultures and Communities: Heritage and Sustainability
          * 2021-09, Wisdom Transfer: Towards the Scientific Inscription of Individual Legacies in Contexts of Retirement from Art and Design, The Barcelona Conference on Arts, Media & Culture (BAMC)
          * 2020-09, Typographic essays as a contribution to trans-generational wisdom transfer in art and design, The Barcelona Conference on Arts, Media & Culture (BAMC)
          * 2020-09, A Pedagogical Revolution Before the Revolution: The Legacy of Architect Carlos Ramos, The Barcelona Conference on Arts, Media & Culture (BAMC)
          * 2020-05, Pedagogical practices for the appropriation and activation of transgenerational knowledge in art and design, Asian Conference on Arts and Humanities (ACAH2020 11th)
          * 2020-05, Interfaces of Knowledge: Digital Media as Mediator of the Contemporary Reactivation of Legacies, Asian Conference on Arts and Humanities (ACAH2020 11th)

        Artistic exhibition

          * 2023-12, Steal this Meme: Exploratory memes for citizens health
          * 2023-05-20, Histórias cruzadas: um olhar sobre o Balteiro e a Escola Oficina [Crossing Stories: A Glimpse of Balteiro and Escola Oficina]
          * 2023, Y U NO TRUST SCIENCE??? engaging with post-digital audiences on the subject of reliable scientific knowledge.
          * 2021-05-13, Retratos Contados [Narrated Portraits], Reitoria da Universidade do Porto, Portugal
          * 2016-12-10, Inspired by Surf - Photography exhibition
          * 2014-09-06, Framing the Waves - Surf Photography

        Visual artwork

          * Documentary photography of the work and routines of seamstresses in a workshop school in Vila Nova de Gaia in the context of the research project ECHO: Echoing the Communal Self: designing the dissemination and replication of self-initiated practices in underprivileged urban communities in a post-pandemic world. EXPL/ART-DAQ/0037/2021 23
          * Documentary photography of portuguese artists, their studios working methods; in the scope of Wisdom Transfer. POCI-01-0145-FEDER-029022

        Curatorial / Museum exhibition

          * 2022-05, Voltar ao Trabalho — Armando Alves. Exposição dos 90 cartazes. Armando Alves - Artes Gráficas 1965-2004 [Armando Alves Poster Exhibition]. Museu da Faculdade de Belas Artes, Universidade do Porto.
          * 2021, Threads of a Legacy. Towards a pedagogical heritage in art and design: the Porto School of Fine Arts, 1956-1984.

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona