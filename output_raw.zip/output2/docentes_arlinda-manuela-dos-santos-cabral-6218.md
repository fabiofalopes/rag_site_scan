# Response for https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
          PT: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218 EN: https://www.ulusofona.pt/en/teachers/arlinda-manuela-dos-santos-cabral-6218
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
        fechar menu : https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/arlinda-manuela-dos-santos-cabral-6218
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Arlinda Manuela Dos Santos Cabral

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6218
              p62***@ulusofona.pt
              9118-3DEA-120D: https://www.cienciavitae.pt/9118-3DEA-120D
              0000-0002-7399-1760: https://orcid.org/0000-0002-7399-1760
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/ec3da4bd-53dc-496c-885d-64222953539d
      : https://www.ulusofona.pt/

        Resume

        Arlinda Cabral holds a Ph.D. in Sociology of Education, Knowledge, and Culture, Universidade Nova de Lisboa (FCSH/UNL, 2014), with a grant from the Foundation for Science and Technology (FCT). Master's degree in Sociology of Education, Knowledge, and Society (FCSH / UNL, 2009) and Degree in Education Sciences – specialization in Training Management, from Universidade Lusófona de Humanidades e Tecnologias (ULHT, 2006). Certified with the “Literacy of Children and Adults in Paulo Freire's Pedagogy” Course (ULHT, 2004) and with the 14th Course of African Studies, from the Instituto Universitário Militar (2020). Assistant Professor in the Degree in Educational Sciences at the Faculty of Social Sciences, Education and Administration (FAED), Universidade Lusófona (ULHT). Coordinating Researcher at ReLeCo NEA-ES – Nucleus of African Studies: Education and Society, of the Center for Interdisciplinary Studies in Education and Development at Universidade Lusófona (CeiED/ULHT). Researcher at (1) CeiED/ULHT, (2) Ibero-American Research Network on Education Policies (RIAIPE), and (3) Working Group on Universities and Higher Education Policies of the Latin American Council of Social Sciences (CLACSO). Member of (1) the European Citizen Science Association (CSA), (2) the European Sociological Association, (3) the Portuguese Sociology Association, (4) the CPLP Research and Development Network, and the (4) Association of Young Researchers from Cape Verde, of which she was Vice-President (2010-2012). She has articles published in scientific journals. She has collaborated in the organization of national and international conferences and congresses, integrating Organizing Committees and Scientific Committees. A reviewer at JARHE – Journal of Applied Research in Higher Education/EMERALD, member of the Scientific Council of Inheritance – Journal of History, Heritage and Culture and member of the Editorial Board of Revista Lusófona de Educação (ULHT). She has supervised master's dissertations and academic internships in the areas of Political Science, International Relations and Diplomacy, African Studies, Education, and Sociology. She has been a member of doctoral and master's juries. She was a Guest Professor at ESTeSL/IPL and Guest Lecturer at FCSH/UNL, at the Higher Institute of Economics and Management of the University of Lisbon (ISEG/UL) and the Higher Institute of Agronomy of the University of Lisbon (ISA/UL). She has presented communications at national and international conferences. She was Dean of Graduation, Pedagogical Innovations and Distance Education at the University of Cabo Verde (Uni-CV, 2009/2010) and Coordinator of the Advanced Training Center at Escola Superior de Tecnologia da Saúde, Instituo Politécnico de Lisboa (ESTeSL/IPL), Portugal. She has been a Professor and Guest Lecturer at the National University of Timor-Leste (UNTL) (Timor-Leste), at the Higher Institute of Education Sciences (ISCED) in Luanda (Angola), and at the Eduardo Mondlane University (UEM) (Mozambique). She is Senior Technician Responsible for Cooperation in Education at the Executive Secretariat of the Community of Portuguese Speaking Countries (CPLP). Areas of academic and scientific interest: Educational Sciences; Sociology of Education; Comparative Education; Educational Policies; Global Education Agendas; Quality assessment in education and higher education; Education in Sub-Saharan and Lusophone Africa; Teacher training; gender issues in education and higher education.

        Graus

            * Mestrado
              Sociologia / Sociology
            * Licenciatura
              Ciências da Educação / Educational Sciences
            * Outros
              Formação Pedagógica Inicial de Formadores / Initial Pedagogical Training of Trainers
            * Curso médio
              Alfabetização de Crianças e Adultos segundo o Método de Paulo Freire / Literacy for Children and Adults according to Paulo Freire's Method
            * Outros
              XIV Curso de Estudos Africanos / 14th African Studies Course
            * Outros
              Seminário de Especialização em Conceção e Avaliação de Projetos / Specialisation Seminar in Project Design and Evaluation
            * Outros
              Statistical Package for Social Sciences (SPSS)
            * Doutoramento
              Sociologia / Sociology
            * Outros
              African Regional and Continental Integration and Cooperation in Higher Education

        Publicações

        Artigo em revista

          * 2024, África Subsaariana e Agendas Globais de Educação: uma reflexão sobre políticas de educação e de formação de professores , Cadernos de Estudos Africanos, Centro de Estudos Internacionais (CEI-IUL), Instituto Universitário de Lisboa (ISCTE-IUL)
          * 2022-03-22, Nota Introdutória ao Dossiê temático "A Educação na África Subsariana: Paradoxos e Desafios" (RLE54) / Introductory note to the thematic dossier "Education in Sub-Saharan Africa: Paradoxes and Challenges" (RLE54) , Revista Lusófona de Educação
          * 2021-08-28, Global Education Agendas and Teacher Training in Sub-Saharan Africa - Some Initial Thoughts, Academia Letters
          * 2019-12, Cape Verde Teacher Profile: From the global education agenda(s) to national policies, International Journal of Science and Research
          * 2014-09, Transition to work of university graduates: is gender a difference point? , International Journal of Research In Social Sciences
          * 2012-06-01, Inserção profissional de diplomados da UL e UNL: aprendizagens académicas e competências profissionais / Professional insertion of UL and UNL graduates: academic learning and professional skills, Revista Angolana de Sociologia
          * 2012, The Economic and Technical Contemporary Paradigm and the Transition to Work of Higher Education Graduates in Engineering, Manufacturing and Construction, International Journal of Social Sciences and Humanity Studies
          * 2012, O lugar do trabalho na vida dos diplomados do ensino superior em processo de inserção profissional / The place of work in the lives of higher education graduates in the process of transition to work, Atas do VII Congresso Português de Sociologia
          * 2012, Academic learning and professional skills: Transition to work of Higher Education Graduates in Engineering, Manufacturing and Construction, International Journal of Educational Research and Technology
          * 2009, O brain drain associado aos migrantes universitários cabo-verdianos / The brain drain associated with Cape Verdean university migrants, Actas do X Congresso Luso-Afro-Brasileiro de Ciências Sociais: Sociedades Desiguais e Paradigmas em Confronto
          * 2007, Recensão temática «A construção da escola democrática. Uma reflexão com base em Jacques Delors et al., Licínio Lima e Jaume Carbonell Sebarroja» / Building a democratic school. A reflection based on Jacques Delors et al., Licínio Lima and Jaume Carbonell Sebarroja, Revista Lusófona de Educação
          * 2005, Recensão crítica «Pedagogia do oprimido», de Paulo Freire, Revista Lusófona de Educação
          * 2005, Recensão crítica sobre a «Pedagogia do Oprimido», de Paulo Freire / Critical review of Paulo Freire's "Pedagogy of the Oppressed", Revista Lusófona de Educação (RLE)

        Tese / Dissertação

          * 2014, Doutoramento, A inserção profissional dos diplomados do ensino superior: conciliação e conflito na relação entre o trabalho e outras esferas da vida social / The professional integration of higher education graduates: reconciliation and conflict in the relationship between work and other spheres of social life

        Livro

          * 2016, Questões de género entre diplomados do ensino superior: Diferenças e semelhanças da situação laboral e da centralidade e valores do trabalho nas trajetórias profissionais / Gender issues among higher education graduates: Differences and similarities in employment status and the centrality and values of work in career paths, Cabral, Arlinda , Nova Edições Académicas

        Capítulo de livro

          * 2024, The Influence of Global and Regional Agenda on Higher Education in Sub-Saharan Africa: A Reflection on Policies and Practices for Social Transformation, Quality in African Higher Education
          * 2024, O Colonial: um circuito informativo entre Portugal e os domínios ultramarinos em finais da Monarquia, The Portuguese Studies Review/Baywolf Press , 1, !º, Baywolf Press
          * 2021, 12. Identidades étnico-raciais e educação. Dos pressupostos teóricos da igualdade entre os homens à construção de sociedades mais justas / 12. Ethnic-racial identities and education. From the theoretical assumptions of equality between men to the construction of fairer societies, Identidades, Paco Editorial
          * 2015, Trajetórias profissionais de diplomados do ensino superior: semelhanças e diferenças de género perante a centralidade do trabalho / Career paths of higher education graduates: similarities and gender differences in the face of the centrality of work, Livro de Atas do 1.º Congresso da Associação Internacional de Ciências Sociais e Humanas em Língua Portuguesa
          * 2014, Inovações pedagógicas ao serviço do trabalho docente: o caso do Instituto Superior de Ciências da Educação de Luanda - Angola / Pedagogical innovations at the service of teaching work: the case of the Higher Institute of Educational Sciences of Luanda - Angola, Experiências e innovación docente en el contexto actual de la docência universitária, Edita Educación Editora
          * 2013, A inserção profissional dos diplomados do ensino superior: das aprendizagens académicas às competências profissionais requeridas pelo mercado de trabalho / The professional integration of higher education graduates: from academic learning to the professional skills required by the job market, Trabalho, Organizações e Profissões: Recomposições Conceptuais e Desafios Empíricos , Associação Portuguesa de Sociologia
          * 2011, Comunidades de prática virtuais on line / Online virtual communities of practice, Formação Contínua. Relatos e Reflexões, Escola Superior de Educação/Instituto Politécnico de Lisboa
          * 2007, A educação, o primado da competência e a aprendizagem ao longo da vida - A nova forma necessária de ser na actualidade / Education, the primacy of competence and lifelong learning - The necessary new way of being today, A Juventude e a Promoção da Cultura de Investigação - I Encontro de Jovens Investigadores Cabo-Verdianos, SerSilito

        Edição de livro

          * 2023, Edições Universitárias Lusófonas
          * 2023, Edições Universitárias Lusófonas
          * 2022, Edições Universitárias Lusófonas
          * 2022
          * 2019, CPLP
          * 2019, CPLP

        Manual

          * 2006, Uma aventura na Web: À Descoberta de Paulo Freire / An Adventure on the Web: Discovering Paulo Freire

        Artigo em conferência

          * 2015-02, Expansão do ensino superior em Angola entre 2000 e 2010 - Contributos do Sul para a sociologia do ensino superior / Expansion of higher education in Angola between 2000 and 2010 - Contributions from the South to the sociology of higher education, XII CONLAB / 1.º Congresso da Associação internacional de Ciências Sociais e Humanas em Língua Portuguesa

        Resumo em conferência

          * 2023-09-27, O pensamento de Amílcar Cabral e a Educação: dos pressupostos teóricos da construção de democracia(s) à (re)descoberta no(s) campo(s) epistémico(s) contemporâneo(s) [The thought of Amílcar Cabral and Education: from the theoretical assumptions of the democracy building to its (re)discovery in the contemporary epistemic field(s)] , XV Congresso Luso-Afro-Brasileiro de Ciências Sociais (CONLAB): Reinventando a Democracia num Mundo de Inseguranças: Desafios para as Ciências Sociais e Humanas [XV Luso-Afro-Brazilian Congress of Social Sciences]

        Outra produção

          * 2011, Conciliação ou conflito entre o trabalho e as outras esferas da vida social na inserção profissional dos diplomados do ensino superior / Reconciliation or conflict between work and other spheres of social life in the professional integration of higher education graduates, Inserção profissional, diplomados, trabalho, esferas da vida social

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona