# Response for https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
          PT: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262 EN: https://www.ulusofona.pt/en/teachers/ana-catarina-francisco-nunes-matias-5262
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
        fechar menu : https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/ana-catarina-francisco-nunes-matias-5262
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Catarina N. Matias

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5262
              p52***@ulusofona.pt
              E516-067C-EBD3: https://www.cienciavitae.pt/E516-067C-EBD3
              0000-0003-2847-5924: https://orcid.org/0000-0003-2847-5924
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/da56c9a6-0689-4e23-ba16-e060bc2b1610
      : https://www.ulusofona.pt/

        Graus

            * Licenciatura
              Bioquímica
            * Mestrado
              Bioquímica
            * Doutoramento
              Atividade Física e Saúde
            * Pós-doutoramento
              Motricidade Humana

        Publicações

        Journal article

          * 2023-12-01, Is muscle localized phase angle an indicator of muscle power and strength in young women?, Physiological Measurement
          * 2023-11, Game on: A cross-sectional study on gamers’ mental health, Game patterns, physical activity, eating and sleeping habits, Computers in Human Behavior
          * 2023-03, Fat-free mass estimation in male elite futsal players: Development and validation of a new bioelectrical impedance–based predictive equation, Nutrition
          * 2023-01-05, Methods over Materials: The Need for Sport-Specific Equations to Accurately Predict Fat Mass Using Bioimpedance Analysis or Anthropometry, Nutrients
          * 2023, Resposta hormonal a uma carga de estresse e estados de ansiedade, humor, cansaço e recuperação dos cadetes-alunos de polícia portugueses , Revista Brasileira Medicina do Trabalho
          * 2023, Cortisol, testosterone and psychosocial responses in the assessment of stress in police officers: A brief systematic review of the literature , Revista Brasileira de Medicina do Trabalho
          * 2022-10-27, Development and Validation of an Anthropometric Equation to Predict Fat Mass Percentage in Professional and Semi-Professional Male Futsal Players, Nutrients
          * 2022-10, Comparison of generalized and athletic bioimpedance-based predictive equations for estimating fat-free mass in resistance-trained exercisers, Nutrition
          * 2022-08-24, Association between Phase Angle from Bioelectric Impedance and Muscular Strength and Power in Physically Active Adults, Biology
          * 2022-07-19, A Novel Plant-Based Protein Has Similar Effects Compared to Whey Protein on Body Composition, Strength, Power, and Aerobic Performance in Professional and Semi-Professional Futsal Players, Frontiers in Nutrition
          * 2022-05-11, Editorial: New Training Strategies and Evaluation Methods for Improving Health and Physical Performance, International Journal of Environmental Research and Public Health
          * 2022-03-25, Bioelectrical Impedance Vector Analysis Discriminates Aerobic Power in Futsal Players: The Role of Body Composition, Biology
          * 2021-11-27, Adaptive thermogenesis after moderate weight loss: magnitude and methodological issues, European Journal of Nutrition
          * 2021-10-27, The effects of phosphatidic acid on performance and body composition - a scoping review, Journal of Sports Sciences
          * 2021-10-27, The effects of phosphatidic acid on performance and body composition - a scoping review, Journal of Sports Sciences
          * 2021-10-01, Effectiveness of a lifestyle weight-loss intervention targeting inactive former elite athletes: the Champ4Life randomised controlled trial, British Journal of Sports Medicine
          * 2021-10-01, Effectiveness of a lifestyle weight-loss intervention targeting inactive former elite athletes: the Champ4Life randomised controlled trial, British Journal of Sports Medicine
          * 2021-08-19, Generalized bioelectric impedance-based equations underestimate body fluids in athletes, Scandinavian Journal of Medicine & Science in Sports
          * 2021-08-19, Generalized bioelectric impedance-based equations underestimate body fluids in athletes, Scandinavian Journal of Medicine & Science in Sports
          * 2021-06-21, Phase Angle Is a Marker of Muscle Quantity and Strength in Overweight/Obese Former Athletes, International Journal of Environmental Research and Public Health
          * 2021-06-21, Phase Angle Is a Marker of Muscle Quantity and Strength in Overweight/Obese Former Athletes, International Journal of Environmental Research and Public Health
          * 2021-06-12, Specific Bioelectrical Impedance Vector Analysis Identifies Body Fat Reduction after a Lifestyle Intervention in Former Elite Athletes, Biology
          * 2021-06-12, Specific Bioelectrical Impedance Vector Analysis Identifies Body Fat Reduction after a Lifestyle Intervention in Former Elite Athletes, Biology
          * 2021-03-25, Does adaptive thermogenesis occur after weight loss in adults? A systematic review, British Journal of Nutrition
          * 2021, Predictive equation for assessing appendicular lean soft tissue mass using bioelectric impedance analysis in older adults: effect of body fat distribution
          * 2020-12-18, Leucine metabolites do not induce changes in phase angle, bioimpedance vector analysis patterns, and strength in resistance trained men, Applied Physiology, Nutrition, and Metabolism
          * 2020-11-05, Prediction of Somatotype from Bioimpedance Analysis in Elite Youth Soccer Players, International Journal of Environmental Research and Public Health
          * 2020-10-27, A New Strategy to Integrate Heath–Carter Somatotype Assessment with Bioelectrical Impedance Analysis in Elite Soccer Players, Sports
          * 2020-09-10, Body Water Content and Morphological Characteristics Modify Bioimpedance Vector Patterns in Volleyball, Soccer, and Rugby Players, International Journal of Environmental Research and Public Health
          * 2020-09, Phase angle predicts physical function in older adults, Archives of Gerontology and Geriatrics
          * 2020-08-07, Fat-free Mass Bioelectrical Impedance Analysis Predictive Equation for Athletes using a 4-Compartment Model, International Journal of Sports Medicine
          * 2020-07-06, Bioimpedance Vector Patterns Changes in Response to Swimming Training: An Ecological Approach, International Journal of Environmental Research and Public Health
          * 2020-06-21, Phase Angle as a Marker of Muscular Strength in Breast Cancer Survivors, International Journal of Environmental Research and Public Health
          * 2020-05-26, Somatotype and Bioimpedance Vector Analysis: A New Target Zone for Male Athletes, Sustainability
          * 2020-05-12, The Cellular Composition of the Innate and Adaptive Immune System Is Changed in Blood in Response to Long-Term Swimming Training, Frontiers in Physiology
          * 2020-03-01, Identifying Athlete Body Fluid Changes During a Competitive Season With Bioelectrical Impedance Vector Analysis, International Journal of Sports Physiology and Performance
          * 2020-02, Phase angle and bioelectrical impedance vector analysis in the evaluation of body composition in athletes, Clinical Nutrition
          * 2020-02, Athletes have more susceptibility to oxidative stress: Truth or myth? A study in swimmers, Science & Sports
          * 2020-01-24, The Predictive Role of Raw Bioelectrical Impedance Parameters in Water Compartments and Fluid Distribution Assessed by Dilution Techniques in Athletes, International Journal of Environmental Research and Public Health
          * 2020-01-21, Champ4life Study Protocol: A One-Year Randomized Controlled Trial of a Lifestyle Intervention for Inactive Former Elite Athletes with Overweight/Obesity, Nutrients
          * 2020-01-07, Are predictive equations a valid method of assessing the resting metabolic rate of overweight or obese former athletes?, European Journal of Sport Science
          * 2019-12-12, Classic Bioelectrical Impedance Vector Reference Values for Assessing Body Composition in Male and Female Athletes, International Journal of Environmental Research and Public Health
          * 2019-12, Total body water and water compartments assessment in athletes: Validity of multi-frequency bioelectrical impedance, Science & Sports
          * 2019-10, The usefulness of Tanita TBF-310 for body composition assessment in Judo athletes using a four-compartment molecular model as the reference method, Revista da Associação Médica Brasileira
          * 2019-09-26, Usefulness of raw bioelectrical impedance parameters in tracking fluid shifts in judo athletes, European Journal of Sport Science
          * 2019-07, Usefulness of Reflection Scanning in Determining Whole-Body Composition in Broadly Built Individuals Using Dual-Energy X-ray Absorptiometry, Journal of Clinical Densitometry
          * 2019-05-12, Leucine metabolites do not attenuate training-induced inflammation in young resistance trained men, Journal of Sports Sciences
          * 2019-01, Leucine Metabolites Do Not Enhance Training-induced Performance or Muscle Thickness, Medicine & Science in Sports & Exercise
          * 2019-01, Association between whey protein, regional fat mass, and strength in resistance-trained men: a cross-sectional study, Applied Physiology, Nutrition, and Metabolism
          * 2019, Bioelectrical impedance vector analysis and phase angle: prognostic tools for swimmers?
          * 2018-12-27, No effect of HMB or a-HICA supplementation on training-induced changes in body composition, European Journal of Sport Science
          * 2018-10-22, Lack of agreement of in vivo raw bioimpedance measurements obtained from two single and multi-frequency bioelectrical impedance devices, European Journal of Clinical Nutrition
          * 2018-06-28, Accuracy of Bioelectrical Impedance Analysis in Estimated Longitudinal Fat-Free Mass Changes in Male Army Cadets, Military Medicine
          * 2018-05, Characterization and Comparison of Nutritional Intake between Preparatory and Competitive Phase of Highly Trained Athletes, Medicina
          * 2018-01-08, Long-term swimming training modifies acute immune cell response to a high-intensity session, European Journal of Applied Physiology
          * 2018, ) Effects of alpha-hydroxy-isocaproic acid upon body composition in a type I diabetic patient with muscle atrophy – a case study
          * 2017-10, Do Dynamic Fat and Fat-Free Mass Changes follow Theoretical Driven Rules in Athletes?, Medicine & Science in Sports & Exercise
          * 2017-06, Compensatory Changes in Energy Balance Regulation over One Athletic Season, Medicine & Science in Sports & Exercise
          * 2017-03, Comparison of immunohematological profile between endurance- and power-oriented elite athletes, Applied Physiology, Nutrition, and Metabolism
          * 2017, Energy Balance over One Athletic Season
          * 2016-05, Immune cell changes in response to a swimming training session during a 24-h recovery period, Applied Physiology, Nutrition, and Metabolism
          * 2016-04, Estimation of total body water and extracellular water with bioimpedance in athletes: A need for athlete-specific prediction models, Clinical Nutrition
          * 2016-04, Coordination between antioxidant defences might be partially modulated by magnesium status, Magnesium Research
          * 2016-03-02, Suitability of Bioelectrical Based Methods to Assess Water Compartments in Recreational and Elite Athletes, Journal of the American College of Nutrition
          * 2015-07, Utility of novel body indices in predicting fat mass in elite athletes, Nutrition
          * 2015-07, Magnesium and phase angle: a prognostic tool for monitoring cellular integrity in judo athletes, Magnesium Research
          * 2015, Validação da bioimpedância elétrica por multifrequência em atletas
          * 2014-10-03, Assessment of total body water and its compartments in elite judo athletes: comparison of bioelectrical impedance spectroscopy with dilution techniques, Journal of Sports Sciences
          * 2014-07-10, Increases in Intracellular Water Explain Strength and Power Improvements over a Season, International Journal of Sports Medicine
          * 2014-07, Validity of a combined heart rate and motion sensor for the measurement of free-living energy expenditure in very active individuals, Journal of Science and Medicine in Sport
          * 2014-05-15, Reference Values for Body Composition and Anthropometric Measurements in Athletes, PLoS ONE
          * 2014-04-02, Accuracy of a combined heart rate and motion sensor for assessing energy expenditure in free-living adults during a double-blind crossover caffeine trial using doubly labeled water as the reference method, European Journal of Clinical Nutrition
          * 2014, Sex-based effects on immune changes induced by a maximal incremental exercise test in well-trained swimmers
          * 2014, Magnesium Status and Exercise Performance in Athletes
          * 2013-07-15, Caffeine Intake, Short Bouts of Physical Activity, and Energy Expenditure: A Double-Blind Randomized Crossover Trial, PLoS ONE
          * 2013-07, Total Energy Expenditure Assessment in Elite Junior Basketball Players, Journal of Strength and Conditioning Research
          * 2013-06, Total body water and its compartments are not affected by ingesting a moderate dose of caffeine in healthy young adult males, Applied Physiology, Nutrition, and Metabolism
          * 2013-02, Estimation of percent body fat based on anthropometric measurements in children and adolescents with congenital adrenal hyperplasia due to 21-hydroxylase deficiency, Clinical Nutrition
          * 2013-02, Body composition in taller individuals using DXA: A validation study for athletic and non-athletic populations, Journal of Sports Sciences
          * 2013, Sedentary behaviour and adiposity in elite athletes
          * 2013, A moderate dose of caffeine ingestion does not change energy expenditure but decreases sleep time in physically active males: A Double-blind Crossover Randomized Trial
          * 2012-12-19, Is bioelectrical impedance spectroscopy accurate in estimating total body water and its compartments in elite athletes?, Annals of Human Biology
          * 2012-08, Is bioelectrical impedance spectroscopy accurate in estimating changes in fat-free mass in judo athletes?, Journal of Sports Sciences
          * 2012-07, Magnesium intake mediates the association between bone mineral density and lean soft tissue in elite swimmers, Magnesium Research
          * 2012-03, Anthropometric profiles of elite older triathletes in the Ironman Brazil compared with those of young Portuguese triathletes and older Brazilians, Journal of Sports Sciences
          * 2012-01-25, Validity of extracellular water assessment with saliva samples using plasma as the reference biological fluid, Biomedical Chromatography
          * 2012, Association of an entire season with body composition in elite junior basketball players
          * 2011-12, Magnesium intake is associated with strength performance in elite basketball, handball and volleyball players, Magnesium Research
          * 2011-11-24, Changes in regional body composition explain increases in energy expenditure in elite junior basketball players over the season, European Journal of Applied Physiology
          * 2011, Determinant factors of cardiorespiratory fitness in Portugueses of different ethnicities
          * 2010, Magnesium And Strength In Elite Judo Athletes According to Intracellular Water Changes
          * 2010, Accuracy of DXA in estimating body composition changes in elite athletes using a four compartment model as the reference method, Nutrition & Metabolism

        Thesis / Dissertation

          * 2014, PhD, Hydrometry and Body Composition: Methods Development and Validation in Athletes
          * 2008, Master, Avaliação fisiológica de um grupo de atletas de alta competição de desportos de combate
          * 2007, Degree, Avaliação imunológica de um grupo de atletas de alta competição antes e depois de regime de treino

        Book chapter

          * 2017, Weight Sensitive Sports, Body Composition: Health and Performance in Exercise and Sport

        Report

          * 2014, Development and Validation of Methods to Assess Total Body Water, Extracellular and Intracellular water in Highly Active Adults
          * 2012, Efeitos da ingestão de cafeína na água corporal total, distribuição de fluidos intra e extracelulares e no dispêndio energético

        Conference abstract

          * 2023, The influence of sex on pulmonary oxygen uptake and deoxyhemoglobin kinetics during moderate and supramaximal intensity running , European College of Sport Sciences
          * 2023, Phase angle is a preditor in swimming.? , European College of Sport Sciences
          * 2023, Does the ultrasound thickness represent an accurate method to predict lean mass in resistance trained men? , ECSS
          * 2022, The Development And Validation Of A Skinfold-Thickness Prediction Equation In High Level Futsal Athletes., ECSS
          * 2022, Sensibilidade de indicadores de fadiga não invasivos às variações da carga de treino ao longo de um macrociclo em nadadores jovens, APTN
          * 2022, Physical Activity: a tool to improve sleep and mental health in esports , Anais do 45° Simpósio Internacional de Ciências do Esporte
          * 2022, No Differences Between A Novel Plant-Based Protein Vs. Whey Protein On Body Composition And Performance Of Professional And Semi-Professional Futsal Players , ECSS
          * 2022, Effects of a novel melatonin supplement format on sleep scores, body composition and metabolism. , Anais do 45° Simpósio Internacional de Ciências do Esporte
          * 2022, Development and validation of a bioelectrical impedance-based predictive equation for estimating fat-free mass in professional and semi-professional male futsal players , Anais do 45° Simpósio Internacional de Ciências do Esporte
          * 2022, Can critical velocity in young swimmers be determined by a 10x25m all-out swimming test? , ECSS
          * 2021, Ângulo de fase como indicador de hidratação celular e força muscular dinâmica em adultos fisicamente ativos , 44º Simpósio Internacional de Ciências do Esporte e 4º Simpósio de Atividade Física e Comportamento Sedentário
          * 2021, The Effects of Leucine Metabolites on Perfomance, Body Composition and Biochemical Markers of Mucle Damage Inflammation in Young Resistance , Science Symposia – Sports Science Congress
          * 2021, Associação entre o ângulo de fase da impedância bioelétrica e o desempenho anaeróbio em adultos fisicamente ativos , 44º Simpósio Internacional de Ciências do Esporte e 4º Simpósio de Atividade Física e Comportamento Sedentário
          * 2021, A higher skeletal muscle mass and strength is related with a greater phase angle in former athletes with overweight/obesity , Science Symposia – Sports Science Congress
          * 2021, ) Specific bioelectrical impedance vector analysis identifies body fat reduction after a lifestyle intervention in former elite athletes , European Congresso of Sport Science
          * 2020, Characterization of body composition and health outcomes in former athletes with overweight/obesity.
          * 2020, CHAMP4LIFE Study Protocol: A one-year randomized controlled trial of a lifestyle intervention for inactive former elite athletes with overweight/obesity
          * 2019, Usefulness of Tanita TBF-310 for body composition assessment in Judo elite athletes using a four-compartment molecular model as the reference method
          * 2019, Long-term changes on bdnf and igf-1 in patients with T2DM training at different intensities.
          * 2019, Are Predictive Equations Valid for Resting Metabolic Rate Estimation in Former Elite Athletes Using Indirect Calorimetry as the Reference Method?
          * 2019, Are Predictive Equations Valid for Resting Metabolic Rate Estimation in Former Elite Athletes Using Indirect Calorimetry as the Reference Method
          * 2018, No Effect Of Hmb Or a-hica On Training-induced Changes In Performance Or Body Composition
          * 2017, Training influences the accute imune response to a maximal swimming test
          * 2017, Training influences the accute imune response to a maximal swimming test
          * 2017, Highly trained athletes do not reach nutritional recommendations over the season
          * 2017, Directly Measured Free Living Energy Expenditure and Anaerobic Performance in Children and Adolescents
          * 2017, CBA – cytokines applied to sports sciences
          * 2016, Is Magnesium a key factor for redox balance in athletes?
          * 2015, Total body and extracellular water hydration estimates in highly active adults: a validation of bioelectrical impedance methods
          * 2015, Skinfold thickness measurement in athletes: a comparison between Lohman´s and ISAK protocol
          * 2015, Immune response to a swimming session during a 24h recovery period
          * 2015, Hematocrit variations mediates the association between aerobic capacity and fat-free mass changes
          * 2015, Energy Expenditure, Energy Balance and Body Composition over a season.
          * 2015, A Partial Scanning Technique for the Assessment of Broad Individuals using DXA.
          * 2014, Total body and extracellular water hydration estimates in highly active adults: a validation of bioelectrical impedance methods
          * 2014, Skinfold thickness measurement in athletes: a comparison between Lohman´s and ISAK protocol
          * 2014, Magnesium and Phase Angle: a prognostic tool in cellular integrity of judo athletes
          * 2014, Hematocrit variations mediates the association between aerobic capacity and fat-free mass changes
          * 2014, Energy Expenditure, Energy Balance and Body Composition over a season
          * 2014, Changes in energy expenditure, energy intake, energy imbalance, and body composition and over a season
          * 2014, BIA models to assess total body and extracellular hydration in athletes
          * 2014, A Partial Scanning Technique for the Assessment of Broad Individuals using DXA
          * 2013, Role of Caffeine Intake on Short Bouts Frequency in Light and Moderate-to-Vigorous Physical Activity Patterns
          * 2013, Elite Players that Increased Intracellular Water Improved Jumping Height and Strength Over the Season
          * 2013, Are Changes in Body Composition Associated With Jumping Height and Strength Over a Season in National Level Basketball, Handball, And Volleyball Players?
          * 2012, Systemic changes after 4 months of swimming training
          * 2012, Magnesium status and performance.
          * 2012, Magnesium status and performance.
          * 2012, Is a Combined Heart Rate and Motion Sensor Valid for Assessing Energy Expenditure in Free-Living Adults during a Caffeine or Placebo Experimental Trial using Double Labeled Water as the Reference Method
          * 2012, Immune response effects of a swimming session remain for more than 24 hours.
          * 2012, Doses Moderadas de Cafeína tem Efeito sobre a Água Corporal Total e Seus Compartimentos em Homens Saudáveis?
          * 2012, Does caffeine intake increases energy expenditure and habitual physical activity? A double-blind randomized crossover trial
          * 2012, Are Body Composition Changes Associated with Energy Expenditure in Elite Junior Basketball Players
          * 2011, Validation of body components assessed by DXA using the sum of two separate scans: a preliminary study
          * 2011, Total energy expenditure: combined heart rate and motion sensor vs uni-axial accelerometry models
          * 2011, The role of calf circumference among sarcopenic and non-sarcopenic Brazilian elderly: the SABE Study
          * 2011, Pre-season characterization of elite Portuguese athletes for total and activity energy expenditure and physical activity level
          * 2011, Magnesium intake is associated with strength performance in elite basketeball, handball and volleyball players
          * 2011, Magnesium intake is associated with strength performance in elite basketball, handball and volleyball players
          * 2011, Is Bioelectrical Impedance Spectroscopy Accurate to Estimate Fat-Free Mass Changes in Elite Judo Athletes?
          * 2011, Immune Responses To An Acute Maximal Exercise Changes During A Training Cycle In Swimming
          * 2011, Immune Changes Induced by a Maximal Incremental Swimming Test.
          * 2011, Extracellular Water Assessment by Bromide Dilution with Saliva Samples: A Validation Study Using Plasma as the Reference Biological Fluid
          * 2011, Energy Requirements of Elite Junior male basketball Players: A Validation Study Using Doubly Labeled Water
          * 2011, Effects Total body Water and Body Fluid distribution changes on Strength in Elite Basketball Players
          * 2011, Does caffeine intake affect resting energy expenditure?
          * 2011, Do elite swimmers report accurately their energy requirements? A validation study using doubly-labeled water
          * 2011, Do Changes in Total-Body Water and Fluid Distribution Predict Outcome in Forearm Maximal Strength in Elite Judo Athletes?
          * 2011, Changes in body composition and energy expenditure over the season in elite junior basketball players: is there a link?
          * 2011, Changes in Fat-Free Mass Composition and Density in Elite Basketball Players over an Entire Season
          * 2011, Body cell mass is a cardiorespiratory fitness predictor in male and female elite swimmers
          * 2011, Accuracy of a combined heart rate and motion sensor for the measurement of energy expenditure in elite junior basketball players
          * 2010, Validity of Bioelectrical Impedance Spectroscopy Using Deuterium Dilution as the Reference Method in Middle-Aged and Elderly Portuguese Men and Women
          * 2010, Relationship between changes in total-body water and fluid distribution with maximal forearm strength in elite judo athletes
          * 2010, Magnesium and Strength in Elite Combat Sports Athletes According to Intracellular Water Changes
          * 2010, Is body cell mass determinant for cardiorespiratory fitness in male and female elite basketball players?
          * 2010, Is body cell mass a cardiorespiratory fitness predictor in male and female elite basketball players?
          * 2010, Effects of an entire season on body composition and performance in elite basketball players
          * 2009, An Intracellular Water Reduction Before A Competition Decreases Grip Strength In Elite Judo Athletes
          * 2008, Magnesium and immune system in elite combat sports athletes.
          * 2008, Magnesium and immune system in elite combat sports athletes.
          * 2008, Immune system in elite combat sports athletes.
          * 2008, Immune changes in elite swimmers over the course of a training cycle.
          * 2008, Immune changes in elite swimmers after a maximal exercise test.
          * 2008, An Intracellular Water Reduction Before A Competition Decreases Upper-body Power Output In Elite Judo Athletes.

        Conference poster

          * 2023, Physiological and psychological characteristics of the Portuguese Air Force crews, Congresso de Exercício e Saúde e Portugal Fit.
          * 2023, Phase angle is a preditor in swimming.? , ECSS
          * 2023, Inclusive Swimming Competition - Beyond Handicaps., Congresso de Exercício e Saúde e Portugal Fit.
          * 2023, ACTIVUS – Activating the Dual Career of Athletes and Holistic Development of Young, Talented Athletes across Europe. , Congresso de Exercício e Saúde e Portugal Fit.
          * 2022, The Development And Validation Of A Skinfold-Thickness Prediction Equation In High Level Futsal , ECSS
          * 2021, Specific bioelectrical impedance vector analysis identifies body fat reduction after a lifestyle intervention in former elite athletes , 26th Annual Congress Of The European College Of Sport Science
          * 2021, ) A higher skeletal muscle mass and strength is related with a greater phase angle in former athletes with overweight/obesity , Science Symposia – Sports Science Congress
          * 2020, Characterization of body composition and health outcomes in former athletes
          * 2020, CHAMP4LIFE Study Protocol: A one-year randomized controlled trial of a lifestyle intervention for inactive former elite athletes with overweight/obesity
          * 2019, Long-term changes on bdnf and igf-1 in patients with T2DM training at different intensities
          * 2018, Usefulness of Tanita TBF-310 for body composition assessment in Judo elite athletes using a four-compartment molecular model as the reference method. (
          * 2018, Are Predictive Equations Valid for Resting Metabolic Rate Estimation in Former Elite Athletes Using Indirect Calorimetry as the Reference Method?
          * 2017, Training influences the accute imune response to a maximal swimming test
          * 2017, Highly trained athletes do not reach nutritional recommendations over the season
          * 2017, Highly trained athletes do not reach nutritional recommendations over the season
          * 2017, Directly Measured Free Living Energy Expenditure and Anaerobic Performance in Children and Adolescents
          * 2016, Is Magnesium a key factor for redox balance in athletes?
          * 2014, Total body and extracellular water hydration estimates in highly active adults: a validation of bioelectrical impedance methods.
          * 2014, Hematocrit variations mediates the association between aerobic capacity and fat-free mass changes
          * 2014, A Partial Scanning Technique for the Assessment of Broad Individuals using DXA
          * 2013, Role of Caffeine Intake on Short Bouts Frequency in Light and Moderate-to-Vigorous Physical Activity Patterns.
          * 2013, Elite Players that Increased Intracellular Water Improved Jumping Height and Strength Over the Season.
          * 2012, Is a Combined Heart Rate and Motion Sensor Valid for Assessing Energy Expenditure in Free-Living Adults during a Caffeine or Placebo Experimental Trial using Double Labeled Water as the Reference Method?
          * 2012, Does caffeine intake increases energy expenditure and habitual physical activity? A double-blind randomized crossover trial
          * 2011, Validation of body components assessed by DXA using the sum of two separate scans: a preliminary study
          * 2011, Total energy expenditure: combined heart rate and motion sensor vs uni-axial accelerometry models
          * 2011, The role of calf circumference among sarcopenic and non-sarcopenic Brazilian elderly: the SABE Study
          * 2011, Pre-season characterization of elite portuguese athletes for total and activity energy expenditure and physical activity level
          * 2011, Magnesium intake is associated with strength performance in elite basketeball, handball and volleyball players
          * 2011, Is Bioelectrical Impedance Spectroscopy Accurate to Estimate Fat-Free Mass Changes in Elite Judo Athletes?
          * 2011, Immune Responses to An Acute Maximal Exercise Changes During A Training Cycle In Swimming
          * 2011, Immune Changes Induced by a Maximal Incremental Swimming Test
          * 2011, Does caffeine intake affect resting energy expenditure?
          * 2011, Do elite swimmers report accurately their energy requirements? A validation study using doubly-labeled water
          * 2010, Validity of Bioelectrical Impedance Spectroscopy Using Deuterium Dilution as the Reference Method in Middle-Aged and Elderly Portuguese Men and Women
          * 2010, Magnesium and Strength in Elite Combat Sports Athletes According to Intracellular Water Changes
          * 2009, An Intracellular Water Reduction Before a Competition Decreases Upper-body Power Output in Elite Judo Athlet
          * 2009, An Intracellular Water Reduction Before a Competition Decreases Grip Strength in Elite Judo Athletes.
          * 2008, Magnesium and immune system in elite combat sports athletes.
          * 2008, Immune system in elite combat sports athletes.
          * 2008, Immune changes in elite swimmers over the course of a training cycle
          * 2008, Immune changes in elite swimmers after a maximal exercise test.

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona