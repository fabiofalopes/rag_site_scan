# Response for https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
          PT: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879 EN: https://www.ulusofona.pt/en/teachers/fabrizio-boscaglia-901879
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
        fechar menu : https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/fabrizio-boscaglia-901879
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Fabrizio Boscaglia

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p901879
              fab***@ulusofona.pt
              3C18-8A32-F3DE: https://www.cienciavitae.pt/3C18-8A32-F3DE
              0000-0001-8816-3880: https://orcid.org/0000-0001-8816-3880
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/066c51ae-d7ed-40d0-896d-d17494ef7727
      : https://www.ulusofona.pt/

        Resume

        Fabrizio Boscaglia (Turin, 1981) is a lecturer and researcher at the Lusófona University (Lisbon, Portugal), where he is deputy director of the master's programme in Science of Religions and a member of the LusoGlobe (Lusófona Centre on Global Challenges). He holds a PhD in Philosophy from the University of Lisbon and collaborates with the Centre for Global Studies at the Aberta University as well as the Centre of Philosophy and the Centre for Comparative Studies at the University of Lisbon. These are his research interests: the reception and representation of Islam in contemporary Portuguese culture; the thought and work of Fernando Pessoa; Sufism and Islamic spirituality. He is author and coordinator of scientific publications at international level, guest editor of scientific journals at Brown University (USA, «Pessoa Plural») and University of Múrcia (Spain, «El Azufre Rojo»), guest curator at the Calouste Gulbenkian Museum (exhibition of Islamic art «Divine Wisdom: the Sufi way») and at the National Library of Portugal, consultant at King's College London, coordinator of the Database of Islamic Heritage in Portugal at Lusófona University, lecturer on Literary and Religious Tourism at the National Tourism Authority of Portugal, author of one book or poetry, coordinator for Portugal of the MIAS-Latina studies association.

        Graus

            * Mestrado integrado
              Mestrado Integrado em Psicologia (Pré-Bolonha) [Master's Degree in Psychology]
            * Outros
              Curso de Filosofia Islâmica [Islamic Philosophy Course]
            * Doutoramento
              Doutoramento em Filosofia [PhD in Philosophy]

        Publicações

        Artigo em revista (magazine)

          * 2022-08-16, Turismo literário: a palavra enquanto viagem, Publituris Hotelaria
          * 2015-12-21, A presença de Omar Khayyam e da cultura islâmica no pensamento de Fernando Pessoa (Entrevista com Fabrizio Boscaglia), Piadero Literary Magazine
          * 2015-12-20, Entrevista com Fabrizio Boscaglia, Blog Um Fernando Pessoa
          * 2015-07-20, «Non me ne sono mai andato, sto viaggiando». Intervista a Mariano Deidda a cura di Fabrizio Boscaglia, Portosepolto Taccuino Letterario
          * 2010, Intervista a D. Trasparente, Scripta Ri(Manent) Magazine

        Edição de número de revista

          * Número especial Maria Gabriela Llansol e Ibn Arabi, 6

        Artigo em revista

          * 2021, Pessoa e a interiorização do Oriente [recensão/review], Pessoa Plural – A Journal of Fernando Pessoa Studies
          * 2020, Ibn Arabi, O Engaste de Sabedoria Profética no Verbo de Jesus, Philosophica
          * 2018, Edmondo De Amicis, Constantinopla, Lisboa, Tinta-da-china, 2017 [recensão/review], Estudos Italianos em Portugal
          * 2017, [Fernando Pessoa e a cultura arábico-islâmica], [O Contexto Literário]
          * 2017, Uma abstração do abgad? Entrevista com a artista portuguesa Sara Domingos , Al-Irfan - Revista de ciencias humanas y sociales
          * 2017, Orientalismo e Islão em Fidelino de Figueiredo, Nova Águia - Revista de Cultura para o Século XXI
          * 2017, O Pensamento Português na revista Philosophica: uma síntese panorâmica (1993-2017), Philosophica
          * 2017, O Pensamento Português na Revista Philosophica: Uma Síntese Panorâmica
          * 2017, Elementos para um estudo sobre Pessoa e Khayyam, Rivista di Studi Portoghesi e Brasiliani
          * 2016-01, Fernando Pessoa, Blas Infante e Al-Mu'tamid: do Al-Andalus ao «dia triunfal», Colóquio-Letras
          * 2016, Remarks on Islam and Islamic Philosophy in Portuguese Contemporary Thought: from Antero to Pessoa, Revista Lusófona de Ciência das Religiões
          * 2016, Número especial Oriente e Orientalismo: Introdução, Pessoa Plural - A Journal of Fernando Pessoa Studies
          * 2016, Nietzsche, Pessoa e o Islão: notas sobre a receção de Der Antichrist por Fernando Pessoa, Nietzsche e Pessoa: Ensaios
          * 2016, Manuel Cândido Pimentel, Sofia Alexandra Carvalho (coord.), António Quadros. Obra, Pensamento, Contextos [recensão/review], Philosophica
          * 2016, Fernando Pessoa and Islam: an introductory overview with a critical edition of twelve documents, Pessoa Plural - A Journal of Fernando Pessoa Studies
          * 2016, As Chronicas Decorativas de Fernando Pessoa: edição crítica de oito documentos, Pessoa Plural - A Journal of Fernando Pessoa Studies
          * 2015, Pessoa, Borges and Khayyam, Variaciones Borges
          * 2014, «Di là dall’orizzonte»: scritti, pensieri e immagini dagli archivi di Fernando Pessoa, Tintas. Quaderni di letterature iberiche e iberoamericane
          * 2013, Presence of Islamic philosophy in unpublished writings by the young Fernando Pessoa, Pessoa Plural: a Journal of Fernando Pessoa Studies
          * 2013, Iberismo e “arabismo” in Fernando Pessoa, Eurasia. Rivista di Studi Geopolitici
          * 2013, Cenni sulla lusofonia, Eurasia. Rivista di Studi Geopolitici
          * 2013, A presença arábico-islâmica na Ibéria de Fernando Pessoa, Nova Águia. Revista de Cultura para o Século XXI
          * 2012, L'influenza Arabo-Islamica nel pensiero di Fernando Pessoa: l'entusiasmo dell'immaginazione, L'ombra. Tracce e Percorsi a partire da C. G. Jung
          * 2012, Fernando Pessoa leitor de Theodor Nöldeke. Notas sobre a recepção do elemento arábico-islâmico em Pessoa, Pessoa Plural: a Journal of Fernando Pessoa Studies
          * 2011, Khayyam na obra e na biblioteca de Pessoa: entre poesia, filosofia e ecos de sabedoria Sufi, Cultura Entre Culturas

        Tese / Dissertação

          * 2015, Doutoramento, A presença árabe-islâmica em Fernando Pessoa
          * 2007, Mestrado, Sostiene Pessoa: l'arte di un'individuazione debole

        Livro

          * 2012, Considerações sobre a presença do elemento arábico-islâmico no sensacionismo e no neo-paganismo de Fernando Pessoa, 1, Boscaglia, Fabrizio, Al-Barzakh

        Capítulo de livro

          * 2023, Adalberto Alves - 40 anos de vida literária: mostra na Biblioteca Nacional de Portugal, Adalberto Alves – 40 anos de vida literária, Edições Universitárias Lusófonas
          * 2021, Fernando Pessoa and Islamic philosophy, Fernando Pessoa and Philosophy: countless lives inhabit us, Rowman & Littlefield International
          * 2020, Tavira e as religiões no século XVI: cristãos, cristãos-novos e mouriscos, A Principal do Reino do Algarve – Tavira nos séculos XV e XVI, Museu Municipal de Tavira-Palácio da Galeria
          * 2019, O Sagrado na Tradição Islâmica, Tabula Rasa: 2º Festival Literário de Fátima – A Literatura e o Sagrado, Zéfiro
          * 2019, Agostinho da Silva, o Islão e o Quinto Império, Redenção e Escatologia – Estudos de Filosofia, Religião, Literatura e Arte na Cultura Portuguesa, 3, Universidade Católica Editora
          * 2018, A Pérsia em Fernando Pessoa, Portugal no Golfo Pérsico: 500 anos, Biblioteca Nacional de Portugal
          * 2017, Córdova e Granada e No Magrebe de Antero de Figueiredo: estudo e edição crítica de cinco documentos, A Dinâmica dos Olhares – Cem Anos de Literatura e Cultura em Portugal, CLEPUL
          * 2017, Atavismos árabes em Teixeira de Pascoaes, Teixeira de Pascoaes, vol. 2, A Arte de Ser Português e a Renascença Portuguesa, Colibri
          * 2016, Quem são os infiéis no Quinto Império de Fernando Pessoa?, Giochi di Specchi: modelli, tradizioni, contaminazioni e dinamiche interculturali nei e tra i paesi di lingua portoghese, ETS
          * 2016, Orpheu da Arábia: a temática arábico-islâmica no modernismo português, 100 Orpheu, 1, Edições Esgotadas
          * 2016, Islão, Vertente Sunita | Vertente Xiita | Vertente Xiita Ismaelita
          * 2016, Islão - vertente xiita, Cosmovisões Religiosas e Espirituais: guia didático de tradições presentes em Portugal, Alto Comissariado para as Migrações
          * 2016, Islão - vertente xiita ismaelita, Cosmovisões Religiosas e Espirituais: guia didático de tradições presentes em Portugal, Alto Comissariado para as Migrações
          * 2016, Islão - vertente sunita, Cosmovisões Religiosas e Espirituais: guia didático de tradições presentes em Portugal, Alto Comissariado para as Migrações
          * 2010, La sabiduría de Omar Khayyam en la lectura de Fernando Pessoa y en la tradición filosófica persa: elementos para una comparación, El pensar poético de Fernando Pessoa, 1, Morata de Tajuña

        Edição de livro

          * 2023, Edições Universitárias Lusófonas
          * 2022, Edições Universitárias Lusófonas
          * 2016, 1, Brown University

        Revisão de livro

          * MANUEL CÂNDIDO PIMENTEL, SOFIA ALEXANDRA CARVALHO (coord.), António Quadros. Obra, Pensamento, Contextos.

        Artigo em conferência

          * Orpheu Filosófico: a Geração de Orpheu entre Artes e Filosofia (notas introdutórias), Novos Estudos Pessoanos ¿- Colóquio 2022
          * O Livro do Desasocego e a Psicologia de James Hillman: um diálogo imaginário, Colóquio Internacional Olhares Europeus sobre Fernando Pessoa
          * Notas sobre a presença do "elemento árabe" nos ismos de Fernando Pessoa, Nietzsche, Pessoa e Freud. Colóquio Internacional
          * Fernando Pessoa e a cultura árabe-islâmica: de Al-Cossar a Omar Khayyam, Congresso Internacional Fernando Pessoa

        Prefácio / Posfácio

          * 2023, Adalberto Alves: 40 anos de vida literária
          * 2022, Orpheu Filosófico: a Geração de Orpheu entre Artes e Filosofia
          * 2021, Dante e Portugal: presenças lusas e andaluzas na Divina Comédia
          * 2019, El Azufre Rojo – Revista de Estudios sobre Ibn Arabi - Número especial sobre Maria Gabriela Llansol e Ibn ¿Arabi
          * 2016, Pessoa Plural – A Journal of Fernando Pessoa Studies, n.º especial Oriente e Orientalismo

        Exposição artística

          * 2022, Pinharanda Gomes: historiador do pensamento português
          * 2022, Divine Wisdom: the Sufi way
          * 2020, Al-Mu'tamid: poeta do Gharb al-Andalus
          * 2020, Adalberto Alves: 40 anos de vida literária
          * 2018, As mil e uma noites em Portugal
          * 2017, Árabes e Islão na Literatura e no Pensamento Português (1826-1935)

        Outra produção

          * 2018, Visita guiada "Álvaro de Campos, Tavira e as Três Culturas"
          * 2018, Visita au Santuário do Sol Eterno e da Lua
          * 2018, Recordando Fernando Pessoa
          * 2018, Inauguração da Exposição Reverdecer de Sara Domingos
          * 2018, Cosmopolitismo e interculturalidade em Fernando Pessoa
          * 2017, Visita Guiada - Árabes e Islão na literatura e no pensamento português (1826-1935)
          * 2017, Saudade de uma outra Arábia
          * 2017, Al-Gharb Project - projeto literário musical
          * 2015, Visitas turístico-literárias "Lisboa com Fernando Pessoa"
          * 2015, Tertúlia "Álvaro de Campos tinha antepassados árabes?"
          * 2015, Tertúlia "Fernando Pessoa tinha heterónimos árabes?"
          * 2015, Tertúlia "Conversas no Café-Bar: essa alma pública de uma vila"
          * 2015, Passeio turístico-literário "A Lisboa de Antero de Quental e da Geração de 70"
          * 2015, Palestra "A cultura arábico-islâmica no Quinto Império de Fernando Pessoa"
          * 2014, Tertúlia "Mil e um Fernando Pessoa"
          * 2013, Roteiro Literário
          * 2012, Tertúlia "Notas sobre Fernando Pessoa, Omar Khayyâm e as rubaiyat"
          * 2009, Tertúlia "Eteronimia e psiche in Fernando Pessoa"
          * 2009, Rito Culturale
          * 2008, Tertúlia "Il mito-Pessoa"

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona