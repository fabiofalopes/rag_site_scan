# Response for https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
          PT: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340 EN: https://www.ulusofona.pt/en/teachers/angela-sofia-mendes-ferreira-5340
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
        fechar menu : https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/angela-sofia-mendes-ferreira-5340
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          ângela Sofia Mendes Ferreira

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5340
              ang***@me.com
              0000-0001-8597-5648: https://orcid.org/0000-0001-8597-5648
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/16165a08-6b33-4582-9a92-b2e6e0e69151
      : https://www.ulusofona.pt/

        Resume

        Ângela Ferreira, Porto 1975. Ângela is an artist, curator and researcher in the field of Contemporary Photography and Visual Culture. She has a PhD in Visual Communication from the University of Minho (Braga, Portugal), with a scholarship from FCT dedicated to the indigenous studies; Master in Photography, from the Utrecht School of Arts-Netherlands and a Law Degree from the University of Minho. She has a Postdoctoral research at Post-Graduation Program in Visual Arts, in the line of research of Theory and Experiments in Art, in the field of Interdisciplinary Poetics at the School of Fine Arts of the Federal University of Rio de Janeiro, Brazil, developing studies on contemporary visual practices that problematize the hybrid forms of Photography, and contemporary art, as a hybrid phenomenon, through transversal languages. Integrated Member of CICANT, Center for Research in Applied Communication, Culture and New Technologies, Lisboa and Member of the research group NANO Organisms of New Arts at the School of Fine Arts at UFRJ. (NanoLab), Rio de Janeiro, Brazil. She is guest Adjunct teacher at Polytechnic Institute of Porto (School of Media Arts and Design) in Portugal where she coordinates the Pos graduation in Photobooks and the International Summer School dedicated to Media Arts. She is also guest teacher at Universidade Lusofóna de Lisboa at the School of Communication, Architecture, Arts and Information Technologies (ECATI). Co-founder of the Portuguese Festival "Encontros da Imagem", an International Photography Festival based in Braga Portugal, in which she collaborated as Curator and Artistic Director between 2004 to 2016. She teaches contemporary photography throughout Europe and Latin American countries, with emphasis on Brazil. She has worked as a curator of national and international exhibitions. She had lectured on contemporary photography throughout Europe, Latin American Countries and Asia and published intensely in the field of photography and indigenous cultures being artist and researcher for AEI - Arte Eletrônica Indígena project, run by the Brazilian NGO Thydêwá, where she participated in three exhibitions: Digital Natives, Leeds International Festival, 2018; and special exhibits at the British Academy Summer Showcase 2019, and at the Ars Electronica Festival 2019 and in 2021 in the _AIRE_Art with Indigenous People in Electronic Residences. Her works have been presented widely, in exhibitions and conferences such as: Museu do Amanhã, Rio de Janeiro, Brazil; CAFA, Center of Arts in Beijing, China; University of Applied Arts Leeds, UK; Centro de Fotografia de Bilbao, Spain, Museu Bogotá, Colombia; Centro de Fotografia de Montevideo, Uruguay, Escola de Artes Visuais do Parque Lage, Rio de Janeiro, Brazil. Universidade de Clermont Ferrand, França, Centro de Fotografia de Curitiba, Goa Photo Festival, India, Delhi Photo Festival, India. For the past 5 years she curated exhibitions for the Korea International PhotoFestival, Seoul Arts Center, Seoul (2019); Viaduto das Artes, Belo-Horizonte Brazil (2019); 3rd Seoul Photobiennial of China, Beijing and Beizgen (2018), and Solar Foto Festival ( 2018) Museu da Fotografia de Fortaleza (2017) and between 2016 and to 20106 she was director and curator of the oldest international photofestival Portugal in Braga, Portugal. In 2019, she was guest curator of the GoaPhoto Festival in India and Korea International PhotoFestival in Seoul. Since 2017, she is curator of the Photography Museum in Fortaleza and is currently artistic advisor at FotoFestival SOLAR and advisor to the Photography Program of the Ceará Department of Culture, Brazil. Ângela collaborate with local and international artists with focuses on the development of cultural exchanges and social problems, and she is involved as a nominator and juror for the international photo organizations. She lives between Portugal and Brazil.

        Graus

            * Mestrado
              European Media Master_ Photography, Utrecht School of Arts
            * Título de Agregado
              Post-Graduation in Art Direction and Curatorship
            * Licenciatura
              Law Degree
            * Doutoramento
              Visual Communication and Plastic Expression
            * Pós-doutoramento
              Interdiciplinary Photopoetics

        Publicações

        Magazine article

          * 2021-03-04, Transa – baladas do último sol , Bildersturm, platform for contemporary photobooks.
          * 2018-09, Mind Games, the world of Roger Ballen
          * 2005, Do mito da Caverna às metáforas do Real, Margens e Confluências
          * 2004, Publicação de texto e portfolio, Revista Latina

        Journal article

          * 2018-05-23, A Imersão do Artista- Investigador e a Estética da Afetividade, Cadernos IRI : imagens do Real Imaginado
          * 2018, Photography in an era of catastrophes. Notes about the 3rd Beijing Photography Biennial., https://revistalibero.casperlibero.edu.br/dossie/a-fotografia-numa-era-de-catastrofes-notas-sobre-a-iii-bienal-de-fotografia-de-beijing-china/

        Thesis / Dissertation

          * 2004, Master, Painted Pictures

        Book

          * 2020, Transa, Baladas do último sol , 1, Ferreira, Ângela; Veronica Cordeiro, Espacio Jhannia Castro
          * 2017, Nhnhã Aba, Coração de Indio , 50, Ferreira, Ângela, Scopio editions
          * 2016, Nynhã Aba, Coração de Índio , 10, Ferreira, Ângela, Autopublicação
          * 2012, "Os Maias" de Eça de Queirós, edição revisitada com fotografia e curta metragem. Braga: Publicação dst, sa., 1, Ferreira, Ângela, dst
          * 2008, Afetos, Ferreira, Ângela, Labirinto
          * 2007, As primeiras coisas, Ferreira, Ângela, Câmara Municipal de Câmara de Lobos
          * 2006, Pensar Babel, Ferreira, Ângela, dst
          * 2001, As palavras que ficaram por dizer , 1, Ferreira, Ângela, Centro Portugues de Fotografia

        Book chapter

          * 2021, Hybrid Photography : The resolutive images as awakening of consciousness, HYPERORGANIC S: ¿ CONSCIOUSNESS AND NATURE: CREATE, CULTIVATE, CONNECT, 3, Circuito
          * 2021, Au sujet Nynhã Aba (Coeur de Indien ) , TEMPORALITÉS AMÉRINDIENNES Représentations de l’Autre et rachat du passé, 1, 1, Centre de recherches sur le literatures et la sociopoetique
          * 2019, À Clara e aos pássaros de fogo, 700 Anos do Convento de Santa Clara, 70x7, Câmara Municipal de Vila do Conde
          * 2003, Fotografias, Revista Águas Furtadas, números 3, 4 e 5

        Edited book

          * 2013, 1, Fundação Lapa do Lobo
          * 2012, 500, 1, Encontros da Imagem
          * 2011, I, SSP- Letónia, Genis Genis Aci Project Office- Turquia, a Icelandic Contemporary Photography Association e o Reykjavik Museum of Photography.
          * 2008, ESAP

        Conference paper

          * The Hybridism of Photography in a era of catastrophes, ARTeFACTo2020
          * O Real na Fotografia, O cinema e as Artes ou a Arte no Cinema
          * 2021-07-08, Reframing colonial narratives: Notes about Post-photography, KISMIF International Conference. “Keep It Simple, Make It Fast! (KISMIF)
          * 2019-06-16, "Love and Art above any algorithm" Forum Latino Americano da Fotografia , Forum Latino Americano da Fotografia
          * 2018-05-27, "O coração Indígena e a vertigem das tecnologias." : Museu do Amanhã, Rio de janeiro, Hiperorganicos
          * 2015-12-15, "Indian Mirror, the self portrait of the indigenous nations of Brazil ", Heterotemporalidades: o anacronismo na literatura brasileira

        Conference abstract

          * 2022-05, The silent scream of Berna Reale: a transit between the crime scene and the artistic scene , XIII Congresso Internacional CSO'2022 // Criadores Sobre outras Obras//
          * 2021, The Photography as a vibration of existence , Hiperorgânicos Arte, Consciência e Natureza. Criar, cultivar, conectar

        Exhibition catalog

          * 2021, My mind is a cage, Terra Esplendida / Centro Portugues da Fotografia
          * 2019, Korea, International photo Festival, Eu Hyon-Jin
          * 2018, PhotoBienal Beijing 2018 : "Troubles and tensions ahead ", PHOTOBIENAL BEIJING
          * 2016, Happiness, a place in the sun, Encontros da Imagem
          * 2015, Poder e Ilusão , Encontros da Imagem
          * 2014, Umbilical , Galeria Fuga Pela Escada
          * 2014, Memórias da Cidade: Contra o seu esquecimento, Encontros da Imagem
          * 2014, Love will tear us apart , Encontros da Imagem
          * 2014, Hope and Faith , ENCONTROS DA IMAGEM
          * 2012, Fronteiras do género , Encontros da Imagem
          * 2009, "Transmutações da Paisagem ", Encontros da Imagem
          * 2006, Pensar Babel , Dst
          * 2006, A construção e a experiência da Paisagem, Catálogo dos Encontros da Imagem, Braga 2006.

        Preface / Postscript

          * 2020, Dryads and Fauns
          * 2019, "The Way to High Mountain
          * 2018, Terra em Transe _ Edição Abismo

        Artistic exhibition

          * 2021-06-05, Digital residencies “AIRE” ( co-produced a video with indigenous from Brazil, Chile, Argentina, Ecuador, Bolivia in partnership Miller-Zillmer Found.
          * 2020-09-23, Transa, Ballads of Last Sun. , Porto, Portugal
          * 2019-12, "Aldona Through Family Eyes"
          * 2018-05-01, Painted pictures | Thydewá | Leeds Festival
          * 2018-04-05, Digital Natives, Leeds Festival 2018; special exhibits British Academy & Ars Electronic
          * 2017-01-05, “Nynhã Aba // Corazón de Indio / Bilbao , Centro de Fotografia de Bilbao, Espanha.
          * 2016-12, Nynhã Aba // Corazón de Indio / Montevideo
          * 2014, "Coma"
          * 2011, RETRATOS PINTADOS, Centro Municipal de Arte Hélio Oiticica Rua Luís de Camões, Rio de Janeiro.
          * 2011, OS MAIAS / Galeria Show Me, Galeria Show Me, Braga
          * 2010, Jogo-do-homem / Clube Literário do Porto., Clube Literário do Porto
          * 2009, Three minutes before / Galeria Pedro Remy , Galeria Pedro Remy, Braga.
          * 2008, Quando se pinta e busca o real? Velha-a-Branca Estaleiro Cultural
          * 2008, Alice / Museu D. Diogo de Sousa
          * 2007, Encontros Exposição Coletiva - Okastudio Gallery, Porto
          * 2007, Colectivo+CIA. Exposição Coletiva - Galeria Lab 65., Galeria Lab 65
          * 2007, Barroco a dois tempos
          * 2006, PENSAR BABEL
          * 2006, As Primeiras coisas.
          * 2006, Artistic Residency in Câmara de Lobos, Madeira, which culminated in an exhibition and publication "As primeiras coisas", no centro cultural de Câmara de Lobos. , Câmara de Lobos, Madeira
          * 2005, Exposição coletiva // Laboratório das Artes
          * 2004, ÍNDIA, Palácio da Abolição, Palácio da Abolição
          * 2004, Retratos Pintados / Galeria Mário Sequeira
          * 2004, Indian Mirror
          * 2004, Dreamers
          * 2003, “The Dream of the Little Prince
          * 2002, ÍNDIA, DOIS OLHARES

        Visual artwork

          * Un Regard sur le Brésil, tables rondes Ângela Berlinde / Daniela Paolielo | Rencontres d´Arles
          * Residência Artística com a Comunidade indígena dos Tupinambás de Olivença, Ilhéus, Salvador da Bahia
          * Residência Artística "Art territory", Vilnius, Lituânia
          * Projeto Transatlântico, Programa de travessias Visuais que uniu fotógrafos portugueses e Brasileiros
          * Os MAIAS
          * - Rituals Photographiques
          * Lançamento do livro : Transa, Baladas do último sol, FOTORIO, Festival de Fotografia do Rio de Janeiro

        Curatorial / Museum exhibition

          * 2022-03-09, OPEN STUDIO DAYS
          * 2021-07-10, ROGER BALLEN "My mind is a Cage"
          * 2021-05-03, AEI - Indigenous Electronic Arts, project run by the Brazilian NGO Thydêwá ( Co-curator )
          * 2020-10-09, ALÉM MAR
          * 2020-03-05, Cássio Vasconcellos, Galeria Nara Rosler, Rio de Janeiro
          * 2019-12-05, GOA PHOTO FESTIVAL
          * 2019-12, Edgar Martins "What Photography has in Common with an Empty Vase"
          * 2019-12, Ana Janeiro, Revisiting the album 1951-1961
          * 2019-08-18, Berna Reale, Viaduto das Artes, Belo Horizonte
          * 2019-03-07, Cyro Almeida e Julio Santos, Museu Mineiro, Belo Horizonte
          * 2018-12-07, " Grito Mudo " By Berna Reale
          * 2018-12-05, "Desconstruindo Osama" by Joan Fontcuberta
          * 2018-12, "Sequências de Verdade e Decepção " by Vanja Bucan
          * 2018-12, "Unomgcana" by Nobukho Nqaba
          * 2018-12, "Traces" by Weronika Gsiscka
          * 2018-10-01, PhotoBienal Beijing, CAFA art Museum, China
          * 2018-09-07, Mind Games by Roger Ballen
          * 2018-08-20, The Unseen
          * 2018-08-04, Paisagem Ambulante, Daniel Moreira
          * 2018-07-20, MadSummer School
          * 2018, Korea International PhotoFestival | Seoul
          * 2016-09-24, Encontros da Imagem, Festival de Fotografia 2016
          * 2016, Viviane Sassen, Lexicon
          * 2016, Phil Toledano
          * 2016, Malick Sidibé
          * 2016, International Photography Award / Emergentes dst
          * 2016, Christto & Andrew
          * 2016, Brian Griffin, Photographs
          * 2015-12, "Os Territórios da Fotografia Portuguesa Contemporânea", Indira Gandhi National Centre for the Arts
          * 2015-09-20, “New Visions of Chinese Photography”
          * 2015-09-20, CRISTINA DE MIDDEL, "This is what hatred did"
          * 2015-09-20, Encontros da Imagem, Festival de Fotografia, 2015 Poder e Ilusão
          * 2015-09, Edgar Martins "The Poetic Impossibility to Manage the Infinite "
          * 2015, "Philosopher, a female wisdom” CATRINE VAL
          * 2014-09-20, Encontros da Imagem, Festival de Fotografia 2014, Hope and Faith
          * 2014-09-20, "The Dwarf Empire" by Sanne de Wilde
          * 2014-09, Anna & Eve, by Viktoria Soronschi
          * 2014-09, "Moments of transition" by Mario Macilau
          * 2014-09, "I am Walé, Respect me " By Patrick Willock
          * 2014-09, "Good dog" by Ysuf Sevincli
          * 2014-09, "Asylum of the Birds¿" by Roger Ballen
          * 2014, Rafal Milach
          * 2014, Prémio de Fotografia e Exposição Emergentes DST 2014
          * 2014, "The Guilty", by Ji Hyun Kown
          * 2014, "The Family Project" by Matias Costa
          * 2014, "MIracles and Company" by Joan Fontcuberta
          * 2013-09-20, Encontros da Imagem, Festival de Fotografia 2012,
          * 2013-09-20, Encontros da Imagem, Festival de Fotografia 2013 / Love Will Tear us apart
          * 2013, Prémio de Fotografia e Exposição Emergentes DST 2013
          * 2013, Elina Brotherus
          * 2012-09-20, Encontros da Imagem, Festival de Fotografia 2012
          * 2012, VISUAL NARRATIVES - EUROPEAN BORDERLINES
          * 2012, Prémio de Fotografia e Exposição Emergentes DST 2012
          * 2010, Prémio de Fotografia e Exposição Emergentes DST 2010
          * 2009, Prémio de Fotografia e Exposição Emergentes DST 2009
          * 2009, Prémio de Fotografia e Exposição Emergentes DST 2009
          * 2007, Diálogos. Galeria Pisecká Brana - PRAGA.

        Other output

          * 2016, Residência Artística “The Independent AIR, Acompanhamento da residência artística “The Independent AIR”, organização internacional sem fins lucrativos cuja ação se destina a acompanhar residências artísticas, oficinas, redes e exposições, tendo em vista discutir os processos criativos que reflectem sobre o papel da arte e do artista na sociedade.
          * 2014, Residência Artística na Escola de Artes Visuais do Parque Lage, Jardim Botânico Rio de Janeiro Brasil, Escola de Artes Visuais do Parque Lage, Jardim Botânico Rio de Janeiro Brasil, sobre Retrato e Fotografia Vernacular no Brasil. Neste processo foram coleccionadas fotos-pinturas para elaborar uma obra onde as imagens ganharam uma nova dimensão estética e uma inserção cultural distinta da sua condição anterior.

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona