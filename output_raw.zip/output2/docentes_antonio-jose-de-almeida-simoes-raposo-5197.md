# Response for https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
          PT: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197 EN: https://www.ulusofona.pt/en/teachers/antonio-jose-de-almeida-simoes-raposo-5197
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
        fechar menu : https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/antonio-jose-de-almeida-simoes-raposo-5197
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          António Raposo

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5197
              ant***@ulusofona.pt
              F019-6DAC-8250: https://www.cienciavitae.pt/F019-6DAC-8250
              0000-0002-5286-2249: https://orcid.org/0000-0002-5286-2249
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/e3e4e922-719f-43a9-8ecf-07b5ab8fd11e
      : https://www.ulusofona.pt/

        Publicações

        Artigo em revista

          * 2024-04-29, Enhancing life with celiac disease: unveiling effective tools for assessing health-related quality of life, Frontiers in Immunology
          * 2024-04-19, The Role of Social Media Advertisement and Physical Activity on Eating Behaviors among the General Population in Saudi Arabia, Nutrients
          * 2024-04-18, Risk of Gluten Cross-Contamination Due to Food Handling Practices: A Mini-Review, Nutrients
          * 2024-04, Exploring Lifestyle Factors and Treatment Adherence among Older Adults with Hypertension Attending a Mobile Health Unit (MHU) in a Rural Area of Central Portugal, Nutrients
          * 2024-04, Comparative assessment of radical scavenging potential of A1 and A2 cow's milk casein pre- and post-enzymatic hydrolysis, LWT
          * 2024-04, Assessment of knowledge, attitude, and practices regarding the relationship of obesity with diabetes among the general community of Pakistan, Heliyon
          * 2024-03-23, Psychometric Evaluation of the Food Life Questionnaire—Short Form among Brazilian Adult Women, Nutrients
          * 2024-03-04, Health-related quality of life among celiacs in Portugal: a comparison between general and specific questionnaires, Frontiers in Immunology
          * 2024-03, Nutritional and biological attributes of Spondias tuberosa (Umbu) fruit: An integrative review with a systematic approach, Journal of Food Composition and Analysis
          * 2024-03, Factors That Most Influence the Choice for Fast Food in a Sample of Higher Education Students in Portugal, Nutrients
          * 2024-03, Cross-cultural ethnobotany of the Baltis and Shinas in the Kharmang district, Trans-Himalaya India-Pakistan border, Heliyon
          * 2024-02-09, Modulation of gut-microbiota through probiotics and dietary interventions to improve the host health, Journal of the Science of Food and Agriculture
          * 2024-02, Ganoderma lucidum: Insight into antimicrobial and antioxidant properties with development of secondary metabolites, Heliyon
          * 2024-02, Development and Rapid Sensory Descriptive Characterization of Cereal Bars Made with Brazilian Licuri Nut (Syagrus coronata), Foods
          * 2024-02, Bioactive activity and safety analysis of Monascus red biopigment, Food Bioscience
          * 2024-01-26, Chickpea aquafaba: a systematic review of the different processes for obtaining and their nutritional and technological characteristics, Journal of Food Science and Technology
          * 2024-01-18, Consumer Knowledge about Dietary Relevance of Fruits and Vegetables: A Study Involving Participants from Portugal and France, Nutrients
          * 2024-01-03, Positive and negative aspects of bacteriophages and their immense role in the food chain, npj Science of Food
          * 2024-01, Unveiling the global nexus: Pandemic fear, government responses, and climate change-an empirical study, Heliyon
          * 2024-01, The Cannabis sativa L. in the Western Himalayas: a tale of the ecological factors behind its continuous invasiveness, Global Ecology and Conservation
          * 2024-01, Effect of incorporation of pumpkin seed powder and chia seed powder on storage stability of fiber enriched chicken meat nuggets, LWT
          * 2024-01, Brazilian Front-of-Package Labeling: A Product Compliance Analysis 12 Months after Implementation of Regulations, Nutrients
          * 2023-12-31, Production of Gamma Aminobutyric Acid (GABA)- MISO Using Candida parapsilosis Isolated from a Commercial Soy Sauce MOROMI, Sains Malaysiana
          * 2023-12, Sclareol exerts synergistic antidepressant effects with quercetin and caffeine, possibly suppressing GABAergic transmission in chicks, Biomedicine & Pharmacotherapy
          * 2023-11-13, Instruments to Evaluate Food Neophobia in Children: An Integrative Review with a Systematic Approach, Nutrients
          * 2023-11, Eating Attitudes of Patients with Celiac Disease in Brazil: A Nationwide Assessment with the EAT-26 Instrument, Nutrients
          * 2023-10, Evaluation of the antiedematogenic and anti-inflammatory properties of Ximenia americana L. (Olacaceae) bark extract in experimental models of inflammation, Biomedicine & Pharmacotherapy
          * 2023-09-01, Correction: Raposo et al. The Role of Food Supplementation in Microcirculation—A Comprehensive Review. Biology 2021, 10, 616, Biology
          * 2023-09, Comparative transcriptomics analysis of multidrug-resistant Acinetobacter baumannii in response to treatment with the terpenic compounds thymol and carvacrol, Biomedicine & Pharmacotherapy
          * 2023-08-30, Controlling Intestinal Infections and Digestive Disorders Using Probiotics, Journal of Medicinal Food
          * 2023-07, Chemical composition and antimicrobial potential of Acrocomia aculeata (Jacq.) Lodd. ex Mart. and Syagrus cearensis Noblick (Arecaceae), Microbial Pathogenesis
          * 2023-06-12, Plant protection from virus: a review of different approaches, Frontiers in Plant Science
          * 2023-05-19, Development and application of fruit and vegetable based green films with natural bio-actives in meat and dairy products: a review, Journal of the Science of Food and Agriculture
          * 2023-05-12, Detoxifying the heavy metals: a multipronged study of tolerance strategies against heavy metals toxicity in plants, Frontiers in Plant Science
          * 2023-05-11, A narrative action on the battle against hunger using mushroom, peanut, and soybean-based wastes, Frontiers in Public Health
          * 2023-05-10, Brazzein and Monellin: Chemical Analysis, Food Industry Applications, Safety and Quality Control, Nutritional Profile and Health Impacts, Foods
          * 2023-04-26, Pilot-scale process to produce bio-pigment from Monascus purpureus using broken rice as substrate for solid-state fermentation, European Food Research and Technology
          * 2023-04, Toxicity Analysis of Some Frequently Used Food Processing Chemicals Using Allium cepa Biomonitoring System, Biology
          * 2023-04, Quality of Life Perception among Portuguese Celiac Patients: A Cross-Sectional Study Using the Celiac Disease Questionnaire (CDQ), Nutrients
          * 2023-04, Challenging the Status Quo to Shape Food Systems Transformation from a Nutritional and Food Security Perspective: Second Edition, Foods
          * 2023-03, Food Security Challenges in Europe in the Context of the Prolonged Russian–Ukrainian Conflict, Sustainability
          * 2023-02, Eating Sturgeon: An Endangered Delicacy, Sustainability
          * 2023-02, Coconut Sugar: Chemical Analysis and Nutritional Profile; Health Impacts; Safety and Quality Control; Food Industry Applications, International Journal of Environmental Research and Public Health
          * 2023-02, Antibacterial effect, efflux pump inhibitory (NorA, TetK and MepA) of Staphylococcus aureus and in silico prediction of a, ß and d-damascone compounds, Arabian Journal of Chemistry
          * 2023-01, Nutritional Profile of Commercialized Plant-Based Meat: An Integrative Review with a Systematic Approach, Foods
          * 2023-01, Individual and interactive effect of ultrasound pre-treatment on drying kinetics and biochemical qualities of food: A critical review, Ultrasonics Sonochemistry
          * 2023-01, Effect of ultrasound assisted cleaning on pesticide removal and quality characteristics of Vitis vinifera leaves, Ultrasonics Sonochemistry
          * 2023, Brazzein and Monellin: Chemical Analysis and Nutritional Profile, Health Impacts, Safety and Quality Control, and Food Industry Applications, Foods
          * 2022-12-16, Modification of Antibiotic Activity by Fixed Oil of the Artocarpus heterophyllus Almond against Standard and Multidrug-Resistant Bacteria Strains, Biology
          * 2022-12, Ethnomedicinal Uses, Phytochemistry, and Therapeutic Potentials of Litsea glutinosa (Lour.) C. B. Robinson: A Literature-Based Review, Pharmaceuticals
          * 2022-11-16, Floristic composition, biological spectrum, and phytogeographic distribution of the Bin Dara Dir, in the western boundary of Pakistan, Frontiers in Forests and Global Change
          * 2022-10, Use of Parthenium hysterophorus with synthetic chelator for enhanced uptake of cadmium and lead from contaminated soils—a step toward better public health, Frontiers in Public Health
          * 2022-10, Preparation and characterization of sequilhos-type biscuits added with almond flour of Acrocomia intumescens, Frontiers in Nutrition
          * 2022-10, Mechanisms of Actions Involved in The Antinociceptive Effect of Estragole and its ß-Cyclodextrin Inclusion Complex in Animal Models, Plants
          * 2022-10, Maple Syrup: Chemical Analysis and Nutritional Profile, Health Impacts, Safety and Quality Control, and Food Industry Applications, International Journal of Environmental Research and Public Health
          * 2022-10, Salicornia bigelovii, S. brachiata and S. herbacea: Their Nutritional Characteristics and an Evaluation of Their Potential as Salt Substitutes, Foods
          * 2022-09, Jellyfish as Food: A Narrative Review, Foods
          * 2022-09, Factors interfering with the adoption of good hygiene practices in public school food services in Bahia, Brazil, Frontiers in Public Health
          * 2022-09, Consumer Behaviour and Attitude towards the Purchase of Organic Products in Riobamba, Ecuador, Foods
          * 2022-09, Antiviral COVID-19 protein and molecular docking: In silico characterization of various antiviral compounds extracted from Arisaema jacquemontii Blume, Frontiers in Public Health
          * 2022-07-08, Eating Competence and Aspects Related to a Gluten-Free Diet in Brazilian Adults with Gluten-Related Disorders, Nutrients
          * 2022-06-29, The Multifaceted Nature of Food and Nutrition Insecurity around the World and Foodservice Business, Sustainability
          * 2022-06-09, A Study on Perception and Exposure to Occupational Risks at Public School Food Services in Bahia, Brazil, Frontiers in Public Health
          * 2022-06, Agave Syrup: Chemical Analysis and Nutritional Profile, Applications in the Food Industry and Health Impacts, International Journal of Environmental Research and Public Health
          * 2022-05-30, Brazilian Food Handlers' Years of Work in the Foodservice and Excess Weight: A Nationwide Cross-Sectional Study, Frontiers in Public Health
          * 2022-05-29, Plasma-Activated Water for Food Safety and Quality: A Review of Recent Developments, International Journal of Environmental Research and Public Health
          * 2022-05-27, Are Vegan Alternatives to Meat Products Healthy? A Study on Nutrients and Main Ingredients of Products Commercialized in Brazil, Frontiers in Public Health
          * 2022-05-17, Sense and Manner of WASH and Their Coalition With Disease and Nutritional Status of Under-five Children in Rural Bangladesh: A Cross-Sectional Study, Frontiers in Public Health
          * 2022-05-10, Amorphophallus konjac: Sensory Profile of This Novel Alternative Flour on Gluten-Free Bread, Foods
          * 2022-04, Eating Competence, Food Consumption and Health Outcomes: An Overview, International Journal of Environmental Research and Public Health
          * 2022-03, The Impact of COVID-19 on the Food Supply Chain and the Role of E-Commerce for Food Purchasing, Sustainability
          * 2022-02, Occupational Risk Assessment in School Food Services: Instruments’ Construction and Internal Validation, Sustainability
          * 2022-02, Challenging the Status Quo to Shape Food Systems Transformation from a Nutritional and Food Security Perspective, Foods
          * 2022-01-10, Sustainability Recommendations and Practices in School Feeding: A Systematic Review, Foods
          * 2022-01-05, Influence of Different Cooking Methods on Fillet Steak Physicochemical Characteristics, International Journal of Environmental Research and Public Health
          * 2022-01, Food Neophobia among Brazilian Children: Prevalence and Questionnaire Score Development, Sustainability
          * 2022-01, A Comprehensive Review on Bio-Preservation of Bread: An Approach to Adopt Wholesome Strategies, Foods
          * 2021-10, Occupational Risks in Hospitals, Quality of Life, and Quality of Work Life: A Systematic Review, International Journal of Environmental Research and Public Health
          * 2021-09, Green Restaurants Assessment (GRASS): A Tool for Evaluation and Classification of Restaurants Considering Sustainability Indicators, Sustainability
          * 2021-08, Eating Competence among Brazilian Adults: A Comparison between before and during the COVID-19 Pandemic, Foods
          * 2021-07-30, Food Safety, Security, Sustainability and Nutrition as Priority Objectives of the Food Sector, International Journal of Environmental Research and Public Health
          * 2021-07, Well-Being at Work: A Cross-Sectional Study on the Portuguese Nutritionists, International Journal of Environmental Research and Public Health
          * 2021-07, The Role of Food Supplementation in Microcirculation—A Comprehensive Review, Biology
          * 2021-07, Quality of Life of Vegetarians during the COVID-19 Pandemic in Brazil, Nutrients
          * 2021-07, Quality of Life of Brazilian Vegetarians Measured by the WHOQOL-BREF: Influence of Type of Diet, Motivation and Sociodemographic Data, Nutrients
          * 2021-07, Investigating International Students’ Perception of Foodservice Attributes in Malaysian Research Universities, Sustainability
          * 2021-07, Influence of Cooking Method on the Nutritional Quality of Organic and Conventional Brazilian Vegetables: A Study on Sodium, Potassium, and Carotenoids, Foods
          * 2021-07, Evaluation of the Effectiveness of Brazilian Community Restaurants for the Dimension of Low-Income People Access to Food, Nutrients
          * 2021-07, An Overview on Nutritional Aspects of Plant-Based Beverages Used as Substitutes for Cow’s Milk, Nutrients
          * 2021-06, Eco-Inefficiency Formula: A Method to Verify the Cost of the Economic, Environmental, and Social Impact of Waste in Food Services, Foods
          * 2021-05, Texture-Modified Food for Dysphagic Patients: A Comprehensive Review, International Journal of Environmental Research and Public Health
          * 2021-05, Health-Related Quality of Life and Experiences of Brazilian Celiac Individuals over the Course of the Sars-Cov-2 Pandemic, Nutrients
          * 2021-05, Food Waste on Foodservice: An Overview through the Perspective of Sustainable Dimensions, Foods
          * 2021-05, Amorphophallus konjac: A Novel Alternative Flour on Gluten-Free Bread, Foods
          * 2021-04-12, Vegetarian Diet: An Overview through the Perspective of Quality of Life Domains, International Journal of Environmental Research and Public Health
          * 2021-03, Impact of Ginger Root Powder Dietary Supplement on Productive Performance, Egg Quality, Antioxidant Status and Blood Parameters in Laying Japanese Quails, International Journal of Environmental Research and Public Health
          * 2021-03, Highlights of Current Dietary Guidelines in Five Continents, International Journal of Environmental Research and Public Health
          * 2021-03, Halal Food Performance and Its Influence on Patron Retention Process at Tourism Destination, International Journal of Environmental Research and Public Health
          * 2021-03, A Systematic Review on Gluten-Free Bread Formulations Using Specific Volume as a Quality Indicator, Foods
          * 2021-02, To Dine, or Not to Dine on a Cruise Ship in the Time of the COVID-19 Pandemic: The Tripartite Approach towards an Understanding of Behavioral Intentions among Female Passengers, Sustainability
          * 2021-02, Microbial Biofilms in the Food Industry—A Comprehensive Review, International Journal of Environmental Research and Public Health
          * 2021-02, How Are School Menus Evaluated in Different Countries? A Systematic Review, Foods
          * 2021-02, Glycemic Index of Gluten-Free Bread and Their Main Ingredients: A Systematic Review and Meta-Analysis, Foods
          * 2021-02, Design and Development of an Instrument on Knowledge of Food Safety, Practices, and Risk Perception Addressed to Children and Adolescents from Low-Income Families, Sustainability
          * 2021-01-04, The Cardiovascular Therapeutic Potential of Propolis—A Comprehensive Review, Biology
          * 2021-01-04, Characterization, Nutrient Intake, and Nutritional Status of Low-Income Students Attending a Brazilian University Restaurant, International Journal of Environmental Research and Public Health
          * 2021-01, Food Insecurity among Low-Income Food Handlers: A Nationwide Study in Brazilian Community Restaurants, International Journal of Environmental Research and Public Health
          * 2020-10-14, Memórias do patrimônio alimentar romano: uma reflexão, Revista Família, Ciclos de Vida e Saúde no Contexto Social
          * 2020-08-28, Natural Sweeteners: The Relevance of Food Naturalness for Consumers, Food Security Aspects, Sustainability and Health Impacts, International Journal of Environmental Research and Public Health
          * 2020-07-20, Maltitol: Analytical Determination Methods, Applications in the Food Industry, Metabolism and Health Impacts, International Journal of Environmental Research and Public Health
          * 2020-04, A study of vegetable (thistle) rennet in the production of Flor de Guía cheese, Biomedical and Biopharmaceutical Research Journal
          * 2020-03, Gastroesophageal reflux (Clinical case), Biomedical and Biopharmaceutical Research Journal
          * 2019-09, Entomophagy: Nutritional, ecological, safety and legislation aspects, Food Research International
          * 2019-08-06, Traditional consumption of and rearing edible insects in Africa, Asia and Europe, Critical Reviews in Food Science and Nutrition
          * 2019-01, Is the use of supermarket trolleys microbiologically safe? Study of microbiological contamination, Journal of Applied Animal Research
          * 2018-12, Studying the compliance of the labelling in different types of farm fresh eggs for human consumption marketed in Gran Canaria (Spain) – An egg labelling proposition for those produced in Canary Islands, Journal Biomedical and Biopharmaceutical Research
          * 2018-11-05, Bisphenol A: Food Exposure and Impact on Human Health, Comprehensive Reviews in Food Science and Food Safety
          * 2018-08-30, Eating jellyfish: safety, chemical and sensory properties, Journal of the Science of Food and Agriculture
          * 2018-06, Degree of implementation and satisfaction in food companies with the International Food Standards (IFS) and British Retail Consortium (BRC) certifications on the Canary Islands, Journal Biomedical and Biopharmaceutical Research
          * 2018, Vending machines and university students’ consumption trends, Journal of Food and Nutrition Research
          * 2017-06-27, CBiOS Science Sessions - 2016 -Supplement, Journal Biomedical and Biopharmaceutical Research
          * 2017, Use of gamma radiation in sheep butter manufacturing process for shelf-life extension, International Dairy Journal
          * 2017, Influence of Different Cooking Methods on the Concentration of Glucosinolates and Vitamin C in Broccoli, Food and Bioprocess Technology
          * 2016, Vending machine foods: Evaluation of nutritional composition, Italian Journal of Food Science
          * 2016, Puffer fish and its consumption: To eat or not to eat?, Food Reviews International
          * 2016, Identification of the risk factors associated with cheese production to implement the hazard analysis and critical control points (HACCP) system on cheese farms, Journal of Dairy Science
          * 2015, Microbiological evolution of gilthead sea bream (Sparus aurata) in Canary Islands during ice storage, Journal of Food Science and Technology
          * 2014, Predictive models for bacterial growth in sea bass (Dicentrarchus labrax) stored in ice, International Journal of Food Science and Technology
          * 2012, Postural stability decreases in elite young soccer players after a competitive soccer match, Physical Therapy in Sport
          * 2012, Monitoring of cleanliness and disinfection in dairies: Comparison of traditional microbiological and ATP bioluminescence methods, Food Control
          * 2011, Social and personal determining factors in the results on contents of food handlers’ formation plans, Food and Nutrition Sciences
          * 2011, Small Food Businesses: trying to improve taking records with a mobile device application, Intelligent Information Management
          * 2011, Microbiological evaluation of prepared/cooked foods in a HACCP environment, Food and Nutrition Sciences

        Tese / Dissertação

          * 2013, Doutoramento, Evaluación de la seguridad alimentaria y gestión de riesgos en sistemas de venta automática de alimentos y estudio asociado a los hábitos alimentarios = Avaliação da segurança alimentar e gestão de riscos em sistemas de venda automática de alimentos e estudo associado aos hábitos alimentares

        Livro

          * 2013, Techniques to evaluate cleanliness and disinfection in dairies, Carrascosa, C.; Raposo, A.; Sanjuán, E.; Millán, R.; Pérez, E.

        Capítulo de livro

          * 2023, Food Safety and Allergies
          * 2017, Food spoilage by pseudomonas spp.-An overview
          * 2017, Allergen management as a key issue in food safety, Taylor & Francis

        Artigo em conferência

          * Vending: Food safety evaluation through models of hygiene assessment system and checklist
          * Towards a healthy and safe jellyfish snack: preliminary assay with allergic patients
          * Pasteurização a frio de ovos e ovoprodutos por radiação ionizante
          * Is jellyfish ingestion safe in allergic patients? Preliminary results
          * Healthy food innovation using natural resources, Catostylus tagi jellyfish: sensory evaluation
          * First acceptability trial of a Catostylus tagi snack in healthy untrained panellists
          * Estudo comparativo sobre o pão de mistura comercializado no concelho de Almada
          * 2011, Hygiene evaluation systems in flour mills

        Outra produção

          * 2018, Jellyfish ingestion was safe for patients with crustaceans, cephalopods, and fish allergy, 1/3 https://apallergy.org To the editor, For centuries, the umbrella of edible jellyfish has been consumed in Asia, usually cooked and sliced in salads. Edible jellyfish has a type of collagen which acts as an auxiliary agent in preventing arthritis and some peptides with antihypertensive effect.
          * 2018, Ibero-American consensus on low- and no-calorie sweeteners: Safety, nutritional aspects and benefits in food and beverages, International scientific experts in food, nutrition, dietetics, endocrinology, physical activity, paediatrics, nursing, toxicology and public health met in Lisbon on 2-4 July 2017 to develop a Consensus on the use of low- and no-calorie sweeteners (LNCS) as substitutes for sugars and other caloric sweeteners. LNCS are food additives that are broadly used as sugar substitutes to sweeten foods and b
          * 2018, Development of cereal bars with adequate nutritional profile for each trimester of pregnancy– An exploratory study, Nutrition plays a crucial role in pregnancy as it may help to prevent pregnancy complications and fetal pathologies. It is beneficial for pregnant women to have a fractionated alimentation, as it minimizes symptoms of hyperemesis gravidarum and reduces the increased risk of hypoglycemia. The objective of this study was the preparation of three cereal bars, each one suitable for a trimester of preg
          * 2015, Vending machines: Food safety and quality assessment focused on food handlers and the variables involved in the industry, "The purpose of this paper was to analyse the quality and safety parameters of food products sold in vending machines. A hygienic-sanitary assessment was conducted on 338 vending machines located on the island of Gran Canaria. Hygiene Assessment System (HAS) surveys, food handler examinations and microbiological (processed food and water) and physicochemical (water) controls were applied, permitti

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona