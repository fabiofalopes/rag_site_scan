# Response for https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
          PT: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397 EN: https://www.ulusofona.pt/en/teachers/fatima-cristina-da-silva-ribeiro-gameiro-2397
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
        fechar menu : https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/fatima-cristina-da-silva-ribeiro-gameiro-2397
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Fátima Cristina Da Silva Ribeiro Gameiro

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p2397
              fat***@ulusofona.pt
              9912-0BF1-3E87: https://www.cienciavitae.pt/9912-0BF1-3E87
              0000-0003-0202-6813: https://orcid.org/0000-0003-0202-6813
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/ab5be95d-81db-4960-b582-0ab5122d3353
      : https://www.ulusofona.pt/

        Resume

        Fátima Cristina da Silva Ribeiro Gameiro. Doutora em Psicologia/Neuropsicologia em 2013/03/22 pela Universidad de Salamanca; Mestre em Sexologia Clinica em 2003/07/03 pelo(a) Universidade Lusófona de Humanidades e Tecnologias; e Licenciada em Psicologia Clinica em 1998/12/18 pelo Instituto Superior de Psicologia Aplicada. É Professora Auxiliar na Universidade Lusófona de Lisboa desde 2005, no Instituto de Serviço Social e na Escola de Psicologia. Publicou diversos artigos científicos em revistas especializadas. Possui capítulos de livros e livro. É revisora de diversas revistas cientificas. Orienta dissertações de mestrado. Atua na área de Ciências Sociais com ênfase em Psicologia. No seu currículo Ciência Vitae os termos mais frequentes na contextualização da produção científica são: Riscos e Violência(s)nas sociedades atuais; Crianças e Jovens em Perigo; Acolhimento Residencial e Familiar de Crianças e Jovens; Neuropsicologia; Funções Executivas; Comportamento Alimentar. Diretora da Pós-Graduação Intervenção com Crianças e Jovens em Perigo: Acolhimento Familiar e Residencial do ISS/ULHT. Psicóloga Efetiva n.º 977 da Ordem dos Psicólogos Portugueses, com diploma de Especialidade em Psicologia Clínica e da Saúde e diplomas de Especialidade Avançada em Sexologia e Neuropsicologia e orientadora profissional da OPP. Foi Psicóloga clínica em diversas Casas de Acolhimento Residencial. Diretora do D'AR-TE: Para crescermos juntos no âmbito do POISE (Programa Operacional Inclusão Social e Emprego) desde Março de 2020. Fátima Cristina da Silva Ribeiro Gameiro. PhD in Psychology/Neuropsychology in 2013/03/22 from the University of Salamanca; Master's in Clinical Sexology in 2003/07/03 from the Lusófona University of Humanities and Technologies; and Degree in Clinical Psychology in 1998/12/18 from the Higher Institute of Applied Psychology. She has been an Assistant Professor at the Lusófona University of Lisbon since 2005, at the Institute of Social Work and the School of Psychology. She has published several scientific articles in specialized journals. She has book chapters and a book. She is a reviewer for various scientific journals. She has supervised master's dissertations. She works in the field of Social Sciences with an emphasis on Psychology. In her Ciência Vitae CV, the most frequent terms used to contextualize her scientific production are: Risks and Violence(s) in today's societies; Children and Young People in Danger; Residential and Family Foster Care for Children and Young People; Neuropsychology; Executive Functions; Eating Behavior. Director of the Postgraduate course Intervention with Children and Young People in Danger: Family and Residential Care at ISS/ULHT. Effective Psychologist No. 977 of the Order of Portuguese Psychologists, with a Specialty Diploma in Clinical and Health Psychology and Advanced Specialty Diplomas in Sexology and Neuropsychology and professional advisor to the OPP. She has been a clinical psychologist in several residential care homes. Director of D'AR-TE: Para crescermos juntos (To grow together) under POISE (Operational Program for Social Inclusion) since March 2020.

        Graus

            * Licenciatura
              Psicologia Clinica
            * Pós-Graduação
              Sexologia Clinica
            * Mestrado
              Sexologia Clinica
            * Outros
              Neuropsicologia Clínica
            * Doutoramento
              Psicologia
            * Título de especialista
              Psicologia Clínica e da Saúde
            * Título de especialista
              Neuropsicologia
            * Título de especialista
              Sexologia

        Publicações

        Artigo em revista (magazine)

          * 2006, Os mitos do sexo, Medicina & Saúde

        Pré-impressão

          * 

        Artigo em revista

          * 2023-12-29, Inteligência emocional, resiliência e stresse nos/as interventore/as sociais, Revista Temas Sociais
          * 2023-10-08, Frontal lobe functions and quality of life in individuals with obesity with and without binge eating disorder, Endocrines
          * 2023-08, Social intervention in residential care homes in times of pandemic, Revista Temas Sociais
          * 2023-08, Children and teenagers with the residential care: the importance of art and sport as a strategy for social intervention, Revista Temas Sociais
          * 2023-04, Suporte social percebido em crianças e jovens portugueses em diferentes tipologias familiares e acolhimento residencial , Revista Portuguesa de Investigação Comportamental e Social
          * 2023-04, Emotional and relational regulation of children and youth in residential care. , Studies in Social Sciences Review
          * 2023-03-12, Association between Social and Emotional Competencies and Quality of Life in the Context of War, Pandemic and Climate Change, Behavioral Sciences
          * 2022-11-16, Inhibitory control and ability to maintain response in obesity and binge eating disorder, Archives of Health
          * 2022-08-01, Cognitive flexibility in healthy elderly: The effect of educational level. , Archives of Health
          * 2022, Inhibitory control and ability to maintain response in obesity and binge eating disorder. , Archives of Health
          * 2021-08-10, Risks of Obesity in Adolescence: The Role of Physical Activity in Executive Functions, Obesities
          * 2018, O controlo inibitório em adolescentes com medida de acolhimento residencial. , The Psychologist: Practice & Research Journal
          * 2017-11-21, Obesidade na adolescência: O papel da actividade física nas funções executivas. , PSICOLOGIA
          * 2017-01, Executive functioning in obese individuals waiting for clinical treatment. , Psicothema
          * 2012, Rendimentos frontais na obesidade, Revista Portuguesa de Cirurgia
          * 2012, Executive functions in binge eating: Preliminary data, APXEIA Review

        Tese / Dissertação

          * 2018, O envelhecimento e a ocupação do tempo na reforma: atividades de lazer e satisfação com a vida
          * 2015, Impacto dos PEC´s na reabilitação de alcoólicos crónicos
          * 2013-03-22, Doutoramento, Estudio de las funciones ejecutivas en sujetos obesos con trastorno de la conducta alimentaria
          * 2003-07-03, Mestrado, Relações Sexuais Forçadas em Estudantes Universitários
          * 1998-12-18, Licenciatura, Satisfação de sujeitos diabéticos em relação aos cuidados de saúde

        Livro

          * 2014, Percurso dos afetos +, 1, Gameiro, Fátima Cristina da Silva Ribeiro; Georgette Lima; Leonor Ferreira; Maria Manuela Durão; Ricardina Dias, EAPN Portugal

        Capítulo de livro

          * 2023, Prática de judo e comportamento agressivo em crianças e jovens com medida de acolhimento residencial, Caminos de reflexión y pensamiento: Análisis desde la filosofía hasta los ODS, 1
          * 2023, O efeito da arte e do desporto na diminuição de comportamentos agressivos em crianças e jovens com medida de acolhimento residencial, Caminos de reflexión y pensamiento: Análisis desde la filosofía hasta los ODS, 1
          * 2023, La percepción de la calidad de vida en un contexto pospandémico, de guerra y de alteraciones climáticas, Equilibrio social: perspectivas de análisis y mejora para las sociedades del siglo XXI , 1, Dykinson,S.L.
          * 2023, Competências emocionais e sociais em contexto pós- pandémico, de guerra e de alterações climáticas, Equilibrio social: perspetivas de análisis y mejora para las sociedades del siglo XXI, 1, Dykinson,S.L.
          * 2022, Doença mental: o papel de vítima e/ou agressor na família, Innovación e investigación, rescate humano y transferencia de conocimientos: retos para la universidad ante el horizonte 2030, 1, 1, Ediciones Egregius
          * 2022, Ajustamento psicoemocional e relacional de crianças e jovens com medida de acolhimento residencial, E-book II Congresso Internacional Humanismo, Direitos Humanos e Cidadania., Edições Universitárias Lusófonas
          * 2022, Ajustamento psicoemocional de crianças e jovens portugueses integrados em distintas tipologias de agregado, Investigación y transferencia de las ciencias sociales frente a un mundo en crisis, 1, 1, Ediciones Egregius.
          * 2021, O perfil de competências do assistente social em contexto de acolhimento residencial, Luces en el camino: Filosofía y ciencias sociales en tiempos de desconcierto , editorial Dykinson S.L.
          * 2021, Intervenção com crianças e jovens em risco em acolhimento residencial: O Projeto D'AR-TE, Luces en el camino: filosofía y ciencias sociales en tiempos de desconcierto, editorial Dykinson S.L.
          * 2021, A arte na intervenção com crianças e jovens com medida de acolhimento residencial: D’AR-TE, Discursos. Mujeres y artes ¿Construyendo o derribando fronteras? , 95, 1, Ediciones Dykinson, S.L.
          * 2021, (Re)Aprender a confiar: O perfil de competências do assistente social em contexto de acolhimento residencial, Luces en el camino: Filosofía y ciencias sociales en tiempos de desconcierto, 1, editorial Dykinson S.L.
          * 2017, Neuropsychological predictors of alcohol abtinence following a detoxification program. , ). ICTs for Improving Patients Rehabilitation Research Techniques. REHAB 2015. Communications in Computer and Information Science, 665, Springer, Cham
          * 2015, Gamito, P., Oliveira, J., Brito, R, Lopes, P., Morais, D., Pinto, L., Rodelo, L., Gameiro, F., & Rosa, B. (2015). Assessing cognitive functions with VR-based serious games that reproduce daily life: Pilot testing for normative values. In. S. Barbosa, P. Chen, A. Cuzzocrea, X. Du, J. Filipe, O. Kara, I. Kotenko, K.M. Sivalingam, D. Slezak, T. Washio, & X. Yang (Eds.). Communications in Computer an

        Relatório

          * 2023-05, Relatório técnico do projeto D’AR-TE 2020-2023

        Artigo em conferência

          * 2023-11, Crescer na instabilidade: Fatores contextuais e o seu efeito no desenvolvimento dos jovens portugueses, VI Congresso Iberoamericano de Intervenção Social (VI CIAIS) e Pré-Congresso Mundial do X Congresso Mundial de Infância e Juventude
          * 2021-10-28, Ajustamento psicoemocional e relacional de crianças e jovens com medida de acolhimento residencial, II Congresso Internacional 2021: Humanismo, Direitos Humanos e Cidadania-Direitos Humanos Fundamentais e Intervenção Social: Intervenção social
          * 2016, Obesidade na adolescência: O papel da actividade física nas funções executivas. , IX Simpósio Nacional de Investigação em Psicologia
          * 2015, Executive functions in obese individulas with binge eating. , I International Congress of Psychobiology
          * 2015, Executive functions in binge eating: Preliminary Data, 17th International Conference of the Association of Psychology and Psychiatry for Adults and Children
          * 2015, Cognitive stimulation of alcoholics through VR-based Instrumental Activities of Daily Living, 3rd 2015 Workshop on ICTs for improving Patients Rehabilitation Research Techniques
          * 2014, Reabilitação Neuropsicológica em alcoólicos com recurso a aplicações móveis, IX Congresso Iberoamericano de Psicologia/2º Congresso da OPP
          * 2014, Flexibilidade cognitiva em indivíduos obesos com Perturbação de Ingestão Compulsiva. , IX Congresso Iberoamericano de Psicologia/2º Congresso da OPP
          * 2013, Obesidade e Perturbação de Ingestão Compulsiva: Controlo inibitório e capacidade de manutenção da resposta, VIII Simpósio Nacional de Investigação em Psicologia
          * 2000, Satisfação de sujeitos diabéticos em relação aos cuidados de saúde, 3.º Congresso Nacional de Psicologia da Saúde

        Resumo em conferência

          * 2023, Competências emocionais e sociais: perceção dos jovens portugueses face ao atual contexto mundial, 7º ICCA- International Conference on Childhood and Adolescence
          * 2023, Autoperceção da capacidade empática dos jovens portugueses face ao atual contexto mundial, 7º ICCA- International Conference on Childhood and Adolescence
          * 2022, Transições: Resiliências contextuais- Um estudo sobre o suicídio e comportamentos suicidas dos jovens trans masculinos, 3rd International Conference LGBT+ Psychology and related fieds: Promoting equality, social justice and psychosocial well-being in a contrasting world
          * 2022, Perceção de suporte social de pares e de familiares de crianças e jovens portuguesas integrados em distintas tipologias de agregados, 6th International Conference on Childhood and Adolescence and 9th Anual Meeting of the Social Paediatric Subcommittee (SPS-SPP) of the Portuguese Society of Paediatrics
          * 2022, A agressividade de crianças e jovens no acolhimento residencial, XI Simpósio Nacional de Investigação em Psicologia
          * 2021, Doença mental: o papel de vítima e/ou agressor na família, II Congreso Internacional Nodos del Conocimiento. Universidad, innovación e investigación, rescate humano y transferencia de conocimientos: retos para la universidad ante el horizonte 2030
          * 2021, Ajustamento psicoemocional e relacional de crianças e jovens com medida de acolhimento residencial, II Congreso Internacional Nodos del Conocimiento. Universidad, innovación e investigación, rescate humano y transferencia de conocimientos: retos para la universidad ante el horizonte 2030
          * 2021, Ajustamento psicoemocional de crianças e jovens portugueses integrados em distintas tipologias de agregado, II Congreso Internacional Nodos del Conocimiento. Universidad, innovación e investigación, rescate humano y transferencia de conocimientos: retos para la universidad ante el horizonte 2030
          * 2021, A arte na intervenção com crianças e jovens com medida de acolhimento residencial: D’AR-TE, I Congreso Internacional CIIID2021- Identidades, Inclusión y Desigualdad
          * 2021, (Re)Aprender a confiar: O perfil de competências do assistente social em contexto de acolhimento residencial, Congreso Internacional Nodos del Conocimiento 2020- Universidad, innovación e investigación ante el horizonte 2030
          * 2020-12-11, Intervenção com crianças e jovens em risco em acolhimento residencial: O Projeto D’AR-TE, Congreso Internacional Nodos del Conocimiento 2020- Universidad, innovación e investigación ante el horizonte 2030
          * 2018, O controlo inibitório em adolescentes com medida de acolhimento residencial, 4º Congresso da Ordem dos Psicólogos Portugueses
          * 2016, Obesidade na adolescência: O papel da actividade física nas funções executivas, IX Simpósio Nacional de Investigação em Psicologia
          * 2015, Executive functions in obese individulas with binge eating, I International Congress of Psychobiology
          * 2014, Reabilitação Neuropsicológica em alcoólicos com recurso a aplicações móveis, IX Congresso Iberoamericano de Psicologia/2º Congresso da OPP
          * 2013, Obesidade e perturbação de ingestão compulsiva: Controlo inibitório e capacidade de manutenção da resposta, VIII Simpósio Nacional de Investigação em Psicologia
          * 2004, Relações Sexuais Forçadas em Estudantes Universitários- , 3.º Simpósio de Sexologia da Universidade Lusófona
          * 2002, Relações sexuais coercivas em estudantes universitários, 2.º Simpósio de Sexologia

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona