# Response for https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
          PT: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459 EN: https://www.ulusofona.pt/en/teachers/benilde-mendes-dos-reis-6459
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
        fechar menu : https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/benilde-mendes-dos-reis-6459
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Benilde Reis

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6459
              ben***@ulusofona.pt
              EA1B-CE27-5FE1: https://www.cienciavitae.pt/EA1B-CE27-5FE1
              0000-0003-0525-0853: https://orcid.org/0000-0003-0525-0853
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/3b4330a7-4084-4c8d-bbbd-344f079e5487
      : https://www.ulusofona.pt/

        Resume

        Benilde is a Fashion Design Professor and researcher at Lusófona University. She holds a B.Des. & M.Des. in Fashion Design (2011 & 2013), both from the University of Beira Interior and with the dissertation ¿Contemporary Tailoring: Handmade Tailoring and Industrial Tailoring a Case Study¿. She has fashion experience as a pattern-cutting assistant in the menswear department at Twintex. B2B experience working as a fashion design researcher at U.MAKE.ID project (B2B online platform). Temporary lecturer in Fashion Design courses at UBI (2016-2020). 2018-2020: fashion design researcher in TEXBOOST project: 'New Materials and Advanced Use of Natural Fibers: New fabrics for high-performance applications based on natural fibres', applying wool in textile fabrics for fashion products in activewear. 2020: PhD in Fashion Design, with the research ¿Gender Issues in Genderless Clothing: Trends vs Paradigm¿, an interdisciplinary study in fashion design with support from sociology and consumer behaviour. Since 2021, she has been Assistant Professor at Lusófona University in Fashion Design and Production, in Bachelor's and Master's Degrees. Her research area is in Genderless Clothing, 3D - Digital and Virtual construction of Clothes and Patternmaking/Cutting considering genderless clothing and digital fashion. She has a personal project called "The Unafashionable Worth of Fashion", where she writes about current and past fashion issues.

        Graus

            * Ensino secundário
              Design, Ceramics and Sculpture
            * Licenciatura
              Fashion Design
            * Mestrado
              Fashion Design
            * Doutoramento
              Fashion Design (association)
            * Outros
              University Teaching
            * Outros
              Communicating on Social Media
            * Outros
              Learn Marvelous Designer
            * Outros
              3D clothing design with Marvelous Designer
            * Outros
              Clo3D for beginners
            * Outros
              Fashion Journalism Online Short Course
            * Outros
              Fashion as Design
            * Outros
              UNDERSTANDING FASHION: From Business to Culture
            * Outros
              Data Analysis with SPSS
            * Outros
              CREATIVE WRITING COURSE
            * Outros
              ENGLISH LANGUAGE - INDUSTRIAL RELATIONS
            * Outros
              PATTERNMAKING DESIGN COURSE ASSISTED BY COMPUTER MODARIS
            * Outros
              CAP - CERTIFICATE OF PEDAGOGICAL SKILLS
            * Outros
              Notions of Industrial Cutting
            * Outros
              Foreign Language - English
            * Outros
              VStitcher 101

        Publicações

        Artigo em revista

          * 2024-02, Inclusividade no Design de Moda e Sustentabilidade Social - Projeto Finally Fashion, IJFMA: International Journal of Film and Media Arts
          * 2020-06-02, The Fabrics Design Influence in Real and Simulated Drape of Clothing, KnE Engineering

        Tese / Dissertação

          * 2020, Doutoramento, Questões de Género no Vestuário Sem Género
          * 2013, Mestrado, Alfaiataria na contemporaneidade: alfaiataria artesanal e alfaiataria industrial, um estudo de caso

        Capítulo de livro

          * 2023, Women's Tailoring in Contemporary Time: The Deconstruction of Classic
          * 2023, The Paradigm of Patternmaking Teaching - Draping as a Starting Point
          * 2023, Studying Genderless Fashion Design: Triangulation Method in Fashion Research
          * 2023, New Ways of Ageless Fashion: Project Development in Class Context, Advances in Fashion and Design Research II, 1, Springer Nature Switzerland
          * 2023, Gender Issues in Genderless Clothing: A Theoretical Framework in Fashion Interdisciplinary Research
          * 2023, Fashion Design - Sustainability and Technologies - The Carlos Gil Case
          * 2022, Functional Design of Tri-Laminated Wool Fabrics Improving Comfort Properties, Journal of Biomimetics, Biomaterials and Biomedical Engineering , 57, 1, Trans Tech Publications, Ltd.
          * 2021, Usability Attributes for Fashion Design of Functional Wool Leisurewear, Advances in Design, Music and Arts , 9, Springer Nature Switzerland AG
          * 2021, Design of Fashionable and Functional Tri-laminated Wool Fabrics for Leisurewear Considering Drape and Touch, Lecture Notes in Networks and Systems, Springer International Publishing
          * 2021, Design of Fashionable and Functional Tri-Laminated Wool Fabrics for Leisurewear Considering Comfort, Lecture Notes in Networks and Systems, Springer International Publishing
          * 2020, The relation of textile aesthetics with the development of genderless clothing
          * 2020, Technology-Driven Sustainability: Innovation in the Fashion Supply Chain , Global and national business theories and practice: Bridging the past with the future, Palgrave Macmillan
          * 2020, Digital Technology for Global Supply Chain in Fashion: A Contribution for Sustainability Development
          * 2020, Clothing for leisurewear with fashionable and functional wool fabrics, Textiles, Identity and Innovation: In Touch, CRC Press
          * 2018, Genderless clothing issues in fashion, Textiles, Identity and Innovation: Design the Future, CRC Press
          * 2018, Analysis of Attributes in Unisex and Genderless Clothing, Reverse Design: A Current Scientific Vision From the International Fashion and Design Congress, CRC Press

        Website

          * 2021-04, The Unfashionable Worth of Fashion, Through this personal project, I intend to write more than just about fashion, but what leads to certain fashion items being icons, eventually writing about political-social and artistic events that influenced and continue to influence fashion., https://theworthoffashion.com/

        Artigo em conferência

          * Women wears men’s clothing: a study case for a niche market, 2nd Symposium of the FibEnTech Research Unit: Fiber Materials and Environmental Technologies
          * U.MAKE.ID - A Digital Sourcing Platform Project: A Theoretical Approach, 2nd Symposium of the FibEnTech Research Unit: Fiber Materials and Environmental Technologies
          * U.MAKE.ID - A DIGITAL SOURCING PLATFORM PROJECT FOR THE FASHION BUSINESS: A THEORETICAL STUDY, 10th Annual Conference of the EuroMed-Academy-of-Business
          * Tailoring in contemporary times Handmade tailoring and industrial tailoring a study case, 3rd International Conference on Innovation and Entrepreneurship in Marketing & Consumer Behaviour (ICIEMC) – 2016
          * Innovation And Social Responsability In Fashion Design Training, 5th International Conference On Global Fashion - Tradition and Innovation: Challenges for Fashion and Luxury in the 21st century
          * Fashionable and functional wool fabrics: clothing design for outdoor activities, 3rd Symposium of the FibEnTech - Fiber Materials and Environmental Technologies Research Unit
          * Craftsmanship and Tradition Tailoring in Contemporary Fashion, Global Fashion Conference
          * Ambivalência do vestuário sem género na moda, I CONGRESSO IBÉRICO DE SEMIÓTICA: MODAS, MODOS, MANEIRAS
          * 2022-11-29, The Contribution of 3D Virtual Fashion Product Development to the Sustainability and Productivity of the Textile and Apparel Industry, ICEUBI22 - International Congress on Engineering
          * 2022-11-04, SANTA CLARA TRAPOLOGY A CASE OF A TRADITIONAL TEXTILE TECHNOLOGY, Fashion&Sustainability
          * 2018-10-03, U.MAKE.ID Fashion Sourcing Platform Project, 1st International Textile Design Conference

        Resumo em conferência

          * 2024-01-31, Simpósio da Moda e a ITV, Simpósio do Ensino da Moda e a ITV
          * 2023-01-20, Simpósio do Ensino da Moda e a ITV #01 ¿ Formação de Talentos para a Fileira da Moda, Simpósio do Ensino da Moda e a ITV
          * 2022, Santa Clara trapologia: A case of a traditional textile, FL Conference | Fashion & Sustainability
          * 2022, Inclusiveness in fashion design and social sustainability: Finally Fashion Project, FL Conference | Fashion & Sustainability
          * 2021, Design of Fashionable, Functional and Comfortable Tri-Laminated Wool Fabrics for Leisurewear, Autex 2021 - Unfolding the Future

        Poster em conferência

          * 2022-05, Engineering design of laminated wool fabrics for functional leisurewear considering mechanical and comfort performance, iTechStyle Summit ‘22 – International Conference on Textiles and Clothing
          * 2018-02-28, Digital Sourcing Platforms: A Plus for the Fashion Design and Industry Regarding the Circular Economy in the Fashion Context, iTech Style Summit - International Conference on Textiles and Clothing
          * 2018, Unisex Clothes + Androgynous Bodies = Genderless Fashion, 3rd Symposium of the FibEnTech - Fiber Materials and Environmental Technologies Research Unit

        Outra produção

          * 2023-07-21, Over&Out - Desfile com os trabalhos dos estudantes de Design e Produção de Moda, Over&Out - Desfile com os trabalhos dos estudantes de Design e Produção de Moda
          * 2023-07-08, Lérias: A Arte das Linhas, Mostra de trabalhos desenvolvidos pelos estudantes do Curso de Design e Produção de Moda
          * 2022-11, FL Conference | Fashion & Sustainability - Upcycling Expo Catalog

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona