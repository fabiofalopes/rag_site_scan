# Response for https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
          PT: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082 EN: https://www.ulusofona.pt/en/teachers/alexandra-maria-dos-santos-esteves-vilela-3082
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
        fechar menu : https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/alexandra-maria-dos-santos-esteves-vilela-3082
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Alexandra Vilela

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p3082
              p30***@ulusofona.pt
              9F18-EE68-253C: https://www.cienciavitae.pt/9F18-EE68-253C
              0000-0003-2816-0623: https://orcid.org/0000-0003-2816-0623
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/c1fa2c72-b7bc-4360-8b5c-ce55faabe208
      : https://www.ulusofona.pt/

        Resume

        Alexandra Vilela is a Professor at Universidade Lusófona, teaching at the University Centers of Porto and Lisbon in the areas of Criminal and Administrative Sanctionary Law, in the three study cycles: bachelor, master's and doctorate. She is the director of the master¿s in legal and criminal sciences at the Faculty of Law of CUP Porto. She is a member of the Disciplinary Council and the Electoral Commission of the Universidade Lusófona. She holds a master's in criminal legal sciences from FDUC and a doctorate in the same area from the same institution, with the thesis ¿O Direito de Mera Ordenação Social: entre a ideia de «recorrência» e a «erosão» do Direito Penal Clássico¿ (¿The Administrative Sanctionary Law: between the idea of «recurrence» and «erosion» of Classical Criminal Law "). The master's dissertation, «The Principle of the Presumption of Innocence in Criminal Procedural Law» and the doctoral thesis were both published in Portugal ¿ the doctoral thesis was republished by Edições Universitárias Lusófonas, coming out as a second edition. She has two postgraduate degrees, in Biomedical Law and European Studies, both from FDUC, and has professional training in Administrative Law. She taught at the International University of Figueira da Foz and the Escola Superior de Gestão of the Instituto Politécnico de Castelo Branco. She was the director of the ULP Review, where she publishes regularly and is a member of its Editorial Board. She has co-organized several books and has published chapters and articles in Portuguese and international magazines, journals and books. Alexandra Vilela supervises several master's and doctoral students in Legal and Criminal Sciences. She participates in masters and PhD juries and advises students to obtain academic degrees. She was an integrated member of the Research Center for Criminal Law and Criminal Sciences at FDUL, and from that date onwards, she became a collaborating researcher. She is a researcher at the Center for Advanced Studies in Law-Francisco Suárez at Universidade Lusófona. She organizes and participates in scientific events in the area of her studies, both in Portugal and abroad (the last of which on January 24, 2024). She has been a lawyer since 1994 and was a Deontology Council member of the Coimbra Regional, Council of the Portuguese Bar Association from 2008-2010 and 2011-13. Between 2007 and 2011, she was a trainer in the Insolvency Process Course, aimed at trainee lawyers who are in the 2nd phase of the internship at the Coimbra Regional Council of the Portuguese Bar Association and, between March 2011 and December 2016, she was a member of a jury of the Regional Council of Coimbra, for the oral exams of the final evaluation and aggregation exam to the Portuguese Bar Association. In the three years from 2017 to 2019, she was a member of the National Internship and Training Commission (CNEF) and the National Evaluation Commission of the Portuguese Bar Association. She is also a member of the Commission for the Protection of Minors and Vulnerable Adults from the Diocese of Coimbra, established by His Holiness Pope Francis. 27 January 2024

        Graus

            * Mestrado
              Mestrado em Ciências Jurídico-Criminais
            * Pós-Graduação
              Estudos Europeus
            * Licenciatura
              Licenciatura em Direito
            * Pós-Graduação
              Direito Biomédico
            * Pós-Graduação
              Direito Administrativo
            * Doutoramento
              Direito

        Publicações

        Artigo em revista

          * 2024-01-31, A New Perspective on the Issue (Always on the Agenda) of Voluntary Termination of Pregnancy, US-China Law Review,
          * 2023, Does the way forward today have to be criminal law, especially for crimes within the family?, YIECPL - Yearbook of International & European Criminal and Procedure Law
          * 2022-04-30, Responsabilidade das empresas e dos seus dirigentes, Vida Judiciária
          * 2022-02-06, Primeira reflexão sobre o novel Regime Jurídico das contra-ordenações económicas, Research Outputs
          * 2022-02-01, Is the Legislator of Sanctionatory Law Attentive to Criminal Policy?, US-China Law Review
          * 2021-12-04, O DIREITO SANCIONATÓRIO E O ESTADO REGULADOR NO PLANO ECONÓMICO-FINANCEIRO, Virtuajus
          * 2021-09-22, Os crimes agravados pelo resultado de dupla negligência típica e a observância do princípio da culpa, JULGAR Online
          * 2021-07-15, O crime de violência doméstica: reflexão a propósito do crime cometido sob a forma de omissão e o concurso com o crime de omissão de auxílio, De Legibus Revista de Direito
          * 2019-06-15, «A mediatização da justiça criminal ou um cenário em que nem as pedras são inocentes», Revista da Faculdade de Direito e Ciência Política da Universidade Lusófona do Porto
          * 2018, A propósito da técnica de qualificação do homicídio prevista no artigo 132.º do Código Penal, Revista da Faculdade de Direito e Ciência Política da Universidade Lusófona do Porto , 2018
          * 2017, «A fase jurisdicional do processo contraordenacional», Anatomia do Crime
          * 2015, «O direito contra ordenacional: um direito sancionatório com futuro?», Anatomia do Crime - Revista de Ciências Jurídico-criminais
          * 2015, Revisitando o n.º 1 do artigo 206.º do Código Penal: a extinção da responsabilidade criminal e a (não)necessidade de pena, JULGAR Online
          * 2014, Pequena reflexão sobre a Lei n.º 30/2000 (consumo de estupefacientes e substâncias psicotrópicas, Newsletter ASPF – PJ
          * 2014, A segunda parte do regime geral do ilícito de mera ordenação social: um direito processual muitas vezes ignorado, Revista da Faculdade de Direito da Universidade Lusófona do Porto
          * 2013, Crime e contraordenção: por morrerem algumas andorinhas pode acabar a primavera, Revista da Faculdade de Direito da Universidade Lusófona do Porto
          * 2012, Notas dispersas sobre algumas normas do C.P., Revista da Faculdade de Direito da Universidade Lusófona do Porto
          * 2012, BECCARIA: contributo do “direito penal total” para o exercício da cidadania, Boletim da Faculdade de Direito
          * 2009, Notas sobre a última revisão ao Código Penal: um exemplo, o artigo 132.º, Revista Portuguesa de Ciência Criminal
          * 2004, Colheita de órgãos e tecidos em dadores vivos para fins de transplante. Artigos 19.º e 20.º da Convenção sobre os Direitos do Homem e a Biomedicina, Lex Medicinae - Revista Portuguesa de Direito da Saúde
          * 1998, A Intervenção do Direito Penal no Âmbito da Transmissão do Vírus HIV por Via Sexual , Boletim do Conselho Distrital de Coimbra, Ordem dos Advogados

        Livro

          * 2023, Observações, reflexões e desdobramentos analíticos a partir das lições de Direito Penal de Faria Costa, Vilela, Alexandra, Edições Universitárias Lusófonas
          * 2022, O Direito de Mera Ordenação Social: entre a ideia de «recorrência» e a de «erosão» do Direito Penal Clássico , 2, Vilela, Alexandra, Edições Universitárias Lusófonas
          * 2013, O Direito de Mera Ordenação Social Entre a ideia de recorrência a de erosão do Direito Penal Clássico - 1.ª ed., 1, Vilela, Alexandra, Coimbra Editora
          * 2005, Considerações acerca do Princípio da Presunção de Inocência em Direito Processual Penal, Reimp., Vilela, Alexandra, Coimbra Editora

        Capítulo de livro

          * 2023, O Confisco no Direito de Mera Ordenação Social, O Confisco não Baseado numa Condenação - 40 Anos Depois do Código Penal e 20 Anos Depois da Lei N.º 5/2002, o Crime Continua a Compensar?, 1, 1, Edições Almedina
          * 2023, Nota Prévia ao Artigo 392.º; Artigo 392.º; Artigo 393.º; Artigo 394.º; Artigo 395.º; Artigo 396.º; Artigo 398.º;, Comentário do Código de Processo Penal à luz da Constituição da República e da Convenção Europeia dos Direitos do Humanos, , 2, 5, Universidade Católica Editora
          * 2023, El combate a la corrupción, en Portugal. Que se seguirá con la "ia ética, responsable y transparente? , La atribución de una responsabilidad jurídico penal e internacional de la inteligencia artificial , 1, Iustel Portal Derecho
          * 2022, «Comentário ao artigo 19.º», Convenção para a Proteção dos Direitos do Homem e da dignidade do ser humano face às aplicações da biologia e da medicina – 20 anos de vigência em Portugal, coordenadores: Loureiro, João caros, Pereira, André Dias, Barbosa, Carla, 1, 1, Instituto Jurídico, Faculdade de Direito da Universidade de Coimbra
          * 2022, Questões em torno das sanções do direito de mera ordenação social, Prof. Doutor Augusto Silva Dias, in memoriam, 2, 1, Associação Académica da Faculdade de Direito de Lisboa - Editora
          * 2022, Os crimes agravados pelo resultado e «dupla negligência típica» e a observância do princípio da culpa , A culpa e o Tempo, 1, 1, Imprensa da Universidade de Coimbra
          * 2021, O direito das contra-ordenações necessário para um combate eficaz da corrupção , Corrupção em Portugal. Avaliação legislativa e proposta de reforma, 1, 1, Universidade Católica Editora
          * 2021, Cotejo entre a proteção do jurídico-penal da vida humana de pessoa já nascida em Portugal e no Brasil, Estudos de Direito Lusófono Comparado II, Coordenação de Alberto de Sá e Mello, 2, 1, Edições Universitárias Lusófonas
          * 2020, Responsabilidade contra ordenacional da Pessoa Colectiva, Novos Estudos sobre Law Enforcement, Compliance e Direito Penal, 1, 1, Edições Almedina
          * 2020, Proibição de expulsão de nacionais, Comentário da Convenção Europeia dos Direitos Humanos e dos Protocolos Adicionais, III, 1, Universidade Católica Editora
          * 2020, Covid-19 e o Direito Penal, E-Book COVID-19 e o Direito, 1, 1, Edições Universitárias Lusófonas
          * 2020, A propósito do designado «Direito Penal da Família», Homenagem ao Professor Doutor Germano Marques da Silva, Coord. José Lobo Moutinho, Henrique Salinas, Elsa Vaz Sequeira e Pedro Garcia Marques, 1, 1, Universidade Católica Editora
          * 2019, «As reformas do ordenamento jurídico penal: suas andanças», Estudos dos Advogados em comemoração dos 100 anos do Tribunal da Relação de Coimbra, 1, 1, Almedina
          * 2019, As infracções Relacionadas com o Direito da Moda, Direito da Moda, I, UNL-CEDIS, UNL - CEDIS
          * 2018, Alguns aspectos das recentes alterações ao Código de Processo Penal Português: a utilização em fase de julgamento das declarações anteriormente prestadas e a sua compatibilidade com os princípios do processo penal português, As novas fronteiras do Direito- e.book, Edições Universitárias Lusófonas
          * 2016, «A interrupção da gravidez ao abrigo da alínea e) do n.º 1 do artigo 142.º do Código Penal, introduzido pela Lei n.º 16/2007», Direito da Saúde, Estudos em Homenagem ao Prof. Doutor Guilherme de Oliveira, 5, Almedina
          * 2014, O cidadão enquanto sujeito no Direito Internacional: o caso particular da Convenção Europeia dos Direitos do Homem, Para Jorge Leite Escritos Jurídicos, 2, 1, Coimbra Editora
          * 2013, Reflexões em torno do princípio da oportunidade: no direito processual penal e no direito de mera ordenação social, Temas contemporâneos de Direito - Brasil e Portugal, 1, 1, Arraes Editores

        Edição de livro

          * 2018, Edições Universitárias Lusófonas
          * 2013, 1, 1, Arraes Editora

        Artigo em jornal

          * 2023-09-22, Amanhã, o melhor virá, Sol

        Documento de trabalho

          * 2022-11-07, Sumários desenvolvidos de Direito Penal I
          * 2022-10-23, Sumários de apoio à unidade curricular de Direito Penal Especial (desenvolvidos a partir das anotações ao Comentário Conimbricense

        Manual

          * 2020, Sumários de apoio à Unidade Curricular de Direito Penal II

        Recurso online

          * 2022-05-24, O código penal e as sucessivas revisões- a fuga ao espírito do legislador, https://drive.google.com/file/d/1FhbwYxeAghuxE7_0G_Oj0xtaMhAu_mNX/view?fbclid=IwAR3P_FttUKR2cnqPqirXW1yBsz-73aauJqlE0iurSTfIlFln-teezxSnY0M

        Artigo em conferência

          * «A responsabilidade contraordenacional da pessoa colectiva no “Estado Regulador”», I Curso de Pós-Graduação sobre Law Enforcement, Compliance e Direito Penal nas atividades bancária, financeira e económica
          * O medicamento, a sua comercialização e o ilícito de mera ordenação social, Colóquio Internacional As novas questões em torno da vida e da morte em direito penal; uma perspectiva integrada
          * 2020-04-17, «The Sanctionatory Law And The Regulatory State In The Economic-Financial Plan» - também publicado no v.6, n. 11 2021 Virta Jus, 52nd International Scientific Conference on Economic and Social Development Development

        Outra produção

          * 2016, Legítima Defesa (Entrada em Dicionário), in: Maia, Rui Leandro, Nunes, Laura ... (Coord.), Dicionário Crime, Justiça e Sociedade

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona