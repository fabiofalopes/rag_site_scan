# Response for https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
          PT: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195 EN: https://www.ulusofona.pt/en/teachers/clarisse-simoes-coelho-6195
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
        fechar menu : https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/clarisse-simoes-coelho-6195
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Clarisse Simões Coelho

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p6195
              cla***@gmail.com
              D310-EC71-CCE8: https://www.cienciavitae.pt/D310-EC71-CCE8
              0000-0003-2506-3510: https://orcid.org/0000-0003-2506-3510
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/97382eda-7ccb-47ae-bb88-e5e0af5894ac
      : https://www.ulusofona.pt/

        Resume

        Médica Veterinária formada pela Faculdade de Veterinária da Universidade Federal Fluminense, RJ, Brasil (1997). Fez residência em Clínica e Cirurgia de Grandes Animais pela FMVZ - USP, SP, Brasil, em 1998. Possui mestrado na área de Clínica Veterinária, concluído em 2002, e doutorado na área de Clínica Cirúrgica Veterinária, concluído em 2006, ambos pela FMVZ-USP. Possui reconhecimento dos títulos de Mestrado Integrado em Medicina Veterinária (2017) e Doutorado (2019) pelo Instituto de Ciências Biomédicas Abel Salazar, Universidade do Porto (ICBAS - UPorto). Tem experiência docente/pesquisa/extensão , tendo ministrado aulas na graduação e pós-graduação na UNIMONTE-SP, UVV-ES e Universidade Federal da Bahia (UFBA), com mais de 60 artigos publicados e 228 citações (h-index 9). Orientou 15 alunos de mestrado, 35 de graduação em medicina veterinária (bacharelado) e 21 alunos de iniciação científica, participando de 105 bancas de avaliação de alunos (mestrados, doutorados, graduação) . Foco de pesquisa na área de medicina esportiva de equinos e cães militares. Atualmente, é docente na Universidade Lusófona (Lisboa, Portugal). Coordena as disciplinas do 4o ano do 2o ciclo de estudos, com ênfase em medicina equina, e as disciplinas de Biomecanica Equina e Medicina desportiva Equina. / Veterinary Doctor trained by the Faculty of Veterinary Medicine of the Fluminense Federal University, RJ, Brazil (1997). Residence in Clinic and Surgery of Large Animals by FMVZ - USP, SP, Brazil, in 1998. Master's degree in the area of Veterinary Clinic, completed in 2002, and PhD in the area of Veterinary Surgical Clinic, completed in 2006, both by FMVZ- USP. Both titles were validated in Integrated Master in Veterinary Medicine (2017) and PhD Title (2019) by the Abel Salazar Institute of Biomedical Sciences, University of Porto (ICBAS - UPorto). I have teaching/research/extension experience, having taught undergraduate and post-graduation classrooms at UNIMONTE, UVV-ES and Federal University of Bahia (UFBA). Research focus in the area of sports medicine for horses and military dogs with more than 60 published manuscripts and 228 citations (h-index 9). She supervised 15 master's students, 35 undergraduate students in veterinary medicine (bachelor's degree) and 21 scientific initiation students, participating in 105 student evaluation boards (masters, doctorates, undergraduate).Currently, she is a professor at the Lusofona University (Lisbon, Portugal), where she coordinates the curricular units of the 4th year of the 2nd cycle of studies, with an emphasis on equine medicine. Also, she is responsible for Equine Biomechanics and Equine Sports Medicina units..

        Graus

            * Doutoramento
              Ciências Veterinárias
            * Mestrado integrado
              Medicina Veterinária
            * Graduado
              Medicina Veterinária
            * Magister (2.º ciclo de estudos)
              Medicina Veterinária
            * Doktor (PhD)
              Medicina Veterinária

        Publicações

        Artigo em revista

          * 2024-02-09, The Welfare of Horses Competing in Three-Barrel Race Events Is Shown to Be Not Inhibited by Short Intervals between Starts, Animals
          * 2023-12-13, Analysis of Stress Predictors in Vaquejada Horses Running with Different Interval Rest Periods, Stresses
          * 2023-11-17, Is a 6-week training protocol effective in preparing young Lusitano horses in early athletic life?, Comparative Exercise Physiology
          * 2023-07-28, Dynamic effect of water levels on the recovery spine movement pattern in horses with kissing spine, Comparative Exercise Physiology
          * 2023, Biomarkers of Stress and Inflammation in Assessing the Quality of Welfare of Conditioned Vaquejada Horses, Open Journal of Veterinary Medicine
          * 2023, Association between Infrared Thermography, Blood Count and Creatine Kinase in the Evaluation of the Welfare of Vaquejada Horses, Open Journal of Veterinary Medicine
          * 2022-12-06, Training Effects on the Stress Predictors for Young Lusitano Horses Used in Dressage, Animals
          * 2022-12, The role of embryonic stem cells, transcription and growth factors in mammals: a review, Tissue and Cell
          * 2022-11-09, Effects of the Ingestion of Ripe Mangoes on the Squamous Gastric Region in the Horse, Animals
          * 2022-05-20, Rabies in a previously vaccinated horse: case report, Acta Veterinaria Brasilica
          * 2022-05, Which spend more energy in the practice of Vaquejada: pull horses or helper horses?, Comparative Exercise Physiology
          * 2022-05, Is a 6-week training protocol effective in preparing Lusitano horses in early athletic life?, Comparative Exercise Physiology
          * 2022-04-08, Evaluation of Mangalarga Marchador foal development in the first year of life, Brazilian Journal of Veterinary Research and Animal Science
          * 2022-02, Data on multiple regression analysis between boron, nickel, arsenic, antimony, and biological substrates in horses: The role of hematological biomarkers, Journal of Biochemical and Molecular Toxicology
          * 2021-11-30, How Much Energy Vaquejada Horses Spend in a Field Simulation Test?, Animals
          * 2020-09-09, Changes in Glutamine, Glutamate and Alanine concentrations after Vaquejada and 3-barrel simulation test on horses, Revista Acadêmica Ciência Animal
          * 2020, Is There an Ideal Rest Interval Between Races During Vaquejada in Which It Would Be Possible to Associate Best Performance and Welfare?, Journal of Equine Veterinary Science
          * 2019, Vitamin D concentrations and biological biomarkers of lactating mares and foals in the dry season, Pferdeheilkunde
          * 2019, Heart Rate Monitoring in Mangalarga Marchador Horses During a Field Marcha Test, Journal of Equine Veterinary Science
          * 2019, Effects of resistance training on serum iron, total iron-binding capacity and transferrin saturation in police working dogs, Comparative Exercise Physiology
          * 2018-09, Effect of a Marcha Field Test on Some Blood and Electrocardiographic Parameters of Mules, Journal of Equine Veterinary Science
          * 2018, The effect of repeated barrel racing on blood biomarkers and physiological parameters in Quarter horses, Comparative Exercise Physiology
          * 2018, Acute responses of iron indices in quarter horses during a 3-barrel racing exercise, Acta Veterinaria Brno
          * 2017-09-29, Influência da marcha sobre o eritrograma em equinos da raça mangalarga marchador, Veterinária e Zootecnia
          * 2017-05, Effects of topical application of pure and ozonized andiroba oil on experimentally induced wounds in horses, Brazilian Journal of Veterinary Research and Animal Science
          * 2017, Heart rate variability in Mangalarga Marchador horses after physical exercise, Veterinarni Medicina
          * 2017, Electrocardiographic and Blood Parameters in Show Jumping Horses Submitted to a Field Test Under Tropical Conditions, Journal of Equine Veterinary Science
          * 2017, Effects of resistance training on electrocardiographic and blood parameters of police dogs, Comparative Exercise Physiology
          * 2016-09, VOLUME CORPUSCULAR MÉDIO (VCM) E AMPLITUDE DA DISTRIBUIÇÃO DO TAMANHO DOS ERITRÓCITOS (RDW) EM EQUINOS DA RAÇA QUARTO DE MILHA USADOS EM PROVAS DE TRÊS TAMBORES, Ciência Animal Brasileira
          * 2016-03-08, Electrocardiographic patterns of Mangalarga Marchador horses before and after implementation of the marcha gait, Ciência Rural
          * 2016, VOLUME CORPUSCULAR MÉDIO (VCM) E AMPLITUDE DA DISTRIBUIÇÃO DO TAMANHO DOS ERITRÓCITOS (RDW) EM EQUINOS DA RAÇA QUARTO DE MILHA USADOS EM PROVAS DE TRÊS TAMBORES
          * 2016, Oral creatine supplementation on performance of Quarter Horses used in barrel racing, Journal of Animal Physiology and Animal Nutrition
          * 2016, Hoof capsule distortion and radiographic measurements of the front feet in Mangalarga Marchador horses subjected to athletic training,Veränderungen der Hufkapsel und radiographische Messungen der Vordergliedmaßen von Pferden der Rasse Mangalarga Marchador in Training, Pferdeheilkunde
          * 2016, Electrocardiographic patterns of Mangalarga Marchador horses before and after implementation of the marcha gait
          * 2016, Effects of 3-Barrel Racing Exercise on Electrocardiographic and on Blood Parameters of Quarter Horses, Journal of Equine Veterinary Science
          * 2015-09, Measurement of Incisor Overjet and Physiological Diastemata Parameters in Quarter Horse Foals, Journal of Veterinary Dentistry
          * 2015, Use of ozone therapy in chronic laminitis in a horse., Journal of Ozone Therapy
          * 2015, Thyroid hormones response to marcha gait in Mangalarga Marchador horses, Revista Brasileira de Ciência Veterinária
          * 2015, Comparative study of computerized and conventional electrocardiography in Quarter Horse and Mangalarga Marchador,Estudo comparativo da eletrocardiografia convencional e computadorizada em equinos das raças Quarto de Milha e Mangalarga Marchador, Arquivo Brasileiro de Medicina Veterinaria e Zootecnia
          * 2014-05-04, CONCENTRAÇÕES SÉRICAS DE SÓDIO, POTÁSSIO E CÁLCIO EM EQUINOS DA RAÇA MANGALARGA MARCHADOR APÓS EXERCÍCIO FÍSICO, Archives of Veterinary Science
          * 2014, Serum concentration of sodium, potassium and calcium in Mangalarga Marchador horses after physical exercise,Concentrações séricas de sódio, potássio e cálcio em equinos da raça mangalarga marchador após exercício físico, Archives of Veterinary Science
          * 2014, Serum concentration of sodium, potassium and calcium in Mangalarga Marchador horses after physical exercise,Concentra?ões séricas de sódio, potássio e cálcio em equinos da ra?a mangalarga marchador após exercício físico, Archives of Veterinary Science
          * 2014, Serum concentration of sodium, potassium and calcium in Mangalarga Marchador horses after physical exercise,Concentra?ões séricas de sódio, potássio e cálcio em equinos da ra?a mangalarga marchador após exercício físico, Archives of Veterinary Science
          * 2014, Serum concentration of sodium, potassium and calcium in Mangalarga Marchador horses after physical exercise,Concentra?ões séricas de sódio, potássio e cálcio em equinos da ra?a mangalarga marchador após exercício físico, Archives of Veterinary Science
          * 2014, Erythrogram in mules after a 100 Km endurance exercise,Eritrograma em muares submetidos à prova de resistência de 100 Km, Revista Brasileira de Medicina Veterinaria
          * 2014, Erythrogram in mules after a 100 Km endurance exercise,Eritrograma em muares submetidos à prova de resistencia de 100 Km, Revista Brasileira de Medicina Veterinaria
          * 2014, Erythrogram in mules after a 100 Km endurance exercise,Eritrograma em muares submetidos à prova de resistencia de 100 Km, Revista Brasileira de Medicina Veterinaria
          * 2014, Erythrogram in mules after a 100 Km endurance exercise,Eritrograma em muares submetidos à prova de resistencia de 100 Km, Revista Brasileira de Medicina Veterinaria
          * 2013-06-11, Concentrações séricas de aspartato aminotransferase e creatinoquinase e concentrações plasmáticas de lactato em equinos da raça Mangalarga Marchador após exercício físico, Brazilian Journal of Veterinary Research and Animal Science
          * 2013-02, Glicemia e concentrações séricas de insulina, triglicérides e cortisol em equinos da raça Quarto de Milha e mestiços usados em provas de laço em dupla, Brazilian Journal of Veterinary Research and Animal Science
          * 2013, Serum activity of muscular enzymes in mules after a 100 km endurance exercise,Atividade sérica das enzimas musculares em muares submetidos à prova de resistência de 100 km, Pesquisa Veterinaria Brasileira
          * 2013, Atividade sérica das enzimas musculares em muares submetidos à prova de resistência de 100 km
          * 2012, Use of extracts of sunflower-seed oil (Helianthus annus L.) for the treatment of cutaneous injuries in equine metatarsus: A case report,Uso do óleo de semente de girassol (Helianthus annus) no tratamento de lesões cutâneas no metatarso de um equino: Relato de caso, Revista Brasileira de Plantas Medicinais
          * 2012, Serum aspartate aminotransferase and creatine kinase concentrations and plasma lactate in Mangalarga Marchador horses after physical exercise,Concentrações séricas de aspartato aminotransferase e creatinoquinase e concentrações plasmáticas de lactato em equinos da raça Mangalarga Marchador após exercício físico, Brazilian Journal of Veterinary Research and Animal Science
          * 2012, Serum aspartate aminotransferase and creatine kinase concentrations and plasma lactate in Mangalarga Marchador horses after physical exercise,Concentra?ões séricas de aspartato aminotransferase e creatinoquinase e concentra?ões plasmáticas de lactato em equinos da ra?a Mangalarga Marchador após exercício físico, Brazilian Journal of Veterinary Research and Animal Science
          * 2012, Serum aspartate aminotransferase and creatine kinase concentrations and plasma lactate in Mangalarga Marchador horses after physical exercise,Concentra?ões séricas de aspartato aminotransferase e creatinoquinase e concentra?ões plasmáticas de lactato em equinos da ra?a Mangalarga Marchador após exercício físico, Brazilian Journal of Veterinary Research and Animal Science
          * 2012, Serum aspartate aminotransferase and creatine kinase concentrations and plasma lactate in Mangalarga Marchador horses after physical exercise,Concentra?ões séricas de aspartato aminotransferase e creatinoquinase e concentra?ões plasmáticas de lactato em equinos da ra?a Mangalarga Marchador após exercício físico, Brazilian Journal of Veterinary Research and Animal Science
          * 2012, Prevalence of hypocalcemia and hypomagnesemia in equines with gastrointestinal diseases,Prevalência de hipocalcemia e hipomagnesemia em equinos com distúrbios gastrintestinais, Arquivo Brasileiro de Medicina Veterinaria e Zootecnia
          * 2012, Glycemy and serum concentrations of insuline, triglycerides and cortisol in Quarter horses and crossbred submitted to team ropping,Glicemia e concentrações séricas de insulina, triglicérides e cortisol em equinos da raça Quarto de milha e mestiços usados em provas de laço em dupla, Brazilian Journal of Veterinary Research and Animal Science
          * 2012, Glycemy and serum concentrations of insuline, triglycerides and cortisol in Quarter horses and crossbred submitted to team ropping,Glicemia e concentra?ões séricas de insulina, triglicérides e cortisol em equinos da ra?a Quarto de milha e mesti?os usados em provas de la?o em dupla, Brazilian Journal of Veterinary Research and Animal Science
          * 2012, Glycemy and serum concentrations of insuline, triglycerides and cortisol in Quarter horses and crossbred submitted to team ropping,Glicemia e concentra?ões séricas de insulina, triglicérides e cortisol em equinos da ra?a Quarto de milha e mesti?os usados em provas de la?o em dupla, Brazilian Journal of Veterinary Research and Animal Science
          * 2012, Glycemy and serum concentrations of insuline, triglycerides and cortisol in Quarter horses and crossbred submitted to team ropping,Glicemia e concentra?ões séricas de insulina, triglicérides e cortisol em equinos da ra?a Quarto de milha e mesti?os usados em provas de la?o em dupla, Brazilian Journal of Veterinary Research and Animal Science
          * 2012, Effects of Topical Application of Sunflower-Seed Oil on Experimentally Induced Wounds in Horses, Journal of Equine Veterinary Science
          * 2012, Concentrações séricas de aspartato aminotransferase e creatinoquinase e concentrações plasmáticas de lactato em equinos da raça Mangalarga Marchador após exercício físico
          * 2011-03-04, Influence of acepromazine on the cardiovascular actions of dobutamine in isoflurane-anesthetized horses, Ciência Rural
          * 2011-03, Hepatische Enzephalopathie bei einer Stute, pferde spiegel
          * 2011, Lactacidemia e concentrações séricas de aspartato aminotransferase e creatinoquinase em equinos da raça Quarto de Milha usados em provas de laço em dupla
          * 2011, Influência do exercício físico sobre sódio e potássio séricos em equinos da raça Quarto de Milha e mestiços submetidos à prova de laço em dupla, Revista Brasileira de Ciência Veterinária
          * 2011, Influence of physical exercise on serum activities of AST and CK and plasma concentration of lactate in Quarter horses submitted to team roping,Lactacidemia e concentrações séricas de aspartato aminotransferase e creatinoquinase em equinos da raça Quarto de Milha usados em provas de laço em dupla, Pesquisa Veterinaria Brasileira
          * 2011, Influence of chromium supplementation on energy metabolism in horses used in policing activity, Arquivo Brasileiro de Medicina Veterinaria e Zootecnia
          * 2011, Influence of acepromazine on the cardiovascular actions of dobutamine in isoflurane-anesthetized horses,Ifluência da acepromazina sobre os efeitos cardiovasculares da dobutamina em cavalos anestesiados com isofluorano, Ciencia Rural
          * 2011, Influence of acepromazine on the cardiovascular actions of dobutamine in isoflurane-anesthetized horses
          * 2011, Glycemia and serum concentrations of insuline, triglycerides and cortisol in Mangalarga Marchador horses after physical exercise,Glicemia e concentrações séricas de insulina, triglicérides e cortisol em equinos da raça Mangalarga Marchador após exercício físico, Pesquisa Veterinaria Brasileira
          * 2011, Glycemia and serum concentrations of insuline, triglycerides and cortisol in Mangalarga Marchador horses after physical exercise,Glicemia e concentra?ões séricas de insulina, triglicérides e cortisol em equinos da ra?a Mangalarga Marchador após exercício físico, Pesquisa Veterinaria Brasileira
          * 2011, Glicemia e concentrações séricas de insulina, triglicérides e cortisol em equinos da raça Mangalarga Marchador após exercício físico
          * 2009, Short-Term Effects of Duodenocecostomy on Body Weight, Glucose Absorption, Serum Components, and Intestinal Histopathology in Four Normal Horses, Journal of Equine Veterinary Science
          * 2007, Plasma values of glucose, cholesterol and triglycerides of healthy Brasileiro de Hipismo fillies,Determinações plasmáticas de glicose, colesterol e triglicérides em potras sadias, da raça brasileiro de hipismo, Brazilian Journal of Veterinary Research and Animal Science
          * 2007, Plasma values of glucose, cholesterol and triglycerides of healthy Brasileiro de Hipismo fillies,Determina?ões plasmáticas de glicose, colesterol e triglicérides em potras sadias, da ra?a brasileiro de hipismo, Brazilian Journal of Veterinary Research and Animal Science
          * 2007, Plasma values of glucose, cholesterol and triglycerides of healthy Brasileiro de Hipismo fillies,Determina?ões plasmáticas de glicose, colesterol e triglicérides em potras sadias, da ra?a brasileiro de hipismo, Brazilian Journal of Veterinary Research and Animal Science
          * 2007, Plasma values of glucose, cholesterol and triglycerides of healthy Brasileiro de Hipismo fillies,Determina?ões plasmáticas de glicose, colesterol e triglicérides em potras sadias, da ra?a brasileiro de hipismo, Brazilian Journal of Veterinary Research and Animal Science
          * 2007, Evaluation of tracheal wash of horses with exercise-induced pulmonary hemorrhage treated with furosemide, Arquivo Brasileiro de Medicina Veterinaria e Zootecnia
          * 2007, Determinações plasmáticas de glicose, colesterol e triglicérides em potras sadias, da raça Brasileiro de Hipismo, Brazilian Journal of Veterinary Research and Animal Science
          * 2005-08-01, Parâmetros bioquímicos para avaliação da função renal e do equilíbrio hidroeletrolítico em bezerras sadias, da raça Holandesa, no primeiro mês de vida, Brazilian Journal of Veterinary Research and Animal Science
          * 2005, Função renal em eqüinos sadios, da raça Mangalarga Paulista, criados no estado de são paulo, Revista Brasileira de Ciência Veterinária
          * 2003-04, Parâmetros bioquímicos para avaliação da função hepática em bezerras sadias, da raça holandesa, no primeiro mês de vida, Ciência Rural
          * 2003-02, Revisão de 26 casos clínicos de duodeno-jejunite proximal em eqüinos (1996-2000), Ciência Rural
          * 2003, Revisão de 26 casos clínicos de duodeno-jejunite proximal em eqüinos (1996-2000)
          * 2003, Proteinograma sérico de bezerras sadias, da raça holandesa, no primeiro mês pós-nascimento, Brazilian Journal of Veterinary Research and Animal Science
          * 2003, Proteinograma sérico de bezerras sadias, da raça holandesa, no primeiro mês pós-nascimento
          * 2003, Parâmetros bioquímicos para avaliação da função hepática em bezerras sadias, da raça holandesa, no primeiro mês de vida

        Tradução

          * 2010, Prática Veterinária - Uma abordagem didática, Roca
          * 2009, O Paciente Felino, Roca
          * 2008, Nutrição e Alimentação de Eqüinos, Roca
          * 2008, Manual Merck de Veterinária, Roca
          * 2008, Anatomia funcional e fisiologia dos animais domésticos, Roca
          * 2006, Urinálise e Hematologia - Laboratorial para o Clínico de Pequenos Animais, Roca
          * 2006, Reprodução em Éguas para Veterinário de Eqüinos, Roca
          * 2006, Reprodução em bovinos, Roca
          * 2006, Obstetrícia Veterinária, Roca
          * 2006, Cuidado de Ferimentos para veterinários de Eqüinos, Roca
          * 2006, Claudicação em Eqüinos segundo Adams, Roca

        Resumo em conferência

          * 2023, SERIA UM TREINO DE 6 SEMANAS EFICIENTE PARA APRIMORAR INDICADORES DE CONSUMO ENERGÉTICO EM JOVENS LUSITANOS USADOS EM PROVAS DE DRESSAGE?
          * 2023, AVALIAÇÃO DE PERFORMANCE DESPORTIVA DE EQUINOS DA MODALIDADE DE SALTOS DE OBSTÁCULOS CRIADOS E TREINADOS EM PORTUGAL

        Poster em conferência

          * 2022-03-11, Doença inflamatória intestinal em equinos: diagnóstico por gastroscopia e biópsia duodenal, 13as Jornadas Hospital Veterinário Muralha de Évora

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona