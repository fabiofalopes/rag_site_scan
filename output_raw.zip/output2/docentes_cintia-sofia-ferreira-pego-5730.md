# Response for https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
          PT: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730 EN: https://www.ulusofona.pt/en/teachers/cintia-sofia-ferreira-pego-5730
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
        fechar menu : https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/cintia-sofia-ferreira-pego-5730
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Cíntia Ferreira-pêgo

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p5730
              cin***@ulusofona.pt
              4115-8C7E-28D5: https://www.cienciavitae.pt/4115-8C7E-28D5
              0000-0001-6930-4107: https://orcid.org/0000-0001-6930-4107
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/22497277-0ea5-4f30-af72-93cb955937a1
      : https://www.ulusofona.pt/

        Resume

        Cíntia Ferreira-Pêgo is the Director of the Nutrition Sciences Bachelor at Universidade Lusófona, coordinator of the Nutrition & Well-being science domain, and assistant researcher and integrated member at CBIOS (Lusófona's Research Center for Biosciences Health Technologies). Member of the Pedagogical and Scientific Council of the School of Health Sciences and Technologies (ECTS) of the Universidade Lusófona and the CBIOS - Universidade Lusófona's Research Center for Biosciences & Health Technologies. Member of the University Council of Universidade Lusófona. Member of the Consultative Observers of the Thematic Commission on Health and Food and Nutrition Security (SSAN) of the CPLP (Community of Portuguese-Speaking Countries). Cíntia is a full member and Specialist in Community Nutrition and Public Health by the Ordem dos Nutricionistas. Cíntia graduated in Human Nutrition and Dietetics from the Universitat Rovira i Virgili (Spain, 2010), a master's in Training and Sports Nutrition from the Universidad Europea de Madrid (Spain, 2012), and a Ph.D. with International Mention in Nutrition and Metabolism from the Universitat Rovira i Virgili, Spain, and the University of Arkansas, USA (2016). Cíntia published more than 40 papers in international and national peer-reviewed journals, 2 book chapters, and 1 editorial in an international peer-reviewed journal, the vast majority as first or last author, totaling more than 800 citations. She has several communications at national and international scientific congresses, and she's currently supervising 1 PhD thesis, 2 Master thesis, and 5 Nutrition Sciences final work. She participated in the organization of various scientific events and is also a reviewer of several international journals, mainly in the Nutrition Sciences field. Cíntia's main research interest is the relationship between different dietary habits (mainly plant-based diets, such as Vegetarian and Mediterranean diets) and body composition, different metabolic markers, and cardiovascular disease risk.

        Graus

            * Bacharelato
              Human Nutrition and Dietetics
            * Licenciatura
              Human Nutrition and Dietetics
            * Mestrado
              Masters in Training and Sports Nutrition
            * Doutoramento
              Ph.D in Nutrition and Metabolism

        Publicações

        Journal article

          * 2023-07, Functional Foods for Health: The Antioxidant and Anti-Inflammatory Role of Fruits, Vegetables and Culinary Herbs, Foods
          * 2023-05, Mediterranean Diet Adherence and Its Relationship to Metabolic Markers and Body Composition in Portuguese University Students, Nutrients
          * 2023, Hydration patterns and beverage consumption among a sample of institutionalized senior adults in Portugal, Biomedical and Biopharmaceutical Research
          * 2023, Food and Nutrition Knowledge of Elementary School Teachers in a Region of Lisbon, Portugal, Biomedical and Biopharmaceutical Research
          * 2022-10, University Students Eating Habits: Normal Semester vs. Lockdown Period Caused by COVID-19 Pandemic, International Journal of Environmental Research and Public Health
          * 2022-10, Bioimpedance and Dual-Energy X-ray Absorptiometry Are Not Equivalent Technologies: Comparing Fat Mass and Fat-Free Mass, International Journal of Environmental Research and Public Health
          * 2022-04, Polyphenols and Their Metabolites in Renal Diseases: An Overview, Foods
          * 2022-04, Comparison between Different Groups of Vegetarianism and Its Associations with Body Composition: A Literature Review from 2015 to 2021, Nutrients
          * 2021-12-24, Lipid-based carriers for food ingredients delivery, Journal of Food Engineering
          * 2021-06-03, Body composition assessment of vegetarian-vegan and omnivore young women - an exploratory study, Journal Biomedical and Biopharmaceutical Research
          * 2021-03, Nutrition Literacy of Portuguese Adults—A Pilot Study, International Journal of Environmental Research and Public Health
          * 2020-11, Grape Pomace: A Potential Ingredient for the Human Diet, Foods
          * 2020-09, Anthropometric assessment of children aged between 6 and 14 years from a school in Lisbon, Biomedical and Biopharmaceutical Research Journal
          * 2020-08-11, Eating behavior: The influence of age, nutrition knowledge, and Mediterranean diet, Nutrition and Health
          * 2020-07, Changes in Eating Habits among Displaced and Non-Displaced University Students, International Journal of Environmental Research and Public Health
          * 2020-03, Preliminary sensory evaluation of salty crackers with grape pomace flour, Biomedical and Biopharmaceutical Research Journal
          * 2020-03, Factors influencing healthy food choices of university students, Biomedical and Biopharmaceutical Research Journal (BBR)
          * 2019-12, Body shape concerns in Portuguese university students, Journal Biomedical and Biopharmaceutical Research
          * 2019-12, Anthropometric evaluation of pre-school and school age children from Azores archipelago, Portugal, Journal Biomedical and Biopharmaceutical Research
          * 2019-12, Anthropometric evaluation of children aged between 3 and 9 years from Canary Island, Journal Biomedical and Biopharmaceutical Research
          * 2019-06, Adherence to the Mediterranean diet in Portuguese university students, Journal Biomedical and Biopharmaceutical Research
          * 2017, Prediction of cardiovascular disease by the framingham-REGICOR equation in the high-risk PREDIMED cohort: Impact of the mediterranean diet across different risk strata, Journal of the American Heart Association
          * 2017, A higher Mediterranean diet adherence and exercise practice are associated with a healthier drinking profile in a healthy Spanish adult population, European journal of nutrition
          * 2016, Letter to the Editor Re: Nissensohn M. et al.; Nutrients 2016, 8, 232, Nutrients
          * 2016, Frequent Consumption of Sugar- and Artificially Sweetened Beverages and Natural and Bottled Fruit Juices Is Associated with an Increased Risk of Metabolic Syndrome in a Mediterranean Population at High Cardiovascular Disease Risk, The Journal of nutrition
          * 2016, Beverage Intake Assessment Questionnaire: Relative Validity and Repeatability in a Spanish Population with Metabolic Syndrome from the PREDIMED-PLUS Study, Nutrients
          * 2015, Total fluid intake and its determinants: cross-sectional surveys among adults in 13 countries worldwide, European journal of nutrition
          * 2015, Magnesium in tap and bottled mineral water in Spain and its contribution to nutritional recommendations, Nutricion hospitalaria
          * 2015, Intake of water and different beverages in adults across 13 countries, European journal of nutrition
          * 2014, The calcium concentration of public drinking waters and bottled mineral waters in Spain and its contribution to satisfying nutritional needs, Nutricion hospitalaria
          * 2014, Fluid intake in Spanish children and adolescents; a cross-sectional study, Nutricion hospitalaria
          * 2014, Fluid intake from beverages in Spanish adults; cross-sectional study, Nutricion hospitalaria

        Book chapter

          * 2021, Grape Pomace: A Potential Ingredient for the Human Diet, Advances in Food Science, Hyderabad, India: Vide Leaf
          * 2021, Fruit and vegetable juices and Breast Cancer, Cancer: Oxidative Stress and Dietary Antioxidants, 2, Elsevier - Academic Press

        Newspaper article

          * 2016, Water mineralization and its importance for health, limentacion, Nutricion y Salud

        Encyclopedia entry

          * Polyphenols in Renal Pathophysiology, Scholarly Community Encyclopedia

        Conference abstract

          * 2023-12, Assessing Recreational Athletes' Awareness of Contaminants in Food Supplements and their Health Implications, 5th European Lifestyle Medicine Congress
          * 2023-11-10, Contribution of diet quality to cardiovascular risk: Mediterranean vs. Vegetarian dietary patterns, APNEP congress
          * 2023, Recreational Athletes' Perception of Contaminants in Food Supplements and their Risks for Health, X Congresso Iberoamericano de Ciências Farmacêuticas - Acta Farmacêutica Portuguesa
          * 2023, Body composition and cardiovascular risk: a comparison between vegetarians and omnivores, XXII Congresso de Nutrição e Alimentação
          * 2022-06-02, Differences in body composition and human skin physiology between vegetarian-vegan and omnivores regimes., ISBS Congress.
          * 2021, Safety awareness and usage practices of materials used for cooking and storing food, III Jornadas Ibéricas de Toxicologia
          * 2021, Physiology of body composition how do vegetarians and omnivores differ?, The Physiological Society - Annual Conference
          * 2021, In vivo body composition analysis - comparing data from Dual Energy X-ray Absorptiometry (DXA) and Bioelectrical Impedance Analysis (BIA), The Physiological Society - Annual Conference
          * 2020-03-03, OC 7: Influence of Instagram and Digital Influencers on College Student Feeding, III Jornadas Lusófonas da Nutrição

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona