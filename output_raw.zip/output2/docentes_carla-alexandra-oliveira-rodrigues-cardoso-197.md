# Response for https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
          PT: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197 EN: https://www.ulusofona.pt/en/teachers/carla-alexandra-oliveira-rodrigues-cardoso-197
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
        fechar menu : https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/carla-alexandra-oliveira-rodrigues-cardoso-197
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Carla Alexandra Oliveira Rodrigues Cardoso

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p197
              car***@ulusofona.pt
              7D10-6290-4765: https://www.cienciavitae.pt/7D10-6290-4765
              0000-0003-0790-6924: https://orcid.org/0000-0003-0790-6924
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/47278573-aeba-44df-9a56-37af94af21cd
      : https://www.ulusofona.pt/

        Resume

        Carla Rodrigues Cardoso holds a PhD in Communication Sciences by NOVA University of Lisbon. At Lusófona University, she is Associate Professor and integrated researcher at CICANT, where she is the scientific coordinator of MagLab - Magazine Media Lab, the first international Lab on Magazine Studies. MagLab unites in its MagNet more than 40 researchers from around the world. The researcher is also the Editor of the International Journal of Magazine Studies, the first European journal on this scientific field. Her main research interests are Journalism and Magazine Studies, History of Journalism and, more recently, Intersectionality. Carla was the Principal Investigator of the research project "IM Lab (Intersectionality Media Lab) - The Joacine Katar Moreira Case Study" (COFAC/CICANT/PhDResearcher/2020) that ended in 2023. In 2020, she launched the course "Magazine Journalism in the Digital Age", the first academic formation on Magazine Studies in Portugal. In 2022, she edited two books, published three book chapters and an article, all connected to magazine and journalism studies. Carla Rodrigues Cardoso is the founder of the international conference "The Future of Magazine", that was held for the first time in 2023, at Lusófona University, in Lisbon.

        Graus

            * Licenciatura
              Ciências da Comunicação
            * Mestrado
              Master in Communication Sciences - Media Studies and Journalism
            * Doutoramento
              PhD in Communication Sciences
            * Bachelor (1st cycle)
              Erasmus+ Programme (Staff Mobility for Training) no BA Magazine Journalism and Publishing
            * Master
              Erasmus+ Programme (Staff Mobility for Training) no MA Magazine Journalism
            * Diploma de especialização
              Certificate of Proficiency in English
            * Diploma de especialização
              First Certificate in English
            * Outros
              Journalism Teacher
            * Postgraduate Certificate
              Erasmus+ Programme (Staff Mobility for Training)

        Publicações

        Magazine article

          * 2020-04, "A máquina agora está montada para os jornalistas não precisarem de ir ao local" | "The machine is now set up so journalists don't need to go to the field", JJ - Jornalismo & Jornalistas
          * 2007-10, Newsmagazines: Uma Forma Diferente de Fazer Jornalismo, JJ - Jornalismo & Jornalistas
          * 2001-10, O Lugar da Cultura nas Newsmagazines, JJ - Jornalismo & Jornalistas

        Journal article

          * 2022-04-21, A natureza híbrida da newsmagazine | The hybrid nature of the newsmagazine, Animus. Revista Interamericana de Comunicação Midiática
          * 2021-12-14, Artur Portela (Filho) e as marcas de uma irreverência única no Jornal Novo e na Opção | Artur Portela (Filho) and the marks of a unique brand of irreverence in Jornal Novo and Opção, Media & Jornalismo
          * 2012, Quando a Capa da Newsmagazine é Feminina, Media & Jornalismo
          * 2011-01-12, Obama on the Cover, JRE On-Line Journal
          * 2010-08, The Future of Newsmagazines, Journalism Studies
          * 2009, A Capa de Newsmagazine como Dispositivo de Comunicação, Observatorio (OBS*)
          * 2005, Anúncio e capa de revista : territórios paralelos ou contíguos?, Caleidoscópio – Revista de Comunicação e Cultura

        Thesis / Dissertation

          * 2015-05, PhD, A newsmagazine em Portugal: 70 anos até à consolidação do conceito
          * 2006, Master, As capas de newsmagazines como dispositivo de comunicação (Newsweek, Veja, L'Express e Visão - Janeiro a Março de 1999)

        Book

          * 2016, Colocar em Perspe(c)tiva | Putting in Perspe(c)tive, Carla Rodrigues Cardoso, Edições Universitárias Lusófonas
          * 2012, Seduzir ou Informar? - A capa de Newsmagazine como Dispositivo de Comunicação, Carla Rodrigues Cardoso, MinervaCoimbra

        Book chapter

          * 2024, Jornalismo de revista, Jornalismo de Especialidade, II, Livros Horizonte
          * 2022, As revistas durante a Ditadura Militar (1926-1933) e o Estado Novo (1933-1974) | Magazines during the Military Dictatorship (1926-1933) and the "Estado Novo" (1933-1974), Para uma História das Revistas de Informação Geral em Portugal , ICNOVA
          * 2022, As revistas durante a Democracia (1974-...) | Magazines during Democracy (1974-...), Para uma História das Revistas de Informação Geral em Portugal, ICNOVA
          * 2022, (News)magazine transformations in the digital age, (Trans)forming Magazines: Rethinking the Medium in the Digital Age, Cambridge Scholars Publishing
          * 2021, Uma newsmagazine militante: Opção (1976-78) | A militant newsmagazine: Opção (1976-78), Para uma história do jornalismo em Portugal II, Livros ICNOVA
          * 2020, Observador: a newsmagazine da Primavera Marcelista | Observador: the newsmagazine of the Marcelist Spring, Para uma história do jornalismo em Portugal, Instituto de Comunicação da Nova

        Edited book

          * 2022, ICNOVA
          * 2022, Edições Universitárias Lusófonas
          * 2022, Cambridge Scholars Publishing
          * 2017, Edições Universitárias Lusófonas
          * 2016, Edições Universitárias Lusófonas
          * 2013, Edições Universitárias Lusófonas
          * 2012, Edições Universitárias Lusófonas
          * 2011, Edições Universitárias Lusófonas
          * 2010, Edições Universitárias Lusófonas
          * 2009, Edições Universitárias Lusófonas
          * 2008, Edições Universitárias Lusófonas
          * 2007, Edições Universitárias Lusófonas
          * 2006, Edições Universitárias Lusófonas
          * 2005, Edições Universitárias Lusófonas
          * 2004, Edições Universitárias Lusófonas

        Newspaper article

          * 2023-12-20, Tenhamos a coragem de fazer diferente, Nascer do Sol
          * 2023-01-01, O problema e a solução somos nós, Nascer do Sol
          * 2017-10-04, Ainda vale a pena verificar os factos?, Sol
          * 2015-08-18, Sair do ninho e começar a voar, Sol

        Encyclopedia entry

          * Women's Lifestyle Magazines, The International Encyclopedia of Gender, Media, and Communication

        Conference paper

          * Padrões e Identidades nas Capas de Newsmagazines: 1999/2009, VI Congresso SOPCOM
          * 2021-07-13, How the Portuguese media represented the first racialized female MP head of a political party, IAMCR Online 2021 - 11-15 July
          * 2019-09-26, A newsmagazine em Portugal: 70 anos até à consolidação do modelo | The newsmagazine in Portugal: 70 years to the consolidation of the model, XVI Congreso Internacional AsHisCom
          * 2007-09-06, Nos Bastidores do Óbvio: A Capa de Newsmagazine como Dispositivo de Comunicação, V Congresso SOPCOM
          * 2007-09-06, Contributos para uma História da Newsmagazine, V Congresso SOPCOM
          * 2006, Capa de Newsmagazine: Dispositivo Comunicacional Padronizado?, II Seminário Internacional Media, Jornalismo e Democracia

        Conference abstract

          * 2018-10-31, Searching for the roots of constructive journalism on the covers of newsmagazines, ECREA 2018
          * 2018-07-25, Newspaper or magazine? The nature of newsmagazines, Mapping the Magazine 5
          * 2018-05-10, The classroom as lab: creating a newsmagazine from scratch, Trial and Error II
          * 2017-11-27, Revista: um objeto de estudo (quase) por desbravar | Magazine: an object of study (almost) to be discovered, X Congresso da SOPCOM
          * 2017-11-27, Jornal, revista ou 'jorvista'? A natureza única da newsmagazine | Newspaper, magazine or 'newszine'? The unique nature of the newsmagazine, X Congresso da SOPCOM
          * 2010-07-20, Female Representations on the Cover of Newsmagazines, IAMCR 2010

        Preface / Postscript

          * 2010, Leitura (Im)possível de uma Visita – Significados e o não-visível na visita de Bento XVI a Portugal - Revista de Ciência das Religiões – Colecção (Re)Pensar a Religião

        Video recording

          * 2018, Como imagina Lisboa no futuro? | How do you imagine Lisbon in the future?, Universidade Lusófona de Humanidades e Tecnologias, Museu de Lisboa
          * 2014-05-09, Ser igual na diferença, Universidade Lusófona de Humanidades e Tecnologias, Disponível em: https://www.youtube.com/watch?v=Xf8ZH91D6BE

        Other output

          * 2023-03-03, Revista Time faz hoje 100 anos | Time Magazine is 100 years old today, Participation in radio journalism piece - Antena 1 | RTP
          * 2022-05-03, Estudo das necessidades formativas dos jornalistas em Timor-Leste, Revisão Técnico-Científica (com Helena Garrido) do estudo elaborado por Carina Valério e Sandra Ferreira para o projeto Consultório da Língua para Jornalistas do Instituto Camões

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona