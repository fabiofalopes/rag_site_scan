# Response for https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656

    : https://www.ulusofona.pt/ : https://www.filmeu.eu/
        Cursos: https://www.ulusofona.pt/cursos Notícias: https://www.ulusofona.pt/noticias Investigação: https://investigacao.ulusofona.pt/pt/ Eventos: https://www.ulusofona.pt/eventos Candidaturas: https://www.ulusofona.pt/candidaturas
      : https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
          PT: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656 EN: https://www.ulusofona.pt/en/teachers/filipe-joel-nunes-soares-4656
          abrir menu fechar menu
        fechar : https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
        fechar menu : https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656

            Novos Cursos

            Os Nossos Cursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Informações Académicas

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes

            Recursos

                Licenciaturas: https://www.ulusofona.pt/licenciaturas
                Mestrados: https://www.ulusofona.pt/mestrados
                Doutoramentos: https://www.ulusofona.pt/doutoramentos
                Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              https://www.ulusofona.pt/logo/filmeu-big.png : https://www.filmeu.eu/
                * Página Inicial: https://www.ulusofona.pt/
                * eMail: http://email.ulusofona.pt/
                * NetPA: https://secretaria.virtual.ensinolusofona.pt
                * Moodle: https://moodle.ensinolusofona.pt/
                * Colibri: https://videoconf-colibri.zoom.us/account/
                * Avadoc: https://secure.ensinolusofona.pt/avadoc/
                * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
                * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
                * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                * Office 365: https://www.ulusofona.pt/servicos/office-365
                * Intranet: https://grupolusofona.sharepoint.com/sites/Click/

                Cursos

                  * Licenciaturas: https://www.ulusofona.pt/licenciaturas
                  * Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
                  * Mestrados: https://www.ulusofona.pt/mestrados
                  * Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
                  * Doutoramentos: https://www.ulusofona.pt/doutoramentos
                  * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
                  * Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
                  * Lusófona X - Academia Digital: https://lusofona-x.pt/

                A Universidade

                  * Calendários Académicos: https://www.ulusofona.pt/calendarios
                  * Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
                  * Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
                  * Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
                  * Propinas: https://www.ulusofona.pt/propinas
                  * Razões para Frequentar: https://razoes.ulusofona.pt/
                  * Qualidade: https://www.ulusofona.pt/qualidade
                  * Sobre Nós: https://www.ulusofona.pt/sobre
                  * Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
                  * Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna

                Instalações

                  * Campus: https://campus.ulusofona.pt/
                  * Contactos: https://www.ulusofona.pt/contactos
                  * Entidade Instituidora: https://www.cofac.pt
                  * Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
                  * Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/

                Colaboradores

                  * Avadoc: https://www.ulusofona.pt/avadoc
                  * Boas-Vindas: https://boasvindas.ulusofona.pt/
                  * Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
                  * Diretório: https://diretorio.ulusofona.pt/
                  * Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
                  * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
                  * Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
                  * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml

                Investigação

                  * Portal de Investigação: https://research.ulusofona.pt/
                  * ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
                  * Revistas Científicas: https://revistas.ulusofona.pt/
                  * Unidades de Investigação: https://investigacao.ulusofona.pt/

                Recursos

                  * Biblioteca: https://biblioteca.ulusofona.pt/
                  * Click - Portal de e-Learning: https://www.ulusofona.pt/click
                  * Documentos: https://www.ulusofona.pt/documentos
                  * FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
                  * Guia de Acolhimento: https://bemvindo.ulusofona.pt/
                  * Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
                  * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
                  * Regulamentos: https://www.ulusofona.pt/documentos?cat=1
                  * Reshape: https://secure.ensinolusofona.pt/reshape/
                  * Serviços Digitais: https://www.ulusofona.pt/servicos
                  * Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf

                Internacional

                  * Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
                  * Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
                  * FILMEU - Universidade Europeia: https://www.filmeu.eu/
                  * Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade

                Estudantes

                  * Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
                  * App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
                  * Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
                  * EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
                  * Estudantes: https://www.ulusofona.pt/estudantes
                  * Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
                  * Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
                  * Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
                  * Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
                  * Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens

                Ligação à Comunidade

                  * Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
                  * Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
                  * Criar Saberes: https://www.ulusofona.pt/criar-saberes
                  * Dias Abertos: https://www.ulusofona.pt/dias-abertos
                  * Escola Sénior: https://escolasenior.ulusofona.pt/
                  * Escola de Verão: https://escolaverao.ulusofona.pt/
                  * Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
                  * Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
                  * Lusófona Verde: https://www.ulusofona.pt/lusofona-verde

                Media e Eventos

                  * Crónicas: https://www.ulusofona.pt/cronicas
                  * Lessons: https://www.ulusofona.pt/lessons
                  * Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
                  * My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
                  * Notícias: https://www.ulusofona.pt/noticias
                  * Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * Cursos: https://www.ulusofona.pt/cursos
          * Notícias: https://www.ulusofona.pt/noticias
          * Investigação: https://investigacao.ulusofona.pt/pt/
          * Eventos: https://www.ulusofona.pt/eventos
          * Candidaturas: https://www.ulusofona.pt/candidaturas
          * Cursos: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Licenciaturas: https://www.ulusofona.pt/licenciaturas
              + Mestrados Integrados: https://www.ulusofona.pt/mestrados-integrados
              + Mestrados: https://www.ulusofona.pt/mestrados
              + Mestrados Erasmus Mundus: https://www.ulusofona.pt/erasmus-mundus
              + Doutoramentos: https://www.ulusofona.pt/doutoramentos
              + Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              + Formação ao Longo da Vida: https://www.ulusofona.pt/formacao
              + Lusófona X - Academia Digital: https://lusofona-x.pt/
          * A Universidade: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Calendários Académicos: https://www.ulusofona.pt/calendarios
              + Carreiras - Junte-se a Nós: https://www.ulusofona.pt/vagas
              + Faculdades e Escolas: https://www.ulusofona.pt/faculdades-e-escolas
              + Plano de Género e Diversidade: https://www.ensinolusofona.pt/pt/plano-de-genero-e-diversidade
              + Propinas: https://www.ulusofona.pt/propinas
              + Razões para Frequentar: https://razoes.ulusofona.pt/
              + Qualidade: https://www.ulusofona.pt/qualidade
              + Sobre Nós: https://www.ulusofona.pt/sobre
              + Faça-nos uma Visita: https://ulusofona.typeform.com/to/ypj6qk
              + Canal de Denúncia Interna: https://www.ulusofona.pt/canal-denuncia-interna
          * Instalações: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Campus: https://campus.ulusofona.pt/
              + Contactos: https://www.ulusofona.pt/contactos
              + Entidade Instituidora: https://www.cofac.pt
              + Lusófona no Mundo: https://www.ensinolusofona.pt/pt/
              + Lusófona 360º: https://vr360.ulusofona.pt/visitavirtual_PT/
          * Colaboradores: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Avadoc: https://www.ulusofona.pt/avadoc
              + Boas-Vindas: https://boasvindas.ulusofona.pt/
              + Carreira Docente: https://www.ulusofona.pt/documentos?q=Carreira+Docente
              + Diretório: https://diretorio.ulusofona.pt/
              + Emprego Científico: https://www.ulusofona.pt/vagas/emprego-cientifico-e-bolsas-de-investigacao
              + Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
              + Lusófona Mobile Docentes: https://www.ulusofona.pt/servicos/lusofona-mobile-docentes
              + Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Investigação: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Portal de Investigação: https://research.ulusofona.pt/
              + ReCiL - Repositório Científico: https://recil.ensinolusofona.pt/
              + Revistas Científicas: https://revistas.ulusofona.pt/
              + Unidades de Investigação: https://investigacao.ulusofona.pt/
          * Recursos: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Biblioteca: https://biblioteca.ulusofona.pt/
              + Click - Portal de e-Learning: https://www.ulusofona.pt/click
              + Documentos: https://www.ulusofona.pt/documentos
              + FAQ - Central de Ajuda: https://www.ulusofona.pt/faqs
              + Guia de Acolhimento: https://bemvindo.ulusofona.pt/
              + Logótipos e Identidade Gráfica: https://www.ulusofona.pt/documentos?cat=3
              + Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados
              + Regulamentos: https://www.ulusofona.pt/documentos?cat=1
              + Reshape: https://secure.ensinolusofona.pt/reshape/
              + Serviços Digitais: https://www.ulusofona.pt/servicos
              + Teses e Dissertações - Normas: https://www.ulusofona.pt/media/normas-para-elaboracao-e-apresentacao-de-dissertacoes-e-teses.pdf
          * Internacional: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Estudantes Brasileiros: https://www.ulusofona.pt/estudante-internacional/estudantes-brasileiros
              + Estudante Internacional: https://www.ulusofona.pt/estudante-internacional
              + FILMEU - Universidade Europeia: https://www.filmeu.eu/
              + Mobilidade de Estudantes: https://www.ulusofona.pt/mobilidade
          * Estudantes: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Agenda de Teses e Dissertações: https://www.ulusofona.pt/teses
              + App Ensino Lusófona: https://www.ulusofona.pt/servicos/app-ensino-lusofona
              + Cartão de Estudante: https://www.ulusofona.pt/noticias/cartao-estudante
              + EVA - Estágios e Vida Ativa: https://eva.ulusofona.pt/
              + Estudantes: https://www.ulusofona.pt/estudantes
              + Necessidades Ed. Especiais: https://www.ulusofona.pt/gaenee
              + Portal de Emprego: https://eva.ulusofona.pt/portal-de-emprego-universia/
              + Provedor do Estudante: https://www.ulusofona.pt/provedor-do-estudante
              + Serviço de Ação Social e bolsas: https://www.ulusofona.pt/acao-social-escolar
              + Vantagens e Benefícios: https://www.ensinolusofona.pt/pt/vantagens
          * Ligação à Comunidade: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Às Quartas na Lusófona: https://www.ulusofona.pt/evento/as-quartas-na-lusofona-23-24
              + Cinema Fernando Lopes: https://www.ulusofona.pt/cinema-fernando-lopes
              + Criar Saberes: https://www.ulusofona.pt/criar-saberes
              + Dias Abertos: https://www.ulusofona.pt/dias-abertos
              + Escola Sénior: https://escolasenior.ulusofona.pt/
              + Escola de Verão: https://escolaverao.ulusofona.pt/
              + Hospital Veterinário - Marcações: https://www.ulusofona.pt/noticias/marcacoes-hospital-veterinario-
              + Lusófona Talks: https://www.ulusofona.pt/lusofona-talks
              + Lusófona Verde: https://www.ulusofona.pt/lusofona-verde
          * Media e Eventos: https://www.ulusofona.pt/docentes/filipe-joel-nunes-soares-4656
              + Crónicas: https://www.ulusofona.pt/cronicas
              + Lessons: https://www.ulusofona.pt/lessons
              + Lusófona Nos Media: https://www.ulusofona.pt/lusofona-nos-media
              + My Story - Testemunhos: https://www.ulusofona.pt/testemunhos
              + Notícias: https://www.ulusofona.pt/noticias
              + Podcast - Direta Sem Café: https://www.ulusofona.pt/noticias/direta-sem-cafe-podcast-lusofona
          * eMail: http://email.ulusofona.pt/
          * NetPA: https://secretaria.virtual.ensinolusofona.pt
          * Moodle: https://moodle.ensinolusofona.pt/
          * Colibri: https://videoconf-colibri.zoom.us/account/
          * Avadoc: https://secure.ensinolusofona.pt/avadoc/
          * Portal do Colaborador: https://colaborador.ensinolusofona.pt/mygiaf/Login.xhtml
          * Kuadro (Reservar Sala): https://www.ulusofona.pt/noticias/espaco-kuadro
          * Ficha Docente: https://secure.ensinolusofona.pt/ficha_docente/f?p=123:LOGIN_DESKTOP::::::
          * Office 365: https://www.ulusofona.pt/servicos/office-365
          * Intranet: https://grupolusofona.sharepoint.com/sites/Click/
          Serviços
          WhatsApp - Porto : https://api.whatsapp.com/send?phone=351961135355 netpa : https://secure.ensinolusofona.pt/ulht/secretaria_virtual/page Wifi : https://www.ulusofona.pt/servicos/wifi Moodle : https://moodle.ensinolusofona.pt/ Alterar password : https://secure.ensinolusofona.pt/alteracao_password/f?p=133:1:::::: Colibri : https://videoconf-colibri.zoom.us/account/ Office 365 : https://www.ulusofona.pt/servicos/office-365 WhatsApp - Lisboa : https://api.whatsapp.com/send?phone=351963640100
      https://www.ulusofona.pt/assets/images/cinema-logo.png : https://www.ulusofona.pt/cinema-fernando-lopes

          Docente
          Filipe Joel Nunes Soares

          https://secure.ensinolusofona.pt/lsm/LusofonaMobileWebService_2_0/UserThumb?user_login=p4656
              fso***@ulp.pt
              FE1E-ECA0-632E: https://www.cienciavitae.pt/FE1E-ECA0-632E
              0000-0002-0750-5058: https://orcid.org/0000-0002-0750-5058
              Ver o Perfil completo no PURE: https://research.ulusofona.pt/en/persons/90543366-cf2d-4667-9030-ef1a2c43d72a
      : https://www.ulusofona.pt/

        Resume

        Filipe Joel Soares graduated in Physics at the Faculty of Sciences of the University of Porto in 2004 and a PhD in Sustainable Energy Systems, at the MIT | Portugal program, at the Faculty of Engineering at the University of Porto in 2012. He is currently Senior Researcher at INESC Porto (Institute of Systems and Computer Engineering of Porto) and Assistant Professor at Universidade Lusófona do Porto (ULP). Its research activity is related to the integration of renewable energy sources and electric vehicles in the distribution networks, as well as the implementation of load management and intelligent charging features. In these areas, he actively participated in several national and international projects, such as: GREEN ISLANDS - Power demand estimation and power system impacts resulting from fleet penetration of electric / plug-in vehicles (FCT); REIVE - Smart Grids with Electric Vehicles, (FCT and FAI); MERGE - Mobile Energy Resources in Grids of Electricity (FP7); STABALID - STAtionary BAtteries LI-ion safe Deployment (FP7); AnyPLACE - Adaptable Platform for Active Services Exchange (H2020). He is also the coordinator of the European project FEEdBACk - Fostering Energy Efficiency and BehAvioural Change through ICT (H2020) and author or co-author of more than 90 articles published in international journals and conferences with peer-review process.

        Graus

            * Licenciatura
              Physics
            * Pós-Graduação
              Electrical and Computer Engineering (Renewable Energies)
            * Doutoramento
              MIT|Portugal Progam - Sustainable Energy Systems

        Publicações

        Artigo em revista

          * 2023, The role of hydrogen electrolysers in frequency related ancillary services: A case study in the Iberian Peninsula up to 2040, SUSTAINABLE ENERGY GRIDS & NETWORKS
          * 2023, Real-time management of distributed multi-energy resources in multi-energy networks, SUSTAINABLE ENERGY GRIDS & NETWORKS
          * 2023, Comparison of network-(in)secure bidding strategies to coordinate distributed energy resources in distribution networks, Sustainable Energy, Grids and Networks
          * 2023, An energy-as-a-service business model for aggregators of prosumers, APPLIED ENERGY
          * 2022-06-14, Using Virtual Choreographies to Identify Office Users’ Behaviors to Target Behavior Change Based on Their Potential to Impact Energy Consumption, Energies
          * 2022, Network-secure bidding strategy for aggregators under uncertainty, SUSTAINABLE ENERGY GRIDS & NETWORKS
          * 2021-04-23, Real-World Implementation of an ICT-Based Platform to Promote Energy Efficiency, Energies
          * 2021-04, Forecasting Energy Technology Diffusion in Space and Time: Model Design, Parameter Choice and Calibration, IEEE Transactions on Sustainable Energy
          * 2021-03-10, FEEdBACk: An ICT-Based Platform to Increase Energy Efficiency through Buildings’ Consumer Engagement, Energies
          * 2021, Network-secure bidding optimization of aggregators of multi-energy systems in electricity, gas, and carbon markets, APPLIED ENERGY
          * 2020-09, A gamification platform to foster energy efficiency in office buildings, Energy and Buildings
          * 2020-05-28, Flexibility Assessment of Multi-Energy Residential and Commercial Buildings, Energies
          * 2020, Wind variability mitigation using multi-energy systems, INTERNATIONAL JOURNAL OF ELECTRICAL POWER & ENERGY SYSTEMS
          * 2020, Forecasting Energy Technology Diffusion in Space and Time: Model Design, Parameter Choice and Calibration, IEEE Transactions on Sustainable Energy
          * 2020, DER adopter analysis using spatial autocorrelation and information gain ratio under different census-data aggregation levels, IET RENEWABLE POWER GENERATION
          * 2020, An innovative approach for distribution network reinforcement planning: Using DER flexibility to minimize investment under uncertainty, ELECTRIC POWER SYSTEMS RESEARCH
          * 2019-05, Trading Small Prosumers Flexibility in the Energy and Tertiary Reserve Markets, IEEE Transactions on Smart Grid
          * 2019-03, A cluster-based optimization approach to support the participation of an aggregator of a larger number of prosumers in the day-ahead energy market, Electric Power Systems Research
          * 2019-02, Digital Audio Broadcasting (DAB)-based demand response for buildings, electric vehicles and prosumers (DAB-DSM), Energy Procedia
          * 2019, Spatiotemporal model for estimating electric vehicles adopters, ENERGY
          * 2019, Real-time provision of multiple electricity market products by an aggregator of prosumers, APPLIED ENERGY
          * 2019, Orchestrating incentive designs to reduce adverse system-level effects of large-scale EV/PV adoption - The case of Portugal, APPLIED ENERGY
          * 2019, Optimal bidding strategy for an aggregator of prosumers in energy and secondary reserve markets, APPLIED ENERGY
          * 2019, Distribution network planning considering technology diffusion dynamics and spatial net-load behavior, INTERNATIONAL JOURNAL OF ELECTRICAL POWER & ENERGY SYSTEMS
          * 2019, Development and Field Demonstration of a Gamified Residential Demand Management Platform Compatible with Smart Meters and Building Automation Systems, ENERGIES
          * 2018, Optimal supply and demand bidding strategy for an aggregator of small prosumers, APPLIED ENERGY
          * 2018, Electric Vehicles Charging Management and Control Strategies, IEEE VEHICULAR TECHNOLOGY MAGAZINE
          * 2018, Control Room Requirements for Voltage Control in Future Power Systems, ENERGIES
          * 2015, The STABALID project: Risk analysis of stationary Li-ion batteries for power system applications, RELIABILITY ENGINEERING & SYSTEM SAFETY
          * 2015, Exploiting autoencoders for three-phase state estimation in unbalanced distributions grids, ELECTRIC POWER SYSTEMS RESEARCH
          * 2015, Electric vehicles contribution for frequency control with inertial emulation, Electric Power Systems Research
          * 2015, Development and implementation of Portuguese smart distribution system, ELECTRIC POWER SYSTEMS RESEARCH
          * 2014, Quasi-real-time management of Electric Vehicles charging, ELECTRIC POWER SYSTEMS RESEARCH
          * 2013, Evaluation of the benefits of the introduction of electricity powered vehicles in an island, Energy Conversion and Management
          * 2012, Optimized bidding of a EV aggregation agent in the electricity market, IEEE Transactions on Smart Grid
          * 2012, Initial Findings of ‘MERGE’ (Mobile Energy Resources in Grids of Electricity) - A European Commission Funded Project Addressing the Impact of the Roll-Out of Electric and Plug-in Hybrid Vehicles on Grid Infrastructure -, International Journal of Automotive Engineering
          * 2011, Veículos elétricos: recursos móveis de energia
          * 2011, Integration of Electric Vehicles in the Electric Power System, PROCEEDINGS OF THE IEEE
          * 2010, Electric Vehicles in Isolated Power Systems: Conceptual Framework and Contributions to Improve the Grid Resilience, IFAC Proceedings Volumes

        Tese / Dissertação

          * 2012, Doutoramento, Impact of the Deployment of Electric Vehicles in Grid Operation and Expansion

        Livro

          * 2012, Integration of Electric Vehicles in Distribution Networks: Methodologies to Evaluate Impacts and Manage Electric Vehicles' Charging, Filipe Joel Soares

        Capítulo de livro

          * 2019, Explorative Spatial Data Mining for Energy Technology Adoption and Policy Design Analysis
          * 2016, Control and Management Architectures
          * 2016, Active Management of Electric Vehicles Acting as Distributed Storage
          * 2014, Impacts of Plug-in Electric Vehicles Integration in Distribution Networks Under Different Charging Strategies, Plug In Electric Vehicles in Smart Grids, Springer Singapore
          * 2013, Simulation of Electric Vehicles Motion Using a Stochastic Model: Assessment of Energy Requirements and Environmental Impacts, Grid Electrified Vehicles: Performance, Design and Environmental Impacts, Nova Science Publishers
          * 2013, Advanced models and simulation tools to address electric vehicle power system integration (steady-state and dynamic behavior)
          * 2012, State of the Art on Different Types of Electric Vehicles
          * 2012, Impacts of Large-Scale Deployment of Electric Vehicles in the Electric Power System

        Artigo em conferência

          * Using vehicle-to-grid to maximize the integration of intermittent renewable energy resources in islanded electric grids
          * Using Choreographies to support the gamification process on the development of an application to reduce electricity costs, Games and Learning Alliance 6th International Conference, GALA 2017
          * Synergies between electric vehicles and distributed renewable generation?
          * Smart charging strategies for electric vehicles: Enhancing grid performance and maximizing the use of variable renewable energy resources
          * Siting and Sizing of Energy Storage Systems to Maximize DG Integration in MV Distribution Networks
          * Primary Frequency Control in Future Power Systems The ELECTRA Project Approach under the Web-of-Cells Concept, IREP 2017
          * Online Algorithm to Coordinate Electric Vehicles' Charging with Renewable Power Generation, ISAP - Intelligent System Applications to Power Systems
          * On the Emerging Role of Spatial Load Forecasting in Transmission/Distribution Grid Planning
          * Mobile Energy Resources in Grids of Electricity: the EU MERGE Project
          * MERGE - A EUROPEAN COMMISSION FUNDED PROJECT ADDRESSING THE IMPACT OF THE ROLL-OUT OF ELECTRIC AND PLUG-IN HYBRID VEHICLES ON GRID INFRASTRUCTURE
          * Explorative ex-ante consumer cluster delineation for electrification planning using image processing tools
          * Exploiting the potential of electric vehicles to improve operating conditions in islanded grids, CIGRE 2011 Bologna Symposium - The Electric Power System of the Future: Integrating Supergrids and Microgrids
          * Evaluating the impacts of Electric Vehicles and Micro-Generation in Distribution Networks
          * Energy Requirements of Electric Vehicles and Related Environmental Impacts, Conference on Sustainable Development of Energy, Water and Environment Systems – SDEWES
          * Electric Vehicles Grid Integration Under the MicroGrid Concept
          * Distribution Network Planning Using Detailed Flexibility Models for DER
          * Building Automation Systems and Smart Meter Integrated Residential Customer Platform
          * Bottom-up approach to compute DER flexibility in the transmission-distribution networks boundary
          * Aggregated active and reactive power and energy management of distributed energy resources and performance evaluation
          * ASSESSMENT OF ENERGY REQUIREMENTS AND ENVIRONMENTAL IMPACTS OF ELECTRIC VEHICLES, Energy for Sustainability 2013
          * A Technical Management and Market Operation Framework for Electric Vehicles Integration into Electric Power Systems
          * 2023, TSO-DSO Coordinated Operational Planning in the Presence of Shared Resources $i,m,o,t$
          * 2023, Evaluation of the economic, technical, and environmental impacts of multi-energy system frameworks in distribution networks
          * 2023, Assessing the Membership of Portugal and Spain in the FCR Cooperation: TSO Costs and VPP Revenues
          * 2022, The Role of Hydrogen Electrolysers in the Frequency Containment Reserve: A Case Study in the Iberian Peninsula up to 2040
          * 2021, Simulating spatiotemporal energy technology adoption patterns under different policy designs
          * 2021, Impact of Electric Vehicles in Three-Phase Distribution Grids
          * 2021, A method for optimal integration of energy storage in distribution networks: A business case
          * 2020, Optimal Planning of Smart Home Technologies
          * 2019, Vertical Load Uncertainty at the T/D Boundary under different spatial der allocation techniques
          * 2019, Strategic Trade of Multi-Energy Aggregators with Local Multi-Energy Systems while Participating in Energy and Reserve Markets
          * 2019, Digital Audio Broadcasting (DAB) grid agents for ancillary services of the smart grid
          * 2019, Detailed Evaluation of Long-term Gamified Residential Demand Management System Field Implementation
          * 2018, Management of Inverter-based Distributed Energy Resources for Providing Voltage Regulation Support in Islanded Operation of Low Voltage Networks
          * 2018, Identification and comparison of power and energy management capabilities of distributed energy resources
          * 2017, Trading Small Prosumers Flexibility in the Day-ahead Energy Market
          * 2017, Stochastic Market Clearing Model with Probabilistic Participation of Wind and Electric Vehicles
          * 2017, Spatial Load Forecasting of Electric Vehicle Charging using GIS and Diffusion Theory
          * 2017, Mapping the Impact of Daytime and Overnight Electric Vehicle Charging on Distribution Grids
          * 2017, GReSBAS project: A gamified approach to promote more energy efficient behaviours in buildings
          * 2017, Electric Vehicles in Automatic Generation Control for Systems with Large Integration of Renewables
          * 2017, Assessing the Impact of Demand Flexibility on Distribution Network Operation
          * 2017, Assessing the Adaption of Stochastic Clearing Procedure to a Hydro-penetrated Market
          * 2017, Analysis of Consumer Expectations, Preferences and Concerns on Deployment of Demand Response in Turkey
          * 2017, A novel incentive-based retail demand response program for collaborative participation of small customers
          * 2016, Impact of PV for Self-consumption in the Day-ahead Spot Prices
          * 2015, Optimized Demand Response Bidding in the Wholesale Market under Scenarios of Prices and Temperatures
          * 2014, State Estimation in Distribution Smart Grids Using Autoencoders
          * 2014, Probabilistic Analysis of Stationary Batteries Performance to Deal with Renewable Variability
          * 2014, Framework for the Participation of EV Aggregators in the Electricity Market
          * 2014, Electric Vehicles Charging Management and Control Strategies
          * 2014, Development of a Novel Management System for Electric Vehicle Charging
          * 2014, Availability of Household loads to Participate in Demand Response
          * 2014, Advanced models and algorithms for demand participation in electricity markets
          * 2013, Controlling Electric Vehicles in Quasi-Real-Time
          * 2011, Inertial control in off-shore wind farms connected to AC networks through multi-terminal HVDC grids with VSC
          * 2011, A stochastic model to simulate electric vehicles motion and quantify the energy required from the grid
          * 2010, Grid interactive charging control for plug-in electric vehicles
          * 2010, Automatic Generation Control operation with electric vehicles
          * 2010, Advanced Metering Infrastructure functionalities for electric mobility
          * 2009, Quantification of technical impacts and environmental benefits of electric vehicles integration on electricity grids
          * 2009, Identifying Management Procedures to Deal with Connection of Electric Vehicles in the Grid, 2009 IEEE Bucharest PowerTech

        Outra produção

          * 2018, Optimal supply and demand bidding strategy for an aggregator of small prosumers (vol 213, pg 658, 2018)

              Email

                Link Direto

        Política de Cookies
          Este website utiliza cookies para lhe proporcionar uma melhor experiência de navegação.
            Rejeitar
            Escolher >
            Permitir Todos
              Necessários
            Cookies necessários para o funcionamento do website.
              Analíticos
            Cookies de análise e comportamento do website.
              Marketing
            Cookies de tracking para o propósito de anúncios.
            Rejeitar
            Permitir Selecionados
            Permitir Todos

          Newsletter

            Subscrição com sucesso. Não foi possível adicionar o email à lista da newsletter.

      Subscreva a Newsletter

      Concordo com a política de privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade/ em vigor Subscrever
            * Facebook Porto: https://www.facebook.com/ulporto Lisboa: https://www.facebook.com/u.lusofona
            * X (Twitter) Porto: https://twitter.com/ulusofonaporto Lisboa: https://twitter.com/ulusofona
            * Threads Porto: https://www.threads.net/@ulporto Lisboa: https://www.threads.net/@ulusofona
          * Youtube : https://www.youtube.com/@UniversidadeLusofonaVideos
            * Instagram Porto: https://www.instagram.com/ulporto/ Lisboa: https://www.instagram.com/ulusofona/
            * Linkedin Porto: https://www.linkedin.com/school/universidade-lusofona-do-porto Lisboa: https://www.linkedin.com/school/universidade-lusofona-de-humanidades-e-tecnologias/

            Serviços

              * Contactos: https://www.ulusofona.pt/contactos
              * Alteração e Recuperação de Password: https://secure.ensinolusofona.pt/alteracao_password/f?p=133:2
              * Ajude-nos a Melhorar: https://ulusofona.typeform.com/to/cipp2UFI
              * Perdidos e Achados: https://www.ulusofona.pt/perdidos-e-achados

            Ensino

              * Licenciaturas: https://www.ulusofona.pt/licenciaturas
              * Mestrados: https://www.ulusofona.pt/mestrados
              * Doutoramentos: https://www.ulusofona.pt/doutoramentos
              * Pós-Graduações: https://www.ulusofona.pt/pos-graduacoes
              * Todos os Cursos: https://www.ulusofona.pt/cursos

            Documentos

              * Propinas e Emolumentos: https://www.ulusofona.pt/documentos?cat=5
              * Regulamentos e Despachos: https://www.ulusofona.pt/documentos?cat=1
              * Formulários: https://www.ulusofona.pt/documentos?cat=13
              * Relatórios: https://www.ulusofona.pt/documentos?cat=4
              * Validação de documentos: https://www.ulusofona.pt/validador-de-documentos
            Lisboa
            Campo Grande, 376
            1749-024 Lisboa, Portugal
            Tel.: 217 515 500: tel:217515500 | email: info.cul@ulusofona.pt: mailto:info.cul@ulusofona.pt
            WhatsApp: +351 963 640 100: https://api.whatsapp.com/send?phone=351963640100
            Porto
            Rua Augusto Rosa, nº 24
            4000-098 Porto - Portugal
            Tel.: 222 073 230: tel:222073230 | email: info.cup@ulusofona.pt: mailto:info.cup@ulusofona.pt
            WhatsApp: +351 961 135 355: https://api.whatsapp.com/send?phone=351961135355
                2024 © COFAC | Política de Privacidade: https://www.ensinolusofona.pt/pt/politica-de-privacidade
            https://www.ulusofona.pt/media/lisboa-2020.jpg https://www.ulusofona.pt/media/portugal-2020-small.jpg https://www.ulusofona.pt/media/financiado-eu-2024.png https://www.ulusofona.pt/media/prr-2024.png : https://recuperarportugal.gov.pt/ https://www.ulusofona.pt/media/republica-portuguesa-2024.png https://www.ulusofona.pt/media/logo-ue-financed.jpg https://www.ulusofona.pt/media/provedor-do-estudante.png : https://ulusofona.typeform.com/to/MTP9d7?typeform-source=www.ulusofona.pt https://www.ulusofona.pt/media/livro-de-reclamaoes.png : https://www.livroreclamacoes.pt/inicio https://www.ulusofona.pt/media/elogios.png : https://elogiar.livrodeelogios.com/elogiar/universidade-lusofona